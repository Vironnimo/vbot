import importlib.util
import subprocess
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).resolve().parents[2]
MODULE_PATH = PROJECT_ROOT / "scripts" / "quality-frontend.py"


def _load_quality_frontend_module():
    spec = importlib.util.spec_from_file_location("quality_frontend", MODULE_PATH)
    if spec is None or spec.loader is None:
        raise AssertionError(f"Unable to load module from {MODULE_PATH}")

    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


GUARD_NOTE_PREFIX = "repo-wide guard tests added: "


def _with_guards(module, targets: list[str]) -> list[str]:
    """Return *targets* followed by every repo-wide guard test, as source scopes select."""
    return [*targets, *module._guard_test_targets()]


def test_parse_vitest_counts_strips_ansi_color_codes():
    module = _load_quality_frontend_module()
    output = (
        "\x1b[1m\x1b[30m\x1b[46m RUN \x1b[49m\x1b[39m\x1b[22m\n"
        "\n"
        " \x1b[32m✓\x1b[39m src/components/__tests__/AgentsView.test.persistence.test.js\n"
        "\n"
        " Test Files  \x1b[32m1 passed\x1b[39m (1)\n"
        "      Tests  \x1b[32m16 passed\x1b[39m (16)\n"
        "   Start at  22:02:18\n"
    )

    assert module.parse_vitest_counts(output) == (16, 16)


def test_parse_vitest_counts_returns_zero_without_summary_line():
    module = _load_quality_frontend_module()

    assert module.parse_vitest_counts("\x1b[32m✓\x1b[39m test output without summary") == (0, 0)


def test_translate_to_vitest_targets_keeps_explicit_test_file():
    module = _load_quality_frontend_module()

    targets, notes = module.translate_to_vitest_targets(
        ["src/components/__tests__/SettingsView.test.behavior.test.js"]
    )

    assert targets == ["src/components/__tests__/SettingsView.test.behavior.test.js"]
    assert notes == []


def test_translate_to_vitest_targets_resolves_named_mirror_test():
    module = _load_quality_frontend_module()

    # A component whose mirror was split resolves to every owned suite.
    targets, notes = module.translate_to_vitest_targets(["src/components/SettingsView.svelte"])

    assert targets == _with_guards(
        module,
        [
            "src/components/__tests__/SettingsView.test.appearance.test.js",
            "src/components/__tests__/SettingsView.test.behavior.test.js",
            "src/components/__tests__/SettingsView.test.channels.test.js",
            "src/components/__tests__/SettingsView.test.provider-refresh.test.js",
            "src/components/__tests__/SettingsView.test.providers.test.js",
            "src/components/__tests__/SettingsView.test.specialized-models.test.js",
            "src/components/__tests__/SettingsView.test.subagents-and-voice.test.js",
        ],
    )
    assert len(notes) == 1
    assert notes[0].startswith(GUARD_NOTE_PREFIX)


def test_translate_to_vitest_targets_resolves_split_lib_mirror_tests():
    module = _load_quality_frontend_module()

    targets, notes = module.translate_to_vitest_targets(["src/lib/settingsView.js"])

    assert targets == _with_guards(
        module,
        [
            "src/lib/__tests__/settingsView.test.integration.test.js",
            "src/lib/__tests__/settingsView.test.normalization.test.js",
            "src/lib/__tests__/settingsView.test.providers.test.js",
        ],
    )
    assert [note.startswith(GUARD_NOTE_PREFIX) for note in notes] == [True]


def test_translate_to_vitest_targets_finds_test_one_level_up():
    module = _load_quality_frontend_module()

    # The settings panels keep their tests in the parent components/__tests__ dir,
    # not a co-located one — the resolver must climb to find the named mirror.
    targets, notes = module.translate_to_vitest_targets(
        ["src/components/settings/SettingsProvidersPanel.svelte"]
    )

    assert targets == _with_guards(
        module, ["src/components/__tests__/SettingsProvidersPanel.test.js"]
    )
    assert [note.startswith(GUARD_NOTE_PREFIX) for note in notes] == [True]


def test_translate_to_vitest_targets_maps_testless_dir_to_ancestor():
    module = _load_quality_frontend_module()

    # src/components/settings has no __tests__ of its own; its tests live one
    # level up, so scoping the directory runs the component suite and notes why.
    targets, notes = module.translate_to_vitest_targets(["src/components/settings"])

    assert targets == _with_guards(module, ["src/components"])
    assert len(notes) == 2
    assert "src/components/settings" in notes[0]
    assert "src/components" in notes[0]
    assert notes[1].startswith(GUARD_NOTE_PREFIX)


def test_translate_to_vitest_targets_falls_back_for_untested_source_file():
    module = _load_quality_frontend_module()

    # A subcomponent with no same-named test (exercised through AgentsView) falls
    # back to the nearest ancestor dir that holds tests, with a note.
    targets, notes = module.translate_to_vitest_targets(
        ["src/components/agents/AgentEditor.svelte"]
    )

    assert targets == _with_guards(module, ["src/components"])
    assert len(notes) == 2
    assert "src/components/agents/AgentEditor.svelte" in notes[0]
    assert notes[1].startswith(GUARD_NOTE_PREFIX)


def test_translate_to_vitest_targets_keeps_dir_with_colocated_tests():
    module = _load_quality_frontend_module()

    targets, notes = module.translate_to_vitest_targets(["src/lib"])

    # src/lib already contains the guard tests, so none is added twice.
    assert targets == ["src/lib"]
    assert notes == []


def test_guard_test_targets_discover_repo_wide_guards():
    module = _load_quality_frontend_module()

    guards = module._guard_test_targets()

    assert {
        "src/lib/__tests__/i18nPlaceholders.guard.test.js",
        "src/lib/__tests__/rpcOwnership.guard.test.js",
        "src/lib/__tests__/uiPrimitives.guard.test.js",
    } <= set(guards)
    assert all("/__tests__/" in guard and ".guard.test." in guard for guard in guards)


def test_translate_to_vitest_targets_skips_guards_for_test_only_or_outside_inputs():
    module = _load_quality_frontend_module()

    targets, notes = module.translate_to_vitest_targets(
        ["src/components/__tests__/SettingsProvidersPanel.test.js", "package.json"]
    )

    # Neither an explicit test nor a file outside src/ can break a guard scan.
    assert targets == ["src/components/__tests__/SettingsProvidersPanel.test.js"]
    assert not any(note.startswith(GUARD_NOTE_PREFIX) for note in notes)


def test_translate_to_vitest_targets_adds_only_guards_not_already_covered(tmp_path, monkeypatch):
    module = _load_quality_frontend_module()
    webui = tmp_path / "webui"
    for guard in ("src/lib/__tests__/a.guard.test.js", "src/app/__tests__/b.guard.test.js"):
        (webui / guard).parent.mkdir(parents=True, exist_ok=True)
        (webui / guard).write_text("test('guard', () => {})", encoding="utf-8")
    (webui / "src" / "app" / "view.js").write_text("export {}", encoding="utf-8")
    monkeypatch.setattr(module, "WEBUI_ROOT", webui)
    monkeypatch.setattr(module, "SRC_ROOT", webui / "src")

    targets, notes = module.translate_to_vitest_targets(["src/app"])

    assert targets == ["src/app", "src/lib/__tests__/a.guard.test.js"]
    assert notes == [f"{GUARD_NOTE_PREFIX}src/lib/__tests__/a.guard.test.js"]


def test_translate_to_eslint_targets_drops_inputs_without_lintable_files():
    module = _load_quality_frontend_module()

    lint_paths, notes = module.translate_to_eslint_targets(
        ["src/styles", "src/styles/app.css", "src/lib", "src/lib/i18n.js"]
    )

    assert lint_paths == ["src/lib", "src/lib/i18n.js"]
    assert len(notes) == 2
    assert notes[0].startswith("src/styles:")
    assert notes[1].startswith("src/styles/app.css:")


def test_translate_to_eslint_targets_ignores_dependency_and_build_folders(tmp_path, monkeypatch):
    module = _load_quality_frontend_module()
    webui = tmp_path / "webui"
    (webui / "src" / "assets" / "node_modules" / "pkg").mkdir(parents=True)
    (webui / "src" / "assets" / "node_modules" / "pkg" / "index.js").write_text("", "utf-8")
    (webui / "src" / "assets" / "logo.svg").write_text("<svg/>", encoding="utf-8")
    monkeypatch.setattr(module, "WEBUI_ROOT", webui)

    lint_paths, notes = module.translate_to_eslint_targets(["src/assets"])

    assert lint_paths == []
    assert len(notes) == 1


def _run_main_capturing(module, monkeypatch, argv):
    commands: list[list[str]] = []
    monkeypatch.setattr(module.shutil, "which", lambda name: name)
    monkeypatch.setattr(module.sys, "argv", ["quality-frontend.py", *argv])
    monkeypatch.setattr(module, "snapshot_target_files", lambda *args: {})

    def fake_run(cmd, capture_output, text, cwd, encoding, errors):
        commands.append(cmd)
        stdout = "Tests  1 passed (1)\n" if cmd[1] == "vitest" else ""
        return module.subprocess.CompletedProcess(cmd, 0, stdout=stdout, stderr="")

    monkeypatch.setattr(module.subprocess, "run", fake_run)
    return commands


@pytest.mark.parametrize("check", [False, True])
def test_main_skips_eslint_when_scope_has_nothing_lintable(monkeypatch, capsys, check):
    module = _load_quality_frontend_module()
    argv = ["--check", "webui/src/styles"] if check else ["webui/src/styles"]
    commands = _run_main_capturing(module, monkeypatch, argv)

    assert module.main() == 0

    output = capsys.readouterr().out
    assert not any(cmd[1] == "eslint" for cmd in commands)
    eslint_lines = [line for line in output.splitlines() if line.startswith("eslint")]
    assert len(eslint_lines) == (1 if check else 2)
    assert all("NO FILES" in line and "PASS" not in line for line in eslint_lines)
    assert "note: src/styles: no ESLint-lintable files" in output
    assert ["npx", "prettier", "--check" if check else "--write", "src/styles"] in commands


def test_main_lints_only_lintable_scope_inputs(monkeypatch, capsys):
    module = _load_quality_frontend_module()
    commands = _run_main_capturing(
        module, monkeypatch, ["--check", "webui/src/styles", "webui/src/lib/i18n.js"]
    )

    assert module.main() == 0

    output = capsys.readouterr().out
    assert ["npx", "eslint", "src/lib/i18n.js"] in commands
    assert ["npx", "prettier", "--check", "src/styles", "src/lib/i18n.js"] in commands
    assert "eslint        .... PASS" in output
    assert "note: src/styles: no ESLint-lintable files" in output


def test_translate_to_vitest_targets_notes_file_without_any_tests():
    module = _load_quality_frontend_module()

    # A webui file outside src has no tests: no vitest arg, just a note — so the
    # runner reports "no tests" honestly instead of running the whole suite.
    targets, notes = module.translate_to_vitest_targets(["package.json"])

    assert targets == []
    assert len(notes) == 1
    assert "package.json" in notes[0]


def test_translate_to_vitest_targets_maps_extension_page_sources_to_build_test():
    module = _load_quality_frontend_module()

    targets, notes = module.translate_to_vitest_targets(
        ["../tests/fixtures/extension-pages/alpha/ui/page.js"]
    )

    assert targets == ["scripts/__tests__/build-extension-pages.test.js"]
    assert notes == []


def test_translate_to_vitest_targets_maps_bundled_extension_page_sources_to_build_test():
    module = _load_quality_frontend_module()

    targets, notes = module.translate_to_vitest_targets(
        ["../resources/extensions/example/ui/Page.svelte"]
    )

    # uiPrimitives also scans bundled Extension UI, so page sources run the guards.
    assert targets == _with_guards(module, ["scripts/__tests__/build-extension-pages.test.js"])
    assert [note.startswith(GUARD_NOTE_PREFIX) for note in notes] == [True]


def test_translate_to_vitest_targets_includes_a_page_rendered_test_before_build_smoke(
    tmp_path, monkeypatch
):
    module = _load_quality_frontend_module()
    ui = tmp_path / "resources" / "extensions" / "alpha" / "ui"
    tests = ui / "__tests__"
    tests.mkdir(parents=True)
    source = ui / "SwarmPage.svelte"
    source.write_text("<main />", encoding="utf-8")
    rendered = tests / "SwarmPage.test.js"
    rendered.write_text("test('rendered', () => {})", encoding="utf-8")
    monkeypatch.setattr(module, "PROJECT_ROOT", tmp_path)
    monkeypatch.setattr(module, "WEBUI_ROOT", tmp_path / "webui")
    monkeypatch.setattr(module, "EXTENSION_UI_ROOT", tmp_path / "resources" / "extensions")

    targets, notes = module.translate_to_vitest_targets(
        ["../resources/extensions/alpha/ui/SwarmPage.svelte"]
    )

    assert targets == [
        "../resources/extensions/alpha/ui/__tests__/SwarmPage.test.js",
        "scripts/__tests__/build-extension-pages.test.js",
    ]
    assert notes == []


def test_extension_page_source_excludes_owner_python_and_generated_web(tmp_path, monkeypatch):
    module = _load_quality_frontend_module()
    root = tmp_path / "resources" / "extensions"
    (root / "alpha" / "ui").mkdir(parents=True)
    monkeypatch.setattr(module, "EXTENSION_UI_ROOT", root)

    assert module._is_extension_page_source(root / "alpha" / "ui" / "Page.svelte")
    assert not module._is_extension_page_source(root / "alpha" / "extension.py")
    assert not module._is_extension_page_source(root / "alpha" / "web" / "page.html")


def test_main_accepts_extension_page_source_outside_webui(monkeypatch, capsys):
    module = _load_quality_frontend_module()
    commands: list[list[str]] = []
    monkeypatch.setattr(module.shutil, "which", lambda name: name)
    monkeypatch.setattr(
        module.sys,
        "argv",
        ["quality-frontend.py", "tests/fixtures/extension-pages/alpha/ui"],
    )

    def fake_run(cmd, capture_output, text, cwd, encoding, errors):
        commands.append(cmd)
        stdout = "Tests  1 passed (1)\n" if cmd[1] == "vitest" else ""
        return module.subprocess.CompletedProcess(cmd, 0, stdout=stdout, stderr="")

    monkeypatch.setattr(module.subprocess, "run", fake_run)

    assert module.main() == 0
    capsys.readouterr()
    expected_source = "../tests/fixtures/extension-pages/alpha/ui"
    assert [
        "npx",
        "prettier",
        "--config",
        "prettier.config.js",
        "--plugin",
        "prettier-plugin-svelte",
        "--write",
        expected_source,
    ] in commands
    assert [
        "npx",
        "eslint",
        "--config",
        "webui/eslint.config.js",
        "tests/fixtures/extension-pages/alpha/ui",
    ] in commands
    vitest = next(command for command in commands if command[1] == "vitest")
    assert vitest[5:] == ["scripts/__tests__/build-extension-pages.test.js"]


def test_filter_vitest_failure_output_removes_pass_noise():
    module = _load_quality_frontend_module()
    output = (
        "\x1b[1m\x1b[46m RUN \x1b[49m\x1b[22m v4.1.5 C:/Development/projects/vBot/webui\n"
        "\n"
        " \x1b[32m✓\x1b[39m "
        "src/components/__tests__/SettingsView.test.behavior.test.js (2 tests) 30ms\n"
        "   \x1b[32m✓\x1b[39m SettingsView (2)\n"
        "     \x1b[32m✓\x1b[39m saves automatically\n"
        "     \x1b[31m×\x1b[39m keeps dirty state on error 15ms\n"
        "\n"
        "\x1b[31mFAIL\x1b[39m src/components/__tests__/SettingsView.test.behavior.test.js > "
        "SettingsView > keeps dirty state on error\n"
        "AssertionError: expected false to be true\n"
        "\n"
        " Test Files  1 failed | 1 passed (2)\n"
        "      Tests  1 failed | 3 passed (4)\n"
        "   Duration  1.20s\n"
    )

    filtered = module.filter_vitest_failure_output(output)

    assert "RUN  v4.1.5" not in filtered
    assert "saves automatically" not in filtered
    assert (
        "FAIL src/components/__tests__/SettingsView.test.behavior.test.js > "
        "SettingsView > keeps dirty state on error" in filtered
    )
    assert "AssertionError: expected false to be true" in filtered
    assert "Tests  1 failed | 3 passed (4)" in filtered


def test_main_runs_vitest_with_default_reporter(monkeypatch, capsys):
    module = _load_quality_frontend_module()
    commands: list[list[str]] = []

    monkeypatch.setattr(module.shutil, "which", lambda name: name)
    monkeypatch.setattr(
        module.sys,
        "argv",
        ["quality-frontend.py", "webui/src/components/AgentsView.svelte"],
    )

    def fake_run(cmd, capture_output, text, cwd, encoding, errors):
        commands.append(cmd)
        if cmd[1] == "vitest":
            return module.subprocess.CompletedProcess(
                cmd, 0, stdout="Tests  1 passed (1)\n", stderr=""
            )
        return module.subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setattr(module.subprocess, "run", fake_run)

    assert module.main() == 0

    output = capsys.readouterr().out
    assert f"note: {GUARD_NOTE_PREFIX}" in output
    vitest_command = next(cmd for cmd in commands if cmd[1] == "vitest")
    assert vitest_command[:5] == [
        "npx",
        "vitest",
        "run",
        "--reporter=default",
        "--passWithNoTests",
    ]
    assert vitest_command[5:] == _with_guards(
        module,
        [
            "src/components/__tests__/AgentsView.test.creation-and-layout.test.js",
            "src/components/__tests__/AgentsView.test.identity-and-access.test.js",
            "src/components/__tests__/AgentsView.test.models-and-catalog.test.js",
            "src/components/__tests__/AgentsView.test.persistence.test.js",
        ],
    )


def test_help_exits_successfully_without_frontend_prerequisites(monkeypatch):
    module = _load_quality_frontend_module()
    monkeypatch.setattr(module.sys, "argv", ["quality-frontend.py", "--help"])

    def fail_which(*args, **kwargs):
        raise AssertionError("help must not require frontend tools")

    monkeypatch.setattr(module.shutil, "which", fail_which)

    with pytest.raises(SystemExit) as exit_info:
        module.main()

    assert exit_info.value.code == 0


def test_check_mode_validates_without_fix_commands(monkeypatch, capsys):
    module = _load_quality_frontend_module()
    commands: list[list[str]] = []
    monkeypatch.setattr(module.shutil, "which", lambda name: name)
    monkeypatch.setattr(
        module.sys,
        "argv",
        ["quality-frontend.py", "--check", "webui/src/components/AgentsView.svelte"],
    )

    def fail_snapshot(*args, **kwargs):
        raise AssertionError("check mode must not snapshot for source mutations")

    def fake_run(cmd, capture_output, text, cwd, encoding, errors):
        commands.append(cmd)
        returncode = 1 if cmd[1:3] == ["prettier", "--check"] else 0
        stdout = "Tests  1 passed (1)\n" if cmd[1] == "vitest" else ""
        return module.subprocess.CompletedProcess(cmd, returncode, stdout=stdout, stderr="")

    monkeypatch.setattr(module, "snapshot_target_files", fail_snapshot)
    monkeypatch.setattr(module.subprocess, "run", fake_run)

    assert module.main() == 1

    captured = capsys.readouterr()
    assert "prettier      .... FAIL" in captured.out
    assert ["npx", "prettier", "--check", "src/components/AgentsView.svelte"] in commands
    assert not any("--write" in command or "--fix" in command for command in commands)


def test_main_reports_no_tests_instead_of_pass(monkeypatch, capsys):
    module = _load_quality_frontend_module()
    monkeypatch.setattr(module.shutil, "which", lambda name: name)
    monkeypatch.setattr(
        module.sys,
        "argv",
        [
            "quality-frontend.py",
            "webui/src/components/__tests__/AgentsView.test.persistence.test.js",
        ],
    )

    def fake_run(cmd, capture_output, text, cwd, encoding, errors):
        if cmd[1] == "vitest":
            # vitest ran but collected nothing (no summary count line).
            return module.subprocess.CompletedProcess(
                cmd, 0, stdout="No test files found\n", stderr=""
            )
        return module.subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setattr(module.subprocess, "run", fake_run)

    assert module.main() == 0

    captured = capsys.readouterr()
    vitest_line = next(line for line in captured.out.splitlines() if line.startswith("vitest"))
    assert "NO TESTS" in vitest_line
    assert "PASS" not in vitest_line
    # The auto-fix steps changed nothing, so they report the action, not a pass.
    assert "NO CHANGES" in captured.out


def test_main_reports_no_tests_when_scope_maps_to_none(monkeypatch, capsys):
    module = _load_quality_frontend_module()
    monkeypatch.setattr(module.shutil, "which", lambda name: name)
    # A webui file with no tests must not fall through to a full-suite vitest run.
    monkeypatch.setattr(module.sys, "argv", ["quality-frontend.py", "webui/package.json"])

    commands: list[list[str]] = []

    def fake_run(cmd, capture_output, text, cwd, encoding, errors):
        commands.append(cmd)
        return module.subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setattr(module.subprocess, "run", fake_run)

    assert module.main() == 0

    captured = capsys.readouterr()
    assert "NO TESTS" in captured.out
    assert "note: package.json" in captured.out
    assert not any(cmd[1] == "vitest" for cmd in commands)


def test_main_filters_vitest_failure_output(monkeypatch, capsys):
    module = _load_quality_frontend_module()
    vitest_output = (
        "\x1b[1m\x1b[46m RUN \x1b[49m\x1b[22m v4.1.5 C:/Development/projects/vBot/webui\n"
        " \x1b[32m✓\x1b[39m "
        "src/components/__tests__/SettingsView.test.behavior.test.js (2 tests) 30ms\n"
        "   \x1b[32m✓\x1b[39m SettingsView (2)\n"
        "     \x1b[32m✓\x1b[39m saves automatically\n"
        "     \x1b[31m×\x1b[39m keeps dirty state on error 15ms\n"
        "\n"
        "\x1b[31mFAIL\x1b[39m src/components/__tests__/SettingsView.test.behavior.test.js > "
        "SettingsView > keeps dirty state on error\n"
        "AssertionError: expected false to be true\n"
        "\n"
        " Test Files  1 failed | 1 passed (2)\n"
        "      Tests  1 failed | 3 passed (4)\n"
    )

    monkeypatch.setattr(module.shutil, "which", lambda name: name)
    monkeypatch.setattr(
        module.sys, "argv", ["quality-frontend.py", "webui/src/components/AgentsView.svelte"]
    )

    def fake_run(cmd, capture_output, text, cwd, encoding, errors):
        if cmd[1] == "vitest":
            return module.subprocess.CompletedProcess(cmd, 1, stdout=vitest_output, stderr="")
        return module.subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setattr(module.subprocess, "run", fake_run)

    assert module.main() == 1

    captured = capsys.readouterr()
    assert "--- vitest ---" in captured.out
    assert "saves automatically" not in captured.out
    assert (
        "FAIL src/components/__tests__/SettingsView.test.behavior.test.js > "
        "SettingsView > keeps dirty state on error" in captured.out
    )


def test_parse_vitest_counts_handles_skipped_segment():
    module = _load_quality_frontend_module()
    output = " Test Files  2 passed (2)\n      Tests  1 skipped | 4 passed (5)\n"

    assert module.parse_vitest_counts(output) == (4, 5)


def test_main_rejects_unknown_input_path(monkeypatch, capsys):
    module = _load_quality_frontend_module()
    monkeypatch.setattr(module.shutil, "which", lambda name: name)
    monkeypatch.setattr(
        module.sys, "argv", ["quality-frontend.py", "webui/src/components/Missing.svelte"]
    )

    def fail_run(*args, **kwargs):
        raise AssertionError("no tool may run for unknown input paths")

    monkeypatch.setattr(module.subprocess, "run", fail_run)

    assert module.main() == 2

    captured = capsys.readouterr()
    assert "src/components/Missing.svelte" in captured.out


def _full_scan_run_factory(build_returncode, build_stdout, build_stderr):
    """Return a fake ``subprocess.run`` for a full-scan gate run.

    Every step passes except the build, which is given the supplied result so a
    test can exercise a clean build, a warning-emitting build, or a failing one.
    """

    def fake_run(cmd, capture_output, text, cwd, encoding, errors):
        if cmd[:3] == ["npm", "run", "build"]:
            return subprocess.CompletedProcess(
                cmd, build_returncode, stdout=build_stdout, stderr=build_stderr
            )
        if cmd[1] == "vitest":
            return subprocess.CompletedProcess(cmd, 0, stdout="Tests  1 passed (1)\n", stderr="")
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    return fake_run


@pytest.mark.parametrize("check", [False, True])
@pytest.mark.parametrize("scoped", [False, True])
@pytest.mark.parametrize("build", [False, True])
def test_build_selection_preserves_scope_and_fix_mode(monkeypatch, check, scoped, build):
    module = _load_quality_frontend_module()
    commands: list[list[str]] = []
    monkeypatch.setattr(module.shutil, "which", lambda name: name)
    argv = ["quality-frontend.py"]
    if check:
        argv.append("--check")
    if build:
        argv.append("--build")
    if scoped:
        argv.append("webui/src/lib/settingsView.js")
    monkeypatch.setattr(module.sys, "argv", argv)
    monkeypatch.setattr(module, "snapshot_target_files", lambda *args: {})

    def fake_run(cmd, **kwargs):
        assert kwargs["cwd"] == (
            module.PROJECT_ROOT if not scoped and cmd[1] == "eslint" else module.WEBUI_ROOT
        )
        commands.append(cmd)
        return subprocess.CompletedProcess(cmd, 0, stdout="Tests  1 passed (1)\n", stderr="")

    monkeypatch.setattr(module.subprocess, "run", fake_run)

    assert module.main() == 0
    assert commands.count(["npm", "run", "build"]) == int(build or not scoped)
    if build or not scoped:
        assert commands[-1] == ["npm", "run", "build"]
    assert any("--fix" in cmd for cmd in commands) is not check
    assert any("--write" in cmd for cmd in commands) is not check
    lint = next(cmd for cmd in commands if cmd[1] == "eslint" and "--fix" not in cmd)
    if scoped:
        assert lint[2:] == ["src/lib/settingsView.js"]
    else:
        expected_scope = ["src/", "scripts/", *module._extension_page_ui_paths()]
        expected_lint = [
            (module.WEBUI_ROOT / path).resolve().relative_to(module.PROJECT_ROOT).as_posix()
            for path in expected_scope
        ]
        assert lint[2:] == ["--config", "webui/eslint.config.js", *expected_lint]
    vitest = next(cmd for cmd in commands if cmd[1] == "vitest")
    assert vitest[5:] == (
        _with_guards(
            module,
            [
                "src/lib/__tests__/settingsView.test.integration.test.js",
                "src/lib/__tests__/settingsView.test.normalization.test.js",
                "src/lib/__tests__/settingsView.test.providers.test.js",
            ],
        )
        if scoped
        else ["src/", "scripts/"]
    )


def test_full_frontend_scope_includes_extension_page_build_sources():
    module = _load_quality_frontend_module()

    paths = module._extension_page_ui_paths()

    assert "../tests/fixtures/extension-pages/alpha/ui" in paths
    assert "../tests/fixtures/extension-pages/beta/ui" in paths


def test_scoped_build_failure_fails_gate(monkeypatch, capsys):
    module = _load_quality_frontend_module()
    monkeypatch.setattr(module.shutil, "which", lambda name: name)
    monkeypatch.setattr(
        module.sys,
        "argv",
        ["quality-frontend.py", "--check", "--build", "webui/src/lib/settingsView.js"],
    )
    monkeypatch.setattr(module.subprocess, "run", _full_scan_run_factory(1, "", "build failed"))

    assert module.main() == 1
    assert "build failed" in capsys.readouterr().out


def test_main_surfaces_build_warnings_on_success(monkeypatch, capsys):
    module = _load_quality_frontend_module()
    monkeypatch.setattr(module.shutil, "which", lambda name: name)
    monkeypatch.setattr(module.sys, "argv", ["quality-frontend.py"])

    # vite routes the asset list to stdout and warnings to stderr; the build
    # still exits 0. The warning carries ANSI color codes, like the real tool.
    build_stdout = "dist/assets/index.js  701.14 kB\n✓ built in 2.0s\n"
    build_stderr = "\x1b[33m\n(!) Some chunks are larger than 800 kB after minification.\x1b[39m"

    monkeypatch.setattr(
        module.subprocess,
        "run",
        _full_scan_run_factory(0, build_stdout, build_stderr),
    )

    assert module.main() == 0

    captured = capsys.readouterr()
    assert "build" in captured.out
    assert "PASS" in captured.out and "warnings" in captured.out
    assert "--- build (warnings) ---" in captured.out
    assert "(!) Some chunks are larger than 800 kB after minification." in captured.out
    # ANSI codes are stripped from the surfaced warning.
    assert "\x1b[33m" not in captured.out
    # Warnings do not fail the gate, and the asset-list noise stays hidden.
    assert "All gates passed" in captured.out
    assert "701.14 kB" not in captured.out


def test_main_hides_build_output_on_clean_success(monkeypatch, capsys):
    module = _load_quality_frontend_module()
    monkeypatch.setattr(module.shutil, "which", lambda name: name)
    monkeypatch.setattr(module.sys, "argv", ["quality-frontend.py"])

    build_stdout = "dist/assets/index.js  701.14 kB\n✓ built in 2.0s\n"

    monkeypatch.setattr(
        module.subprocess,
        "run",
        _full_scan_run_factory(0, build_stdout, ""),
    )

    assert module.main() == 0

    captured = capsys.readouterr()
    assert "All gates passed" in captured.out
    assert "warnings" not in captured.out
    assert "--- build (warnings) ---" not in captured.out
    # A clean build prints only its PASS line, no asset-list noise.
    assert "701.14 kB" not in captured.out


def test_main_fails_when_fix_step_crashes(monkeypatch, capsys):
    module = _load_quality_frontend_module()
    monkeypatch.setattr(module.shutil, "which", lambda name: name)
    monkeypatch.setattr(
        module.sys, "argv", ["quality-frontend.py", "webui/src/components/AgentsView.svelte"]
    )

    def fake_run(cmd, capture_output, text, cwd, encoding, errors):
        if cmd[1] == "prettier":
            return module.subprocess.CompletedProcess(
                cmd, 2, stdout="", stderr="prettier internal error"
            )
        if cmd[1] == "vitest":
            return module.subprocess.CompletedProcess(
                cmd, 0, stdout="Tests  1 passed (1)\n", stderr=""
            )
        return module.subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setattr(module.subprocess, "run", fake_run)

    assert module.main() == 1

    captured = capsys.readouterr()
    assert "prettier internal error" in captured.out
    assert "All gates passed" not in captured.out
