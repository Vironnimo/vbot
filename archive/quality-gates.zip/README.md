# Archived Quality Gate Runners

Frozen source of `scripts/quality.py` (backend) and `scripts/quality-frontend.py`
(frontend), their shared `_quality_common.py`, documentation and tests, plus the
integration files that invoked them, before retirement.

The runners wrapped format -> lint -> type-check -> test into one command with
name-based test mapping and filtered output, designed when Agents needed a single
compact command. They were replaced by a tracked pre-commit hook
(`.githooks/pre-commit`, `scripts/commit_check.py`) for formatting, linting and
type checks, targeted `pytest`/`vitest` runs chosen by the committer, and the
complete suite in CI on every push to `main` (`.github/workflows/main.yml`).

Restore only in a worktree; reconcile the integration files with current source
instead of overwriting them.
