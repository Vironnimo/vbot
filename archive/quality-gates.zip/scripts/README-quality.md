# Quality Gates

This document explains how `scripts/quality.py` (backend) and `scripts/quality-frontend.py` (frontend) work: what they run, how they pick which tests to execute, how to read their output, and how to improve them when they hide something you needed.

The short version:

- Run the gate, not the raw tool: for non-mutating feedback during work use `python scripts/quality.py --check <paths...>` and `python scripts/quality-frontend.py --check <paths...>`.
- No arguments checks the whole repo; one or more file/dir paths check just those targets (plus their mirrored tests).
- Before commits, run scoped gates without `--check` to apply fixes before validation; add `--build` for frontend changes. Keep fixes and review the diff. Full gates are for broad effects or effects that cannot be reliably scoped. Docs-only changes need no gate.
- Include all affected source and test areas, including callers whose behavior may change. Automatic test mapping follows names and directories, not cross-domain dependencies.
- Both full and scoped gates filter tool noise and print one verdict. `--check` prevents source fixes; it does not choose the test scope.
- Add `--profile` to the backend gate to print pytest's 25 slowest setup/call/teardown durations while keeping the same path routing and pipeline.
- Add `--check` to validate without changing source files; run either script with `--help` for its complete command reference.
- Reach for raw `pytest`/`ruff`/`mypy`/`vitest`/`eslint`/`prettier` only when you genuinely suspect the gate withheld detail you need — and when it did, improve the gate (see [Improving the gate](#improving-the-gate)) instead of making hand-invocation the habit.

## What the gates are

Two scripts with the same interface, one per side of the codebase. They run the same shape of pipeline — format → lint → type-check → test (→ build, frontend only) — and share their plumbing through `scripts/_quality_common.py`: content-hash snapshots for fix detection, path deduplication, console-encoding setup, and the output-shaping helpers. Each runner supplies only what differs (its file-suffix set, its base directory, its file-vs-directory rule, its tool commands).

The output is the agent contract. It is meant to be read by an agent deciding what to do next, so every step reports a compact status, auto-fixed files are listed explicitly, failures forward the underlying tool output, and the final line states the verdict.

## Running them

```bash
python scripts/quality.py core/runtime/            # scoped pre-commit scan, with fixes
python scripts/quality.py                          # full backend scan
python scripts/quality.py --check                  # full backend scan, no source fixes
python scripts/quality.py --check core/runtime/            # one module, no source fixes
python scripts/quality.py --check core/utils/config.py     # single file (+ its mirrored tests), no source fixes
python scripts/quality.py --check core/utils/config.py core/utils/errors.py   # several targets, no source fixes
python scripts/quality.py --check --profile                # full validation + 25 slowest tests
```

```bash
python scripts/quality-frontend.py --build webui/src/lib/       # scoped pre-commit scan, with fixes and build
python scripts/quality-frontend.py                             # full frontend scan
python scripts/quality-frontend.py --check                     # full frontend scan, no source fixes
python scripts/quality-frontend.py --check webui/src/lib/             # one directory, no source fixes
python scripts/quality-frontend.py --check webui/src/lib/i18n.js      # single file (tests in its dir), no source fixes
python scripts/quality-frontend.py --check webui/src/lib/__tests__/i18n.test.js   # one test file, no source fixes
```

Paths may be files or directories. Backend paths are project-root-relative; frontend paths may be project-root-relative with the `webui/` prefix or relative to `webui/` itself. Both runners normalize input first (backslash → forward slash, trailing slash stripped) and deduplicate: a file already covered by a directory you also passed is dropped, so `core/utils/ core/utils/config.py` runs `core/utils/` once. The backend runner routes direct files by registered capability: Ruff and mypy own `.py`/`.pyi`, while `pyproject.toml` configures and therefore triggers the full Python pipeline without being passed to a Python source formatter. Direct `.sh` and `.ps1` files under `scripts/` (the lifecycle installers and helpers) never reach Ruff or mypy; they get a syntax-only check instead — `sh syntax` runs `bash -n` once per script, `ps1 syntax` runs the PowerShell language parser (`pwsh`, else Windows `powershell`) and prints `path:line:column: message` per error — and `scripts/{install,setup,uninstall}.{ps1,sh}` select `tests/scripts/test_install_scripts.py`. A direct file with no registered capability aborts before any tool runs. Directories remain mixed scopes whose contents each tool filters itself; a future native module adds its suffixes and tool steps rather than widening Ruff's inputs.

A step without inputs reports `NO FILES` instead of running: a scope of only scripts reports `NO FILES (no Python paths)` for the Ruff and mypy steps, because Ruff without a target would fall back to the whole repository. When `bash` or PowerShell is not on `PATH`, the matching syntax step reports `SKIPPED (<tool> not found)` with a `note:` per unchecked script. Both statuses are deliberately non-`PASS` but do not fail the gate: the interpreters are platform tools (Linux usually lacks PowerShell, Windows may lack `bash`), mirroring how `test_install_scripts.py` skips its own parse tests there.

Each shell script gets a separate `sh syntax` result with its path in a `note:`. The runner calls `bash -n` directly, avoiding shell-wrapper quoting changes in Windows WSL launchers. A failure does not prevent the remaining scripts from being checked.

Both scripts support `-h` / `--help`. Their help is the command-level reference for modes, path behavior, pipeline stages, prerequisites, examples, and exit codes.

The default mode is intentionally mutating: it keeps and reports formatter and linter fixes. Intermediate feedback can pass `--check` to avoid changing the code between the failure report and the Agent's next edit. Pre-commit runs omit `--check` so auto-fixes run before validation on the selected scope. `--check` replaces the formatting write with `ruff format --check` or `prettier --check`, omits the Ruff/ESLint fix pass, and then runs the same validation, type-check, and test stages. A complete frontend `--check` run still builds the WebUI. Add `--build` to a scoped frontend run to include the same full build, with or without `--check`; lint and test targets stay scoped. Full runs always build, and adding `--build` does not duplicate that step. `--check` does not change source files, but underlying tools may write caches and the frontend build may write generated artifacts.

Use the current Python interpreter directly — no virtual environment is assumed. The frontend runner additionally needs `npx` and `npm` on `PATH`; it exits early if they are missing.

## The pipeline

Every step is one external tool run. Steps are one of four kinds, which decides how the status is computed:

- **fix** — auto-fixer. It reports the *action* it took, never a verdict: `FIXED (n files)`, `NO CHANGES` (nothing to fix), or `UNCHANGED` (unfixable issues remain — **not** a failure here; the follow-up lint gate reports those with full detail). Only a harder error (exit ≥ 2) fails the step. `PASS` is reserved for the gate and test steps, so a run that changed nothing never reads as passed.
- **gate** — pass/fail validation (`ruff check`, `mypy`, `eslint`). Nonzero exit fails the gate.
- **test** — the test runner, with a `passed/total` count in the status, or `NO TESTS` when the selected scope has none (never a `PASS` — a run that tested nothing does not read as passed).
- **build** — frontend full-project build; see below.

Backend (`quality.py`), in order: `ruff format` (fix) → `ruff check --fix` (fix) → `ruff check` (gate) → `mypy --pretty` (gate) → `sh syntax` / `ps1 syntax` (gate, only for direct scripts) → `pytest -v --tb=short --timeout=30` (test). Pytest uses its physical-core worker count with the work-stealing scheduler so slow tests do not strand the final worker; `--profile` adds the 25 slowest setup/call/teardown durations to the gate report. In `--check` mode the first two steps become one `ruff format --check` gate.

Frontend (`quality-frontend.py`), in order: `prettier --write` (fix) → `eslint --fix` (fix) → `eslint` (gate) → `vitest run --reporter=default --passWithNoTests` (test) → `npm run build` (build). The default reporter keeps failure details and the aggregate summary without paying to render every passing test name. In `--check` mode the first two steps become one `prettier --check` gate. All npm commands run with `cwd=webui/`. A scoped run passes ESLint only the inputs that hold a file it lints (`.js`, `.mjs`, `.cjs`, `.svelte`); every other input, such as `webui/src/styles` or a `.css` file, still goes to Prettier and Vitest but gets a `note:` under the ESLint step. When no input remains, both ESLint steps report `NO FILES (nothing lintable)` instead of running: ESLint would otherwise abort on a directory whose files it all ignores, or exit `0` after linting nothing, which would read as a `PASS`. Like `NO TESTS`, `NO FILES` is non-`PASS` and does not fail the gate.

On a **full scan** (no paths), the tools target fixed defaults rather than the whole tree indiscriminately:

- Backend: ruff → `.`; mypy → `core/ server/ cli/ desktop/ tests/`; pytest → `tests/`. Full-scan mypy does not include `scripts/`; a scoped Python source path is routed to mypy, while `pyproject.toml` triggers these full defaults.
- Frontend: the normal `src/` scope plus bundled Extension page sources and the page builder/tests. The build step runs on a full scan or when `--build` is given, and includes independently built Extension assets with the shared Vite dependencies.

## Output contract

```text
Quality Gates
=============
ruff format   .... FIXED (0.4s, 2 files)
                    core/utils/config.py
                    core/utils/errors.py
ruff fix      .... NO CHANGES (0.3s)
ruff check    .... PASS (0.2s)
mypy          .... PASS (3.1s)
pytest        .... PASS (2.0s, 41/41)

All gates passed in 6.0s.
```

- Each step prints `label .... STATUS`; a fix step lists every changed file, indented, beneath its line.
- A **failing** step's complete output is reproduced afterward in a `--- label ---` block, so the failure detail is always in the report (pytest/vitest passing-test noise is filtered out first; failure lines are kept verbatim).
- Pytest filtering removes verbose progress, including parameterized ids with spaces, only before the diagnostic sections. Failure details and captured output remain intact even when they contain test ids or result words.
- The frontend **build** never fails the gate on warnings. A build that exits `0` but emits stderr (oversized chunks, a11y hints, unused CSS, deprecations) reports `PASS (warnings)` and reproduces the warnings in a `--- build (warnings) ---` block — surfacing them without blocking.
- The final line is either `All gates passed in Xs.` or `N gate(s) failed in Xs.`

## How backend paths map to tests

When you pass a source path, `quality.py` runs the tests that mirror it — the source file itself is never handed to pytest. The rules:

- A `tests` or `tests/...` path is passed through to pytest directly.
- The mirrored packages are `cli`, `core`, `desktop`, `scripts`, `server`. A path whose first segment is none of these selects no tests and prints a `note:` saying so.
- A source **file** `<pkg>/<...>/<file>.py` maps to its exact mirror `tests/<...>/test_<file>.py` **plus** any split-sibling `test_<file>_*.py` in that mirror directory that no more-specific source file owns.
- **Ownership** is by longest matching source stem, with hyphens normalized to `_`. Example: `openai_compatible.py` also runs `test_openai_compatible_oauth.py`, while `openai.py` does **not** — the more specific stem `openai_compatible` owns that split sibling, so the shorter `openai` never swallows it.
- If a source file has no owned mirror test, the whole mirrored **directory** runs instead (with a `note:`), so nearby related tests still execute. If neither the mirror file nor the mirror directory exists, a `note:` says nothing ran.
- A source **directory** maps to `tests/<dir>/` when that exists, else a `note:`.
- A direct **`.sh`/`.ps1` script** under `scripts/` maps through `LIFECYCLE_SCRIPT_TESTS`: `install`, `setup`, and `uninstall` select `tests/scripts/test_install_scripts.py`; any other script selects no tests and prints a `note:`.

Two guardrails worth knowing:

- **Bad paths abort with exit 2 before any tool runs.** A nonexistent input path would otherwise make pytest-xdist collect zero items across the whole invocation and silently skip even the valid paths beside it — a green run that tested nothing. Rejecting up front turns a typo into a clear error.
- **Unsupported direct files also abort with exit 2 before any tool runs.** This is capability routing rather than a project-wide Python restriction: a format is safe only after its formatter, linter, type-checker, and test-selection behavior have been registered. Mixed directories remain valid scopes.
- **A scoped run that maps to no tests skips pytest** (`NO TESTS (nothing mirrored)`) rather than falling back to running the entire suite.

## How frontend paths map to tests

`quality-frontend.py` strips a leading `webui/` from each path (all npm commands run inside `webui/`), then resolves each to the Vitest target that actually covers it — the frontend equivalent of the backend source→test mapping:

- An **explicit test file** — a path under a `/__tests__/` directory, or a filename containing `.test.` or `.spec.` — stays file-scoped.
- A **source file** resolves to its mirrored test `<stem>.test.*` / `<stem>.spec.*`, searched in the `__tests__` dir of the file's own directory and each parent up to `src/`. This is what lets a change in `src/components/settings/SettingsProvidersPanel.svelte` find `src/components/__tests__/SettingsProvidersPanel.test.js` one level up — the panels keep their tests in the parent's `__tests__`, not a co-located one.
- If a source file has **no** dedicated mirror test, the nearest ancestor directory that holds any tests runs instead (with a `note:`), so a broader suite still exercises it — e.g. a subcomponent covered only through its view's test.
- A **directory** that holds tests is used as-is; a directory whose tests live one level up maps to that nearest ancestor (with a `note:`).
- An input with no tests anywhere (e.g. a config file outside `src/`) selects no Vitest target and reports `NO TESTS` with a `note:`, instead of falling through to a whole-suite run.
- **Repo-wide guard tests** (`src/**/__tests__/*.guard.test.*` — UI primitives, RPC ownership, i18n placeholders) scan every source instead of mirroring one, so no mapping above reaches them. Any non-test input under `webui/src/` or a bundled Extension `resources/extensions/<owner>/ui/` (which the UI-primitives guard also scans) adds every guard suite that no selected directory target already covers, and a `note:` lists the added suites. Explicit test files and inputs outside those roots add none.

Because a source file resolves to its **actual** mirrored test rather than just its parent directory, a scoped run can no longer silently report a green pass while running zero of the tests that cover the change. Vitest still runs with `--passWithNoTests` as a safety net, and — as on the backend — an input path that does not exist under `webui/` aborts with exit 2 before any tool runs.

Bundled Extension page inputs under `resources/extensions/<owner>/ui/` and the two `tests/fixtures/extension-pages/` examples are accepted as repository-relative frontend paths. Mapping includes their tests in the existing frontend test system; generated `web/` assets are build output, not lint inputs. The build owner is `webui/scripts/build-extension-pages.mjs`; there is no second dependency tree.

## How "auto-fixed files" is detected

The gate does not trust the fixer to report what it changed. Before each fix step it snapshots content hashes of every fixable file under that step's targets; after the step it re-hashes and lists the files whose hash changed. "Fixable" is decided by a suffix set — `.py`/`.pyi` on the backend; a broad web set (`.js`, `.svelte`, `.css`, `.scss`, `.json`, `.md`, `.html`, `.ts`, `.tsx`, `.jsx`, `.cjs`, `.mjs`, `.yaml`, `.yml`) on the frontend — and build/cache directories (`node_modules`, `dist`, `.git`, caches, etc.) are skipped while snapshotting.

This is why the changed-file list is reliable even across tools that print nothing about what they touched, and why it reflects real content changes rather than tool chatter.

## Exit codes

- `0` — all gates passed.
- `1` — at least one gate failed (or, frontend only, `npx`/`npm` was not found on `PATH`).
- `2` — command-line usage was invalid, an input path did not exist, or a direct file had no registered quality capability; the run aborted before any quality tool ran.

## Profiling test performance

Pass `--profile` to any backend gate invocation to surface pytest's 25 slowest setup, call, or teardown durations. It preserves full/scoped path selection and every normal quality step, so a performance investigation does not need a separate raw pytest command:

```bash
python scripts/quality.py --check --profile
python scripts/quality.py --check --profile tests/core/channels/
```

Profiling changes only the report; it does not change test scheduling, selection, or pass/fail behavior.

## Improving the gate

The gates are the contract, so prefer them over calling the underlying tools by hand. If you do fall back to a raw tool and it shows you something the gate did not — a failure that got filtered away, a test that never got mapped, a fix that was not listed — that is a **gate gap**, not just a one-off. Note it in `.vorch/FLAGGED.md` so the gate can be improved to surface it next time.

Where the relevant behavior lives, when you come to fix it:

- **Noise filtering** that could hide a real failure: `filter_pytest_failure_output` / `_is_pytest_progress_nodeid_line` in `quality.py`, `filter_vitest_failure_output` in `quality-frontend.py`.
- **Test selection** that could miss or over-select tests: `translate_to_test_paths` and its `_owned_test_files` / `_owning_source_stem` helpers in `quality.py`; `translate_to_vitest_targets` and its `_find_named_test_files` / `_nearest_ancestor_with_tests` / `_is_explicit_test_file` / `_guard_test_targets` helpers in `quality-frontend.py`.
- **Backend format routing** that could send a file to the wrong tool or omit a newly supported language: `PYTHON_FILE_SUFFIXES`, `PYTHON_CONFIG_FILES`, `_is_native_script`, `LIFECYCLE_SCRIPT_TESTS`, and `_unsupported_direct_files` in `quality.py`, plus the pipeline steps that own each registered format (`_native_script_steps` for shell/PowerShell). On the frontend, `ESLINT_FILE_SUFFIXES` and `translate_to_eslint_targets` in `quality-frontend.py` decide which scoped inputs reach ESLint; keep the suffix set in step with ESLint's default patterns and the `files` patterns in `webui/eslint.config.js`.
- **Fix detection** that could miss a changed file: the snapshot suffix sets and ignored-dir sets at the top of each runner, plus `snapshot_target_files` / `changed_snapshot_paths` in `_quality_common.py`.

Their tests live in `tests/scripts/` (`test_quality.py`, `test_quality_frontend.py`, `test__quality_common.py`) — extend those alongside any change so the gate's own behavior stays gated.
