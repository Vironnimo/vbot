#!/usr/bin/env python
"""Quality gate runner (frontend) --- formats, auto-fixes, then checks code quality.

Usage:
    python scripts/quality-frontend.py [paths...]

Paths can be files or directories, relative to the project root
(e.g. ``webui/src/components/Foo.svelte`` or just ``src/``).
If no paths are given, the full frontend is checked. Explicit test-file paths
are passed directly to vitest; a source file is translated to its mirrored
``__tests__`` test (searched from its own directory up to ``src/``), falling back
to the nearest ancestor directory that holds tests when it has no dedicated one.
All npm commands run with ``cwd="webui"``.
"""

import argparse
import re
import shutil
import subprocess
import sys
import time
from collections.abc import Iterator
from pathlib import Path

from _quality_common import (
    PROJECT_ROOT,
    changed_snapshot_paths,
    collapse_blank_lines,
    configure_console_encoding,
    deduplicate_paths,
    describe_fix_result,
    iter_snapshot_files,
    snapshot_target_files,
)

configure_console_encoding()

WEBUI_ROOT = PROJECT_ROOT / "webui"
SRC_ROOT = WEBUI_ROOT / "src"
EXTENSION_UI_ROOT = PROJECT_ROOT / "resources" / "extensions"
EXTENSION_PAGE_FIXTURE_ROOT = PROJECT_ROOT / "tests" / "fixtures" / "extension-pages"
EXTENSION_PAGE_TEST = "scripts/__tests__/build-extension-pages.test.js"
FRONTEND_FILE_SUFFIXES = {
    ".cjs",
    ".css",
    ".html",
    ".js",
    ".json",
    ".jsx",
    ".md",
    ".mjs",
    ".scss",
    ".svelte",
    ".ts",
    ".tsx",
    ".yaml",
    ".yml",
}
SNAPSHOT_IGNORED_DIRS = {
    ".git",
    ".svelte-kit",
    "build",
    "coverage",
    "dist",
    "node_modules",
}
# Every suffix ESLint lints here: its default .js/.mjs/.cjs patterns plus the
# .svelte files webui/eslint.config.js adds. ESLint aborts on a directory whose
# files it all ignores and only warns (exit 0) on an ignored file, so scoped
# inputs without these suffixes are not handed to it.
ESLINT_FILE_SUFFIXES = {".js", ".mjs", ".cjs", ".svelte"}

# ---------- path helpers ----------


def _has_extension(path: str) -> bool:
    """Return True if the last segment of *path* looks like a file name."""
    return "." in path.rsplit("/", 1)[-1]


def strip_webui_prefix(path: str) -> str:
    """Remove the ``webui/`` prefix so paths are relative to the webui dir."""
    if path.startswith("webui/"):
        return path[len("webui/") :]
    return path


def _is_explicit_test_file(path: str) -> bool:
    """Return whether *path* is an explicit test file path for Vitest."""

    if not _has_extension(path):
        return False
    if "/__tests__/" in path:
        return True
    filename = path.rsplit("/", 1)[-1]
    return ".test." in filename or ".spec." in filename


# Test files live in ``__tests__`` dirs and carry one of these extensions.
TEST_FILE_SUFFIXES = {".js", ".jsx", ".mjs", ".cjs", ".ts", ".tsx"}
# Repo-wide guard scans (UI primitives, RPC ownership, i18n placeholders):
# they cover every source, so no source-to-mirror mapping ever selects them.
GUARD_TEST_GLOB = "*.guard.test.*"


def _looks_like_test_file(name: str) -> bool:
    """Return whether file *name* is a Vitest test file."""
    return ".test." in name or ".spec." in name


def _relative_to_webui(path: Path) -> str:
    """Return *path* as a posix string relative to the webui dir."""
    return path.relative_to(WEBUI_ROOT).as_posix()


def _iter_dirs_up_to_webui(start_dir: Path) -> Iterator[Path]:
    """Yield *start_dir* and each parent up to and including ``webui/``.

    Stops at ``webui/`` and never climbs above it; yields nothing when
    *start_dir* is not inside the WebUI tree.
    """
    directory = start_dir
    while directory == WEBUI_ROOT or WEBUI_ROOT in directory.parents:
        yield directory
        if directory == WEBUI_ROOT:
            return
        directory = directory.parent


def _dir_has_tests(directory: Path) -> bool:
    """Return whether *directory*'s subtree contains any test file."""
    return any(
        entry.is_file() and _looks_like_test_file(entry.name) for entry in directory.rglob("*")
    )


def _find_named_test_files(stem: str, start_dir: Path) -> list[Path]:
    """Return the mirrored test files for source *stem*, nearest level first.

    Searches the ``__tests__`` dir at *start_dir* and each parent up to ``src/``
    for ``<stem>.test.*`` / ``<stem>.spec.*``, returning the matches from the
    nearest level that has any (empty when none exists). This is what lets a
    changed ``src/components/settings/SettingsProvidersPanel.svelte`` find its
    test in ``src/components/__tests__/`` one level up.
    """
    for directory in _iter_dirs_up_to_webui(start_dir):
        tests_dir = directory / "__tests__"
        if not tests_dir.is_dir():
            continue
        matches = [
            entry
            for entry in sorted(tests_dir.iterdir())
            if entry.is_file()
            and entry.suffix in TEST_FILE_SUFFIXES
            and (entry.name.startswith(f"{stem}.test.") or entry.name.startswith(f"{stem}.spec."))
        ]
        if matches:
            return matches
    return []


def _nearest_ancestor_with_tests(start_dir: Path) -> Path | None:
    """Return the nearest dir (from *start_dir* up to ``src/``) that holds tests."""
    for directory in _iter_dirs_up_to_webui(start_dir):
        if _dir_has_tests(directory):
            return directory
    return None


def _extension_ui_root(path: Path) -> Path | None:
    """Return the declared UI root containing *path*, if any.

    Extension packages contain Python, manifests, and generated ``web/`` output
    beside their editable ``ui/`` sources. Only the latter belongs to the
    frontend gate. Fixtures mirror that same owner/ui shape.
    """
    for root in (EXTENSION_UI_ROOT, EXTENSION_PAGE_FIXTURE_ROOT):
        if not root.is_dir() or not (path == root or root in path.parents):
            continue
        relative = path.relative_to(root)
        if len(relative.parts) >= 2 and relative.parts[1] == "ui":
            return root / relative.parts[0] / "ui"
    return None


def _is_extension_page_source(path: Path) -> bool:
    """Return whether *path* is a declared bundled page UI source."""
    return _extension_ui_root(path) is not None


def _find_extension_page_tests(path: Path) -> list[Path]:
    """Find a page's explicit rendered test under its owning ``ui/`` root."""
    if path.is_dir():
        return []
    root = _extension_ui_root(path)
    if root is None:
        return []
    stem = path.stem
    matches: list[Path] = []
    directory = path.parent
    while directory == root or root in directory.parents:
        tests_dir = directory / "__tests__"
        if tests_dir.is_dir():
            matches.extend(
                entry
                for entry in sorted(tests_dir.iterdir())
                if entry.is_file()
                and entry.suffix in TEST_FILE_SUFFIXES
                and (
                    entry.name.startswith(f"{stem}.test.") or entry.name.startswith(f"{stem}.spec.")
                )
            )
            if matches:
                return matches
        if directory == root:
            break
        directory = directory.parent
    return []


def _extension_page_ui_paths() -> list[str]:
    """Return actual Extension page source directories for a full frontend gate."""
    paths: list[str] = []
    for root in (EXTENSION_UI_ROOT, EXTENSION_PAGE_FIXTURE_ROOT):
        if not root.is_dir():
            continue
        for owner in sorted(root.iterdir()):
            ui = owner / "ui"
            if owner.is_dir() and ui.is_dir():
                paths.append((Path("..") / ui.relative_to(PROJECT_ROOT)).as_posix())
    return paths


def _is_webui_testable_source(path: Path) -> bool:
    """Return whether a WebUI source belongs to the declared test roots."""
    return any(path == root or root in path.parents for root in (SRC_ROOT, WEBUI_ROOT / "scripts"))


def _selects_guard_tests(path: Path) -> bool:
    """Return whether a non-test input falls inside a scope the guard tests scan.

    The guards read every WebUI source under ``src/`` (``uiPrimitives`` also
    reads bundled Extension ``ui/`` sources), so a change anywhere there can
    break one without touching its mirrored test.
    """
    src_root = WEBUI_ROOT / "src"
    if path == src_root or src_root in path.parents:
        return True
    ui_root = _extension_ui_root(path)
    return ui_root is not None and EXTENSION_UI_ROOT in ui_root.parents


def _guard_test_targets() -> list[str]:
    """Return every repo-wide guard test (``src/**/__tests__/*.guard.test.*``)."""
    src_root = WEBUI_ROOT / "src"
    if not src_root.is_dir():
        return []
    return sorted(
        _relative_to_webui(entry)
        for entry in src_root.rglob(GUARD_TEST_GLOB)
        if entry.is_file()
        and entry.parent.name == "__tests__"
        and entry.suffix in TEST_FILE_SUFFIXES
        and "node_modules" not in entry.parts
    )


def _is_covered_by_target(path: str, targets: list[str]) -> bool:
    """Return whether *path* equals a target or lies under a directory target."""
    return any(
        path == target or (not _has_extension(target) and path.startswith(target + "/"))
        for target in targets
    )


def translate_to_vitest_targets(paths: list[str]) -> tuple[list[str], list[str]]:
    """Translate input paths to the Vitest targets that actually cover them.

    Returns ``(targets, notes)``. Explicit test files stay file-scoped. A source
    file resolves to its mirrored test (``<stem>.test.*`` / ``.spec.*``) in a
    ``__tests__`` dir from the file's own directory up to ``src/``; a directory
    that holds tests runs directly. When a file has no dedicated test, or a
    directory keeps its tests one level up, the nearest ancestor directory that
    holds any tests runs instead so a broader suite still exercises it. Inputs
    with no tests anywhere become a note, not a Vitest argument, so the runner
    reports "no tests" honestly instead of a silent green pass. Any non-test
    input under ``src/`` or a bundled Extension ``ui/`` also runs every
    repo-wide guard test not already covered by a directory target, with a note.
    """
    targets: list[str] = []
    notes: list[str] = []
    run_guard_tests = False

    def add(target: str) -> None:
        if target not in targets:
            targets.append(target)

    for p in paths:
        if _is_explicit_test_file(p):
            add(p)
            continue

        absolute = (WEBUI_ROOT / p).resolve()
        run_guard_tests = run_guard_tests or _selects_guard_tests(absolute)
        if _is_extension_page_source(absolute):
            for test_file in _find_extension_page_tests(absolute):
                add((Path("..") / test_file.relative_to(PROJECT_ROOT)).as_posix())
            add(EXTENSION_PAGE_TEST)
            continue
        if not _is_webui_testable_source(absolute):
            notes.append(f"{p}: no tests found")
            continue

        if absolute.is_dir():
            if _dir_has_tests(absolute):
                add(p)
                continue
            ancestor = _nearest_ancestor_with_tests(absolute)
            if ancestor is None:
                notes.append(f"{p}: no tests found")
            else:
                relative = _relative_to_webui(ancestor)
                add(relative)
                notes.append(f"{p}: no tests here, running {relative}/ instead")
            continue

        filename = p.rsplit("/", 1)[-1]
        stem = filename.rsplit(".", 1)[0]
        named = _find_named_test_files(stem, absolute.parent)
        if named:
            for test_file in named:
                add(_relative_to_webui(test_file))
            continue

        ancestor = _nearest_ancestor_with_tests(absolute.parent)
        if ancestor is None:
            notes.append(f"{p}: no tests found")
        else:
            relative = _relative_to_webui(ancestor)
            add(relative)
            notes.append(f"{p}: no {stem} test, running {relative}/ instead")

    targets = deduplicate_paths(targets, _has_extension)
    if run_guard_tests:
        guards = [
            guard for guard in _guard_test_targets() if not _is_covered_by_target(guard, targets)
        ]
        if guards:
            targets.extend(guards)
            notes.append(f"repo-wide guard tests added: {', '.join(guards)}")
    return targets, notes


def translate_to_eslint_targets(paths: list[str]) -> tuple[list[str], list[str]]:
    """Split scoped WebUI-relative inputs into ESLint targets and notes.

    Returns ``(lint_paths, notes)``: a file is kept when ESLint lints its suffix,
    a directory when it contains at least one such file outside build and
    dependency folders. Everything else is dropped with a note instead of making
    ESLint abort or report a pass for a file it ignored.
    """
    lint_paths: list[str] = []
    notes: list[str] = []
    for path in paths:
        absolute = (WEBUI_ROOT / path).resolve()
        if absolute.is_dir():
            lintable = bool(
                iter_snapshot_files(absolute, ESLINT_FILE_SUFFIXES, SNAPSHOT_IGNORED_DIRS)
            )
        else:
            lintable = absolute.suffix in ESLINT_FILE_SUFFIXES
        if lintable:
            lint_paths.append(path)
        else:
            notes.append(f"{path}: no ESLint-lintable files (.js/.mjs/.cjs/.svelte), not linted")
    return lint_paths, notes


def _tool_path_and_absolute(path: str) -> tuple[str, Path]:
    """Resolve an allowed frontend input and its path from the WebUI working dir."""
    normalized = strip_webui_prefix(path)
    candidate = (WEBUI_ROOT / normalized).resolve()
    project_candidate = (PROJECT_ROOT / path).resolve()
    for external in (candidate, project_candidate):
        if _is_extension_page_source(external):
            return (Path("..") / external.relative_to(PROJECT_ROOT)).as_posix(), external
    if candidate.is_relative_to(WEBUI_ROOT):
        return normalized, candidate
    return normalized, candidate


# ---------- vitest output parsing ----------

# vitest summary line, with any combination of segments:
#   Tests  2 passed (2)
#   Tests  1 failed | 2 passed (3)
#   Tests  1 skipped | 4 passed (5)

_ANSI_ESCAPE_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
_VITEST_TESTS_SUMMARY_RE = re.compile(
    r"^\s*Tests\s+(?P<details>[^()\n]+)\((?P<total>\d+)\)\s*$", re.MULTILINE
)
_VITEST_PASSED_COUNT_RE = re.compile(r"(\d+)\s+passed")


def parse_vitest_counts(output: str) -> tuple[int, int]:
    """Return ``(passed, total)`` from Vitest output."""
    cleaned_output = _ANSI_ESCAPE_RE.sub("", output)

    summary = _VITEST_TESTS_SUMMARY_RE.search(cleaned_output)
    if summary is None:
        return 0, 0

    passed_match = _VITEST_PASSED_COUNT_RE.search(summary.group("details"))
    passed = int(passed_match.group(1)) if passed_match else 0
    return passed, int(summary.group("total"))


def filter_vitest_failure_output(output: str) -> str:
    """Remove passing-test noise from Vitest output while keeping failure detail."""

    cleaned_output = _ANSI_ESCAPE_RE.sub("", output)
    filtered_lines: list[str] = []

    for line in cleaned_output.splitlines():
        stripped = line.strip()
        if not stripped:
            filtered_lines.append("")
            continue
        if stripped.startswith("RUN ") or stripped.startswith("DEV "):
            continue
        if stripped.startswith("✓"):
            continue
        filtered_lines.append(line.rstrip())

    collapsed = collapse_blank_lines(filtered_lines)
    filtered_output = "\n".join(collapsed).strip()
    return filtered_output or cleaned_output.strip()


# ---------- main ----------


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=("Run the frontend quality pipeline over the whole WebUI or selected paths."),
        epilog="""Modes:
  default       Auto-format and auto-fix before validating.
  --check       Validate without changing source files. Formatting differences fail.

Pipeline:
  prettier -> eslint -> vitest -> build (complete gate or --build)
  The default mode adds Prettier writes and ESLint fixes. --check uses
  `prettier --check` and omits every fix pass.

Path behavior:
  With no PATH, run the complete frontend gate and build. PATH values may be
  project-root-relative (`webui/src/...`) or WebUI-relative (`src/...`) files or
  directories. Source paths select their nearest mirrored Vitest coverage; any
  non-test path under src/ or a bundled Extension ui/ also selects the repo-wide
  *.guard.test.* suites. ESLint receives only paths holding .js/.mjs/.cjs/.svelte
  files; other inputs get a note, and a scope without any reports the ESLint
  steps as NO FILES (not a pass). A scoped run omits the build unless --build
  is given. --build adds a full WebUI build without widening the selected lint
  or test paths. Missing paths abort before any quality tool runs.

Notes:
  npx and npm must be on PATH. The default mode keeps and reports every source-file
  change made by Prettier or ESLint. --check does not modify source files, although
  tests and builds may still write caches or generated build artifacts.

Exit codes:
  0  All gates passed.
  1  A prerequisite was missing or one or more gates failed.
  2  Invalid arguments or paths.

Examples:
  python scripts/quality-frontend.py
  python scripts/quality-frontend.py --check
  python scripts/quality-frontend.py webui/src/lib/
  python scripts/quality-frontend.py --build webui/src/lib/
  python scripts/quality-frontend.py --check src/components/App.svelte""",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="validate without applying formatter or linter fixes",
    )
    parser.add_argument(
        "--build",
        action="store_true",
        help="also build the full WebUI when checking selected paths",
    )
    parser.add_argument(
        "paths",
        nargs="*",
        metavar="PATH",
        help="project-root- or WebUI-relative file or directory; omit for the complete gate",
    )
    return parser.parse_args(argv)


def main() -> int:
    args = parse_args()

    # Resolve full executable paths so subprocess.run works on Windows
    # (CreateProcess cannot find .cmd executables without shell resolution).
    npx_exe = shutil.which("npx")
    npm_exe = shutil.which("npm")
    if not npx_exe or not npm_exe:
        print("ERROR: npx and/or npm not found on PATH.", file=sys.stderr)
        return 1

    raw_paths: list[str] = args.paths

    # Normalize: backslash → forward slash, strip trailing slash.
    normalized = [p.replace("\\", "/").rstrip("/") for p in raw_paths]
    paths = deduplicate_paths(normalized, _has_extension)
    resolved_paths = [_tool_path_and_absolute(path) for path in paths]
    stripped = [tool_path for tool_path, _absolute in resolved_paths]

    # Reject unknown paths before running anything: a typo would otherwise
    # surface as a confusing tool error instead of a clear message.
    missing_inputs = [
        tool_path
        for tool_path, absolute in zip(stripped, (item[1] for item in resolved_paths), strict=True)
        if not absolute.exists()
    ]
    if missing_inputs:
        for missing in missing_inputs:
            print(f"ERROR: path not found under webui/: {missing}")
        return 2

    # ---------- Build command lists ----------
    is_full_scan = len(stripped) == 0

    if stripped:
        scope_paths = stripped
        prettier_paths = scope_paths
        lint_paths, eslint_notes = translate_to_eslint_targets(scope_paths)
        vitest_paths, vitest_notes = translate_to_vitest_targets(scope_paths)
    else:
        scope_paths = ["src/", "scripts/", *_extension_page_ui_paths()]
        prettier_paths = scope_paths
        lint_paths, eslint_notes = scope_paths, []
        vitest_paths = ["src/", "scripts/"]
        vitest_notes = []
    step_notes = {"eslint": eslint_notes, "vitest": vitest_notes}

    external_scope = any(
        path.startswith("../resources/") or path.startswith("../tests/") for path in scope_paths
    )
    # Prettier resolves a file's configuration relative to that file. Extension
    # page sources sit outside ``webui/``, so without explicit configuration it
    # cannot discover the Svelte plugin or the repository formatting policy.
    prettier_config = (
        ["--config", "prettier.config.js", "--plugin", "prettier-plugin-svelte"]
        if external_scope
        else []
    )
    eslint_config = ["--config", "webui/eslint.config.js"] if external_scope else []
    eslint_paths = (
        [(WEBUI_ROOT / path).resolve().relative_to(PROJECT_ROOT).as_posix() for path in lint_paths]
        if external_scope
        else lint_paths
    )
    # Without a lintable input, ESLint would abort (directory) or lint nothing;
    # a None command reports the step as NO FILES instead of running it.
    eslint_fix_command = (
        [npx_exe, "eslint", *eslint_config, "--fix", *eslint_paths] if eslint_paths else None
    )
    eslint_command = [npx_exe, "eslint", *eslint_config, *eslint_paths] if eslint_paths else None

    # Each step: (label, command, kind, snapshot paths); a None command is skipped.
    # kind: "fix" = auto-fix (shows FIXED), "gate" = validation (PASS/FAIL),
    #       "test" = test runner with count display,
    #       "build" = full build; surfaces stderr warnings on success without failing
    steps: list[tuple[str, list[str] | None, str, list[str] | None]]
    if args.check:
        steps = [
            (
                "prettier",
                [npx_exe, "prettier", *prettier_config, "--check"] + prettier_paths,
                "gate",
                None,
            )
        ]
    else:
        steps = [
            (
                "prettier",
                [npx_exe, "prettier", *prettier_config, "--write"] + prettier_paths,
                "fix",
                prettier_paths,
            ),
            ("eslint fix", eslint_fix_command, "fix", lint_paths),
        ]
    steps.extend(
        [
            ("eslint", eslint_command, "gate", None),
            (
                "vitest",
                # --passWithNoTests: a path filter without nearby tests must not
                # fail the gate (vitest exits 1 on "No test files found").
                [npx_exe, "vitest", "run", "--reporter=default", "--passWithNoTests"]
                + vitest_paths,
                "test",
                None,
            ),
        ]
    )

    # Build the whole WebUI without widening scoped lint or test selection.
    if is_full_scan or args.build:
        steps.append(("build", [npm_exe, "run", "build"], "build", None))

    title = "Quality Gates (Frontend)"
    print(title)
    print("=" * len(title))

    total_elapsed = 0.0
    validation_passed = True
    failures: list[tuple[str, str]] = []  # (label, full_output)
    build_warnings: list[tuple[str, str]] = []  # (label, stderr) — non-fatal

    for label, cmd, kind, snapshot_paths in steps:
        if cmd is None:
            print(f"{label:<14}.... NO FILES (nothing lintable)")
            for note in step_notes.get(label, []):
                print(f"{'':<18}note: {note}")
            continue

        # A scoped run whose inputs map to no test files must not fall through to
        # ``vitest`` with no path argument — that would silently run the whole
        # suite. Report the honest "no tests" outcome and move on.
        if kind == "test" and not vitest_paths:
            print(f"{label:<14}.... NO TESTS (nothing to run)")
            for note in vitest_notes:
                print(f"{'':<18}note: {note}")
            continue

        before_snapshot: dict[str, str] = {}
        if kind == "fix" and snapshot_paths is not None:
            before_snapshot = snapshot_target_files(
                snapshot_paths, WEBUI_ROOT, FRONTEND_FILE_SUFFIXES, SNAPSHOT_IGNORED_DIRS
            )

        start = time.monotonic()
        # Use errors="replace" and text=True to avoid UnicodeDecodeError on Windows.
        # Capture stdout and stderr properly.
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=PROJECT_ROOT if external_scope and label.startswith("eslint") else WEBUI_ROOT,
            encoding="utf-8",
            errors="replace",
        )
        elapsed = time.monotonic() - start
        total_elapsed += elapsed
        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            output += result.stderr
        output = output.strip()
        changed_files: list[str] = []

        if kind == "fix":
            if snapshot_paths is not None:
                after_snapshot = snapshot_target_files(
                    snapshot_paths, WEBUI_ROOT, FRONTEND_FILE_SUFFIXES, SNAPSHOT_IGNORED_DIRS
                )
                changed_files = changed_snapshot_paths(before_snapshot, after_snapshot)
            # prettier --write / eslint --fix
            # Exit code 1 from eslint --fix means "unfixable issues remain"
            # — that is expected; the follow-up eslint gate step catches them.
            if result.returncode <= 1:
                status = describe_fix_result(result.returncode, elapsed, changed_files)
            else:
                status = f"FAIL ({elapsed:.1f}s)"
                validation_passed = False
                failures.append((label, output))
        elif kind == "test":
            passed, total = parse_vitest_counts(output)
            if result.returncode == 0:
                if total == 0:
                    status = f"NO TESTS ({elapsed:.1f}s)"
                else:
                    status = f"PASS ({elapsed:.1f}s, {passed}/{total})"
            else:
                status = f"FAIL ({elapsed:.1f}s, {passed}/{total})"
                validation_passed = False
                failures.append((label, filter_vitest_failure_output(output)))
        elif kind == "build":
            # A successful build still emits warnings (oversized chunks, a11y,
            # unused CSS, deprecations) on stderr without changing the exit code.
            # Surface those — they are the whole reason to look here — but never
            # let them fail the gate. The asset-list noise stays on stdout, so a
            # clean build prints nothing extra.
            if result.returncode == 0:
                warning_text = _ANSI_ESCAPE_RE.sub("", result.stderr or "").strip()
                if warning_text:
                    status = f"PASS ({elapsed:.1f}s, warnings)"
                    build_warnings.append((label, warning_text))
                else:
                    status = f"PASS ({elapsed:.1f}s)"
            else:
                status = f"FAIL ({elapsed:.1f}s)"
                validation_passed = False
                failures.append((label, output))
        else:
            # eslint
            if result.returncode == 0:
                status = f"PASS ({elapsed:.1f}s)"
            else:
                status = f"FAIL ({elapsed:.1f}s)"
                validation_passed = False
                failures.append((label, output))

        print(f"{label:<14}.... {status}")
        if changed_files:
            for changed_path in changed_files:
                print(f"{'':<18}{changed_path}")
        for note in step_notes.get(label, []):
            print(f"{'':<18}note: {note}")

    print()

    # Show complete output for every failed step.
    if failures:
        for label, output in failures:
            print(f"--- {label} ---")
            if output:
                print(output)
            print()

    # Surface non-fatal build warnings — the build still passed.
    if build_warnings:
        for label, warning_text in build_warnings:
            print(f"--- {label} (warnings) ---")
            print(warning_text)
            print()

    if validation_passed:
        print(f"All gates passed in {total_elapsed:.1f}s.")
    else:
        failed_count = len(failures)
        gate_word = "s" if failed_count != 1 else ""
        print(f"{failed_count} gate{gate_word} failed in {total_elapsed:.1f}s.")

    return 0 if validation_passed else 1


if __name__ == "__main__":
    sys.exit(main())
