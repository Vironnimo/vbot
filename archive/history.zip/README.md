# Archived history Tool

Frozen source at 17b591f8801135d61ab4c19b6f7813f5d103511a. Original repository paths are preserved.
The history Tool implementation, its protocol module, focused tests, prior documentation, Provider probe scenario and original shared integration/probe files are included: Tool registration, the checkpoint-derived Session grant and checkpoint guidance in Chat, the Session store's History reads, the compaction event field, the E2E spec and the tests that exercised them.
The vbot-cli Skill's Session search reference replaces the Tool. Shared files remain active in vBot; their copies here are historical reference only.
Restore only in a worktree, reconciling shared files with current source. This archive is not an installable runtime package.
