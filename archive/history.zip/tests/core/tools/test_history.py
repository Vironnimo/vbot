"""The Session-scoped history Tool through production dispatch."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any, cast

import pytest

from core.chat import ChatMessage, ToolCall
from core.chat.messages import ModelFallback
from core.sessions import ChatSession, ChatSessionManager, SessionAddress
from core.tools import (
    HISTORY_RESULT_MAX_BYTES,
    HISTORY_TOOL_NAME,
    ToolContext,
    ToolRegistry,
    register_history_tool,
)
from tests.core.sessions.history_fixtures import append_tool_fixture
from tests.core.tools.tools_test_support import dispatch_as_executor

pytestmark = pytest.mark.usefixtures("current_format_data_directory")


def _context(session_id: str, *, agent_id: str = "agent") -> ToolContext:
    return ToolContext(
        agent_id=agent_id,
        session_id=session_id,
        run_id="run",
        tool_call_id="call",
        tool_name=HISTORY_TOOL_NAME,
        tool_call_index=0,
        workspace=Path("workspace"),
        vbot_root=Path("app"),
        data_root=Path("data"),
        session_tool_grants=(HISTORY_TOOL_NAME,),
    )


def _checkpoint(summary: str = "Earlier context") -> ChatMessage:
    return ChatMessage.compaction_checkpoint(
        summary=summary,
        projection=[],
        compacted_token_count=10,
    )


def _call(
    manager: ChatSessionManager,
    session: ChatSession,
    arguments: dict[str, Any],
    *,
    agent_id: str = "agent",
) -> dict[str, Any]:
    registry = ToolRegistry()
    register_history_tool(registry, manager)
    context = _context(session.id, agent_id=agent_id)
    return asyncio.run(dispatch_as_executor(registry, context, arguments))


def _details(arguments: dict[str, Any], result: dict[str, Any]) -> list[dict[str, Any]]:
    """Return the detail blocks the user sees for one call."""
    registry = ToolRegistry()
    register_history_tool(registry, cast(ChatSessionManager, None))
    return cast(
        list[dict[str, Any]],
        registry.display_for_call(HISTORY_TOOL_NAME, arguments, result=result)["details"],
    )


def _data(result: dict[str, Any]) -> dict[str, Any]:
    assert result["ok"] is True, result
    return cast(dict[str, Any], result["data"])


def _messages(data: dict[str, Any]) -> list[dict[str, Any]]:
    return [item["message"] for item in data["items"]]


def _serialized_size(result: dict[str, Any]) -> int:
    return len(json.dumps(result, ensure_ascii=False, separators=(",", ":")).encode("utf-8"))


def test_registration_is_session_scoped_and_schema_is_flat(tmp_path: Path) -> None:
    manager = ChatSessionManager(tmp_path)
    registry = ToolRegistry()

    register_history_tool(registry, manager)

    tool = registry.get(HISTORY_TOOL_NAME)
    assert tool.session_scoped is True
    assert tool.open_input_schema is True
    assert set(tool.parameters["properties"]) == {
        "action",
        "query",
        "message_id",
        "checkpoint",
        "roles",
        "match",
        "direction",
        "limit",
        "before",
        "after",
        "cursor",
    }
    assert tool.parameters["required"] == ["action"]
    assert '"default"' not in json.dumps(tool.parameters)
    assert tool.description
    assert all(
        isinstance(property_schema.get("description"), str) and property_schema["description"]
        for property_schema in tool.parameters["properties"].values()
    )
    display = registry.display_for_call(
        HISTORY_TOOL_NAME,
        {
            "action": "search",
            "query": "secret",
            "cursor": "opaque",
        },
        result={
            "ok": True,
            "data": {"items": [{"id": "one"}], "has_more": True},
            "error": None,
            "artifacts": [],
        },
    )
    assert display["summary"] == "search · all earlier history"
    assert display["hidden_argument_keys"] == ["cursor", "message_id", "query"]
    assert display["facts"] == [{"kind": "count", "value": 1, "unit": "results", "at_least": True}]


def test_checkpoint_grant_and_cursor_lifecycle_across_restart_move_takeover_and_fork(
    tmp_path: Path,
) -> None:
    manager = ChatSessionManager(tmp_path)
    source = manager.create("alpha", session_id="source")
    source.append(ChatMessage.user("first"))
    source.append(ChatMessage.assistant(model="openai/gpt-5.2", content="second"))
    source.append(_checkpoint())
    first = _data(_call(manager, source, {"action": "read", "limit": 1}, agent_id="alpha"))
    cursor = first["next_cursor"]

    restarted = ChatSessionManager(tmp_path)
    restarted_source = restarted.get(
        SessionAddress(project_id=None, agent_id="alpha", session_id=source.id)
    )
    restarted_page = _call(
        restarted, source, {"action": "read", "cursor": cursor}, agent_id="alpha"
    )
    assert restarted_page["ok"] is True

    moved = asyncio.run(
        restarted.move(
            SessionAddress(project_id=None, agent_id="alpha", session_id=restarted_source.id),
            SessionAddress(project_id=None, agent_id="beta", session_id=restarted_source.id),
        )
    )
    moved_page = _call(restarted, moved, {"action": "read", "cursor": cursor}, agent_id="beta")
    assert moved_page["ok"] is True
    moved.append(ChatMessage.agent_takeover(from_address="alpha", to_address="beta"))
    assert _call(restarted, moved, {"action": "overview"}, agent_id="beta")["ok"] is True

    fork = asyncio.run(
        restarted.fork(
            SessionAddress(project_id=None, agent_id="beta", session_id=moved.id),
            target_agent_id="gamma",
        )
    )
    assert _call(restarted, fork, {"action": "overview"}, agent_id="gamma")["ok"] is True
    fork_cursor_result = _call(
        restarted, fork, {"action": "read", "cursor": cursor}, agent_id="gamma"
    )
    assert fork_cursor_result["error"]["code"] == "invalid_cursor"


def test_checkpoint_free_session_returns_history_unavailable(tmp_path: Path) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    session.append(ChatMessage.user("Hello"))

    result = _call(manager, session, {"action": "read"})

    assert result["ok"] is False
    assert result["error"]["code"] == "history_unavailable"


@pytest.mark.parametrize(
    "arguments",
    [{"request": {"operation": "overview"}}, {"overview": {}}, {"action": "OVERVIEW"}],
)
def test_action_wrappers_and_spellings_run_the_named_action(
    tmp_path: Path, arguments: dict[str, Any]
) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    session.append(ChatMessage.user("Hello"))
    session.append(_checkpoint())

    data = _data(_call(manager, session, arguments))

    assert [item["checkpoint"] for item in data["items"]] == [1]
    assert data["snapshot"]["checkpoint_id"]


def test_overview_reports_fixed_checkpoint_sections(tmp_path: Path) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    first_user = ChatMessage.user("First question")
    first_assistant = ChatMessage.assistant(model="openai/gpt", content="First answer")
    first_checkpoint = _checkpoint("First summary")
    second_user = ChatMessage.user("Second question")
    second_checkpoint = _checkpoint("Second summary")
    for message in (
        first_user,
        first_assistant,
        first_checkpoint,
        second_user,
        second_checkpoint,
    ):
        session.append(message)

    result = _call(manager, session, {"action": "overview"})
    data = _data(result)

    assert [item["checkpoint"] for item in data["items"]] == [1, 2]
    assert data["items"][0] == {
        "checkpoint": 1,
        "checkpoint_id": first_checkpoint.id,
        "timestamp": first_checkpoint.timestamp,
        "start_timestamp": first_user.timestamp,
        "end_timestamp": first_assistant.timestamp,
        "eligible_count": 2,
        "summary": "First summary",
    }
    assert data["items"][1]["eligible_count"] == 1
    assert data["snapshot"]["checkpoint_id"] == second_checkpoint.id
    assert data["scope"] == {"checkpoint": None, "checkpoint_id": None}
    assert data["has_more"] is False
    assert "next_cursor" not in data
    assert "content" not in data
    # The user sees each section's summary; snapshot identity stays raw.
    assert _details({"action": "overview"}, result) == [
        {
            "type": "results",
            "items": [
                {
                    "title": "Checkpoint 1",
                    "meta": "2 messages",
                    "time": first_assistant.timestamp,
                    "text": "First summary",
                },
                {
                    "title": "Checkpoint 2",
                    "meta": "1 message",
                    "time": second_user.timestamp,
                    "text": "Second summary",
                },
            ],
        }
    ]


def test_read_uses_all_history_or_one_non_overlapping_section(tmp_path: Path) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    first_user = ChatMessage.user("First")
    first_assistant = ChatMessage.assistant(model="openai/gpt", content="Answer one")
    first_checkpoint = _checkpoint("First")
    second_user = ChatMessage.user("Second")
    error = ChatMessage.error("network_error", "Temporary failure")
    second_assistant = ChatMessage.assistant(model="openai/gpt", content="Answer two")
    second_checkpoint = _checkpoint("Second")
    after_latest = ChatMessage.user("Not yet hidden")
    for message in (
        first_user,
        first_assistant,
        first_checkpoint,
        second_user,
        error,
        second_assistant,
        second_checkpoint,
        after_latest,
    ):
        session.append(message)

    all_data = _data(_call(manager, session, {"action": "read"}))
    second_data = _data(_call(manager, session, {"action": "read", "checkpoint": 2}))
    end_read = {"action": "read", "checkpoint": 2, "direction": "end", "limit": 2}
    end_result = _call(manager, session, end_read)
    end_data = _data(end_result)

    assert [message["id"] for message in _messages(all_data)] == [
        first_user.id,
        first_assistant.id,
        second_user.id,
        error.id,
        second_assistant.id,
    ]
    assert [item["checkpoint"] for item in all_data["items"]] == [1, 1, 2, 2, 2]
    assert [message["id"] for message in _messages(second_data)] == [
        second_user.id,
        error.id,
        second_assistant.id,
    ]
    assert [message["id"] for message in _messages(end_data)] == [
        second_assistant.id,
        error.id,
    ]
    assert _messages(second_data)[0] == second_user.to_dict()
    # The user sees who wrote each message, when, and its text; the cursor stays raw.
    assert _details(end_read, end_result) == [
        {
            "type": "results",
            "items": [
                {
                    "title": title,
                    "meta": "checkpoint 2",
                    "time": message.timestamp,
                    "text": text,
                }
                for title, message, text in (
                    ("Assistant", second_assistant, "Answer two"),
                    ("Error", error, "Temporary failure"),
                )
            ],
        },
        {"type": "notice", "level": "info", "text": "More history follows."},
    ]


@pytest.mark.parametrize(
    ("match", "query", "expected"),
    [
        ("all_terms", "alpha gamma", ["alpha beta gamma", "gamma alpha"]),
        ("phrase", "alpha beta", ["alpha beta gamma"]),
        ("any_term", "beta delta", ["alpha beta gamma", "delta", "beta later"]),
    ],
)
def test_search_is_case_insensitive_chronological_and_deterministic(
    tmp_path: Path,
    match: str,
    query: str,
    expected: list[str],
) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    contents = ["Alpha beta GAMMA", "delta", "gamma alpha", "beta later"]
    for content in contents:
        session.append(ChatMessage.user(content))
    session.append(_checkpoint())

    data = _data(
        _call(
            manager,
            session,
            {"action": "search", "query": query, "match": match},
        )
    )

    assert [item["excerpt"].casefold() for item in data["items"]] == expected
    assert all(len(item["excerpt"]) <= 320 for item in data["items"])
    assert [item["checkpoint"] for item in data["items"]] == [1] * len(expected)


def test_search_excerpt_marks_omitted_edges_within_320_characters(tmp_path: Path) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    message = ChatMessage.user(f"{'a' * 300} NEEDLE {'b' * 500}")
    session.append(message)
    session.append(_checkpoint())

    data = _data(_call(manager, session, {"action": "search", "query": "needle"}))
    excerpt = data["items"][0]["excerpt"]

    assert len(excerpt) <= 320
    assert excerpt.startswith("...")
    assert excerpt.endswith("...")
    assert "NEEDLE" in excerpt


def test_tool_and_note_roles_are_opt_in_and_history_artifacts_are_removed(tmp_path: Path) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    mixed = ChatMessage.assistant(
        model="openai/gpt",
        content="Keep this unrelated answer.",
        reasoning="Keep this reasoning.",
        tool_calls=[
            ToolCall(id="history-call", name="history", arguments={"action": "read"}),
            ToolCall(id="read-call", name="read", arguments={"path": "notes.md"}),
        ],
    )
    history_result = ChatMessage.tool(
        tool_call_id="history-call",
        name="history",
        content='{"ok":true}',
    )
    read_result = ChatMessage.tool(
        tool_call_id="read-call",
        name="read",
        content='{"ok":true,"data":{"content":"evidence"}}',
    )
    pure_history = ChatMessage.assistant(
        model="openai/gpt",
        content=None,
        tool_calls=[ToolCall(id="history-only", name="history", arguments={"action": "read"})],
    )
    pure_history_result = ChatMessage.tool(
        tool_call_id="history-only",
        name="history",
        content='{"ok":true}',
    )
    note = ChatMessage.note("Internal evidence")
    for message in (
        mixed,
        history_result,
        read_result,
        pure_history,
        pure_history_result,
        note,
        _checkpoint(),
    ):
        session.append(message)

    default_data = _data(_call(manager, session, {"action": "read"}))
    expanded = _data(
        _call(
            manager,
            session,
            {"action": "read", "roles": ["assistant", "tool", "note"]},
        )
    )

    assert [message["id"] for message in _messages(default_data)] == [mixed.id]
    expanded_messages = _messages(expanded)
    assert [message["id"] for message in expanded_messages] == [mixed.id, read_result.id, note.id]
    sanitized_mixed = expanded_messages[0]
    assert sanitized_mixed["content"] == "Keep this unrelated answer."
    assert sanitized_mixed["reasoning"] == "Keep this reasoning."
    assert [call["name"] for call in sanitized_mixed["tool_calls"]] == ["read"]


def test_around_returns_complete_local_sequence_and_honors_section_boundary(tmp_path: Path) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    first = ChatMessage.user("first")
    first_checkpoint = _checkpoint("first")
    second = ChatMessage.user("second")
    anchor = ChatMessage.assistant(model="openai/gpt", content="anchor")
    fourth = ChatMessage.error("network_error", "fourth")
    second_checkpoint = _checkpoint("second")
    for message in (first, first_checkpoint, second, anchor, fourth, second_checkpoint):
        session.append(message)

    data = _data(
        _call(
            manager,
            session,
            {
                "action": "around",
                "message_id": anchor.id,
                "checkpoint": 2,
                "before": 10,
                "after": 10,
            },
        )
    )

    assert [message["id"] for message in _messages(data)] == [second.id, anchor.id, fourth.id]
    assert first.id not in {message["id"] for message in _messages(data)}


def test_around_distinguishes_missing_and_out_of_scope_anchor(tmp_path: Path) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    tool = ChatMessage.tool(tool_call_id="read", name="read", content="evidence")
    append_tool_fixture(session, tool)
    session.append(_checkpoint())

    missing = _call(manager, session, {"action": "around", "message_id": "missing"})
    outside = _call(manager, session, {"action": "around", "message_id": tool.id})

    assert missing["error"]["code"] == "message_not_found"
    assert outside["error"]["code"] == "anchor_outside_scope"


def test_cursor_freezes_snapshot_across_appends_and_later_compaction(tmp_path: Path) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    first = ChatMessage.user("first")
    second = ChatMessage.user("second")
    first_checkpoint = _checkpoint("first")
    for message in (first, second, first_checkpoint):
        session.append(message)

    first_page = _data(_call(manager, session, {"action": "read", "limit": 1}))
    cursor = first_page["next_cursor"]
    appended = ChatMessage.user("new section")
    second_checkpoint = _checkpoint("second")
    session.append(appended)
    session.append(second_checkpoint)

    second_page = _data(_call(manager, session, {"action": "read", "cursor": cursor}))

    assert [message["id"] for message in _messages(first_page)] == [first.id]
    assert [message["id"] for message in _messages(second_page)] == [second.id]
    assert second_page["snapshot"]["checkpoint_id"] == first_checkpoint.id
    assert appended.id not in {message["id"] for message in _messages(second_page)}


def test_cursor_uses_checkpoint_sequence_when_public_ids_repeat(tmp_path: Path) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    first = ChatMessage.user("first")
    first_checkpoint = _checkpoint("first")
    second = ChatMessage.user("second")
    third = ChatMessage.user("third")
    repeated_checkpoint_data = _checkpoint("second").to_dict()
    repeated_checkpoint_data["id"] = first_checkpoint.id
    repeated_checkpoint = ChatMessage.from_dict(repeated_checkpoint_data)
    for message in (first, first_checkpoint, second, third, repeated_checkpoint):
        session.append(message)

    first_page = _data(_call(manager, session, {"action": "read", "limit": 1}))
    second_page = _data(
        _call(manager, session, {"action": "read", "cursor": first_page["next_cursor"]})
    )

    assert first_page["snapshot"]["checkpoint_id"] == first_checkpoint.id
    assert [message["id"] for message in _messages(second_page)] == [second.id]


def test_reads_are_bounded_and_search_scans_in_fixed_batches(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    needle = ChatMessage.user("needle")
    # The search contract is about bounded reads, not one transaction per fixture
    # message. Batch fixture construction keeps this focused under Windows xdist load.
    session.append_many(
        [
            *(ChatMessage.user(f"ordinary record {index}") for index in range(300)),
            needle,
            _checkpoint(),
        ]
    )
    original = ChatSession.load_history_records
    limits: list[int] = []

    def recording_read(self: ChatSession, *args: Any, **kwargs: Any) -> Any:
        limits.append(cast(int, kwargs["limit"]))
        return original(self, *args, **kwargs)

    def fail_load_active(self: ChatSession) -> list[ChatMessage]:
        raise AssertionError("History must use bounded Session reads")

    monkeypatch.setattr(ChatSession, "load_history_records", recording_read)
    monkeypatch.setattr(ChatSession, "load_active", fail_load_active)

    data = _data(_call(manager, session, {"action": "search", "query": "needle", "limit": 1}))

    assert [item["message_id"] for item in data["items"]] == [needle.id]
    assert len(limits) == 3
    assert max(limits) == 128
    assert _data(_call(manager, session, {"action": "read", "limit": 1}))["items"]


def test_cursor_is_refused_for_another_action_or_session_and_when_corrupted(
    tmp_path: Path,
) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    session.append(ChatMessage.user("first"))
    session.append(ChatMessage.user("second"))
    session.append(_checkpoint())
    first_page = _data(_call(manager, session, {"action": "read", "limit": 1}))
    cursor = first_page["next_cursor"]

    wrong_action = _call(manager, session, {"action": "search", "cursor": cursor})
    replacement = "x" if cursor[0] != "x" else "y"
    corrupted = _call(
        manager,
        session,
        {"action": "read", "cursor": f"{replacement}{cursor[1:]}"},
    )

    other = manager.create("agent", session_id="session-two")
    for message in session.load():
        other.append(message)
    wrong_session = _call(manager, other, {"action": "read", "cursor": cursor})

    assert wrong_action["error"]["code"] == "invalid_cursor"
    assert corrupted["error"]["code"] == "invalid_cursor"
    assert wrong_session["error"]["code"] == "invalid_cursor"


def _paged_session(tmp_path: Path, count: int = 3) -> tuple[ChatSessionManager, ChatSession]:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    for index in range(count):
        session.append(ChatMessage.user(f"entry {index}"))
    session.append(_checkpoint())
    return manager, session


def test_cursor_continuation_rejects_conflicting_scope_arguments(tmp_path: Path) -> None:
    manager, session = _paged_session(tmp_path)
    cursor = _data(_call(manager, session, {"action": "read", "limit": 1}))["next_cursor"]

    result = _call(
        manager,
        session,
        {"action": "read", "cursor": cursor, "checkpoint": 1},
    )

    assert result["error"]["code"] == "invalid_arguments"
    assert result["error"]["message"] == (
        "This cursor continues a read with checkpoint null, but checkpoint is 1. To "
        'continue, call history with {"action": "read", "cursor": ...} only; to change '
        "checkpoint, omit cursor and start again."
    )


def test_cursor_continuation_accepts_repeated_fields_and_a_new_limit(tmp_path: Path) -> None:
    manager, session = _paged_session(tmp_path, count=5)
    first = _data(_call(manager, session, {"action": "read", "checkpoint": 1, "limit": 1}))

    repeated = _data(
        _call(
            manager,
            session,
            {"action": "read", "cursor": first["next_cursor"], "checkpoint": 1, "limit": 3},
        )
    )

    assert [message["content"] for message in _messages(first)] == ["entry 0"]
    assert [message["content"] for message in _messages(repeated)] == [
        "entry 1",
        "entry 2",
        "entry 3",
    ]
    assert "note" not in repeated
    rest = _data(_call(manager, session, {"action": "read", "cursor": repeated["next_cursor"]}))
    assert [message["content"] for message in _messages(rest)] == ["entry 4"]


def test_records_omit_replay_accounting_and_presentation_fields(tmp_path: Path) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    answer = ChatMessage.assistant(
        model="openai/gpt",
        content="The answer.",
        reasoning="Visible reasoning.",
        reasoning_meta={"signature": "opaque"},
        reasoning_scope="scope",
        reasoning_timing={
            "started_at": "2026-05-01T12:00:00+00:00",
            "completed_at": "2026-05-01T12:00:01+00:00",
            "duration_ms": 1000,
        },
        usage={"input_tokens": 10},
    )
    opaque_only = ChatMessage.assistant(
        model="openai/gpt", content=None, reasoning_meta={"encrypted": "opaque"}
    )
    fallback = ChatMessage.note(
        "Model openai/gpt unavailable.",
        model_fallback=ModelFallback(from_model="openai/gpt", to_model="anthropic/claude"),
    )
    for message in (answer, opaque_only, fallback, _checkpoint()):
        session.append(message)

    roles = ["assistant", "note"]
    read = _messages(_data(_call(manager, session, {"action": "read", "roles": roles})))
    around = _messages(
        _data(
            _call(manager, session, {"action": "around", "message_id": answer.id, "roles": roles})
        )
    )

    for records in (read, around):
        assert [record["id"] for record in records] == [answer.id, opaque_only.id, fallback.id]
        assert records[0]["content"] == "The answer."
        assert records[0]["reasoning"] == "Visible reasoning."
        assert records[2]["content"] == "Model openai/gpt unavailable."
        for record in records:
            assert not {
                "reasoning_meta",
                "reasoning_scope",
                "reasoning_timing",
                "usage",
                "timing",
                "tool_display",
                "model_fallback",
            } & set(record)


@pytest.mark.parametrize(
    ("arguments", "message"),
    [
        (
            {"action": "read", "checkpoint": 1, "limit": 3, "query": "deploy"},
            'read takes no query. To find records containing it, call history with {"action": '
            '"search", "query": "deploy", "checkpoint": 1, "limit": 3}; to read records in '
            "order, omit query.",
        ),
        (
            {"action": "overview", "query": "deploy"},
            'overview takes no query. To find records containing it, call history with {"action":'
            ' "search", "query": "deploy"}; to list the checkpoint sections, omit query.',
        ),
        (
            {"action": "search", "query": "deploy", "message_id": "m-1"},
            "search takes no message_id. To read records around that message, call history with "
            '{"action": "around", "message_id": "m-1"}; otherwise omit message_id.',
        ),
        (
            {"action": "search", "query": "deploy", "direction": "end"},
            "search returns records oldest first; direction applies only to read. Omit "
            "direction, or use action read to page from the newest records.",
        ),
    ],
)
def test_fields_asking_for_another_action_name_the_corrected_call(
    tmp_path: Path, arguments: dict[str, Any], message: str
) -> None:
    manager, session = _paged_session(tmp_path)

    result = _call(manager, session, arguments)

    assert result["ok"] is False
    assert result["error"]["code"] == "invalid_arguments"
    assert result["error"]["message"] == message


@pytest.mark.parametrize(
    ("arguments", "note"),
    [
        ({"action": "overview", "checkpoint": 1}, "Ignored checkpoint: not used by overview."),
        (
            {"action": "search", "query": "entry", "before": 1, "direction": "start"},
            "Ignored before, direction: not used by search. To read records around one, use "
            "action around with its message_id.",
        ),
        ({"action": "read", "match": "phrase"}, "Ignored match: not used by read."),
    ],
)
def test_fields_an_action_does_not_use_are_noted_and_the_call_runs(
    tmp_path: Path, arguments: dict[str, Any], note: str
) -> None:
    manager, session = _paged_session(tmp_path)

    data = _data(_call(manager, session, arguments))

    assert data["items"]
    assert data["note"] == note


def test_around_notes_an_unused_limit(tmp_path: Path) -> None:
    manager, session = _paged_session(tmp_path)
    anchor = _messages(_data(_call(manager, session, {"action": "read", "limit": 1})))[0]

    data = _data(
        _call(manager, session, {"action": "around", "message_id": anchor["id"], "limit": 1})
    )

    assert data["note"] == "Ignored limit: around returns before + after + 1 records."
    assert len(data["items"]) == 3


def test_oversized_unicode_record_continues_losslessly_under_50_kib(tmp_path: Path) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    original = ChatMessage.user("start-" + "🙂" * 40_000 + "-end")
    session.append(original)
    session.append(_checkpoint())

    result = _call(manager, session, {"action": "read", "limit": 1})
    chunks: list[str] = []
    while True:
        assert _serialized_size(result) <= HISTORY_RESULT_MAX_BYTES
        data = _data(result)
        assert len(data["items"]) == 1
        segment = data["items"][0]["segment"]
        chunks.append(segment["record_json"])
        if not data["has_more"]:
            assert segment["complete"] is True
            break
        result = _call(
            manager,
            session,
            {"action": "read", "cursor": data["next_cursor"]},
        )

    assert json.loads("".join(chunks)) == original.to_dict()


def test_empty_roles_and_no_search_matches_are_successes(tmp_path: Path) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    session.append(ChatMessage.user("known text"))
    session.append(_checkpoint())

    empty_roles = _data(_call(manager, session, {"action": "read", "roles": []}))
    no_matches = _data(_call(manager, session, {"action": "search", "query": "absent term"}))

    assert empty_roles["items"] == []
    assert empty_roles["has_more"] is False
    assert no_matches["items"] == []
    assert no_matches["has_more"] is False


@pytest.mark.parametrize(
    "arguments",
    [
        {"action": "search", "query": " "},
        {"action": "around", "message_id": " "},
        {"action": "read", "roles": ["user", "user"]},
        {"action": "around", "message_id": "x", "before": 101},
    ],
)
def test_invalid_action_arguments_return_invalid_arguments(
    tmp_path: Path,
    arguments: dict[str, Any],
) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    session.append(_checkpoint())

    result = _call(manager, session, arguments)

    assert result["error"]["code"] == "invalid_arguments"


def test_missing_checkpoint_reports_only_available_range(tmp_path: Path) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    session.append(ChatMessage.user("secret content"))
    session.append(_checkpoint())

    result = _call(manager, session, {"action": "read", "checkpoint": 7})

    assert result["error"]["code"] == "checkpoint_not_found"
    assert "1-1" in result["error"]["message"]
    assert "secret content" not in result["error"]["message"]


def test_session_read_failure_returns_history_session_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    manager = ChatSessionManager(tmp_path)
    session = manager.create("agent", session_id="session-one")
    session.append(_checkpoint())

    def fail_load(self: ChatSession, *, snapshot_sequence: int | None = None) -> Any:
        raise OSError("database read failed")

    monkeypatch.setattr(ChatSession, "resolve_history_snapshot", fail_load)

    result = _call(manager, session, {"action": "read"})

    assert result["error"]["code"] == "history_session_error"
