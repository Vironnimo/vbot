# Archived Write Tool

Frozen source before retirement. Use apply_patch Add File for creation and full replacement. Restore only in a worktree; reconcile shared integration files with current source instead of overwriting them. The archive is outside runtime discovery.
