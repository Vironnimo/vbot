# Archived Computer Use (Cua Driver generation)

The first Computer Use Extension: one `computer` Tool with window targets, view ids,
background/foreground delivery, element refs and the external Cua Driver. Replaced
in 2026-10 by the rebuilt Extension at the same path. Files keep their original
repository paths; shared files (provider probe scenarios, vbot-cli reference, runtime
wiring test) are snapshots of the source commit and must be reconciled with current
source before any restoration. Restore only in a worktree.
