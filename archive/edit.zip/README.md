# Archived edit Tool

Frozen source at e9952ea4f7332b20fd47d600bb3b914a02b4b4f9. Original repository paths are preserved.
The edit implementation, focused tests, prior documentation, and original shared integration/probe files are included.
Shared matching and filesystem helpers remain active in vBot; their copies here are historical reference only.
Restore only in a worktree, reconciling shared files with current source. This archive is not an installable runtime package.
