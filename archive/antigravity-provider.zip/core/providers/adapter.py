"""ProviderAdapter abstract base class.

Defines the interface that all provider adapters must implement.
Adapters translate between vBot's request format and the provider's
wire protocol."""

from __future__ import annotations

import ipaddress
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Callable, Iterator, Mapping, Sequence
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import UTC, tzinfo
from typing import TYPE_CHECKING, Any, ClassVar, Final, Literal, cast
from urllib.parse import urlparse

import httpx

from core.models.models import Model
from core.providers._tool_calls import (
    ANTHROPIC_MESSAGES_TOOL_CALL_ID_PROFILE,
    INVALID_TOOL_CALL_NAME,
    MALFORMED_TOOL_ARGUMENT_PREVIEW_CHARS,
    MISTRAL_TOOL_CALL_ID_PROFILE,
    RESPONSES_TOOL_CALL_ID_PROFILE,
    TOOL_CALL_ARGUMENT_SEQUENCE_INDEX_FIELD,
    TOOL_CALL_ARGUMENT_SEQUENCE_LENGTH_FIELD,
    TOOL_CALL_REJECTION_FIELD,
    TOOL_RESULT_CONTENT_BLOCKS_FIELD,
    JsonObject,
    ToolCallIdProfile,
    build_tool_call_rejection,
    canonical_tool_result_is_error,
    normalize_tool_call_candidate,
    normalize_tool_call_candidates,
    normalize_tool_call_ids,
    project_tool_result_content_fallbacks,
    tool_result_content_blocks,
)
from core.providers._tool_result_text import (
    neutralize_system_reminder_tags,
    tool_result_function_response,
    tool_result_text,
)
from core.providers.http import classify_http_status
from core.providers.providers import RequestInput, curated_output_limit
from core.providers.reasoning import (
    ReasoningIntent,
    ReasoningReplayFidelity,
    ReasoningReplayPolicy,
)
from core.providers.reasoning_dialects import describe_profile_reasoning
from core.providers.wire_profile import Protocol, WireProfile
from core.providers.wire_profiles import WireBinding, standalone_wire_binding
from core.utils.errors import ProviderError

if TYPE_CHECKING:
    from core.debug import DebugContext, ProviderDebugRecorder
    from core.providers.providers import ConnectionConfig, ProviderConfig

__all__ = [
    "ANTHROPIC_MESSAGES_TOOL_CALL_ID_PROFILE",
    "IMAGE_WIRE_MEDIA_TYPES",
    "INVALID_TOOL_CALL_NAME",
    "JsonObject",
    "MALFORMED_TOOL_ARGUMENT_PREVIEW_CHARS",
    "MISTRAL_TOOL_CALL_ID_PROFILE",
    "ModelLookup",
    "ProviderAdapter",
    "RESPONSES_TOOL_CALL_ID_PROFILE",
    "RequestContextText",
    "TERMINAL_OUTCOMES",
    "TERMINAL_OUTCOME_CONTENT_FILTERED",
    "TERMINAL_OUTCOME_ERROR",
    "TERMINAL_OUTCOME_OUTPUT_TRUNCATED",
    "TERMINAL_OUTCOME_STOP",
    "TERMINAL_OUTCOME_TOOL_CALLS",
    "TERMINAL_OUTCOME_UNKNOWN",
    "TOOL_CALL_ARGUMENT_SEQUENCE_INDEX_FIELD",
    "TOOL_CALL_ARGUMENT_SEQUENCE_LENGTH_FIELD",
    "TOOL_CALL_REJECTION_FIELD",
    "TOOL_RESULT_CONTENT_BLOCKS_FIELD",
    "TerminalOutcome",
    "ToolCallIdProfile",
    "build_tool_call_rejection",
    "canonical_tool_result_is_error",
    "estimate_wire_request_input_tokens",
    "is_request_context_message",
    "neutralize_system_reminder_tags",
    "normalize_tool_call_candidate",
    "normalize_tool_call_candidates",
    "normalize_tool_call_ids",
    "project_tool_result_content_fallbacks",
    "request_input_budget",
    "resolve_request_input_budget",
    "terminal_outcome_from_response",
    "tool_result_content_blocks",
    "tool_result_function_response",
    "tool_result_text",
]

ModelLookup = Callable[[str], "Model | None"]

TerminalOutcome = Literal[
    "stop",
    "tool_calls",
    "output_truncated",
    "content_filtered",
    "error",
    "unknown",
]

TERMINAL_OUTCOME_STOP: Final[TerminalOutcome] = "stop"

TERMINAL_OUTCOME_TOOL_CALLS: Final[TerminalOutcome] = "tool_calls"

TERMINAL_OUTCOME_OUTPUT_TRUNCATED: Final[TerminalOutcome] = "output_truncated"

TERMINAL_OUTCOME_CONTENT_FILTERED: Final[TerminalOutcome] = "content_filtered"

TERMINAL_OUTCOME_ERROR: Final[TerminalOutcome] = "error"

TERMINAL_OUTCOME_UNKNOWN: Final[TerminalOutcome] = "unknown"

TERMINAL_OUTCOMES: Final[frozenset[TerminalOutcome]] = frozenset(
    {
        TERMINAL_OUTCOME_STOP,
        TERMINAL_OUTCOME_TOOL_CALLS,
        TERMINAL_OUTCOME_OUTPUT_TRUNCATED,
        TERMINAL_OUTCOME_CONTENT_FILTERED,
        TERMINAL_OUTCOME_ERROR,
        TERMINAL_OUTCOME_UNKNOWN,
    }
)

IMAGE_WIRE_MEDIA_TYPES = frozenset({"image/jpeg", "image/png", "image/gif", "image/webp"})


class RequestContextText(str):
    """Content of a user-role request message that Chat renders as context, not a user turn.

    Chat marks the System Reminders and quoted Channel observations it renders
    from Session notes with this type, so an Adapter can tell them from the
    user's own messages (GitHub Copilot's ``x-initiator``). Every string
    operation returns a plain ``str``, so content rewritten after rendering
    loses the mark and counts as a user turn again.
    """

    __slots__ = ()


def is_request_context_message(message: Mapping[str, Any]) -> bool:
    """Return whether ``message`` is Chat-rendered context rather than a user turn."""

    return message.get("role") == "user" and isinstance(message.get("content"), RequestContextText)


_REQUEST_INPUT_BUDGET: ContextVar[tuple[str, RequestInput] | None] = ContextVar(
    "provider_request_input_budget", default=None
)


@contextmanager
def request_input_budget(model_id: str, request_input: RequestInput) -> Iterator[None]:
    """Scope Chat's complete Context projection to one send, including inner wire routing.

    The projection keeps its measured and estimated parts apart, so the
    Adapter's output clamp applies the estimation margin to the estimated part
    only. This local budget never enters request kwargs or a Provider payload.
    """
    with _REQUEST_INPUT_BUDGET.set((model_id, request_input)):
        yield


def resolve_request_input_budget(
    model_id: str, local_estimate: int | Callable[[], int]
) -> RequestInput:
    """Use the scoped projection, else a local estimate evaluated only when needed."""
    budget = _REQUEST_INPUT_BUDGET.get()
    if budget is not None and budget[0] == model_id:
        return budget[1]
    return RequestInput.estimate(local_estimate() if callable(local_estimate) else local_estimate)


def estimate_wire_request_input_tokens(
    adapter: Any,
    messages: Sequence[Mapping[str, Any]],
    *,
    model_id: str,
    tools: Sequence[Mapping[str, Any]] | None = None,
) -> int:
    """Estimate one wire request, retaining the generic fallback for test doubles.

    Production Adapters inherit :meth:`ProviderAdapter.estimate_request_input_tokens`.
    The fallback keeps lightweight duck-typed Adapters used by integration
    seams on the established Chat Completions estimate until they implement the
    richer Adapter contract.
    """

    from core.utils.tokens import estimate_request_input_tokens, split_reported_reasoning

    # Replayed reasoning with a reported count costs that count on every wire.
    messages, reported = split_reported_reasoning(messages)
    estimator = getattr(adapter, "estimate_request_input_tokens", None)
    if callable(estimator):
        estimated = estimator(messages, model_id=model_id, tools=tools)
        if isinstance(estimated, int) and not isinstance(estimated, bool) and estimated >= 0:
            return estimated + reported

    estimated, _ = estimate_request_input_tokens(messages, tools, model_id=model_id)
    return estimated + reported


def is_local_provider_base_url(base_url: str | None) -> bool:
    """Whether a provider base URL points at a loopback or private-network host.

    Local inference servers (Ollama, llama.cpp, vLLM) answer from such hosts.
    Matches ``localhost`` and ``*.localhost`` / ``*.local`` names plus loopback,
    RFC1918 private, and link-local IP literals.
    """
    if not base_url:
        return False
    host = urlparse(base_url).hostname
    if not host:
        return False
    host = host.lower()
    if host == "localhost" or host.endswith((".localhost", ".local")):
        return True
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        return False
    return address.is_loopback or address.is_private or address.is_link_local


class ProviderAdapter(ABC):
    """Abstract base class for provider adapters.

    Every adapter must implement ``send()`` for non-streaming requests
    and ``stream()`` for streaming (SSE) requests.  The exact request
    and response types are intentionally kept as plain dicts so that
    the adapter layer can stabilise independently of the chat-layer
    data types introduced in Phase 2.

    ``stream()`` yields normalized, provider-agnostic delta dicts rather
    than raw provider SSE chunks.  Supported delta shapes are:

    - ``{"type": "content_delta", "text": " token"}``
    - ``{"type": "reasoning_delta", "text": " thinking"}``
    - ``{"type": "tool_call_delta", "id": "...", "name_delta": "...", "arguments_delta": "..."}``
      or ``{"type": "tool_call_delta", "slot": 0, "id": "...", ...}``, where
      ``id`` may be omitted until a later fragment for index-based wires.
      A Provider can reject the entire attempt with ``rejection`` from
      ``build_tool_call_rejection()``. Emit it before advancing to another
      call, text, reasoning or finish, since Chat may dispatch the call then.
    - ``{"type": "heartbeat"}`` (transport liveness only; not Model progress)
    - ``{"type": "reasoning_meta", "reasoning_meta": {...}}``
    - ``{"type": "usage", "input_tokens": 1, "output_tokens": 1}``
      (optional ``cache_read_tokens`` / ``cache_write_tokens`` ints when the
      provider reports prompt-cache usage, plus optional ``reasoning_tokens``
      as a subset of output; ``input_tokens`` is always the total prompt
      including cached tokens; either primary token counter may be omitted when
      the upstream Provider reports only the other one. A known
      ``reported_cost_usd`` can also arrive without token counts. Chat
      estimates the missing counters. Optional ``reported_output_tokens_per_second`` when
      the Provider measured its own decode speed, as local servers do, plus
      ``reported_output_duration_ms`` for its actual measurement window)
    - ``{"type": "finish", "reason": "stop" | "tool_calls" |
      "output_truncated" | "content_filtered" | "error" | "unknown"}``

    ``reasoning_meta`` is internal to the adapter/chat boundary and must
    remain opaque to callers outside the chat core.

    **Debug hooks:**

    When debug mode is enabled, the runtime passes a
    ``ProviderDebugRecorder`` into the adapter constructor; the adapter
    builds its HTTP client through ``http.build_async_client``,
    which wires HTTP capture into a single transport. A stateful non-HTTP
    transport may feed one canonical exchange directly to the same recorder;
    OpenAI Subscription WebSocket streaming is the sanctioned implementation.
    The chat loop calls
    ``set_debug_context()`` before each ``send()`` / ``stream()`` call;
    the base implementation forwards the context to the recorder, which
    the capture transport reads per request.
    """

    # Class-level default so the optional debug hook resolves even on
    # subclasses (and test doubles) that do not call ``super().__init__()``.
    _debug_recorder: ProviderDebugRecorder | None = None

    WIRE_PROTOCOLS: ClassVar[tuple[Protocol, ...]] = ("chat_completions",)
    """Wire protocols this Adapter implements; the first is its default."""

    _wire_binding: WireBinding | None = None

    local_endpoint: bool = False
    """Whether this Adapter's Connection reaches a local inference server.

    Set by the Provider runtime from the Connection's effective base URL
    (:func:`is_local_provider_base_url`); streaming callers turn their stall
    guards off for such endpoints, whose prefill can be silent for minutes.
    """

    display_timezone: tzinfo = UTC
    """The zone in which this Adapter's errors name wall-clock times.

    Set by the Provider runtime from the Settings timezone; an error naming a
    Provider-reported reset (such as a reached usage limit) states it there.
    """

    def __init__(
        self,
        model_lookup: ModelLookup | None = None,
        debug_recorder: ProviderDebugRecorder | None = None,
    ) -> None:
        """Store the Model lookup and debug recorder."""
        self._model_lookup = model_lookup
        self._debug_recorder = debug_recorder

    _availability_check: Callable[[], None] | None = None

    def bind_availability(self, check: Callable[[], None]) -> None:
        """Bind this Adapter to its live Provider registration."""
        self._availability_check = check

    def ensure_available(self) -> None:
        """Refuse a new request after the owning registration was retired."""
        if self._availability_check is not None:
            self._availability_check()

    # ------------------------------------------------------------------
    # Debug hooks
    # ------------------------------------------------------------------

    def set_debug_context(self, ctx: DebugContext) -> None:
        """Forward the per-request debug context to the recorder.

        Called by the chat loop before each ``send()`` or ``stream()``
        call. The context is **never** part of ``**kwargs`` and must not
        leak into provider payloads. No-op when debug mode is off.

        Args:
            ctx: Immutable debug context with run / agent / session /
                provider / model identifiers and iteration number.
        """
        if self._debug_recorder is not None:
            self._debug_recorder.set_context(ctx)

    # ------------------------------------------------------------------
    # Wire profile
    # ------------------------------------------------------------------

    def bind_wire_profiles(self, binding: WireBinding) -> None:
        """Bind the Runtime's wire profiles and learned facts for this Adapter's Connection."""

        self._wire_binding = binding

    @property
    def wire(self) -> WireBinding:
        """Profiles and learned facts of this Adapter's Connection.

        The Runtime binds its shared view (bundled and Custom Provider data,
        learned facts). An Adapter constructed directly resolves against the
        bundled files and its own Model lookup on its first configured
        Connection (the first one with the Adapter's connection mode, when it
        was given one) and keeps learned facts in memory only.
        """

        binding = self._wire_binding
        if binding is None:
            binding = type(self)._standalone_wire_binding(
                getattr(self, "_config", None),
                getattr(self, "_model_lookup", None),
                connection_mode=getattr(self, "_connection_mode", None),
            )
            self._wire_binding = binding
        return binding

    def wire_profile(self, model_id: str) -> WireProfile:
        """Return the resolved wire profile for ``model_id`` on this Adapter's Connection."""

        return self.wire.profile(model_id)

    @classmethod
    def _standalone_wire_binding(
        cls,
        config: ProviderConfig | None,
        model_lookup: ModelLookup | None,
        *,
        connection_mode: str | None = None,
    ) -> WireBinding:
        connections = getattr(config, "connections", ()) or ()
        connection = next(
            (
                candidate
                for candidate in connections
                if connection_mode is not None
                and getattr(candidate, "mode", None) == connection_mode
            ),
            connections[0] if connections else None,
        )
        return standalone_wire_binding(
            provider_id=str(getattr(config, "id", "") or ""),
            connection_id=str(getattr(connection, "id", "")) if connection is not None else "",
            protocols=cls.WIRE_PROTOCOLS,
            model_lookup=model_lookup,
        )

    def _refuse_unadmitted_model(self, model_id: str) -> None:
        """Refuse a request the wire profile does not admit, before any network I/O.

        Raises:
            ProviderError: (not retryable) when the Model is restricted or
                retired on this Adapter's Connection; the profile's admission
                message explains why.
        """

        profile = self.wire_profile(model_id)
        admission = profile.admission
        if admission.state == "available":
            return
        refusal = f"Model '{profile.model_id}' is {admission.state} on this Connection"
        raise ProviderError(
            f"{refusal}: {admission.message}" if admission.message else refusal,
            retryable=False,
        )

    # ------------------------------------------------------------------
    # History shaping policy
    # ------------------------------------------------------------------

    def reasoning_replay_policy(self, model_id: str) -> ReasoningReplayPolicy:
        """Return how persisted assistant reasoning replays for ``model_id``.

        The chat layer queries this once per request build and shapes the
        request history accordingly; adapters must not re-implement
        history-wide reasoning strips on top of it. ``model_id`` is part of the
        contract because one Provider can narrow an individual Model without
        reducing every other Model on the same Adapter. The wire profile's
        ``replay.scope`` decides.
        """
        return self.wire_profile(model_id).replay.scope

    def reasoning_replay_fidelity(self, model_id: str) -> ReasoningReplayFidelity:
        """Return which class of reasoning state this wire carries back.

        The base serializers consult this once per Assistant message build and
        emit exactly one class: opaque meta when the declaration allows or
        prefers it and the turn captured meta, otherwise the readable text —
        never both. Adapters must not re-implement class filtering on top of
        the declaration. ``model_id`` is part of the contract for parity with
        ``reasoning_replay_policy`` because one adapter can route models to
        different wires. The wire profile's ``replay.fidelity`` decides.
        """
        return self.wire_profile(model_id).replay.fidelity

    def on_demand_tools(self, model_id: str) -> bool:
        """Return whether ``model_id`` can be served On-demand Tools on this route.

        False for a route whose Model calls only listed Tools: Chat gives it
        a fixed call_tool proxy instead. True keeps native unlisted calls.
        The wire profile's ``request.on_demand_tools`` decides.
        """
        return self.wire_profile(model_id).request.on_demand_tools

    def effort_updates(self, model_id: str) -> bool:
        """Return whether a thinking effort change can reach ``model_id`` as an effort update.

        True for a route that switches the effort mid-conversation, so a change
        keeps its prompt cache (``core.providers.effort_updates``): Chat then
        sends the history's effort updates with the effort it started from. An
        Adapter whose codec renders effort updates returns the wire profile's
        ``reasoning.effort_updates``; every other Adapter returns false.
        """
        del model_id
        return False

    # ------------------------------------------------------------------
    # Reasoning render description
    # ------------------------------------------------------------------

    def _model_max_output_tokens(self, model_id: str) -> int | None:
        """The model's catalog output ceiling, or ``None`` when it is unknown.

        Strips a ``::variant`` connection suffix and tolerates a missing lookup
        or model. A gateway whose ids need richer resolution (flat vendor-prefixed
        namespaces) overrides this.
        """

        lookup = getattr(self, "_model_lookup", None)
        if lookup is None:
            return None
        model = lookup(model_id.split("::", 1)[0])
        if model is None:
            return None
        ceiling = model.max_output_tokens
        if isinstance(ceiling, int) and not isinstance(ceiling, bool) and ceiling > 0:
            return ceiling
        return None

    def _model_context_window(self, model_id: str) -> int | None:
        """The Model's catalog context window, or ``None`` when unknown."""

        lookup = getattr(self, "_model_lookup", None)
        if lookup is None:
            return None
        model = lookup(model_id.split("::", 1)[0])
        if model is None:
            return None
        context_window = model.context_window
        if (
            isinstance(context_window, int)
            and not isinstance(context_window, bool)
            and context_window > 0
        ):
            return context_window
        return None

    def reported_context_window(self, model_id: str) -> int | None:
        """The Context window the Provider reported for ``model_id`` on this Connection.

        The window a Provider rejection stated (a learned wire fact); an
        Adapter whose server reports the window it serves (a loaded local
        instance) overrides this. ``None`` when nothing was reported. A
        reported window wins over catalog values and estimates: the Adapter's
        output clamp and Chat's Context capacity both budget against it.
        """
        return self.wire.learned_context_window(model_id)

    def _request_context_window(self, model_id: str) -> int:
        """The Context window a request for ``model_id`` must fit on this Adapter's wire.

        Output clamping and the local overflow check budget against it: the
        reported window (``reported_context_window``), else the catalog window
        through the read-side chain (``resolve_context_window``).
        """
        from core.providers.providers import resolve_context_window

        reported = self.reported_context_window(model_id)
        if reported is not None:
            return reported
        return resolve_context_window(
            self._model_context_window(model_id), getattr(self, "_config", None)
        )

    def input_token_limit(self, model_id: str) -> int | None:
        """Provider-reported maximum input tokens of one request below the context window.

        Some Providers accept less input than the Model's context window holds.
        Chat sizes the Context against the smaller value (``context_capacity``)
        and Compaction triggers against it; request builders refuse a larger
        input before I/O. Unknown limits stay absent.
        """
        del model_id
        return None

    def minimum_output_tokens(
        self, model_id: str, thinking_effort: str | None, *, explicit_limit: Any = None
    ) -> int:
        """Output capacity needed to keep this route's native thinking unchanged.

        Chat uses this reservation to compact before shrinking Context would
        change the thinking configuration. Request builders apply the same
        floor while clamping output. Only Messages thinking budgets need one;
        adaptive thinking and effort-only wires return zero.
        """
        from core.providers.reasoning_dialects import render_reasoning

        profile = self.wire_profile(model_id)
        if profile.protocol != "messages" or profile.reasoning.supported is False:
            return 0
        if profile.reasoning.dialect != "anthropic_thinking":
            return 0
        config = getattr(self, "_config", None)
        defaults = getattr(config, "defaults", None) or {}
        ceiling = self._model_max_output_tokens(model_id)
        allowance = next(
            (
                value
                for value in (
                    explicit_limit,
                    curated_output_limit(profile.request.output_limit_default, ceiling),
                    ceiling,
                    defaults.get("max_tokens"),
                )
                if isinstance(value, int) and not isinstance(value, bool) and value > 0
            ),
            None,
        )
        cap = profile.request.output_limit_cap
        if cap is not None:
            allowance = cap if allowance is None else min(allowance, cap)
        payload: dict[str, Any] = {}
        wire = profile.reasoning
        render_reasoning(
            wire,
            wire.plan(thinking_effort, output_allowance=allowance),
            payload,
            output_allowance=allowance,
        )
        thinking = payload.get("thinking", {})
        budget = thinking.get("budget_tokens")
        return budget + 1 if isinstance(budget, int) and budget > 0 else 0

    def describe_reasoning_render(self, model_id: str, effort: str | None) -> ReasoningIntent:
        """Return the provider-neutral reasoning decision a request with ``effort`` carries.

        Describes this Adapter's resolved wire profile for ``model_id``: a
        known Model that does not reason reports ``off``; otherwise the
        profile plans ``effort`` exactly like the request render and its
        reasoning dialect reports what the rendered request carries.
        """

        return describe_profile_reasoning(self.wire_profile(model_id), effort)

    # ------------------------------------------------------------------
    # Wire media capability
    # ------------------------------------------------------------------

    def wire_media_support(self, model_id: str) -> frozenset[str]:
        """Return the concrete media types this adapter's wire carries natively.

        The chat layer intersects this with the model's advertised input
        modalities to decide whether an attachment goes native or is degraded;
        the adapter owns the *format* granularity (e.g. ``"image/png"``,
        ``"audio/wav"``, ``"application/pdf"``) because that is the wire fact.
        ``model_id`` is part of the contract for parity with
        ``reasoning_replay_policy`` and because one adapter can route models to
        different wires; concrete adapters may also branch on their connection
        mode. The wire profile's ``media.types`` decides.
        """
        return self.wire_profile(model_id).media.types

    # ------------------------------------------------------------------
    # Request-context estimation
    # ------------------------------------------------------------------

    def image_size_limit(self, model_id: str) -> int | None:
        """Known per-image encoded-file byte ceiling, excluding base64 overhead.

        Callers can prepare compatible copies before serialization. Unknown
        limits stay absent; request-body and image-count limits remain separate.
        """
        return self.wire_profile(model_id).media.image_max_bytes

    def request_body_limit(self, model_id: str) -> int | None:
        """Verified maximum serialized request bytes for this Model's wire, if known.

        Concrete wires enforce this before network I/O and raise
        ProviderRequestTooLargeError with the actual byte count; an HTTP 413
        raises the same error without sizes. Chat then retires already
        delivered images and submits a smaller request. Unknown limits stay
        absent; this is independent of tokens. The default reads the wire
        profile's ``media.request_max_bytes``.
        """
        return self.wire_profile(model_id).media.request_max_bytes

    def request_image_limit(self, model_id: str) -> int | None:
        """Configured or learned maximum image count for one request, if known.

        Counts every image in the request, earlier turns and Tool Results
        included. Chat keeps requests within it by retiring the oldest
        delivered images; unknown limits stay absent. The default reads the
        wire profile's ``media.request_max_images``.
        """
        return self.wire_profile(model_id).media.request_max_images

    def estimate_request_input_tokens(
        self,
        messages: Sequence[Mapping[str, Any]],
        *,
        model_id: str,
        tools: Sequence[Mapping[str, Any]] | None = None,
    ) -> int:
        """Estimate the context consumed by this Adapter's rendered request.

        Chat uses this same wire-owned estimate for pre-send Context protection
        and automatic Compaction. The default fits Chat Completions-shaped
        requests; Adapters that render a different wire representation override
        it so all local Context decisions budget the request that is actually
        sent rather than the persisted canonical history.
        """

        from core.utils.tokens import estimate_request_input_tokens

        estimated, _ = estimate_request_input_tokens(messages, tools, model_id=model_id)
        return estimated

    # ------------------------------------------------------------------
    # Task endpoints
    # ------------------------------------------------------------------

    @classmethod
    def openai_compatible_base_url(cls, base_url: str) -> str:
        """Return the base of this Provider's OpenAI-compatible HTTP API.

        Task wire clients (embeddings, images, speech, video, music) append
        OpenAI-compatible endpoint paths such as ``/embeddings`` to this base.
        Most Providers configure that base directly and return it unchanged;
        Adapters whose configured base addresses a native API map it to their
        OpenAI-compatible prefix.
        """

        return base_url

    @classmethod
    def classify_task_http_status(
        cls,
        status_code: int,
        *,
        idempotent: bool,
        extra_retryable: set[int] | None,
        detail: str,
        response_headers: httpx.Headers,
    ) -> None:
        """Raise the Provider error a task endpoint's HTTP status reports.

        Task wire clients (``ProviderTaskClient``) classify their responses
        through this hook, so a Provider whose error semantics differ from the
        shared status policy (for example an invalid key reported as HTTP 400,
        or an exhausted daily quota as HTTP 429) applies them to task requests
        too. The default is the shared policy.
        """

        classify_http_status(
            status_code,
            idempotent=idempotent,
            extra_retryable=extra_retryable,
            detail=detail,
            response_headers=response_headers,
        )

    # ------------------------------------------------------------------
    # Catalog normalization policy
    # ------------------------------------------------------------------

    @classmethod
    def finalize_discovered_model(
        cls,
        model: Model,
        connection: ConnectionConfig | None,
    ) -> Model:
        """Apply Connection-specific facts after catalog entry normalization.

        Most Providers expose identical Model facts on every Connection and
        therefore return the normalized Model unchanged. Adapters override
        this only when the listing payload is ambiguous without Connection
        context, such as Ollama's direct Cloud catalog omitting the
        ``remote_host`` marker used by a local Ollama proxy.
        """

        del connection
        return model

    # ------------------------------------------------------------------
    # Per-request conversation context
    # ------------------------------------------------------------------

    def fast_mode_kwargs(self, model_id: str, *, enabled: bool) -> JsonObject:
        """Translate the Chat's speed preference for a route that offers Fast.

        Fast is opt-in, independent of Reasoning. Only Responses profiles that
        declare it may request priority processing; other routes stay unchanged.
        """
        if not enabled:
            return {}
        profile = self.wire_profile(model_id)
        if profile.protocol == "responses" and profile.request.fast_mode:
            return {"service_tier": "priority"}
        return {}

    def request_context_kwargs(
        self,
        *,
        agent_id: str,
        session_id: str,
        project_id: str | None = None,
        prompt_cache_affinity_id: str | None = None,
        session_generation_id: str | None = None,
        request_kind: Literal["chat", "compaction", "utility"] = "chat",
    ) -> JsonObject:
        """Return extra per-request kwargs derived from the conversation identity.

        The chat layer calls this once per provider request and merges the
        result into the ``send()``/``stream()`` kwargs, letting an adapter turn
        Session identity stays available for stateful transport continuation;
        ``prompt_cache_affinity_id`` is a separate, provider-neutral routing
        lineage inherited only by cache-compatible forks. Concrete adapters map
        either identity onto their own wire without the chat layer knowing any
        provider specifics. The ABC default adds nothing, so no unrelated wire
        receives an unknown field.

        ``session_generation_id`` distinguishes a recreated Session at the same
        public address. ``request_kind`` separates its primary chat from
        Compaction and disposable utility requests, which may run concurrently
        without advancing its native Provider conversation. These are local
        lifecycle inputs; an Adapter emits only its own private context kwargs.
        """
        del agent_id, session_id, project_id, prompt_cache_affinity_id
        del session_generation_id, request_kind
        return {}

    def _request_headers_from_kwargs(
        self,
        request_kwargs: JsonObject,
    ) -> dict[str, str]:
        """Extract concrete-Adapter header context before payload serialization.

        The default leaves caller kwargs untouched. A concrete Adapter may pop
        only its own private context keys and return the corresponding wire
        headers. Compatible base Adapters call this once per request, then
        rebuild auth headers and merge these stable values on every retry.
        """

        del request_kwargs
        return {}

    def _stable_request_headers(
        self,
        model_id: str,
        request_kwargs: JsonObject,
    ) -> dict[str, str]:
        """Return the headers every attempt of one request to ``model_id`` adds.

        These are the Adapter's own context headers
        (:meth:`_request_headers_from_kwargs`, which may pop its private kwargs)
        plus the wire profile's ``request.extra_headers``, which win. Every
        request path merges them over each attempt's rebuilt auth and Provider
        headers, so a profile header also replaces one of those.
        """

        headers = self._request_headers_from_kwargs(request_kwargs)
        headers.update(self.wire_profile(model_id).request.extra_headers)
        return headers

    @abstractmethod
    async def aclose(self) -> None:
        """Close the HTTP client and release resources.

        Subclasses that hold an ``httpx.AsyncClient`` should await
        its ``aclose()`` method.  Callers should use the async context
        manager interface (``async with``) or call this explicitly
        when the adapter is no longer needed.
        """

    @abstractmethod
    async def send(self, messages: list[JsonObject], *, model_id: str, **kwargs: Any) -> JsonObject:
        """Send a non-streaming chat request.

        Args:
            messages: Conversation messages in provider wire format.
            model_id: Exact model identifier sent to the provider API.
            **kwargs: Additional parameters (temperature, max_tokens, …).

        Returns:
            Parsed response dict from the provider.
        """

    @abstractmethod
    def stream(
        self, messages: list[JsonObject], *, model_id: str, **kwargs: Any
    ) -> AsyncIterator[JsonObject]:
        """Send a streaming chat request.

        Args:
            messages: Conversation messages in provider wire format.
            model_id: Exact model identifier sent to the provider API.
            **kwargs: Additional parameters (temperature, max_tokens, …).

        Yields:
            Normalized provider-agnostic streaming delta dicts.  Adapters
            must hide raw SSE event formats and provider-specific chunk
            structure from callers.
        """

    def normalize_response(
        self, response: JsonObject, *, model_id: str | None = None
    ) -> JsonObject:
        """Normalize a provider response into canonical assistant-message fields.

        Concrete adapters own provider-specific response parsing.  The default
        raises so subclasses can add this capability without making the legacy
        ABC constructor contract stricter during Phase 2.

        ``model_id`` is optional and keyword-only: the chat layer passes it so an
        adapter can read per-model wire facts (e.g. the data-driven reasoning
        response field) from its ``model_lookup``; callers without it (and the
        compaction summary path) omit it and the adapter falls back to its
        hardcoded default behavior.
        """
        raise NotImplementedError("normalize_response must be implemented by provider adapters")


def terminal_outcome_from_response(response: JsonObject) -> TerminalOutcome:
    """Return one canonical terminal outcome from normalized assistant fields.

    Production adapters must provide ``terminal_outcome``. The missing-field
    inference keeps older third-party/test adapters source-compatible while
    preserving the historical safe distinction between an ordinary answer and
    a Tool turn. An explicit unrecognized value is never inferred from content:
    it fails closed as ``unknown``.
    """

    raw_outcome = response.get("terminal_outcome")
    if raw_outcome is None:
        return TERMINAL_OUTCOME_TOOL_CALLS if response.get("tool_calls") else TERMINAL_OUTCOME_STOP
    if isinstance(raw_outcome, str) and raw_outcome in TERMINAL_OUTCOMES:
        return cast(TerminalOutcome, raw_outcome)
    return TERMINAL_OUTCOME_UNKNOWN
