"""Live provider subscription-usage probe.

This module fetches each logged-in provider's *own* current usage windows
(e.g. a 5h / weekly percentage used, with a reset time and plan) from the
provider's dedicated usage endpoint — no chat request needed. It is **live
provider state**, deliberately separate from ``core.statistics`` (which is a
read-only aggregation over persisted Sessions and never touches the network).

The probe lives inside the providers domain because it owns provider-domain
knowledge: endpoints, auth, and wire shapes. It follows the
``core.providers.task_client`` precedent — a non-chat provider HTTP client that
takes a narrow, locally-defined runtime protocol so it never imports
``core.runtime`` (import-cycle risk) and never caches raw OAuth access tokens."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable, Mapping
from contextlib import suppress
from copy import deepcopy
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx

from core.database import Database, DatabaseError
from core.providers._usage_parsers import (
    _parse_copilot_usage,
    _parse_minimax_usage,
    _parse_ollama_balance,
    _parse_openai_usage,
    _parse_opencode_go_usage,
    _parse_openrouter_usage,
    clamp_percent,
)
from core.providers._usage_types import (
    ANTIGRAVITY_USAGE_CONNECTION,
    CLAUDE_AGENT_USAGE_CONNECTION,
    COPILOT_USAGE_CONNECTION,
    COPILOT_USAGE_URL,
    MINIMAX_USAGE_CONNECTION,
    MINIMAX_USAGE_PATH,
    OLLAMA_BALANCE_PATH,
    OLLAMA_USAGE_CONNECTION,
    OPENAI_USAGE_CONNECTION,
    OPENAI_USAGE_PATH,
    OPENCODE_GO_USAGE_CONNECTION,
    OPENCODE_GO_USAGE_PATH,
    OPENROUTER_CREDITS_PATH,
    OPENROUTER_KEY_PATH,
    OPENROUTER_USAGE_CONNECTION,
    ProviderUsageSnapshot,
    UsageCredits,
    UsageFetchError,
    UsageProbeRuntime,
    UsageReport,
    UsageResponse,
    UsageTransport,
    UsageWindow,
    _SupportedConnection,
)
from core.providers.errors import ProviderAuthError
from core.providers.http import classify_http_status
from core.providers.openai import CODEX_EXTRA_HEADERS
from core.providers.openai_subscription_auth import (
    CHATGPT_ACCOUNT_ID_EXTRA_KEY,
    extract_chatgpt_account_id,
)
from core.providers.token_getter import (
    COPILOT_EDITOR_VERSION,
    COPILOT_INTEGRATION_ID,
    GITHUB_OAUTH_TOKEN_EXTRA_KEY,
    OAuthRequestRecovery,
)
from core.providers.usage_history import (
    ProviderUsageHistoryStore,
    UsageHistoryClearResult,
    UsageHistoryError,
    UsageHistoryReport,
)
from core.utils.errors import ConfigError
from core.utils.logging import get_logger
from core.utils.timestamps import format_canonical_timestamp
from core.utils.tls import shared_ssl_context
from core.utils.workers import cancel_and_wait

__all__ = [
    "CLAUDE_AGENT_USAGE_CONNECTION",
    "COPILOT_USAGE_CONNECTION",
    "COPILOT_USAGE_URL",
    "DEFAULT_USAGE_CACHE_TTL_SECONDS",
    "DEFAULT_USAGE_ERROR_CACHE_TTL_SECONDS",
    "DEFAULT_USAGE_HISTORY_INTERVAL_SECONDS",
    "DEFAULT_USAGE_TIMEOUT_SECONDS",
    "HttpxUsageTransport",
    "MINIMAX_USAGE_CONNECTION",
    "MINIMAX_USAGE_PATH",
    "OLLAMA_BALANCE_PATH",
    "OLLAMA_USAGE_CONNECTION",
    "OPENAI_USAGE_CONNECTION",
    "OPENAI_USAGE_PATH",
    "OPENCODE_GO_USAGE_CONNECTION",
    "OPENCODE_GO_USAGE_PATH",
    "OPENROUTER_CREDITS_PATH",
    "OPENROUTER_KEY_PATH",
    "OPENROUTER_USAGE_CONNECTION",
    "ProviderUsageService",
    "ProviderUsageSnapshot",
    "UsageCredits",
    "UsageFetchError",
    "UsageProbeRuntime",
    "UsageReport",
    "UsageResponse",
    "UsageTransport",
    "UsageWindow",
    "clamp_percent",
]

_LOGGER = get_logger("providers.usage")

DEFAULT_USAGE_TIMEOUT_SECONDS = 8.0

DEFAULT_USAGE_CACHE_TTL_SECONDS = 10.0

DEFAULT_USAGE_ERROR_CACHE_TTL_SECONDS = 60.0

DEFAULT_USAGE_HISTORY_INTERVAL_SECONDS = 60 * 60

# Provider-imposed polling floors for successful snapshots. Ollama allows ten
# usage requests per minute per user across all keys and devices and asks for
# one per minute.
_MIN_CACHE_TTL_SECONDS: dict[str, float] = {
    OLLAMA_USAGE_CONNECTION: 60.0,
    ANTIGRAVITY_USAGE_CONNECTION: 60.0,
}


class HttpxUsageTransport:
    """Default :class:`UsageTransport` backed by a per-request ``httpx`` client."""

    async def get(
        self,
        url: str,
        *,
        headers: Mapping[str, str],
        timeout: float,
        params: Mapping[str, str] | None = None,
    ) -> UsageResponse:
        """Issue one GET, mapping transport failures to a clean fetch error."""

        async with httpx.AsyncClient(timeout=timeout, verify=shared_ssl_context()) as client:
            try:
                return await client.get(
                    url,
                    headers=dict(headers),
                    params=dict(params) if params else None,
                )
            except httpx.TransportError as exc:
                raise UsageFetchError("Network error") from exc


_ANTIGRAVITY = _SupportedConnection("antigravity", "subscription")
_SUPPORTED_CONNECTIONS: tuple[_SupportedConnection, ...] = (
    _ANTIGRAVITY,
    _SupportedConnection("claude-agent", "subscription"),
    _SupportedConnection("openai", "subscription"),
    _SupportedConnection("github-copilot", "oauth"),
    _SupportedConnection("ollama-cloud", "api-key"),
    _SupportedConnection("minimax", "api-key"),
    _SupportedConnection("openrouter", "api-key"),
    _SupportedConnection("opencode-go", "api-key"),
)

_Fetcher = Callable[[_SupportedConnection], Awaitable[ProviderUsageSnapshot]]


class ProviderUsageService:
    """Fetch normalized live usage windows for logged-in provider connections."""

    def __init__(
        self,
        runtime: UsageProbeRuntime,
        *,
        transport: UsageTransport | None = None,
        history_store: ProviderUsageHistoryStore | None = None,
        data_root: str | Path | None = None,
        timeout: float = DEFAULT_USAGE_TIMEOUT_SECONDS,
        cache_ttl: float = DEFAULT_USAGE_CACHE_TTL_SECONDS,
        error_cache_ttl: float = DEFAULT_USAGE_ERROR_CACHE_TTL_SECONDS,
        history_interval: float = DEFAULT_USAGE_HISTORY_INTERVAL_SECONDS,
        monotonic: Callable[[], float] = time.monotonic,
        clock: Callable[[], datetime] = lambda: datetime.now(UTC),
        claude_usage: Callable[[], tuple[datetime | None, tuple[UsageWindow, ...]]] | None = None,
        antigravity_usage: Callable[[], Awaitable[tuple[UsageWindow, ...]]] | None = None,
    ) -> None:
        self._runtime = runtime
        self._transport = transport or HttpxUsageTransport()
        # A store opened here from ``data_root`` is owned and closed by this
        # service; an injected store stays with its caller.
        self._owns_history = history_store is None and data_root is not None
        self._history = history_store or (
            ProviderUsageHistoryStore.open(data_root) if data_root is not None else None
        )
        self._timeout = timeout
        self._cache_ttl = cache_ttl
        self._error_cache_ttl = error_cache_ttl
        self._history_interval = history_interval
        self._monotonic = monotonic
        self._clock = clock
        self._claude_usage = claude_usage
        self._antigravity_usage = antigravity_usage
        self._last_antigravity_check: int | None = None
        self._cache: dict[str, tuple[float, float, ProviderUsageSnapshot]] = {}
        self._observations: dict[tuple[str, str], dict[str, Any]] = {}
        self._observation_listeners: list[Callable[[dict[str, Any]], None]] = []
        self._fetch_locks: dict[str, asyncio.Lock] = {}
        self._history_task: asyncio.Task[None] | None = None
        self._history_started = False
        # Only connections with a registered fetcher are queried.
        self._fetchers: dict[str, _Fetcher] = {
            ANTIGRAVITY_USAGE_CONNECTION: self._fetch_antigravity,
            CLAUDE_AGENT_USAGE_CONNECTION: self._fetch_claude_agent,
            OPENAI_USAGE_CONNECTION: self._fetch_openai,
            COPILOT_USAGE_CONNECTION: self._fetch_copilot,
            OLLAMA_USAGE_CONNECTION: self._fetch_ollama,
            MINIMAX_USAGE_CONNECTION: self._fetch_minimax,
            OPENROUTER_USAGE_CONNECTION: self._fetch_openrouter,
            OPENCODE_GO_USAGE_CONNECTION: self._fetch_opencode_go,
        }

    def start(self) -> None:
        """Start the automatic history sampler on the current event loop."""

        if self._history_started or self._history is None:
            return
        self._history_started = True
        self._history_task = asyncio.create_task(
            self._history_loop(),
            name="provider-usage-history",
        )

    def stop(self) -> None:
        """Cancel automatic sampling without awaiting task completion."""

        self._history_started = False
        task = self._history_task
        self._history_task = None
        if task is not None:
            task.cancel()

    def close(self) -> None:
        """Cancel automatic sampling and close an owned history database."""

        self.stop()
        self._close_history()

    async def astop(self) -> None:
        """Cancel and await the automatic sampler; the history database stays open."""

        task = self._history_task
        self.stop()
        if task is not None:
            await cancel_and_wait(task)

    async def aclose(self) -> None:
        """Cancel and await the automatic sampler, then close an owned history database."""

        try:
            await self.astop()
        finally:
            self._close_history()

    @property
    def history_database(self) -> Database | None:
        """The Provider usage database handle, for data snapshots and status."""

        return self._history.database if self._history is not None else None

    def _close_history(self) -> None:
        if self._owns_history and self._history is not None:
            self._history.close()

    def observations(self) -> list[dict[str, Any]]:
        """Last known limits per Connection and Account. Reading never starts a probe."""
        return deepcopy(list(self._observations.values()))

    def subscribe_observations(
        self, listener: Callable[[dict[str, Any]], None]
    ) -> Callable[[], None]:
        """Notify passive consumers of a new measurement, including an emptied window set."""
        self._observation_listeners.append(listener)
        return lambda: self._observation_listeners.remove(listener)

    def observe_antigravity_usage(
        self, started_at_ns: int, windows: tuple[UsageWindow, ...]
    ) -> None:
        """Reuse a native check ordered by monotonic start time; disconnect clears its Account."""
        self._apply_antigravity_snapshot(
            started_at_ns, self._window_snapshot(_ANTIGRAVITY, windows)
        )

    def _apply_antigravity_snapshot(
        self, started_at_ns: int, snapshot: ProviderUsageSnapshot
    ) -> ProviderUsageSnapshot:
        # A report and several Model steps may check the same native login concurrently.
        if (
            self._last_antigravity_check is not None
            and started_at_ns < self._last_antigravity_check
        ):
            current = self._cache.get(_ANTIGRAVITY.target_id)
            return current[2] if current is not None else self._window_snapshot(_ANTIGRAVITY, ())
        if not snapshot.error:
            self._last_antigravity_check = started_at_ns
        if snapshot.windows or snapshot.error:
            self._store_cache(_ANTIGRAVITY, snapshot)
        else:
            self._cache.pop(_ANTIGRAVITY.target_id, None)
        self._remember(snapshot.to_dict(), format_canonical_timestamp(self._now()))
        return snapshot

    def _remember(self, snapshot: dict[str, Any], observed_at: str) -> None:
        if snapshot["error"]:
            return  # A failed probe supplies no new measurement.
        key = (snapshot["connection"], snapshot["account"])
        observation = {**snapshot, "observed_at": observed_at}
        if snapshot["windows"] or snapshot["credits"]:
            if observation == self._observations.get(key):
                return
            self._observations[key] = observation
        elif self._observations.pop(key, None) is None:
            return
        for listener in tuple(self._observation_listeners):
            listener(deepcopy(observation))

    async def report(self, connections: list[str] | None = None) -> UsageReport:
        """Return usage snapshots for every supported, logged-in connection.

        Fetchers run concurrently; a single fetcher failure (timeout, HTTP
        error, or shape mismatch) becomes that snapshot's ``error`` and never
        breaks its siblings (fail-open). Connections with neither a window nor a
        meaningful error are dropped from the report.
        """

        requested = set(connections) if connections is not None else None
        targets = self._select_targets(requested)
        snapshots = await asyncio.gather(*(self._snapshot_for(target) for target in targets))
        meaningful = [snapshot for snapshot in snapshots if _is_meaningful(snapshot)]
        return UsageReport(generated_at=self._now_iso(), providers=meaningful)

    async def history_report(
        self,
        *,
        since: datetime | None = None,
        until: datetime | None = None,
    ) -> UsageHistoryReport:
        """Return durable automatic samples, never the 10-second live polls."""

        if self._history is None:
            return UsageHistoryReport(generated_at=self._now_iso())
        samples = await self._history.samples(since=since, until=until)
        return UsageHistoryReport(generated_at=self._now_iso(), samples=samples)

    async def clear_history(self) -> UsageHistoryClearResult:
        """Explicitly delete all durable automatic usage samples."""

        if self._history is None:
            return UsageHistoryClearResult(deleted_samples=0)
        return await self._history.clear()

    async def collect_history_sample(self) -> bool:
        """Fetch/coalesce live state and persist at most one automatic sample."""

        if self._history is None:
            return False
        try:
            report = await self.report()
            return await self._history.append(
                report.generated_at,
                [snapshot.to_dict() for snapshot in report.providers],
            )
        except (UsageHistoryError, DatabaseError) as exc:
            _LOGGER.warning("Provider usage history sample could not be stored: %s", exc)
            return False

    async def _history_loop(self) -> None:
        try:
            delay = await self._initial_history_delay()
            if delay > 0:
                await asyncio.sleep(delay)
            while self._history_started:
                try:
                    await self.collect_history_sample()
                except asyncio.CancelledError:
                    raise
                except Exception as exc:  # noqa: BLE001 — each background sample fails soft
                    _LOGGER.error(
                        "Provider usage history sample failed unexpectedly; "
                        "retrying at the next interval: %s",
                        exc,
                        exc_info=True,
                    )
                if self._history_started:
                    await asyncio.sleep(self._history_interval)
        finally:
            self._history_started = False
            self._history_task = None

    async def _initial_history_delay(self) -> float:
        if self._history is None:
            return self._history_interval
        try:
            latest = await self._history.latest_sampled_at()
            if latest is not None:
                for sample in await self._history.samples(since=latest, until=latest):
                    for snapshot in sample.providers:
                        # A live check or disconnect can finish during the database read.
                        if (
                            snapshot["connection"] == ANTIGRAVITY_USAGE_CONNECTION
                            and self._last_antigravity_check is not None
                        ):
                            continue
                        if (snapshot["connection"], snapshot["account"]) not in self._observations:
                            self._remember(snapshot, sample.sampled_at)
        except DatabaseError as exc:
            _LOGGER.warning("Provider usage history freshness could not be read: %s", exc)
            return 0.0
        except Exception as exc:  # noqa: BLE001 — background sampling must fail soft
            _LOGGER.error(
                "Provider usage history freshness check failed unexpectedly; "
                "sampling immediately: %s",
                exc,
                exc_info=True,
            )
            return 0.0
        if latest is None:
            return 0.0
        elapsed = (self._now() - latest).total_seconds()
        return max(0.0, self._history_interval - max(0.0, elapsed))

    def _now(self) -> datetime:
        now = self._clock()
        if now.tzinfo is None:
            return now.replace(tzinfo=UTC)
        return now.astimezone(UTC)

    def _now_iso(self) -> str:
        return self._now().isoformat()

    def _select_targets(self, requested: set[str] | None) -> list[_SupportedConnection]:
        targets: list[_SupportedConnection] = []
        for supported in _SUPPORTED_CONNECTIONS:
            if supported.connection_id not in self._fetchers:
                continue
            if requested is not None and supported.connection_id not in requested:
                continue
            target = self._resolve_target(supported)
            if target is None:
                continue
            targets.append(target)
        return targets

    def _resolve_target(self, connection: _SupportedConnection) -> _SupportedConnection | None:
        try:
            if not self._runtime.provider_credentials.is_usable(
                connection.provider_id, connection.connection_id
            ):
                return None
            account_id = self._runtime.provider_credentials.resolve_account_id(
                connection.provider_id,
                connection.local_connection_id,
            )
        except KeyError, ConfigError:
            return None
        return replace(connection, account_id=account_id)

    async def _snapshot_for(self, connection: _SupportedConnection) -> ProviderUsageSnapshot:
        if connection.connection_id == CLAUDE_AGENT_USAGE_CONNECTION:
            # This source is already in memory and changes only when native
            # streams report new facts. A polling TTL would hide fresh events.
            return await self._run_fetcher(connection)
        cached = self._cached_snapshot(connection.target_id)
        if cached is not None:
            return cached

        lock = self._fetch_locks.setdefault(connection.target_id, asyncio.Lock())
        async with lock:
            cached = self._cached_snapshot(connection.target_id)
            if cached is not None:
                return cached
            if connection.connection_id == ANTIGRAVITY_USAGE_CONNECTION:
                started_at_ns = time.monotonic_ns()
                snapshot = await self._run_fetcher(connection)
                return self._apply_antigravity_snapshot(started_at_ns, snapshot)
            snapshot = await self._run_fetcher(connection)
            self._store_cache(connection, snapshot)
            self._remember(snapshot.to_dict(), format_canonical_timestamp(self._now()))
            return snapshot

    async def _run_fetcher(self, connection: _SupportedConnection) -> ProviderUsageSnapshot:
        fetcher = self._fetchers[connection.connection_id]
        try:
            return await asyncio.wait_for(fetcher(connection), timeout=self._timeout)
        except TimeoutError:
            return self._error_snapshot(connection, "Timeout")
        except UsageFetchError as exc:
            return self._error_snapshot(connection, str(exc))
        except Exception as exc:  # noqa: BLE001 — fail-open: one fetcher must not break siblings
            # Blind Copilot/MiniMax parsing may raise unexpected shapes; convert
            # any non-fetch error into a clean "unavailable" snapshot and log the
            # real cause for debugging (no token data is included in the message).
            _LOGGER.warning(
                "Usage fetch failed for connection %s: %s", connection.connection_id, exc
            )
            return self._error_snapshot(connection, "Unavailable")

    def _error_snapshot(
        self, connection: _SupportedConnection, message: str
    ) -> ProviderUsageSnapshot:
        return ProviderUsageSnapshot(
            connection=connection.connection_id,
            account=connection.account_id,
            display_name=self._display_name(connection),
            error=message,
        )

    def _display_name(self, connection: _SupportedConnection) -> str:
        try:
            name = self._runtime.providers.get(connection.provider_id).name
        except KeyError, AttributeError:
            return connection.provider_id
        return name if isinstance(name, str) and name else connection.provider_id

    def _cached_snapshot(self, target_id: str) -> ProviderUsageSnapshot | None:
        entry = self._cache.get(target_id)
        if entry is None:
            return None
        stored_at, ttl, snapshot = entry
        if self._monotonic() - stored_at >= ttl:
            return None
        return snapshot

    def _store_cache(
        self, connection: _SupportedConnection, snapshot: ProviderUsageSnapshot
    ) -> None:
        if snapshot.error:
            ttl = self._error_cache_ttl
        else:
            ttl = max(self._cache_ttl, _MIN_CACHE_TTL_SECONDS.get(connection.connection_id, 0.0))
        self._cache[connection.target_id] = (self._monotonic(), ttl, snapshot)

    # ------------------------------------------------------------------
    # Per-provider fetchers
    # ------------------------------------------------------------------

    async def _fetch_claude_agent(self, connection: _SupportedConnection) -> ProviderUsageSnapshot:
        observed_at, windows = self._claude_usage() if self._claude_usage else (None, ())
        snapshot = self._window_snapshot(connection, windows)
        self._remember(snapshot.to_dict(), format_canonical_timestamp(observed_at or self._now()))
        return snapshot

    async def _fetch_antigravity(self, connection: _SupportedConnection) -> ProviderUsageSnapshot:
        try:
            windows = await self._antigravity_usage() if self._antigravity_usage else ()
        except ProviderAuthError as exc:
            raise UsageFetchError(str(exc)) from exc
        return self._window_snapshot(connection, windows)

    def _window_snapshot(
        self, connection: _SupportedConnection, windows: tuple[UsageWindow, ...]
    ) -> ProviderUsageSnapshot:
        return ProviderUsageSnapshot(
            connection=connection.connection_id,
            account=connection.account_id,
            display_name=self._display_name(connection),
            windows=list(windows),
        )

    async def _fetch_openai(self, connection: _SupportedConnection) -> ProviderUsageSnapshot:
        provider = self._runtime.providers.get(connection.provider_id)
        connection_config = provider.get_connection(connection.local_connection_id)
        base_url = connection_config.base_url or provider.base_url

        token_getter = self._runtime.get_connection_token_getter(connection.ref)

        async def headers() -> dict[str, str]:
            token = await token_getter()
            account_id = extract_chatgpt_account_id(token)
            if not account_id:
                extra = self._runtime.get_connection_token_extra(connection.ref)
                account_id = extra.get(CHATGPT_ACCOUNT_ID_EXTRA_KEY) or None
            if not account_id:
                raise UsageFetchError("Reconnect required")
            return {
                connection_config.auth.header: f"{connection_config.auth.prefix}{token}",
                "chatgpt-account-id": account_id,
                **CODEX_EXTRA_HEADERS,
            }

        body = await self._get_json(
            _join_url(base_url, OPENAI_USAGE_PATH),
            headers,
            auth_recovery=OAuthRequestRecovery(token_getter, connection_config.auth),
        )
        return _parse_openai_usage(
            connection.connection_id,
            self._display_name(connection),
            body,
            account=connection.account_id,
        )

    async def _fetch_copilot(self, connection: _SupportedConnection) -> ProviderUsageSnapshot:
        # The Copilot usage endpoint authenticates with the GitHub OAuth token
        # (token-store ``extra``) under GitHub's ``token`` scheme — NOT the
        # exchanged Copilot bearer.
        extra = self._runtime.get_connection_token_extra(connection.ref)
        github_oauth_token = extra.get(GITHUB_OAUTH_TOKEN_EXTRA_KEY)
        if not github_oauth_token:
            raise UsageFetchError("Reconnect required")

        headers = {
            "Authorization": f"token {github_oauth_token}",
            "Accept": "application/json",
            "Copilot-Integration-Id": COPILOT_INTEGRATION_ID,
            "Editor-Version": COPILOT_EDITOR_VERSION,
        }
        body = await self._get_json(COPILOT_USAGE_URL, headers)
        return _parse_copilot_usage(
            connection.connection_id,
            self._display_name(connection),
            body,
            account=connection.account_id,
        )

    async def _fetch_minimax(self, connection: _SupportedConnection) -> ProviderUsageSnapshot:
        provider = self._runtime.providers.get(connection.provider_id)
        connection_config = provider.get_connection(connection.local_connection_id)
        base_url = connection_config.base_url or provider.base_url

        token_getter = self._runtime.get_connection_token_getter(connection.ref)
        token = await token_getter()
        headers = {connection_config.auth.header: f"{connection_config.auth.prefix}{token}"}
        body = await self._get_json(_join_url(base_url, MINIMAX_USAGE_PATH), headers)
        return _parse_minimax_usage(
            connection.connection_id,
            self._display_name(connection),
            body,
            account=connection.account_id,
        )

    async def _fetch_ollama(self, connection: _SupportedConnection) -> ProviderUsageSnapshot:
        provider = self._runtime.providers.get(connection.provider_id)
        connection_config = provider.get_connection(connection.local_connection_id)
        base_url = connection_config.base_url or provider.base_url

        token_getter = self._runtime.get_connection_token_getter(connection.ref)
        token = await token_getter()
        headers = {
            connection_config.auth.header: f"{connection_config.auth.prefix}{token}",
            "Accept": "application/json",
        }
        # The endpoint refuses any query parameter.
        body = await self._get_json(_join_url(base_url, OLLAMA_BALANCE_PATH), headers)
        return _parse_ollama_balance(
            connection.connection_id,
            self._display_name(connection),
            body,
            account=connection.account_id,
        )

    async def _fetch_opencode_go(self, connection: _SupportedConnection) -> ProviderUsageSnapshot:
        provider = self._runtime.providers.get(connection.provider_id)
        connection_config = provider.get_connection(connection.local_connection_id)
        base_url = connection_config.base_url or provider.base_url

        token_getter = self._runtime.get_connection_token_getter(connection.ref)
        token = await token_getter()
        headers = {
            **(provider.extra_headers or {}),
            connection_config.auth.header: f"{connection_config.auth.prefix}{token}",
            "Accept": "application/json",
        }
        body = await self._get_json(_join_url(base_url, OPENCODE_GO_USAGE_PATH), headers)
        return _parse_opencode_go_usage(
            connection.connection_id,
            self._display_name(connection),
            body,
            account=connection.account_id,
        )

    async def _fetch_openrouter(self, connection: _SupportedConnection) -> ProviderUsageSnapshot:
        provider = self._runtime.providers.get(connection.provider_id)
        connection_config = provider.get_connection(connection.local_connection_id)
        base_url = connection_config.base_url or provider.base_url

        token_getter = self._runtime.get_connection_token_getter(connection.ref)
        token = await token_getter()
        headers = {connection_config.auth.header: f"{connection_config.auth.prefix}{token}"}
        credits_body = await self._get_json(_join_url(base_url, OPENROUTER_CREDITS_PATH), headers)
        # The key spending-cap endpoint is supplementary: when it fails, degrade
        # to a credits-only snapshot instead of failing the whole fetch.
        key_body: Any = None
        with suppress(UsageFetchError):
            key_body = await self._get_json(_join_url(base_url, OPENROUTER_KEY_PATH), headers)
        return _parse_openrouter_usage(
            connection.connection_id,
            self._display_name(connection),
            credits_body,
            key_body,
            account=connection.account_id,
        )

    async def _get_json(
        self,
        url: str,
        headers: Mapping[str, str] | Callable[[], Awaitable[dict[str, str]]],
        *,
        auth_recovery: OAuthRequestRecovery | None = None,
    ) -> Any:
        async def request() -> Any:
            request_headers = await headers() if callable(headers) else headers
            response = await self._transport.get(
                url, headers=request_headers, timeout=self._timeout
            )
            if auth_recovery is not None:
                auth_recovery.record_response(
                    response.status_code,
                    request_headers,
                    response.text if response.status_code >= 400 else "",
                )
                if response.status_code == 401:
                    classify_http_status(401, idempotent=True)
            if response.status_code >= 400:
                raise UsageFetchError(f"HTTP {response.status_code}")
            try:
                return response.json()
            except ValueError as exc:
                raise UsageFetchError("Invalid response") from exc

        if auth_recovery is None:
            return await request()
        try:
            return await auth_recovery.run(request)
        except ProviderAuthError as exc:
            if getattr(exc, "status_code", None) == 401:
                raise UsageFetchError("HTTP 401") from exc
            raise UsageFetchError("Reconnect required") from exc


def _is_meaningful(snapshot: ProviderUsageSnapshot) -> bool:
    # Enabled credits alone are meaningful: OpenRouter keys without a spending
    # cap (or with a failed /key probe) still report a credits balance.
    credits_meaningful = snapshot.credits is not None and snapshot.credits.enabled
    return bool(snapshot.windows) or credits_meaningful or bool(snapshot.error)


def _join_url(base_url: str, path: str) -> str:
    return f"{base_url.rstrip('/')}/{path.lstrip('/')}"
