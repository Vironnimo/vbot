"""Provider-owned adapter construction and live catalog refresh."""

from __future__ import annotations

import asyncio
import threading
import time
from collections.abc import AsyncIterator, Callable, Iterable, Iterator, Mapping
from contextlib import AbstractAsyncContextManager, asynccontextmanager, contextmanager
from datetime import UTC, datetime, tzinfo
from pathlib import Path
from typing import Any, cast
from zoneinfo import ZoneInfo

from core.debug import DebugTraceStore, ProviderDebugRecorder
from core.models.models import Model, ModelRegistry
from core.providers import _catalog_refresh
from core.providers._antigravity_native import AntigravityNative
from core.providers._claude_agent_sdk import SUBSCRIPTION_REQUIRED_MESSAGE
from core.providers._claude_agent_usage import ClaudeAgentUsage
from core.providers._responses_websocket import ResponsesTransports, responses_conversation_id
from core.providers._usage_types import UsageWindow
from core.providers._wire_profile_files import WireProfileFile
from core.providers.accounts import DEFAULT_ACCOUNT_ID, Account, ConnectionRef, split_connection_id
from core.providers.adapter import ModelLookup, ProviderAdapter, is_local_provider_base_url
from core.providers.adapter_types import ADAPTER_TYPES as ADAPTER_TYPES
from core.providers.adapter_types import adapter_type_for_config
from core.providers.antigravity import AntigravityAdapter
from core.providers.claude_agent import ClaudeAgentAdapter, ClaudeAgentSessions
from core.providers.credentials import ProviderCredentialResolver
from core.providers.github_copilot import GitHubCopilotAdapter
from core.providers.http import ProviderHTTPTransports, ProviderHTTPTransportScope
from core.providers.lmstudio import LMStudioAdapter
from core.providers.ollama import OllamaAdapter
from core.providers.openai import OpenAIAdapter
from core.providers.openrouter import OpenRouterAdapter
from core.providers.providers import (
    ConnectionConfig,
    ProviderConfig,
    ProviderRegistry,
    model_is_local,
    resolve_effective_context_window,
)
from core.providers.reasoning import ReasoningIntent
from core.providers.reasoning_dialects import describe_profile_reasoning
from core.providers.token_getter import (
    COPILOT_API_ENDPOINT_EXTRA_KEY,
    OAuthTokenGetter,
    StaticTokenGetter,
    TokenGetter,
)
from core.providers.token_store import TokenStore
from core.providers.wire_observations import (
    OBSERVATIONS_FILE_NAME,
    ObservedFacts,
    WireObservations,
)
from core.providers.wire_profile import ProfileStatus, Protocol, Verification, WireProfile
from core.providers.wire_profiles import (
    WireProfiles,
    log_wire_profile_issue,
    wire_profile_files,
)
from core.settings.paths import build_effective_settings
from core.settings.settings import effective_timezone_name
from core.storage import StorageManager
from core.utils.errors import ConfigError, StorageError
from core.utils.logging import get_logger
from core.utils.workers import cancel_and_wait, settle_before_cancelling

_LOGGER = get_logger("providers.runtime")
#: How old observed Claude subscription windows may get before a report asks for new ones.
CLAUDE_USAGE_REFRESH_SECONDS = 900.0


class ProviderRuntime:
    """Own Provider adapter creation and mutable local catalog state end to end."""

    def __init__(
        self,
        *,
        providers: ProviderRegistry,
        models: ModelRegistry,
        credentials: ProviderCredentialResolver,
        token_store: TokenStore,
        storage: StorageManager,
        resources_path: Path,
        logger: Any,
        custom_providers: Mapping[str, Mapping[str, Any]] | None = None,
        on_antigravity_usage: Callable[[int, tuple[UsageWindow, ...]], None] | None = None,
    ) -> None:
        self._providers = providers
        self._models = models
        self._credentials = credentials
        self._token_store = token_store
        self._storage = storage
        self._resources_path = resources_path
        self._logger = logger
        self._catalog_refresh_lock: asyncio.Lock | None = None
        self._catalog_refresh_tasks: set[asyncio.Task[Any]] = set()
        self._catalog_refresh_closed = False
        self._external_catalog_task: asyncio.Task[None] | None = None
        self._external_refresh_at: dict[str, float] = {}
        self._external_refresh_lock = asyncio.Lock()
        self._configuration_publication_lock = threading.Lock()
        self._async_configuration_publication_lock = asyncio.Lock()
        self._catalog_changed_callbacks: list[Callable[[], None]] = []
        self.refresh_at: float | None = None
        self._connection_reachability: dict[str, bool] = {}
        # Windows LM Studio reports for its loaded instances, keyed like the
        # Settings map ("<provider>/<model>"); Adapters report them per request
        # on the loop while worker threads read them.
        self._loaded_context_windows: dict[str, int] = {}
        self._loaded_context_lock = threading.Lock()
        self._responses_transports = ResponsesTransports()
        self._external_status: dict[str, dict[str, Any]] = {}
        self._claude_usage = ClaudeAgentUsage()
        self._on_antigravity_usage = on_antigravity_usage
        self._claude_usage_probe: asyncio.Task[None] | None = None
        self._claude_usage_probed_at: float | None = None
        self._retired_native: set[ClaudeAgentSessions | AntigravityNative] = set()
        self._claude_configured_path = self._claude_executable_path()
        self._claude_sessions = self._new_claude_sessions()
        self._antigravity = self._new_antigravity()
        self._http_transports = ProviderHTTPTransports()
        self._wire_observations = self._load_wire_observations(storage)
        self._wire_profiles = WireProfiles(
            files=wire_profile_files(custom_providers, resources_path),
            protocol_support=self._adapter_protocols,
            model_resolver=self._resolve_model,
            report=log_wire_profile_issue,
            observations=self._wire_observations,
        )

    def rebind(
        self,
        *,
        providers: ProviderRegistry,
        models: ModelRegistry,
        credentials: Any,
        token_store: TokenStore,
        storage: StorageManager,
        logger: Any,
    ) -> None:
        """Refresh stable facade references after an in-place Runtime reconfiguration."""
        self._providers = providers
        self._models = models
        self._credentials = credentials
        self._token_store = token_store
        data_changed = storage.data_dir != self._storage.data_dir
        self._storage = storage
        if data_changed:
            self._claude_sessions.abort()
            self._antigravity.abort()
            self._retired_native.update((self._claude_sessions, self._antigravity))
            self._antigravity = self._new_antigravity()
            self._claude_configured_path = self._claude_executable_path()
            self._claude_sessions = self._new_claude_sessions()
            self._external_status.clear()
            self._external_refresh_at.clear()
            self._forget_claude_usage()
            self.retire_http_transports()
            self._wire_observations.close()
            self._wire_observations = self._load_wire_observations(storage)
            self._wire_profiles.set_observations(self._wire_observations)
        self._storage = storage
        self._logger = logger

    def _claude_executable_path(self) -> str:
        return str(
            build_effective_settings(self._storage.load_settings())["providers"]["claude_agent"][
                "executable_path"
            ]
        )

    def _new_claude_sessions(self) -> ClaudeAgentSessions:
        def observe(info: dict[str, Any]) -> None:
            if sessions is self._claude_sessions and not self._catalog_refresh_closed:
                self._claude_usage.observe(info)

        def auth_failed() -> None:
            if sessions is self._claude_sessions:
                self._native_auth_failed()

        sessions = ClaudeAgentSessions(
            temporary_files=self._storage.temporary_files,
            executable_path=self._claude_executable_path,
            observe_usage=observe,
            on_auth_error=auth_failed,
        )
        return sessions

    def _new_antigravity(self) -> AntigravityNative:
        def auth_failed(status: str, message: str) -> None:
            if owner is not self._antigravity:
                return
            for provider_id, provider, connection in self._auto_refresh_targets():
                if provider.adapter != "antigravity" or connection.type != "external":
                    continue
                key = f"{provider_id}:{connection.id}"
                self._external_status[key] = {
                    "connected": False,
                    "status": status,
                    "message": message,
                }
                self._external_refresh_at.pop(key, None)
                self._connection_reachability[key] = False

        owner = AntigravityNative(
            temporary_files=self._storage.temporary_files,
            on_auth_error=auth_failed,
            on_usage=self._on_antigravity_usage,
        )
        return owner

    def claude_usage_windows(self) -> tuple[UsageWindow, ...]:
        return self._claude_usage.observation()[1]

    def current_claude_usage(self) -> tuple[datetime | None, tuple[UsageWindow, ...]]:
        """The observed windows for a usage report.

        When they are missing or older than ``CLAUDE_USAGE_REFRESH_SECONDS``, a
        background probe asks Claude Code for fresh ones (at most once per that
        interval); the next report shows its answer.
        """
        age = self._claude_usage.age_seconds()
        if age is None or age >= CLAUDE_USAGE_REFRESH_SECONDS:
            self._start_claude_usage_probe()
        return self._claude_usage.observation()

    async def current_antigravity_usage(self) -> tuple[UsageWindow, ...]:
        return await self._antigravity.usage()

    def _start_claude_usage_probe(self) -> None:
        if self._catalog_refresh_closed:
            return
        if self._claude_usage_probe is not None and not self._claude_usage_probe.done():
            return
        now = time.monotonic()
        probed_at = self._claude_usage_probed_at
        if probed_at is not None and now - probed_at < CLAUDE_USAGE_REFRESH_SECONDS:
            return
        self._claude_usage_probed_at = now
        self._claude_usage_probe = asyncio.get_running_loop().create_task(
            self._claude_sessions.probe_usage(), name="claude-agent-usage-probe"
        )

    def _forget_claude_usage(self) -> None:
        """A changed native login or executable may report other windows at once."""
        self._claude_usage.clear()
        self._claude_usage_probed_at = None

    async def apply_claude_configuration(self, configured_path: str) -> None:
        """Retire native processes on the Event Loop after a persisted path change."""
        if configured_path == self._claude_configured_path:
            return
        self._claude_configured_path = configured_path
        previous, self._claude_sessions = self._claude_sessions, self._new_claude_sessions()
        self._forget_external_auth("claude_agent")
        self._forget_claude_usage()
        await previous.aclose()

    def _forget_external_auth(self, adapter: str) -> None:
        known = self._providers.list_ids()
        for key in self._external_status.keys() | self._external_refresh_at.keys():
            provider_id = key.partition(":")[0]
            if provider_id not in known or self._providers.get(provider_id).adapter == adapter:
                self._external_status.pop(key, None)
                self._external_refresh_at.pop(key, None)

    def _native_auth_failed(self) -> None:
        self._claude_usage.clear()
        if self._catalog_refresh_closed:
            return
        for provider_id, provider, connection in self._auto_refresh_targets():
            if provider.adapter != "claude_agent" or connection.type != "external":
                continue
            key = f"{provider_id}:{connection.id}"
            self._external_status[key] = {"connected": False, "status": "not_checked"}
            self._external_refresh_at.pop(key, None)

            async def check(provider_id: str = provider_id, key: str = key) -> None:
                try:
                    await self.refresh_external_connection(provider_id, key)
                except ConfigError:
                    return

            self._track_catalog_refresh(asyncio.create_task(check(), name="native-login-refresh"))

    def reload_custom_wire_profiles(
        self, custom_providers: Mapping[str, Mapping[str, Any]]
    ) -> None:
        """Apply the Custom Providers' current ``wire`` blocks to every Adapter.

        Adapters resolve profiles through this Runtime's shared wire profiles,
        so already built Adapters use the new blocks from their next request.
        """
        self._wire_profiles.replace_files(
            wire_profile_files(custom_providers, self._resources_path)
        )
        self.retire_http_transports()

    def retire_http_transports(self) -> None:
        """Use fresh HTTP connections after published credential/configuration changes.

        Active responses finish on their old connections; subsequent requests,
        including those of existing Adapters, acquire the current pool generation.
        """
        self._http_transports.retire_all()

    @property
    def wire_profile_files(self) -> Mapping[str, WireProfileFile]:
        """The wire profile data requests use: bundled files plus Custom Provider blocks."""
        return self._wire_profiles.files

    @property
    def wire_observations(self) -> WireObservations:
        """Wire facts learned from live traffic for every Provider of this Runtime."""
        return self._wire_observations

    def wire_profile(self, provider_id: str, connection_id: str, model_id: str) -> WireProfile:
        """Return the resolved wire profile for one Model on one local Connection id.

        It is the profile requests use, learned facts included.
        """
        return self._wire_profiles.resolve(provider_id, connection_id, model_id)

    def wire_status(
        self, provider_id: str, connection_id: str, model_id: str
    ) -> tuple[ProfileStatus, Verification | None]:
        """Return the wire profile ``(status, verification)`` for one local Connection id.

        Equals ``wire_profile(...).status`` and ``.verification`` without
        resolving the profile, so listing every catalog Model stays cheap.
        """
        return self._wire_profiles.status(provider_id, connection_id, model_id)

    def learned_wire_facts(
        self, provider_id: str, connection_id: str, model_id: str
    ) -> ObservedFacts:
        """Return what live traffic showed for one Model on one local Connection id."""
        return self._wire_observations.facts_for(provider_id, connection_id, model_id)

    def forget_wire_facts(
        self, provider_id: str, connection_id: str | None = None, model_id: str | None = None
    ) -> int:
        """Drop learned wire facts; returns how many (Connection, Model) targets lost facts."""
        return self._wire_observations.forget(provider_id, connection_id, model_id)

    def close_wire_observations(self) -> None:
        """Write pending learned wire facts (called on Runtime shutdown)."""
        self._wire_observations.close()

    async def close_session_transports(self, sessions: Iterable[tuple[str, str]]) -> None:
        """Close the Provider connections kept open for these ``(agent_id, session_id)``."""
        sessions = tuple(sessions)
        await self._responses_transports.close_conversations(
            {responses_conversation_id(agent_id, session_id) for agent_id, session_id in sessions}
        )
        await asyncio.gather(
            self._claude_sessions.close_sessions(set(sessions)),
            self._antigravity.conversations.close_sessions(set(sessions)),
        )

    async def close_connection_transports(
        self, provider_id: str, connection_id: str | None = None
    ) -> None:
        """Close a Connection's kept-open Provider connections after its credentials changed.

        ``connection_id`` is local (``subscription``); without it, every
        Connection of the Provider closes.
        """
        adapter = self._providers.get(provider_id).adapter
        if adapter == "claude_agent":
            previous, self._claude_sessions = self._claude_sessions, self._new_claude_sessions()
            self._forget_external_auth(adapter)
            self._forget_claude_usage()
            await previous.aclose()
        elif adapter == "antigravity":
            previous_agy = self._antigravity
            self._antigravity = self._new_antigravity()
            self._forget_external_auth(adapter)
            if self._on_antigravity_usage is not None:
                self._on_antigravity_usage(time.monotonic_ns(), ())
            await previous_agy.aclose()
        try:
            await self._responses_transports.close_connection(provider_id, connection_id)
        finally:
            await self._http_transports.close_connection(provider_id, connection_id)

    async def aclose_transports(self) -> None:
        """Close every kept-open Provider connection (Runtime shutdown)."""
        if self._claude_usage_probe is not None:
            await cancel_and_wait(self._claude_usage_probe)
        try:
            results = await settle_before_cancelling(
                asyncio.gather(
                    self._claude_sessions.aclose(),
                    self._antigravity.aclose(),
                    *(native.aclose() for native in self._retired_native),
                    return_exceptions=True,
                )
            )
            self._retired_native.clear()
            failures = [result for result in results if isinstance(result, BaseException)]
            if failures:
                raise BaseExceptionGroup("Native Provider cleanup failed.", failures)
        finally:
            self._claude_usage.clear()
            await self._aclose_http_transports()

    async def _aclose_http_transports(self) -> None:
        try:
            await self._responses_transports.aclose()
        finally:
            await self._http_transports.aclose()

    def abort_transports(self) -> None:
        """Drop every kept-open Provider connection without waiting (synchronous shutdown)."""
        if self._claude_usage_probe is not None:
            self._claude_usage_probe.cancel()
        self._claude_sessions.abort()
        self._antigravity.abort()
        self._claude_usage.clear()
        for sessions in self._retired_native:
            sessions.abort()
        try:
            self._responses_transports.abort()
        finally:
            self._http_transports.abort()

    def prepare_provider_http(
        self, connection: ConnectionRef
    ) -> tuple[TokenGetter, ProviderHTTPTransportScope]:
        """Bind credentials and a lazy HTTP scope to the same effective Account."""
        config, account_id = self._connection_config(
            self._providers.get(connection.provider_id), connection.connection_id
        )
        return self._prepare_http(connection, config, account_id)

    def _prepare_http(
        self, connection: ConnectionRef, config: ConnectionConfig, account_id: str | None
    ) -> tuple[TokenGetter, ProviderHTTPTransportScope]:
        account_id = self._http_account_id(connection.provider_id, config, account_id)
        return (
            self._token_getter(connection, config, account_id),
            self._http_transports.scope(connection.provider_id, config.id, account_id),
        )

    def _http_account_id(
        self, provider_id: str, config: ConnectionConfig, account_id: str | None
    ) -> str:
        if config.type == "external":
            return self._credentials.resolve_account_id(
                provider_id, config.id, account_id=account_id
            )
        if account_id is not None:
            return account_id
        if config.type != "none":
            return self._credentials.resolve_account_id(provider_id, config.id)
        return DEFAULT_ACCOUNT_ID

    def get_adapter(self, connection: ConnectionRef) -> ProviderAdapter:
        provider_id = connection.provider_id
        connection_id = connection.connection_id
        provider_config = self._providers.get(provider_id)
        connection_config, account_id = self._connection_config(
            provider_config,
            connection_id,
        )
        if not self._credentials.is_connection_enabled(provider_id, connection_id):
            raise ConfigError(
                f"Provider connection '{provider_id}:{connection_config.id}' is disabled — "
                "enable it in Settings → Providers or via the provider CLI"
            )
        token_getter, http_transport = self._prepare_http(connection, connection_config, account_id)
        adapter_class = adapter_type_for_config(provider_config)
        if adapter_class is None:
            raise ConfigError(
                f"Unknown adapter type '{provider_config.adapter}' for provider '{provider_id}'"
            )

        extra_kwargs: dict[str, Any] = {"http_transport": http_transport}
        if adapter_class is ClaudeAgentAdapter:
            extra_kwargs["sessions"] = self._claude_sessions
            extra_kwargs["connection_id"] = connection_config.id
        if adapter_class is AntigravityAdapter:
            extra_kwargs["native"] = self._antigravity
            extra_kwargs["connection_id"] = connection_config.id
        if adapter_class in (OllamaAdapter, LMStudioAdapter):
            extra_kwargs["local_context_resolver"] = self._local_context_resolver(provider_id)
        if adapter_class is LMStudioAdapter:
            extra_kwargs["loaded_context_reporter"] = self._loaded_context_reporter(provider_id)
        if adapter_class is OpenRouterAdapter:
            extra_kwargs["routing"] = self._storage.load_openrouter_routing_settings()
        if adapter_class is OpenAIAdapter:
            # A Session's Codex socket and continuation outlive the Run's Adapter.
            extra_kwargs["responses_transports"] = self._responses_transports
            extra_kwargs["responses_connection"] = (provider_id, connection_config.id)

        base_url = connection_config.base_url
        if adapter_class is GitHubCopilotAdapter:
            copilot_endpoint = self.get_connection_token_extra(connection).get(
                COPILOT_API_ENDPOINT_EXTRA_KEY
            )
            if copilot_endpoint:
                base_url = copilot_endpoint

        # Resolve fallible Settings/profile reads before constructing an owned client.
        wire_profiles = self._wire_profiles.bind(provider_id, connection_config.id)
        display_timezone = self._display_timezone()
        adapter = cast(Any, adapter_class)(
            provider_config,
            token_getter,
            base_url,
            connection_config.auth,
            model_lookup=self._model_lookup(provider_id),
            debug_recorder=self.debug_recorder(),
            connection_mode=connection_config.mode,
            **extra_kwargs,
        )
        adapter.bind_wire_profiles(wire_profiles)
        adapter.bind_availability(provider_config.ensure_available)
        adapter.local_endpoint = is_local_provider_base_url(base_url or provider_config.base_url)
        adapter.display_timezone = display_timezone
        return cast(ProviderAdapter, adapter)

    def _display_timezone(self) -> tzinfo:
        """The Settings timezone, in which Adapters name Provider-reported times."""

        try:
            return ZoneInfo(effective_timezone_name(self._storage.load_settings()))
        except OSError, ValueError:
            _LOGGER.warning("Failed to load application timezone", exc_info=True)
            return UTC

    def get_connection_token_getter(self, connection: ConnectionRef) -> TokenGetter:
        provider_config = self._providers.get(connection.provider_id)
        connection_config, account_id = self._connection_config(
            provider_config,
            connection.connection_id,
        )
        return self._token_getter(connection, connection_config, account_id)

    def get_connection_token_extra(self, connection: ConnectionRef) -> Mapping[str, str]:
        provider_config = self._providers.get(connection.provider_id)
        connection_config, account_id = self._connection_config(
            provider_config,
            connection.connection_id,
        )
        resolved_account_id = account_id
        if resolved_account_id is None:
            try:
                resolved_account_id = self._credentials.resolve_account_id(
                    connection.provider_id,
                    connection_config.id,
                )
            except ConfigError:
                resolved_account_id = DEFAULT_ACCOUNT_ID
        token = self._token_store.load(
            Account(connection.provider_id, connection_config.id, resolved_account_id)
        )
        return {} if token is None else dict(token.extra)

    def describe_reasoning_render(
        self, provider_id: str, connection_id: str, model_id: str, effort: str | None
    ) -> ReasoningIntent:
        """Return the reasoning decision a request with ``effort`` carries.

        Describes the wire profile requests use for the Model on one local
        Connection id, learned facts included, exactly like
        :meth:`ProviderAdapter.describe_reasoning_render` on that Connection's
        Adapter.
        """
        return describe_profile_reasoning(
            self._wire_profiles.resolve(provider_id, connection_id, model_id), effort
        )

    @asynccontextmanager
    async def model_configuration_publication_async(self) -> AsyncIterator[None]:
        """Serialize catalog commit/reload with live Provider configuration publication.

        Discovery does not hold this guard. Async publishers wait for each other;
        a synchronous publisher already in progress refuses this attempt safely.
        """
        async with self._async_configuration_publication_lock:
            with self.model_configuration_publication():
                yield

    @contextmanager
    def model_configuration_publication(self) -> Iterator[None]:
        """Guard synchronous configuration publication without blocking an Event Loop."""
        if not self._configuration_publication_lock.acquire(blocking=False):
            raise ConfigError("Provider configuration is being published; retry the reload")
        try:
            yield
        finally:
            self._configuration_publication_lock.release()

    @asynccontextmanager
    async def model_database_refresh(self) -> AsyncIterator[None]:
        """Serialize complete catalog refreshes from staging through live reload.

        Manual refreshes and automatic local sweeps publish whole snapshots.
        They must share admission before copying the active root, otherwise a
        later publication can silently restore another Provider's old catalog.
        """
        if self._catalog_refresh_lock is None:
            self._catalog_refresh_lock = asyncio.Lock()
        async with self._catalog_refresh_lock:
            if self._catalog_refresh_closed:
                raise ConfigError("Provider catalog refresh is shutting down")
            task = asyncio.current_task()
            already_tracked = task in self._catalog_refresh_tasks
            if task is not None:
                self._catalog_refresh_tasks.add(task)
            try:
                yield
            finally:
                if task is not None and not already_tracked:
                    self._catalog_refresh_tasks.discard(task)

    async def refresh_model_database(
        self,
        *,
        provider_id: str | None = None,
        target: str = "runtime",
        notify_changed: bool = False,
    ) -> dict[str, Any]:
        return await _catalog_refresh.refresh_model_database(
            self, provider_id=provider_id, target=target, notify_changed=notify_changed
        )

    def external_connection_status(self, provider_id: str, connection_id: str) -> dict[str, Any]:
        """Read the last native login check without starting a program."""
        if ":" not in connection_id:
            connection_id = f"{provider_id}:{connection_id}"
        config, _ = self._connection_config(self._providers.get(provider_id), connection_id)
        if config.type != "external":
            raise ConfigError("Connection does not use an external login")
        return dict(
            self._external_status.get(
                f"{provider_id}:{config.id}",
                {"connected": False, "status": "not_checked"},
            )
        )

    async def _probe_external_connection(
        self, provider_id: str, connection: ConnectionConfig
    ) -> dict[str, Any]:
        provider = self._providers.get(provider_id)
        if connection.type != "external":
            raise ConfigError("Provider does not support an external login")
        sessions = self._external_owner(provider.adapter)
        result = await sessions.probe()
        if sessions is not self._external_owner(
            provider.adapter
        ) or not self._credentials.is_usable(provider_id, f"{provider_id}:{connection.id}"):
            raise ConfigError("External Connection changed during login check; retry the check")
        if result.get("status") == "busy":
            previous = self._external_status.get(f"{provider_id}:{connection.id}", {})
            result["connected"] = previous.get("connected", False)
            if "subscription" in previous:
                result["subscription"] = previous["subscription"]
        elif result.get("connected") and result.get("subscription") is not True:
            result = {
                **result,
                "connected": False,
                "status": result.get("status")
                if result.get("status") == "subscription_unconfirmed"
                else "api_billing",
                "message": result.get("message", SUBSCRIPTION_REQUIRED_MESSAGE),
            }
        self._external_status[f"{provider_id}:{connection.id}"] = {
            key: result[key]
            for key in ("connected", "status", "message", "subscription")
            if key in result
        }
        return result

    def _external_owner(self, adapter: str) -> ClaudeAgentSessions | AntigravityNative:
        if adapter == "claude_agent":
            return self._claude_sessions
        if adapter == "antigravity":
            return self._antigravity
        raise ConfigError("Provider does not support an external login")

    async def refresh_external_connection(
        self, provider_id: str, connection_id: str
    ) -> dict[str, Any]:
        """Check the user's native login and publish its installation catalog."""
        if self._catalog_refresh_closed:
            raise ConfigError("Provider catalog refresh is shutting down")
        task = asyncio.current_task()
        already_tracked = task in self._catalog_refresh_tasks
        if task is not None:
            self._catalog_refresh_tasks.add(task)
        try:
            return await _catalog_refresh.refresh_external_connection(
                self, provider_id, connection_id
            )
        finally:
            if task is not None and not already_tracked:
                self._catalog_refresh_tasks.discard(task)

    def discovery_credential(
        self, provider_id: str, connection_id: str, connection: ConnectionConfig
    ) -> AbstractAsyncContextManager[tuple[ConnectionConfig, str | TokenGetter]]:
        return _catalog_refresh.discovery_credential(self, provider_id, connection_id, connection)

    async def maybe_refresh_local_catalogs(self, *, force: bool = False) -> None:
        await _catalog_refresh.maybe_refresh_local_catalogs(self, force=force)

    def start_local_catalog_refresh(self) -> asyncio.Task[None]:
        task = asyncio.create_task(
            self.maybe_refresh_local_catalogs(), name="local-catalog-refresh"
        )
        self._track_catalog_refresh(task)
        return task

    def start_external_catalog_refresh(self) -> asyncio.Task[None] | None:
        return _catalog_refresh.start_external_catalog_refresh(self)

    def start_installation_catalog_restore(self) -> asyncio.Task[None] | None:
        return _catalog_refresh.start_installation_catalog_restore(self)

    def _track_catalog_refresh(self, task: asyncio.Task[None]) -> None:
        self._catalog_refresh_tasks.add(task)
        task.add_done_callback(self._catalog_refresh_tasks.discard)

    def cancel_catalog_refreshes(self) -> None:
        self._catalog_refresh_closed = True
        for task in tuple(self._catalog_refresh_tasks):
            task.cancel()

    async def shutdown_catalog_refreshes(self) -> None:
        tasks = tuple(self._catalog_refresh_tasks)
        self.cancel_catalog_refreshes()
        if tasks:
            await settle_before_cancelling(asyncio.gather(*tasks, return_exceptions=True))
            self._catalog_refresh_tasks.difference_update(tasks)

    def add_catalog_changed_callback(self, callback: Callable[[], None]) -> Callable[[], None]:
        """Subscribe to automatic catalog changes and successful startup restores.

        A manual Model DB refresh reports its own result; this channel covers
        the automatic sweeps and startup restoration. Returns an unsubscribe function.
        """
        self._catalog_changed_callbacks.append(callback)

        def unsubscribe() -> None:
            if callback in self._catalog_changed_callbacks:
                self._catalog_changed_callbacks.remove(callback)

        return unsubscribe

    def _notify_catalog_changed(self) -> None:
        for callback in tuple(self._catalog_changed_callbacks):
            try:
                callback()
            except Exception as error:
                self._logger.error(
                    "Model catalog change callback failed: %s",
                    error,
                    exc_info=(type(error), error, error.__traceback__),
                )

    def connection_reachability(self, connection_id: str) -> bool | None:
        return self._connection_reachability.get(connection_id)

    def local_context_windows(self) -> Mapping[str, Any]:
        """The local Models' windows: the user's Settings, overridden by served windows.

        A window LM Studio reports for a loaded instance replaces the Settings
        value for that Model, because it is the window the server actually
        serves; it lasts until the Adapter finds the Model unloaded.
        """
        try:
            configured = self._storage.load_local_models_settings()["context_windows"]
        except StorageError as error:
            self._logger.warning("Failed to load local-model context windows: %s", error)
            configured = {}
        with self._loaded_context_lock:
            if not self._loaded_context_windows:
                return cast(Mapping[str, Any], configured)
            return {**configured, **self._loaded_context_windows}

    def has_provider_credentials(self, provider_id: str) -> bool:
        return self._credentials.has_credentials(provider_id)

    def get_provider_credentials(self, provider_id: str) -> str:
        return self._credentials.get_credentials(provider_id)

    def get_model(self, provider_id: str, model_id: str) -> Model:
        return self._models.get(provider_id, model_id)

    def _auto_refresh_targets(self) -> list[tuple[str, ProviderConfig, ConnectionConfig]]:
        targets: list[tuple[str, ProviderConfig, ConnectionConfig]] = []
        for provider_id in self._providers.list_ids():
            provider = self._providers.get(provider_id)
            for connection in provider.connections:
                if not connection.auto_refresh:
                    continue
                if not (
                    connection.models_endpoint
                    or provider.models_endpoint
                    or connection.type == "external"
                ):
                    continue
                if not self._credentials.is_usable(
                    provider_id,
                    f"{provider_id}:{connection.id}",
                ):
                    continue
                targets.append((provider_id, provider, connection))
        return targets

    def debug_recorder(self, *, body_limit: int | None = None) -> ProviderDebugRecorder | None:
        """Return a new trace recorder while debug mode is on, else None.

        *body_limit* caps the bytes kept of each request and response body.
        """
        debug_settings = self._storage.load_debug_settings()
        if not debug_settings.get("enabled", False):
            return None
        trace_limit = debug_settings.get("trace_limit", 50)
        return ProviderDebugRecorder(
            store=DebugTraceStore(self._storage.data_dir, trace_limit=trace_limit),
            body_limit=body_limit,
        )

    @staticmethod
    def _load_wire_observations(storage: StorageManager) -> WireObservations:
        return WireObservations.load(storage.layout.artifacts / OBSERVATIONS_FILE_NAME)

    def _adapter_protocols(self, provider_id: str) -> tuple[Protocol, ...] | None:
        try:
            provider_config = self._providers.get(provider_id)
        except KeyError:
            return None
        adapter_class = adapter_type_for_config(provider_config)
        return adapter_class.WIRE_PROTOCOLS if adapter_class is not None else None

    def _resolve_model(self, provider_id: str, model_id: str) -> Model | None:
        try:
            return self._models.get(provider_id, model_id)
        except KeyError:
            return None

    def _model_lookup(self, provider_id: str) -> ModelLookup:
        def lookup(model_id: str) -> Model | None:
            try:
                return self._models.get(provider_id, model_id)
            except KeyError:
                return None

        return lookup

    def _local_context_resolver(self, provider_id: str) -> Callable[[str], int | None]:
        def resolve(model_id: str) -> int | None:
            bare_model_id = model_id.split("::", 1)[0]
            try:
                model = self._models.get(provider_id, bare_model_id)
            except KeyError, AttributeError:
                return None
            if not model_is_local(model.metadata):
                return None
            try:
                provider_config = self._providers.get(provider_id)
            except KeyError, AttributeError:
                provider_config = None
            return resolve_effective_context_window(
                model.context_window,
                provider_config,
                model_metadata=model.metadata,
                model_key=f"{provider_id}/{bare_model_id}",
                local_context_windows=self.local_context_windows(),
            )

        return resolve

    def _loaded_context_reporter(self, provider_id: str) -> Callable[[str, int | None], None]:
        def report(model_id: str, window: int | None) -> None:
            model_key = f"{provider_id}/{model_id}"
            with self._loaded_context_lock:
                previous = self._loaded_context_windows.get(model_key)
                if window is None:
                    self._loaded_context_windows.pop(model_key, None)
                else:
                    self._loaded_context_windows[model_key] = window
            if previous != window:
                self._logger.debug(
                    "Loaded context window for %s: %s (was %s)", model_key, window, previous
                )

        return report

    def _token_getter(
        self,
        connection: ConnectionRef,
        connection_config: ConnectionConfig,
        account_id: str | None,
    ) -> TokenGetter:
        provider_id = connection.provider_id
        if connection_config.type == "external":
            return StaticTokenGetter("")
        resolved_connection_id = (
            f"{provider_id}:{connection_config.id}:{account_id}"
            if account_id is not None
            else connection.connection_id
        )
        if connection_config.type in {"none", "api_key"}:
            return StaticTokenGetter(
                self._credentials.get_credentials(provider_id, resolved_connection_id)
            )
        if connection_config.type == "oauth":
            if connection_config.oauth is None:
                return StaticTokenGetter(
                    self._credentials.get_credentials(provider_id, resolved_connection_id)
                )
            resolved_account_id = account_id
            if resolved_account_id is None:
                resolved_account_id = self._credentials.resolve_account_id(
                    provider_id,
                    connection_config.id,
                )
            return OAuthTokenGetter(
                self._token_store,
                Account(provider_id, connection_config.id, resolved_account_id),
                connection_config.oauth,
            )
        raise ConfigError(
            f"Unknown connection type '{connection_config.type}' for provider '{provider_id}' "
            f"connection '{connection_config.id}'"
        )

    @staticmethod
    def _connection_config(
        provider_config: ProviderConfig,
        connection_id: str,
    ) -> tuple[ConnectionConfig, str | None]:
        local_connection_id, account_id = split_connection_id(
            provider_config.id,
            connection_id,
        )
        try:
            return provider_config.get_connection(local_connection_id), account_id
        except KeyError as error:
            raise ConfigError(
                f"Unknown connection id '{connection_id}' for provider '{provider_config.id}'"
            ) from error
