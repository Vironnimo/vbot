"""Construct the service graph inside the Runtime lifecycle owner."""

from __future__ import annotations

import asyncio
import sys
from contextlib import suppress
from dataclasses import dataclass
from datetime import UTC, datetime
from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING, Protocol, cast
from uuid import uuid4

from core.activity import SessionActivity
from core.agents import LIVE_BACKEND_BUILTIN
from core.agents.agents import Agent, AgentStore
from core.agents.temporary import TemporaryAgentRegistry
from core.archive import ArchiveService, convert_archived_projects
from core.attachments import AttachmentStore
from core.automation import (
    AutomationReferences,
    BootstrapService,
    CronService,
    GoalService,
    LearningChanges,
    ReflectionService,
    TriggerService,
)
from core.automation.inputs import DirectInputService
from core.calendar import CalendarService
from core.channels import ChannelService
from core.chat import ChatLoop, ChatLoopDependencies, ChatMessage, CommandDispatcher
from core.chat.block_resolver import ContentBlockResolver
from core.chat.session_peers import SessionPeers
from core.compaction import CompactionService
from core.computers import ComputerRegistry
from core.database import (
    DatabaseError,
    canonical_database_path,
    remove_interrupted_staging,
    retire_core_databases,
)
from core.debug import SpeechDebugStore, protect_retained_debug_artifacts
from core.extensions import ExtensionRegistry
from core.extensions.runtime import ExtensionRuntime
from core.memory import MemoryService
from core.model_tasks import (
    EmbeddingService,
    ImageService,
    LocalEmbeddingExecutor,
    LocalSpeechExecutor,
    LocalTaskTargetRegistry,
    MusicService,
    SpeechService,
    TaskModelService,
    VideoService,
)
from core.model_tasks.decisions import DecisionService
from core.model_tasks.live import LiveVoiceService, backend_instructions
from core.models.models import ModelRegistry
from core.permissions import (
    CommandChecker,
    PermissionBoundary,
    PermissionCeiling,
)
from core.projects import ProjectStore, build_agent_resolver
from core.projects.conversion import convert_project_documents
from core.prompts import (
    PromptAgentStore,
    SkillPromptRegistry,
    SystemPromptManager,
)
from core.providers.credentials import ProviderCredentialResolver
from core.providers.providers import ProviderRegistry
from core.providers.runtime import ProviderRuntime
from core.providers.token_store import TokenStore
from core.providers.usage import ProviderUsageService
from core.runs import ChatRunManager, Run
from core.runtime._agent_rename import complete_pending_rename
from core.runtime._bootstrap_services import (
    _agent_default_project,
    _archive_services,
    _build_performance_service,
    _build_scratch_areas,
    _build_terminal_manager,
    _goal_work_pending,
    _librarian_service,
)
from core.runtime._configuration import (
    _SKILLS_DIRNAME,
    _VBOT_ROOT,
    _extension_load_options,
    _extra_extension_directories,
    _global_agent_defaults,
    _positive_size_setting,
    _provider_connection_enabled_overrides,
    _resolve_resources_path,
)
from core.runtime._prompt_blocks import (
    _collect_prompt_block_definitions,
    _loaded_extension_names,
    _StorageManagerBlockStore,
)
from core.runtime._recall import RecallIntegration
from core.runtime._setup import observe_setup
from core.runtime._shutdown import clean_up_failed_startup
from core.runtime.databases import RETIRED_CANONICAL_DATABASES
from core.runtime.keep_awake import KeepAwakeController
from core.secrets import settle_plaintext_credentials
from core.secrets.agent_secrets import AgentSecrets
from core.secrets.requests import SecretRequests
from core.sessions import ChatSession, ChatSessionManager, SessionAddress
from core.sessions.titles import SessionTitleService
from core.settings.paths import (
    DEFAULT_ATTACHMENT_MAX_SIZE_BYTES,
    DEFAULT_SPEECH_UPLOAD_MAX_SIZE_BYTES,
)
from core.settings.settings import effective_timezone_name
from core.skills.authoring import SkillAuthoringService
from core.skills.policy import SkillPolicyService
from core.skills.runtime import SkillRuntime, load_global_skill_registry
from core.statistics import StatisticsIndex
from core.storage.layout import DataDirectoryLayout
from core.storage.storage import StorageManager
from core.subagents import SubAgentCoordinator
from core.subagents.links import ancestors
from core.tools import (
    ChangeTracker,
    FileReadState,
    PageBrowser,
    UpdateHandoffs,
    register_analyze_image_tool,
    register_apply_patch_tool,
    register_background_tasks_tool,
    register_edit_tools,
    register_generate_image_tool,
    register_generate_music_tool,
    register_generate_speech_tool,
    register_generate_video_tool,
    register_memory_tool,
    register_project_tool,
    register_read_tool,
    register_shell_tool,
    register_skill_manage_tool,
    register_skill_tool,
    register_terminal_tool,
    register_web_fetch_tool,
    register_web_search_tool,
)
from core.tools.calendar import register_calendar_tool
from core.tools.call_tool import register_call_tool
from core.tools.classify import register_classify_tool
from core.tools.command_manager import CommandManager
from core.tools.create_goal import register_create_goal_tool
from core.tools.cron import SessionAncestors, register_cron_tool
from core.tools.execute_code import register_execute_code_tool
from core.tools.live import LIVE_TOOL_FAMILY, LiveToolHosts, register_live_tools
from core.tools.load_tools import register_load_tools_tool
from core.tools.portal import register_portal_tool
from core.tools.portal_registry import PortalRegistry
from core.tools.secrets import register_secrets_tool
from core.tools.session import register_session_tool
from core.tools.shell import powershell_executable
from core.tools.shell_cli import ShellCliAccess
from core.tools.shell_environment import inherited_value
from core.tools.show_widget import register_show_widget_tool
from core.tools.skill import skill_loadable
from core.tools.status import register_status_tool
from core.tools.subagent import register_subagent_tools
from core.tools.tools import ToolPromptBlockRegistry, ToolRegistry
from core.tools.update_goal import register_update_goal_tool
from core.tools.vbot import register_vbot_tool
from core.tools.watch_checks import WatchCheckRunner
from core.usage import UsageRecorder
from core.utils.tls import prewarm_outbound_http
from core.utils.tokens import prewarm_estimation_encoding
from core.utils.version import detect_build_identity

if TYPE_CHECKING:
    from core.permissions.commands.commands import CommandAnalyzer
    from core.providers._usage_types import UsageWindow
    from core.runtime.runtime import Runtime


def bootstrap(runtime: Runtime) -> None:
    """Start the runtime and initialise all services.

    Creates the ``vbot.core`` logger, loads provider and model
    registries from the resources directory, and signals that the
    application is ready.  Idempotent — calling ``start()``
    more than once is a no-op (logged at debug level).
    """
    if runtime._started:
        runtime._open_log_manager().get_logger("core").debug("Runtime already started — skipping")
        return

    try:
        runtime._started_at = datetime.now(UTC)
        runtime._startup_id = str(uuid4())
        runtime._build = build = detect_build_identity()
        resources_path = _resolve_resources_path(runtime.config)

        runtime._storage = StorageManager(config=runtime._config, resources_dir=resources_path)
        storage = runtime._storage
        if storage is None:
            raise RuntimeError("Storage service not available")
        runtime._storage.ensure_directories()
        runtime.logger = runtime._open_log_manager().get_logger("core")
        runtime.logger.debug("Runtime startup initiated")
        protect_retained_debug_artifacts(runtime._storage.data_dir)
        if runtime._operational_producers == "enabled":
            runtime._storage.temporary_files.start()
        try:
            remove_interrupted_staging(runtime._storage.data_dir)
        except DatabaseError as exc:
            runtime.logger.warning(
                "Staging left by interrupted data-store operations stays until the next start: %s",
                exc,
            )
        # An update's verification start imports plaintext credential files into
        # the Secret Store without touching them, failing the verification when
        # that fails; the first normal start after activation deletes them.
        settle_plaintext_credentials(
            runtime._storage.secrets,
            mode="normal" if runtime.safe_startup_mode is None else runtime.safe_startup_mode,
        )
        if runtime.safe_startup_mode is None:
            # Not in an update's verification start: its rollback needs every
            # database still registered as the pre-update snapshot recorded it.
            try:
                retire_core_databases(runtime._storage.data_dir, RETIRED_CANONICAL_DATABASES)
            except DatabaseError as exc:
                runtime.logger.warning(
                    "Retired databases stay registered until the next start: %s", exc
                )
        settings = runtime._storage.load_settings()
        timezone_name = effective_timezone_name(settings)
        attachment_max_size_bytes = _positive_size_setting(
            runtime.logger,
            settings,
            key="attachment_max_size_bytes",
            default=DEFAULT_ATTACHMENT_MAX_SIZE_BYTES,
        )
        runtime._speech_upload_max_size_bytes = _positive_size_setting(
            runtime.logger,
            settings,
            key="speech_upload_max_size_bytes",
            default=DEFAULT_SPEECH_UPLOAD_MAX_SIZE_BYTES,
        )
        # Keep-awake is applied as soon as Settings are usable so an enabled
        # server holds its power request for the whole lifetime of the process.
        runtime._keep_awake = KeepAwakeController(runtime.logger)
        runtime._keep_awake.set_enabled(settings.get("keep_awake") is True)
        runtime._attachment_store = AttachmentStore(
            runtime._storage.data_dir,
            max_size_bytes=attachment_max_size_bytes,
        )
        data_dir_credentials = runtime._storage.load_environment()
        runtime._fallback_environment = dict(data_dir_credentials)
        custom_providers = runtime._storage.load_custom_providers_settings()

        runtime._providers = ProviderRegistry.load(
            resources_path,
            custom_providers=custom_providers,
            tolerate_invalid=True,
        )
        runtime._token_store = TokenStore(runtime._storage.secrets)
        runtime._agent_secrets = AgentSecrets(
            runtime._storage.secrets,
            clock=lambda: datetime.now(UTC),
            credential_names=lambda: tuple(runtime._fallback_environment),
        )
        runtime._agent_secrets.reload()
        runtime._agent_secrets.sweep()
        runtime._agent_secrets.set_system_values(data_dir_credentials)
        runtime._secret_requests = SecretRequests(
            runtime._agent_secrets, clock=lambda: datetime.now(UTC)
        )
        runtime._provider_credentials = ProviderCredentialResolver(
            runtime._providers,
            fallback_credentials=data_dir_credentials,
            token_store=runtime._token_store,
            enabled_overrides_loader=lambda: _provider_connection_enabled_overrides(
                runtime._storage, runtime.logger
            ),
        )

        # Opens the canonical provider-usage.db in every startup mode, so an
        # update's verification start checks it; only normal startup samples.
        async def antigravity_usage() -> tuple[UsageWindow, ...]:
            if runtime._provider_runtime is None:
                return ()
            return await runtime._provider_runtime.current_antigravity_usage()

        runtime._provider_usage = ProviderUsageService(
            runtime,
            data_root=runtime._storage.data_dir,
            antigravity_usage=antigravity_usage,
            claude_usage=lambda: (
                runtime._provider_runtime.current_claude_usage()
                if runtime._provider_runtime is not None
                else (None, ())
            ),
        )
        runtime._models = ModelRegistry.load(
            resources_path,
            runtime_models_dir=runtime._storage.layout.models,
            custom_providers=custom_providers,
        )
        # Sessions are a canonical service: it opens and verifies one database
        # before any Agent lifecycle operation can create or validate a Session.
        # Partial startup must close every Session resource in reverse order so a
        # failed start does not leak descriptors or leave a half-open database.
        runtime._chat_sessions = ChatSessionManager(
            runtime._storage.data_dir,
            store_path=runtime._storage.layout.sessions_db_path,
            secrets=runtime._storage.secrets,
        )
        if runtime.safe_startup_mode == "verification":
            # An update's verification start converts the Project configurations an
            # older vBot wrote, live and archived, under the update's data snapshot;
            # a failure fails the verification, so the update rolls back. Normal
            # startup never converts: an older document stays unreadable until
            # `vbot data-store convert` converts it.
            convert_project_documents(runtime._storage.data_dir)
            convert_archived_projects(
                runtime._storage.data_dir, runtime._chat_sessions.archive_ledger
            )
        runtime._attachment_store.collect_session_orphans(runtime._chat_sessions)
        runtime._usage_recorder = UsageRecorder(
            canonical_database_path(runtime._storage.data_dir, "model_usage"),
            pricing_lookup=runtime._models.pricing_for,
            session_source=runtime._chat_sessions,
        )
        runtime._provider_runtime = ProviderRuntime(
            providers=runtime._providers,
            models=runtime._models,
            credentials=runtime._provider_credentials,
            token_store=runtime._token_store,
            storage=runtime._storage,
            resources_path=resources_path,
            logger=runtime.logger,
            custom_providers=custom_providers,
            on_antigravity_usage=runtime._provider_usage.observe_antigravity_usage,
        )
        # Outbound HTTP clients share one TLS context and lazily imported
        # transport modules; prepare both off the Event Loop.
        prewarm_outbound_http()
        local_speech = LocalSpeechExecutor(engines_dir=runtime._storage.layout.speech_engines)
        local_embeddings = LocalEmbeddingExecutor(
            engines_dir=runtime._storage.layout.embedding_engines
        )
        runtime._model_tasks = TaskModelService(
            runtime._providers,
            runtime._models,
            runtime._provider_credentials,
            runtime._storage,
            wire_profile_resolver=runtime.wire_profile,
            local_targets=LocalTaskTargetRegistry(
                [*local_speech.targets.descriptors(), *local_embeddings.targets.descriptors()]
            ),
        )
        runtime._speech = SpeechService(
            runtime._model_tasks,
            runtime,
            runtime._storage.data_dir,
            local_executor=local_speech,
            transcription_audio_getter=runtime._storage.load_speech_settings,
            max_input_bytes=runtime._speech_upload_max_size_bytes,
            usage_recorder=runtime._usage_recorder,
            debug_recordings=SpeechDebugStore(
                runtime._storage.data_dir, runtime._storage.load_debug_settings
            ),
        )
        runtime._image = ImageService(
            runtime._model_tasks,
            runtime,
            max_input_bytes=runtime._attachment_store.max_size_bytes,
            usage_recorder=runtime._usage_recorder,
        )
        runtime._video = VideoService(
            runtime._model_tasks, runtime, usage_recorder=runtime._usage_recorder
        )
        runtime._music = MusicService(
            runtime._model_tasks, runtime, usage_recorder=runtime._usage_recorder
        )
        runtime._embeddings = EmbeddingService(
            runtime._model_tasks,
            runtime,
            usage_recorder=runtime._usage_recorder,
            local_executor=local_embeddings,
        )
        runtime._decisions = DecisionService(
            runtime._model_tasks, runtime, usage_recorder=runtime._usage_recorder
        )
        # The running Live call each Session's Live Tool calls reach.
        runtime._live_tool_hosts = LiveToolHosts()
        runtime._live_voice = LiveVoiceService(
            runtime._model_tasks,
            runtime,
            hosts=runtime._live_tool_hosts,
            usage_recorder=runtime._usage_recorder,
        )
        # Retained Usage enters the ledger before any Agent lifecycle work or
        # accessor can delete history. It resumes from its persisted cursor, so a
        # normal start reads only entries written since the previous import.
        runtime._usage_recorder.import_session_history(runtime._chat_sessions)
        # One owner of the disposable Statistics index for every reader (RPC
        # reports and Extension group usage); it holds no open resources.
        runtime._statistics_index = StatisticsIndex(runtime._storage.data_dir)
        runtime._agents = AgentStore(
            runtime._storage.data_dir,
            template_dir=resources_path / "workspace-templates",
            defaults_provider=lambda: storage.load_defaults().get("agent", {}),
            sessions=runtime._chat_sessions,
            snapshot_barrier=runtime._snapshot_barrier,
            id_references=partial(_secret_grant_references, runtime._agent_secrets),
        )
        # A Session of an Identity Agent whose creator names no working Project
        # (Channels, Automation, wake word) works in the Agent's default Project.
        runtime._chat_sessions.set_agent_default_project(
            partial(_agent_default_project, runtime._agents)
        )
        # An Identity Agent rename interrupted by the last process ends before any
        # roster read or bootstrap Agent: its Agent-owned half first, its references
        # once their owners exist and before any of them starts.
        pending_rename = runtime._agents.recover_rename()
        # Shell update handoffs are claimable only by this server process; files
        # claimed by earlier processes are retained for one update's lifetime.
        runtime._update_handoffs = UpdateHandoffs(runtime._storage.data_dir)
        runtime._update_handoffs.remove_expired_files()
        runtime._tools = ToolRegistry()
        runtime._tools.set_secrets(runtime._agent_secrets)
        # Tool-owned System Prompt block declarations (D6): the tool side of the
        # unified contributor path. Project and Sub-Agent contribute their dynamic
        # catalogs/guidance here; the runtime hands declarations to the prompt
        # manager without importing tool classes into the prompt domain.
        runtime._tool_prompt_blocks = ToolPromptBlockRegistry()
        # Each Agent's Memory history lives beside its default Workspace.
        runtime._memory_service = MemoryService(
            history_root=runtime._storage.layout.agents,
            project_history_root=runtime._storage.layout.projects,
        )
        # Read stamps protect full-file writes; the file edit Tools use the same
        # state for mutation locks and post-success drift warnings (file_state.py).
        runtime._file_state = FileReadState()
        # Session-scoped file-content tracker for git-style change statistics
        # (change_tracker.py). Shared by the file edit Tools and the chat loop.
        runtime._change_tracker = ChangeTracker(
            scratch_root=runtime._storage.layout.scratch_temporary
        )
        # Chat lists these only for Agents that load Tools on demand
        # (core/tools/on_demand.py) and on routes that need the proxy.
        register_load_tools_tool(runtime._tools, runtime._tool_prompt_blocks)
        register_call_tool(runtime._tools)
        register_read_tool(
            runtime._tools,
            attachment_store=runtime._attachment_store,
            speech_service=runtime._speech,
            file_state=runtime._file_state,
            speech_max_size_bytes=runtime._speech_upload_max_size_bytes,
        )
        register_apply_patch_tool(runtime._tools, file_state=runtime._file_state)
        register_edit_tools(runtime._tools, file_state=runtime._file_state)
        register_live_tools(runtime._tools, runtime._live_tool_hosts)
        register_vbot_tool(
            runtime._tools,
            resolve_agent=lambda context: runtime.agent_resolver.resolve_agent_async(
                context.project_id,
                context.agent_id,
                session_id=context.session_id,
                require_model=False,
                include_temporary=True,
            ),
            data_dir=runtime._storage.data_dir,
            server_bind=lambda: (runtime._server_listen_host, runtime._server_port),
            update_handoffs=runtime._update_handoffs,
        )
        # The Live backend Agent's guidance names only the Tools it has.
        runtime._tool_prompt_blocks.register(
            LIVE_TOOL_FAMILY,
            render=lambda context: backend_instructions(context.tool_available),
            owner=f"builtin:{LIVE_BACKEND_BUILTIN}",
        )
        # The local browser starts with the first page that needs it.
        runtime._page_browser = PageBrowser(runtime._storage.layout.temporary / "browser")
        register_web_fetch_tool(
            runtime._tools,
            attachment_store=runtime._attachment_store,
            temporary_files=runtime._storage.temporary_files,
            credential_resolver=runtime.resolve_environment_credential,
            settings_loader=runtime._storage.load_web_fetch_settings,
            browser=runtime._page_browser,
            input_estimate_factor=runtime._usage_recorder.input_estimate_factor,
        )
        register_web_search_tool(
            runtime._tools,
            runtime.resolve_environment_credential,
            runtime._storage.load_web_search_settings,
        )
        register_generate_speech_tool(runtime._tools, runtime._speech)
        register_classify_tool(runtime._tools, runtime._decisions)
        register_show_widget_tool(runtime._tools)
        # The server attaches the listeners; until then opening a Portal is refused.
        runtime._portals = PortalRegistry()
        register_portal_tool(runtime._tools, runtime._portals)
        register_analyze_image_tool(
            runtime._tools, runtime._image, attachment_store=runtime._attachment_store
        )
        register_generate_image_tool(runtime._tools, runtime._image)
        register_generate_video_tool(runtime._tools, runtime._video)
        register_generate_music_tool(runtime._tools, runtime._music)
        extension_dirs = _extra_extension_directories(runtime.logger, settings)
        disabled_extensions, extension_config = _extension_load_options(runtime.logger, settings)
        if runtime.safe_startup_mode is None:
            from core.extensions.dependencies import activate as activate_extension_dependencies

            activate_extension_dependencies(runtime._storage.data_dir)
            runtime._extensions = ExtensionRegistry.load(
                runtime._storage.data_dir / "extensions",
                extra_dirs=extension_dirs,
                disabled=disabled_extensions,
                config=extension_config,
                bundled_dir=resources_path / "extensions",
                config_provider=runtime._live_extension_config,
                credential_resolver=runtime.resolve_environment_credential,
            )
        else:
            runtime._extensions = ExtensionRegistry()
        failed_extension_count = len(runtime._extensions.diagnostics())
        if failed_extension_count > 0:
            runtime.logger.warning(
                "Loaded extensions with %s failed extensions; "
                "see vbot.extensions errors for details",
                failed_extension_count,
            )
        runtime._extensions.apply_providers(runtime._providers)
        runtime._extension_runtime = ExtensionRuntime(
            storage=runtime._storage,
            resources_path=resources_path,
            tools=runtime._tools,
            get_registry=lambda: runtime._extensions,
            set_registry=runtime._set_extension_registry,
            get_command_dispatcher=lambda: runtime._command_dispatcher,
            extra_directories=partial(_extra_extension_directories, runtime.logger),
            load_options=partial(_extension_load_options, runtime.logger),
            live_config=runtime._live_extension_config,
            resolve_credential=runtime.resolve_environment_credential,
            reload_recall=runtime.reload_recall_backend,
            refresh_prompts=runtime._refresh_prompt_block_definitions,
            reload_skills=runtime.reload_skills_async,
            recover_recall=runtime._recover_recall_backend_if_deactivated,
            logger=runtime.logger,
            make_host=runtime._extension_host,
            archive_uninstalled_groups=runtime._archive_uninstalled_extension_groups,
            refresh_secret_sources=runtime._refresh_secret_sources,
            providers=runtime._providers,
            get_channels=lambda: runtime._channel_service,
            integrations_changed=runtime._provider_runtime._notify_catalog_changed,
            resume_integrations=lambda: runtime._operational_producers == "enabled",
            provider_publication=runtime._provider_runtime.model_configuration_publication_async,
        )
        runtime._refresh_secret_sources()
        # Skills load after extensions: a loaded extension may bundle its own skills
        # under ``<extension>/skills/``, which ``_global_roots`` folds into the
        # global pool, so the extension layer must be in place first.
        runtime._skill_policy = SkillPolicyService(runtime._storage)
        prepared_skills = load_global_skill_registry(
            storage=runtime._storage,
            resources_path=resources_path,
            settings=settings,
            fallback_environment=data_dir_credentials,
            extensions=runtime._extensions,
            disabled_packages=runtime._skill_policy.load().disabled_packages,
            logger=runtime.logger,
            reset_documentation_cache=True,
        )
        runtime._skills = prepared_skills.registry
        invalid_skill_count = len(runtime._skills.invalid_diagnostics())
        if invalid_skill_count > 0:
            runtime.logger.warning(
                "Loaded skills with %s invalid skill directories; "
                "see vbot.skills warnings for details",
                invalid_skill_count,
            )
        register_skill_tool(
            runtime._tools,
            runtime.skills_for,
            runtime.reload_skills_async,
            runtime.archived_skill,
            runtime.background_skill_protection,
        )
        # The agent skill-authoring write core refuses the bundled skills root;
        # ``skill_manage`` writes only the calling agent's private home.
        runtime._skill_authoring = SkillAuthoringService(
            protected_roots=[
                resources_path / _SKILLS_DIRNAME,
                DataDirectoryLayout(runtime._storage.data_dir).skill_documentation,
            ],
        )
        register_skill_manage_tool(
            runtime._tools,
            runtime._skill_authoring,
            runtime.agent_skills_dir,
            runtime.invalidate_agent_skills,
            runtime._resolve_shared_skills_dir,
            runtime._resolve_external_skill_scope,
            lifecycle_guard=runtime._agents.lifecycle_guard,
            resolve_subject_created_at=runtime._agents.capture_creation_identity,
            on_changed=runtime._notify_skills_changed,
            run_started_at=runtime.run_started_at,
            follow_merge=runtime.follow_skill_merge,
            resolve_global_skills_dir=lambda: runtime.global_skills_dir,
            publish_skill=runtime._publish_agent_skill,
            refresh_global_skills=runtime.reload_skills_async,
        )
        runtime._projects = ProjectStore(
            runtime._storage.data_dir,
            sessions=runtime._chat_sessions,
            snapshot_barrier=runtime._snapshot_barrier,
        )
        runtime._skill_runtime = SkillRuntime(
            registry=runtime._skills,
            docs_path=prepared_skills.docs_path,
            policy=runtime._skill_policy,
            storage=runtime._storage,
            agents=runtime._agents,
            projects=lambda: runtime.projects,
            extensions=runtime._extensions,
            resources_path=resources_path,
            logger=runtime.logger,
            reload_skills=runtime.reload_skills,
            authoring=runtime._skill_authoring,
        )
        register_project_tool(
            runtime._tools,
            runtime._projects,
            lambda: runtime.system_prompts,
            runtime.project_context_skills,
            runtime._file_state,
            memory_service=runtime._memory_service,
        )
        register_memory_tool(runtime._tools, runtime._memory_service, projects=runtime._projects)
        runtime._temporary_agents = TemporaryAgentRegistry(
            runtime._chat_sessions,
            capture_delegation_bindings=runtime._agents.capture_delegation_bindings,
            resolve_identity=lambda agent_id: cast(
                Agent, runtime.agent_resolver.resolve_agent(None, agent_id)
            ),
            profile_rules=lambda name: runtime.agent_resolver.permission_rules_for_profile(name),
            default_rules=lambda: runtime.agent_resolver.default_permission_rules(),
            prepare_config=lambda config, project_id: (
                runtime.agent_resolver.prepare_temporary_config(config, project_id)
            ),
        )
        runtime._agent_resolver = build_agent_resolver(
            runtime._agents,
            runtime._projects,
            runtime._models,
            runtime._providers,
            runtime._provider_credentials,
            lambda: _global_agent_defaults(runtime._storage),
            permission_profiles=lambda: storage.load_settings().get("permission_profiles", {}),
            project_skill_names=runtime.project_skill_names,
            profile_skill_content=runtime.profile_skill_content,
            skill_pool_names=lambda project_id: frozenset(
                skill.name for skill in runtime.skills_for(project_id).list_all()
            ),
            tool_names=lambda: tuple(
                tool.name for tool in runtime.tools.list_tools(include_session_scoped=False)
            ),
            temporary_agents=runtime._temporary_agents,
            sessions=runtime._chat_sessions,
        )
        # Creating the bootstrap Agent and the built-in Agents enters the snapshot
        # barrier on the calling thread, the Event Loop in the server lifespan. It never
        # waits there: no request, and so no data snapshot, is served before startup
        # completes.
        agents = runtime._agents
        agents.ensure_bootstrap()
        agents.ensure_builtin_agents()
        runtime._recall = RecallIntegration(
            storage=runtime._storage,
            sessions=runtime._chat_sessions,
            tools=runtime._tools,
            models=runtime._models,
            embeddings=runtime._embeddings,
            extensions=lambda: runtime._extensions,
            logger=runtime.logger,
            agent_roster=lambda: [(agent.id, agent.name) for agent in agents.list_with_builtins()],
            skill_check=partial(skill_loadable, runtime.skills_for),
        )
        runtime._chat_sessions.recover_interrupted_runs()
        runtime._chat_run_manager = ChatRunManager(
            persistence=runtime._chat_sessions,
            input_withdrawer=runtime._chat_sessions.remove_accessor_input_async,
            admission_validator=runtime._validate_temporary_admission,
        )
        runtime.chat_runs = runtime._chat_run_manager
        runtime._scratch_areas = _build_scratch_areas(runtime)
        runtime._recall.observe_runs(runtime._chat_run_manager)
        runtime._performance = _build_performance_service(
            runtime._storage, runtime._chat_run_manager
        )
        if runtime._attachment_store is None:
            raise RuntimeError("Attachment store not available")
        resolver = ContentBlockResolver(runtime._attachment_store, transcriber=runtime._speech)
        assert runtime._models is not None
        agent_secrets = runtime._agent_secrets
        compaction_service = CompactionService(
            pricing_lookup=runtime._models.pricing_for,
            usage_recorder=runtime._usage_recorder,
            secret_masker=lambda: agent_secrets.masker,
        )

        # The reflection service starts review runs through the runtime's
        # streaming loop lazily at review time, so constructing it before the
        # loops is safe — the loops only need its notify hook.
        async def wait_for_librarian(agent_id: str) -> None:
            librarian = runtime._librarian_service
            if librarian is not None:
                await librarian.wait_for_pass(agent_id)

        runtime._reflection_service = ReflectionService(
            runtime,
            # Built later; a background review leaves the Skills to a running pass.
            librarian_wait=wait_for_librarian,
            librarian_running=lambda agent_id: (
                runtime._librarian_service is not None
                and runtime._librarian_service.running(agent_id)
            ),
        )
        # What a Run changed in Memory and own/shared Skills, and its undo.
        assert runtime._memory_service is not None
        assert runtime._skill_authoring is not None
        assert runtime._chat_run_manager is not None
        runtime._learning_changes = LearningChanges(
            memory=runtime._memory_service,
            skills=runtime._skill_authoring,
            skill_home=runtime.agent_skills_dir,
            run_active=runtime._chat_run_manager.is_running,
            project_memories=lambda: {
                project.project_id: runtime.projects.memory_workspace(project.project_id)
                for project in runtime.projects.list()
            },
            project_guard=runtime._projects.configuration_guard,
            skill_homes=lambda: {
                agent.id: runtime.agent_skills_dir(agent.id)
                for agent in runtime.agents.list_with_builtins()
            },
            agent_guard=runtime._agents.lifecycle_guard,
            subject_created_at=lambda agent_id: runtime.agents.get(agent_id).created_at,
        )
        runtime._session_title_service = SessionTitleService(
            runtime, usage_recorder=runtime._usage_recorder
        )
        assert runtime._agent_resolver is not None
        assert runtime._projects is not None
        assert runtime._providers is not None
        assert runtime._models is not None
        assert runtime._provider_credentials is not None
        assert runtime._chat_sessions is not None
        assert runtime._chat_run_manager is not None
        assert runtime._tools is not None
        assert runtime._file_state is not None
        assert runtime._storage is not None
        assert runtime._image is not None

        async def deliver_background_completions(
            run: Run, session: ChatSession
        ) -> ChatMessage | None:
            service = runtime._trigger_service
            return (
                None
                if service is None
                else await service.deliver_background_completions(run, session)
            )

        async def subagent_ancestors(address: SessionAddress) -> list[SessionAddress]:
            coordinator = runtime._subagent_coordinator
            return [] if coordinator is None else await coordinator.ancestor_sessions(address)

        chat_dependencies = ChatLoopDependencies(
            agent_resolver=runtime._agent_resolver,
            projects=runtime._projects,
            providers=runtime._providers,
            models=runtime._models,
            provider_credentials=runtime._provider_credentials,
            sessions=runtime._chat_sessions,
            run_manager=runtime._chat_run_manager,
            tools=runtime._tools,
            file_read_state=runtime._file_state,
            change_tracker=runtime._change_tracker,
            scratch_areas=runtime._scratch_areas,
            secrets=runtime._agent_secrets,
            storage=runtime._storage,
            get_extension_registry=lambda: runtime.extensions,
            get_system_prompts=lambda: runtime.system_prompts,
            get_adapter=runtime.get_adapter,
            resolve_skills=runtime.skills_for,
            refresh_skills=runtime.refresh_skills_for,
            get_local_context_windows=runtime.local_context_windows,
            image_understanding_available=runtime._image.analysis_is_available,
            usage_recorder=runtime._usage_recorder,
            deliver_background_completions=deliver_background_completions,
            get_command_manager=lambda: runtime._command_manager,
            get_context_command_runner=lambda: runtime._watch_checks,
            subagent_ancestors=subagent_ancestors,
            subagent_reply_to_user=lambda address, message_id, generation_id: (
                runtime._subagent_coordinator.subagent_reply_to_user(
                    address, message_id, generation_id
                )
                if runtime._subagent_coordinator is not None
                else None
            ),
            server_port=lambda: runtime._server_port,
            server_hosts=runtime._own_server_hosts,
            subagent_tool_usable=lambda address: (
                runtime._subagent_coordinator is None
                or runtime._subagent_coordinator.subagent_tool_usable(address)
            ),
        )
        runtime._chat_loop = ChatLoop(
            chat_dependencies,
            attachment_resolver=resolver,
            compaction_service=compaction_service,
            reflection_service=runtime._reflection_service,
            session_title_service=runtime._session_title_service,
        )
        runtime._trigger_service = TriggerService(
            runtime._chat_loop,
            runtime._chat_run_manager,
            runtime,
            sessions=runtime._chat_sessions,
            secret_masker=lambda: runtime.agent_secrets.masker,
            secrets=runtime._agent_secrets,
        )
        runtime._trigger_service.set_owned_completion_starter(runtime._start_owned_completion)
        runtime._trigger_service.set_owned_completion_validator(runtime._validate_owned_completion)
        # Analyzes restricted Sessions' commands; its analyzer starts on first use.
        runtime._command_checker = CommandChecker(_command_analyzer)
        runtime._computers = ComputerRegistry(runtime._storage.data_dir)
        runtime._terminal_manager = _build_terminal_manager(runtime)
        if runtime._operational_producers == "enabled":
            runtime._start_terminal_manager()
        runtime._command_manager = CommandManager(
            runtime._trigger_service,
            temporary_files=runtime._storage.temporary_files,
            checkpoint_store=runtime._chat_sessions,
            secrets=runtime._agent_secrets,
        )
        if runtime._operational_producers == "enabled":
            runtime._command_manager.start(recover=runtime.safe_startup_mode is None)
        runtime._goal_service = GoalService(
            sessions=runtime._chat_sessions,
            run_manager=runtime._chat_run_manager,
            chat_loop=runtime._chat_loop,
            work_pending=partial(_goal_work_pending, runtime),
        )
        # No Run is active yet: goals a previous Runtime left active pause here.
        runtime._goal_service.pause_after_restart()
        runtime._goal_service.install()
        runtime._bootstrap_service = BootstrapService(
            runtime._trigger_service,
            runtime._storage.data_dir,
            startup_id=runtime._startup_id,
            agent_resolver=runtime._agent_resolver,
            sessions=runtime._chat_sessions,
        )
        runtime._calendar_service = CalendarService(runtime._storage.data_dir, tz=timezone_name)
        # Load before the scheduler and live requests can consult the catalog.
        runtime._calendar_service.list_events()
        runtime._cron_service = CronService(
            runtime._trigger_service,
            runtime._storage.data_dir,
            agent_resolver=runtime._agent_resolver,
            sessions=runtime._chat_sessions,
            tz=timezone_name,
            calendar=runtime._calendar_service,
            secret_masker=lambda: runtime.agent_secrets.masker,
        )
        runtime._calendar_service.bind_event_jobs(runtime._cron_service)
        runtime._direct_inputs = DirectInputService(
            runtime._storage.data_dir,
            chat=runtime._chat_loop,
            sessions=runtime._chat_sessions,
            resolver=runtime._agent_resolver,
            secret_store=runtime._storage.secrets,
        )
        runtime._automation_references = AutomationReferences(
            bootstrap=runtime._bootstrap_service,
            cron=runtime._cron_service,
            inputs=runtime._direct_inputs,
        )
        runtime._librarian_service = _librarian_service(runtime)
        runtime._archive = ArchiveService(_archive_services(runtime))
        runtime._command_dispatcher = CommandDispatcher(
            runtime._chat_run_manager,
            agent_resolver=runtime._agent_resolver,
            sessions=runtime._chat_sessions,
            models=runtime._models,
            started_at=runtime._started_at,
            providers=runtime._providers,
            projects=runtime._projects,
            agents=runtime._agents,
            context_window_resolver=runtime._chat_loop.context_capacity,
            trigger_service=runtime._trigger_service,
            reflection_service=runtime._reflection_service,
            storage=runtime._storage,
            terminal_manager=runtime._terminal_manager,
            command_manager=runtime._command_manager,
            reasoning_render_describer=runtime.describe_agent_reasoning_render,
            wire_profile_describer=runtime.describe_agent_wire_profile,
            automation_references=runtime._automation_references,
            snapshot_barrier=runtime._snapshot_barrier,
            stop_all=lambda address: runtime.subagents.stop_tree(address),
            goals=runtime._goal_service,
            secrets=runtime._agent_secrets,
            secret_requests=runtime._secret_requests,
        )
        if runtime._extensions is not None:
            runtime._extensions.apply_commands(runtime._command_dispatcher)
        runtime._channel_service = ChannelService(
            runtime._trigger_service,
            runtime._chat_sessions,
            agent_store=runtime._agents,
            data_root=runtime._storage.data_dir,
            credential_resolver=runtime.resolve_environment_credential,
            attachment_store=runtime._attachment_store,
            command_dispatcher=runtime._command_dispatcher,
            interaction_dispatcher=runtime._dispatch_channel_interaction,
            tool_catalog=lambda: runtime.tools.list_tools(include_session_scoped=True),
        )
        if runtime._extensions is not None:
            runtime._extensions.apply_channels(runtime._channel_service)
        runtime._trigger_service.set_completion_run_relay(
            runtime._channel_service.relay_completion_run
        )
        runtime._goal_service.set_run_relay(runtime._channel_service.relay_completion_run)
        runtime._cron_service.set_chat_delivery(
            runtime._channel_service, reference_lock=runtime._automation_references.lock
        )
        runtime._channel_service.set_mail_sink(runtime._cron_service)
        runtime._watch_checks = WatchCheckRunner(
            agent_resolver=runtime._agent_resolver,
            sessions=runtime._chat_sessions,
            projects=runtime._projects,
            data_root=runtime._storage.data_dir,
            command_checker=runtime._command_checker,
            ceiling_boundary=partial(_watch_boundary, runtime, Path(runtime._storage.data_dir)),
            credential_names=runtime.environment_credential_names,
            protected_folders=partial(
                _protected_folders,
                Path(runtime._storage.data_dir),
                runtime._projects,
                runtime._agents,
            ),
        )
        runtime._cron_service.set_watch_checks(runtime._watch_checks)
        runtime._cron_service.set_webhook_secrets(runtime._storage.secrets)
        runtime._channel_service._notify_tool_registration_changed_hook = (
            runtime._reload_channel_tool_if_started
        )
        if pending_rename is not None:
            complete_pending_rename(runtime._agent_rename_services(), pending_rename)
        # After a settled rename, before Channels, Cron and Runs: finish or undo
        # interrupted archive operations.
        runtime._archive.recover()
        if runtime.safe_startup_mode is None and runtime._operational_producers == "enabled":
            runtime._start_channel_service()
        runtime._sync_channel_tool_registration()
        if runtime.safe_startup_mode is None and runtime._operational_producers == "enabled":
            runtime._start_cron_service()
        register_cron_tool(
            runtime._tools,
            runtime._cron_service,
            reference_lock=runtime._automation_references.lock,
            session_ancestors=_session_ancestors(runtime),
        )
        register_calendar_tool(
            runtime._tools,
            runtime._calendar_service,
            reference_lock=runtime._automation_references.lock,
            cron_service=runtime._cron_service,
        )
        runtime._subagent_coordinator = SubAgentCoordinator(
            runtime, runtime._trigger_service, secrets=runtime._agent_secrets
        )
        runtime._subagent_coordinator.install(runtime._chat_run_manager)
        runtime._shell_cli = ShellCliAccess(
            resolve_agent=lambda context: runtime.agent_resolver.resolve_agent_async(
                context.project_id,
                context.agent_id,
                session_id=context.session_id,
                require_model=False,
                include_temporary=True,
            ),
            resolve_skills=runtime.skills_for,
            data_dir=runtime._storage.data_dir,
            server_bind=lambda: (runtime._server_listen_host, runtime._server_port),
        )
        register_shell_tool(
            runtime._tools,
            runtime._command_manager,
            credential_resolver=runtime.resolve_environment_credential,
            credential_names=runtime.environment_credential_names,
            prompt_blocks=runtime._tool_prompt_blocks,
            update_handoffs=runtime._update_handoffs,
            projects=runtime._projects,
            scratch_areas=runtime._scratch_areas,
            secrets=runtime._agent_secrets,
            command_checker=runtime._command_checker,
            subagents=runtime._subagent_coordinator,
            review_shell=runtime._review_shell,
            shell_cli=runtime._shell_cli,
            protected_folders=partial(
                _protected_folders,
                Path(runtime._storage.data_dir),
                runtime._projects,
                runtime._agents,
            ),
        )
        register_execute_code_tool(
            runtime._tools,
            command_checker=runtime._command_checker,
            credential_names=runtime.environment_credential_names,
            scratch_areas=runtime._scratch_areas,
        )
        runtime._session_activity = SessionActivity(
            runs=runtime._chat_run_manager,
            commands=runtime._command_manager,
            completions=runtime._trigger_service,
            subagents=runtime._subagent_coordinator,
        )
        register_session_tool(
            runtime._tools,
            SessionPeers(
                runtime._chat_sessions, runtime._session_activity, runtime._chat_run_manager
            ),
            runtime._chat_loop,
        )
        register_subagent_tools(
            runtime._tools,
            runtime._subagent_coordinator,
            runtime._tool_prompt_blocks,
        )
        register_update_goal_tool(runtime._tools, runtime._goal_service)
        register_create_goal_tool(runtime._tools, runtime._goal_service)
        register_secrets_tool(
            runtime._tools,
            runtime._agent_secrets,
            runtime._secret_requests,
            runtime._tool_prompt_blocks,
        )
        register_background_tasks_tool(
            runtime._tools,
            runtime._command_manager,
            subagents=runtime._subagent_coordinator,
        )
        register_terminal_tool(
            runtime._tools,
            runtime._terminal_manager,
            runtime._projects,
            subagents=runtime._subagent_coordinator,
            scratch_areas=runtime._scratch_areas,
            command_checker=runtime._command_checker,
        )
        register_status_tool(
            runtime._tools,
            runtime._agent_resolver,
            runtime._chat_sessions,
            runtime._models,
            runtime._chat_run_manager,
            runtime._started_at,
            runtime._providers,
            runtime._projects,
            runtime._chat_loop.context_capacity,
            runtime.describe_agent_reasoning_render,
            runtime.timezone_name,
        )
        # Built-ins are all registered now; apply extension tools last so a
        # collision with any built-in name is skipped (built-in wins), right
        # before SystemPromptManager consumes the registry.
        if runtime._extensions is not None:
            runtime._extensions.apply_tools(runtime._tools)
        runtime._system_prompts = SystemPromptManager(
            runtime._storage,
            runtime._tools,
            cast(SkillPromptRegistry, runtime._skills),
            channel_registry=cast(ChannelService, runtime._channel_service),
            vbot_version=str(runtime._config.get("VBOT_VERSION") or build.version),
            vbot_root=_VBOT_ROOT,
            data_root=runtime._storage.data_dir,
            memory_provider=runtime._memory_service,
            block_definitions=_collect_prompt_block_definitions(
                runtime._tool_prompt_blocks, runtime._extensions
            ),
            loaded_extensions=_loaded_extension_names(runtime._extensions),
            block_store=_StorageManagerBlockStore(runtime._storage),
            agent_store=cast(PromptAgentStore, runtime._agents),
            timezone_name=runtime.timezone_name,
        )

        runtime._startup_summary = _summarize_startup(runtime)
        runtime._started = True
        observe_setup(runtime, actor="startup")
        # Every Run counts its requests with the estimation encoding. Load it off
        # the Event Loop before the first Run needs it, but after the startup
        # work it would slow down by contending for the GIL.
        prewarm_estimation_encoding()
        # Measurement only observes; safe modes are measured like normal serving.
        runtime._start_performance_service()
        if runtime.safe_startup_mode is None and runtime._operational_producers == "enabled":
            runtime._start_provider_usage_service()
            runtime._start_recall_indexing()
            runtime._start_archive_retention()
            runtime._start_scratch_areas()
            runtime._start_config_backups()
            runtime._start_librarian()
        runtime.logger.debug("Runtime started (%s)", runtime._startup_summary.describe())
        if runtime.safe_startup_mode is None and runtime._operational_producers == "enabled":
            try:
                asyncio.get_running_loop()
            except RuntimeError:
                pass
            else:
                # No task has run since synchronous bootstrap began. Install
                # accepted inputs before Cron/Channel tasks receive their first turn.
                runtime._chat_loop.prepare_accessor_inputs(
                    runtime._chat_sessions.queued_accessor_inputs()
                )
    except Exception as error:
        _log_startup_failure(runtime)
        startup_error = error
    else:
        return
    # Outside the handler, a failed cleanup step's log entry does not repeat the
    # startup traceback as its context.
    clean_up_failed_startup(runtime)
    raise startup_error


def _protected_folders(data_dir: Path, projects: ProjectStore, agents: AgentStore) -> list[str]:
    """The folders a shell command must not delete or move as a whole. Blocking.

    vBot's data directory and the roots of every Project and Workspace (user
    decision 2026-11-16; ``core/tools/_powershell.py``, Guards). A store that
    cannot be read protects nothing of its own: the command still runs.
    """
    folders = [str(data_dir)]
    with suppress(Exception):
        folders.extend(project.cwd for project in projects.list() if project.cwd)
    with suppress(Exception):
        folders.extend(
            str(agent.workspace) for agent in agents.list_with_builtins() if agent.workspace
        )
    return folders


def _watch_boundary(
    runtime: Runtime,
    data_dir: Path,
    ceiling: PermissionCeiling,
    agent_id: str | None,
    project_id: str | None,
    working_project_id: str | None,
) -> PermissionBoundary:
    """The boundary a Cron watch check of a job with *ceiling* runs under. Blocking.

    Only the ceiling's layers: a check runs no Agent. A command check (with the
    job's ``agent_id``) is composed like a Session of that Agent
    (``core.chat.session_permissions``): it works where the Agent works, its
    Workspace stays reachable and the Agent's configuration stays protected. A
    URL check needs no folders.
    """
    from core.chat import SessionPermissions, session_permissions

    if agent_id is None:
        permissions = SessionPermissions(
            rules=None,
            ceilings=(ceiling,),
            workdir=data_dir,
            project_root=None,
            workspace=None,
            agent_config=None,
            rule_files=(),
            allowed_skills=None,
        )
    else:
        agent = runtime.agent_resolver.resolve_agent(project_id, agent_id, require_model=False)
        project_root = (
            Path(runtime.projects.get(working_project_id).cwd)
            if working_project_id is not None
            else None
        )
        permissions = session_permissions(
            agent, data_dir=data_dir, project_root=project_root, ceiling=ceiling
        ).without_agent_rules()
    return permissions.boundary(
        data_dir,
        owner=None,
        loopback_port=runtime._server_port,
        own_hosts=runtime._own_server_hosts,
    )


def _command_analyzer() -> CommandAnalyzer:
    """The command analyzer of restricted Sessions, parsing with the shell's own PowerShell."""
    from core.permissions.commands.commands import CommandAnalyzer

    return CommandAnalyzer(powershell_executable=powershell_executable(inherited_value("PATH")))


def _session_ancestors(runtime: Runtime) -> SessionAncestors | None:
    """The Parent Sessions of a Sub-Agent Session, read on the Session database's pool."""
    sessions = runtime._chat_sessions
    if sessions is None:
        return None

    async def parents(address: SessionAddress) -> list[SessionAddress]:
        return await sessions.run_async(ancestors, sessions, address)

    return parents


def _log_startup_failure(runtime: Runtime) -> None:
    """Record a failed startup with its traceback before cleanup closes logging.

    Mark the reported exception so the server's uvicorn log proxy does not
    repeat its traceback after cleanup restores the host logging pipeline.
    A missing data root is never created just to hold the log.
    """
    if not runtime._data_dir.exists():
        return
    with suppress(Exception):
        runtime._open_log_manager().get_logger("core").exception("Runtime startup failed")
        error = sys.exception()
        if error is not None:
            object.__setattr__(error, "_vbot_startup_failure_logged", True)


@dataclass(frozen=True)
class RuntimeStartupSummary:
    """What a Runtime served when its startup finished."""

    tools: int
    skills: int
    usable_providers: int
    providers: int
    usable_connections: int
    connections: int
    extensions: int
    keep_awake: bool

    def describe(self) -> str:
        """Return the summary as ``key=value`` log fields."""
        return (
            f"tools={self.tools} skills={self.skills}"
            f" providers={self.usable_providers}/{self.providers}"
            f" connections={self.usable_connections}/{self.connections}"
            f" extensions={self.extensions} keep_awake={'on' if self.keep_awake else 'off'}"
        )


def _summarize_startup(runtime: Runtime) -> RuntimeStartupSummary:
    providers = runtime._providers
    provider_credentials = runtime._provider_credentials
    provider_ids: list[str] = []
    usable_provider_count = 0
    total_connection_count = 0
    usable_connection_count = 0

    if providers is not None and provider_credentials is not None:
        provider_ids = providers.list_ids()
        for provider_id in provider_ids:
            provider_is_usable = False
            for connection in providers.get(provider_id).connections:
                total_connection_count += 1
                if provider_credentials.is_usable(provider_id, f"{provider_id}:{connection.id}"):
                    usable_connection_count += 1
                    provider_is_usable = True
            if provider_is_usable:
                usable_provider_count += 1

    return RuntimeStartupSummary(
        tools=len(runtime._tools.list_tools()) if runtime._tools is not None else 0,
        skills=len(runtime._skills.list_all()) if runtime._skills is not None else 0,
        usable_providers=usable_provider_count,
        providers=len(provider_ids),
        usable_connections=usable_connection_count,
        connections=total_connection_count,
        extensions=len(_loaded_extension_names(runtime._extensions)),
        keep_awake=runtime._keep_awake is not None and runtime._keep_awake.active,
    )


class _LoopService(Protocol):
    def start(self) -> None: ...


def start_event_loop_service(service: _LoopService | None, unavailable: str) -> None:
    """Start one producer only when bootstrap runs inside a serving Event Loop."""
    if service is None:
        raise RuntimeError(unavailable)
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return
    service.start()


def _secret_grant_references(secrets: AgentSecrets, agent_id: str) -> tuple[str, ...]:
    """The Agent Secret grants a new Identity Agent ``agent_id`` would inherit."""
    return tuple(f"secret:{secret.name}" for secret in secrets.naming_identity_agent(agent_id))
