# Provider Usage

Read this reference only for Provider subscription limits, usage fetchers/parsers, caching, automatic history, or the `provider.usage*` RPCs. Session usage/cost statistics are separate domains.

## Boundary

`ProviderUsageService` reports a logged-in Connection's upstream subscription state and owns its normalized automatic observation history. Most fetchers probe the Provider; Claude Agent projects native stream observations and asks Claude Code for them with a minimal request when they are missing or stale. It does not read or aggregate vBot Sessions. `core/statistics/` remains a read-only local aggregation; the WebUI correlates the two independent sources only by time.

The Runtime owns one service instance for shared caching and the hourly collector. Live state is exposed by `provider.usage`; persisted observations by `provider.usage_history`; explicit deletion by `provider.usage_history.clear`. Chat can read passive observations without starting a fetcher or a native probe. Its local `UsageProbeRuntime` Protocol avoids importing concrete Runtime; an injectable transport keeps tests offline.

## Report contract

The frozen serializable projection is:

- `UsageWindow`: label, `used_percent` clamped to 0-100, ISO-8601 UTC `reset_at` or null, optional window duration, optional used/remaining/total unit counts and unit name (`USD` for money), and optional unlimited marker.
- `UsageCredits`: `enabled`, optional `balance`, and optional `unit` (`USD` when the Provider states a currency; null for a Provider's own credit unit, such as OpenAI's).
- `ProviderUsageSnapshot`: base Connection id, exact Account id, display name, optional plan, optional structured credits, windows, and optional error.
- `UsageReport`: generation timestamp and Provider snapshots.

`report(connections=None)` supports an optional Connection filter. Only Connections with registered fetchers and `is_usable()` are targets; disabled or uncredentialed Connections are never probed. A snapshot with neither windows, enabled credits, nor an error is omitted. The CLI exposes this as `provider usage [--connection <provider:connection-id>]...`; repeated filters are passed as one `connections` list and output includes used and derived remaining percentages, reset timestamps, window units, credits (USD with cents), and per-Provider errors.

## Passive observations

The service keeps the last successful observation per exact Connection and Account in memory. A new fetch supplies its measurement time (native Claude windows carry their own observation time); cache hits and failed probes do not advance it. Startup seeds this view from the newest stored hourly sample using its sample time. Antigravity's subscription check before each Model step and during enrollment also publishes its measured windows to the external Connection's default Account and refreshes its report cache; disconnecting clears both. When checks overlap, a check started before the latest successful measurement or disconnect cannot supersede it. The shared socket sends the current observations on connect and pushes subsequent changes (`server/events-and-reconnect.md`). Reading or displaying them never starts the live report or its polling timer.

## Automatic history

On Runtime startup inside an active event loop, the collector reads the newest stored sample time (`MAX(sampled_at)`). It samples immediately only when no sample exists or the newest sample is at least one hour old; otherwise it waits for the remainder of the hour. It never backfills missed intervals. Each automatic attempt reuses the same live cache/coalescing path as `provider.usage`; 10-second WebUI live polls are not written.

Meaningful reports are stored in the canonical `<data-dir>/provider-usage.db` (kernel name `provider_usage`, `database.md`), registered in the data-store marker and in `Runtime.canonical_databases()` / `canonical_database_specs`, so snapshots, status and restore cover it. `ProviderUsageService` opens it through `ProviderUsageHistoryStore.open(data_root)` in every startup mode (verification checks it; only normal startup samples) and closes the store it opened in `close()`/`aclose()`; an injected store stays with its caller. Providers is the only writer and owner of this normalized upstream data; Statistics neither writes nor caches it. Error snapshots are stored so upstream outages remain visible gaps with reasons; an empty report caused by having no supported usable Connection is not stored. History is unbounded (retention is manual, via clear) and survives Connection removal because rows are not coupled to current configuration. Storage contains only the normalized public projection, never raw upstream responses or credentials.

Schema (Generation 1, `core/providers/usage_history.py`): `usage_samples` (AUTOINCREMENT `sample_key`, `sampled_at`, indexed by `usage_samples_by_time` for the range read and the MAX read), `usage_snapshots` (one row per Provider snapshot, keyed by sample and report ordinal, with flattened plan/credits/error; `credits_unit` was added as a nullable column on 2026-10-08, so older rows read `unit: null`) and `usage_windows` (keyed by sample, snapshot ordinal and window ordinal). Children cascade from their sample. Every stored timestamp (`sampled_at`, `reset_at`) is canonical UTC `YYYY-MM-DDTHH:MM:SS.ffffffZ` (`core/utils/timestamps.py`); offsets are normalized on write and a naive timestamp is rejected, as are naive `since`/`until` bounds (the RPC edge reads a naive input as UTC before it reaches the store). A sample is validated completely before one write transaction (exact keys, finite numbers, `used_percent` clamped to 0-100), so an invalid report stores nothing. Reads reassemble the same public `{sampled_at, providers}` projection in report order.

All store I/O runs on the database's worker pool, off the Event Loop; the sampler's `DatabaseError` and invalid-sample failures log a warning and skip that attempt. `provider.usage_history` accepts an inclusive optional `{since?, until?}` ISO-8601 window and returns samples oldest first. `provider.usage_history.clear` deletes every sample in one transaction and returns `{deleted_samples}`; the database file itself always remains. The WebUI places an explicit confirmation in front of that destructive RPC; the CLI is `provider history list|clear --yes`.

## Concurrency, cache, and failures

Fetchers fan out concurrently. Each has a bounded timeout and fails open into its own snapshot: timeout, HTTP status, unsupported/invalid shape, or generic unavailable. One Provider cannot fail siblings.

Successful snapshots cache per exact Connection+Account target for 10 seconds, or longer where a Provider sets a polling floor (`_MIN_CACHE_TTL_SECONDS`: Ollama Cloud and Antigravity 60 seconds); error snapshots for 60 seconds. A per-target async lock coalesces concurrent cache misses so multiple browser windows and the automatic collector do not multiply outbound requests. The service caches normalized snapshots, never raw OAuth tokens.

Claude Agent bypasses that polling cache: reading its Runtime-owned immutable window observations costs no I/O, and a new stream event must appear immediately. `ClaudeAgentUsage` keeps the latest measured utilization for each native window, accepts allowed/warning/rejected events, and drops unknown or malformed utilization instead of inventing zero. Claude Code 2.1.x reports all active windows under the raw `unifiedWindows` object (per window `utilization`, `resetsAt`, `status`); its top-level entry names only the deciding window and carries no utilization. A `unifiedWindows` event replaces the whole observed set; the top-level form is a fallback for events without it. Observed live (2026-11-07): Claude Code emits the event once per native process, on its first request, and again only when a window's status changes, so a long-lived native Session process does not refresh them; the SDK offers no control request to query them. Therefore `ProviderRuntime.current_claude_usage()`, the report's source, starts one background `ClaudeAgentSessions.probe_usage()` when no window is observed or the newest observation is at least `CLAUDE_USAGE_REFRESH_SECONDS` (900) old, at most once per that interval whether or not the probe succeeds (a changed native login or executable resets the interval). The probe starts a short-lived native process with the `haiku` alias, a one-line system prompt, no tools, thinking disabled and 16 output tokens, sends `OK`, waits for the result (bound 60 s, live about 3 s), and stops; it skips the request for a non-subscription login and a full process budget, and only logs a failure type. The report returns the current windows at once; the WebUI's 10 s poll shows the probe's answer, and the hourly collector therefore triggers at most one probe per hour while nobody watches. A probe costs a negligible share of the subscription quota (user decision 2026-11-07). A reported reset expires the observation; it does not establish a new window's consumption. Windows update only when a confirmed subscription stream reports them, and closing/rebinding the native Connection clears them. Empty observations produce no snapshot. This source reads no Claude Code credentials; the ordinary hourly collector persists its meaningful report alongside other Providers.

Every fetch acquires fresh auth through Runtime token getters or reads narrowly required token-store extras. Failure logs identify the base Connection only, never its Account id or token data. Provider-specific endpoint/header/shape facts remain in each Provider's map.

OpenAI Usage uses the same `OAuthRequestRecovery` as Chat and discovery, renewing once after an actual HTTP 401 and rebuilding both Authorization and Account routing. Repeated rejection/failed renewal remains an error snapshot within the existing timeout. Copilot Usage cannot use the Copilot bearer recovery: its request uses the original GitHub OAuth extra, while the getter renews only the exchanged Copilot API token. API-key probes have no renewal capability. Coverage: `test_usage.py`.

The hourly sampler isolates each automatic attempt. An unexpected collection failure is logged at error level, then the same sampler waits for the normal interval and tries again; it does not silently terminate or spin in an immediate restart loop. An unexpected initial freshness-check failure is logged and degrades to sampling immediately.

## Supported Connections

- `antigravity:subscription`: the CLI's zero-inference `/usage` command reports remaining fractions and resets by model group. The Provider projects the available five-hour and weekly buckets through the standard Usage report (`providers/antigravity.md`).
- `claude-agent:subscription`: five-hour, weekly, Model-specific weekly and extra-usage windows from SDK `RateLimitInfo`; values come from `unifiedWindows` of Run streams and of the minimal usage probe when observations are missing or older than 15 minutes, verified live against Claude Code 2.1.317.
- `openai:subscription`: ChatGPT usage windows/credits and account-scoped Codex headers; verified endpoint details in `providers/openai.md`.
- `github-copilot:oauth`: Copilot entitlement/usage using stored GitHub OAuth extra; details in `providers/github-copilot.md`.
- `ollama-cloud:api-key`: Ollama Cloud session/weekly limits or monthly included credits with exact reset times, plus purchased USD credits, from the documented `/api/balance`; details in `providers/ollama.md`.
- `minimax:api-key`: MiniMax token-plan remains projection; details in `providers/minimax.md`.
- `openrouter:api-key`: account credits balance (USD) plus an optional API-key spending-cap window; a failed `/key` probe degrades to a credits-only snapshot. Verified endpoint details in `providers/openrouter.md`.
- `opencode-go:api-key`: OpenCode Go 5-hour, weekly and monthly percentages with reset times from an undocumented endpoint; details in `providers/opencode-go.md`. OpenCode Zen exposes no usage to an API key.

OpenAI, Ollama Cloud and OpenCode Go are live-verified as documented in their maps. OpenCode Go's endpoint is not publicly documented, and Ollama Cloud replaced its earlier undocumented one without notice on 2026-10-07; both parsers stay strict and fail open. Copilot and MiniMax parsing is intentionally fail-open against inferred upstream shapes; a mismatch must remain an error snapshot, not break the report. OpenRouter's `/credits` shape is live-verified; the spending-cap window path is unit-tested only (the probe key had no cap set).

## Source and tests

- Service lifecycle, cache, Connection selection and fetchers: `core/providers/usage.py`
- Report shapes and probe contracts: internal `core/providers/_usage_types.py`; Provider response parsing: `_usage_parsers.py`. Existing public imports remain available from `usage.py`.
- Claude Agent's thread-safe, memory-only observation projection: `_claude_agent_usage.py`; native events and Connection lifecycle are wired by `ProviderRuntime` (`providers/claude-agent.md`).
- Durable schema, validation, `provider-usage.db` store and deletion: `core/providers/usage_history.py`
- RPC validation/projection: `server/rpc/provider_usage_methods.py`
- WebUI polling/presentation: `webui/src/lib/providerUsage.svelte.js` (shared live polling for the Overview limits strip and Limits), `webui/src/components/statistics/LimitsStrip.svelte`, `webui/src/components/statistics/ProviderLimits.svelte`, `webui/src/components/statistics/LimitHistory.svelte`, `webui/src/lib/statisticsView.js`
- Focused coverage: `tests/core/providers/test_usage.py` (service and parsing through `report()`), `test_usage_history.py` (storage, off-loop reads and sampling), `tests/core/runtime/test_runtime_lifecycle.py`, `tests/server/rpc/test_provider_usage_methods.py`, and Statistics WebUI tests
