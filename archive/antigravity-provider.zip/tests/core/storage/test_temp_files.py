"""Tests for shared temporary-file allocation and retention."""

from __future__ import annotations

import asyncio
import os
import threading
import time
from datetime import timedelta
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest

from core.storage import DataDirectoryLayout, TemporaryFileManager
from core.storage import temp_files as temp_files_module
from core.storage.temp_files import artifact_owner, terminal_log_scope
from tests.directory_links import link_directory


def _age(path: Path, *, seconds: float) -> None:
    timestamp = time.time() - seconds
    os.utime(path, (timestamp, timestamp))


def test_provider_directory_spares_live_turns_and_removes_crash_leftovers(tmp_path: Path) -> None:
    manager = TemporaryFileManager(tmp_path)
    other = TemporaryFileManager(tmp_path)
    with manager.provider_directory() as active:
        (active / "transcript").write_text("running", encoding="utf-8")
        _age(active, seconds=600)
        orphan = active.with_name("work_000000000000")
        orphan.mkdir()
        (orphan / "transcript").write_text("interrupted", encoding="utf-8")
        (orphan / ".vbot-lease").touch()
        outside = tmp_path / "keep"
        outside.mkdir()
        (outside / "intact").touch()
        link_directory(orphan / "link", outside)
        _age(orphan, seconds=600)
        other.sweep()
        assert (active / "transcript").is_file()
        assert not orphan.exists()
        assert (outside / "intact").exists()
    assert not active.exists()


@pytest.mark.parametrize(
    ("category", "suffix", "directory"),
    [
        ("commands", ".log", "command_temporary"),
        ("subagents", ".md", "subagent_temporary"),
        ("terminals", ".events.jsonl", "terminal_temporary"),
    ],
)
def test_create_allocates_unique_files_in_the_category_directory(
    tmp_path: Path, category: str, suffix: str, directory: str
) -> None:
    manager = TemporaryFileManager(tmp_path)

    first = manager.create(category, suffix)
    second = manager.create(category, suffix)

    assert first.path != second.path
    assert first.path.parent == getattr(DataDirectoryLayout(tmp_path), directory)
    assert first.path.name.endswith(suffix)
    assert first.path.is_file()
    assert second.path.is_file()


@pytest.mark.parametrize(
    ("category", "suffix"),
    [
        ("unknown", ".log"),
        ("atomic", ".tmp"),
        ("bash", ".log"),
        ("commands", "log"),
        ("commands", "../escape"),
    ],
)
def test_create_rejects_unknown_categories_and_unsafe_suffixes(
    tmp_path: Path,
    category: str,
    suffix: str,
) -> None:
    manager = TemporaryFileManager(tmp_path)

    with pytest.raises(ValueError):
        manager.create(category, suffix)


def test_constructor_rejects_category_path_traversal(tmp_path: Path) -> None:
    with pytest.raises(ValueError):
        TemporaryFileManager(tmp_path, retention={"..": timedelta(hours=1)})


def test_terminal_launch_record_lives_as_long_as_its_raw_logs(tmp_path: Path) -> None:
    manager = TemporaryFileManager(tmp_path)
    owner = artifact_owner(None, "main", "example")
    scope = frozenset({"layer"})
    first = manager.create_terminal_log(owner=owner, scope=scope)
    second = manager.create_terminal_log(owner=owner, scope=scope)
    group = second.path.parent
    assert first.path.parent == group
    record = group.with_suffix(".scope")
    scope_reader = terminal_log_scope(tmp_path, owner)
    relative = second.path.relative_to(scope_reader.root).as_posix()

    first.finish()
    for path in (first.path, second.path, record):
        _age(path, seconds=80 * 60 * 60)
    manager.sweep()

    assert not first.path.exists()
    assert second.path.exists()
    assert scope_reader.allows(relative, scope)

    # The process that owned the leases stopped after writing more output.
    # The next manager has no active lease and the record is older than the log.
    second.path.write_text("retained output", encoding="utf-8")
    TemporaryFileManager(tmp_path).sweep()
    assert second.path.read_text(encoding="utf-8") == "retained output"
    assert scope_reader.allows(relative, scope)

    second.finish()
    for path in (second.path, record):
        _age(path, seconds=80 * 60 * 60)
    manager.sweep()
    assert not second.path.exists() and not record.exists()
    assert not scope_reader.allows(relative, scope)


@pytest.mark.parametrize("command_folder", ["commands", "bash"])
def test_sweep_applies_category_retention_and_spares_active_files(
    tmp_path: Path, command_folder: str
) -> None:
    manager = TemporaryFileManager(tmp_path)

    def command_log(index: int):
        if command_folder == "commands":
            return manager.create("commands", ".log")
        path = manager.root / "bash" / f"old-command-{index}.log"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("retired shell output", encoding="utf-8")
        return manager.reopen(path)

    active = manager.create("subagents", ".md")
    expired_subagent = manager.create("subagents", ".md")
    active_command = command_log(0)
    retained_command = command_log(1)
    expired_command = command_log(2)
    expired_subagent.finish()
    retained_command.finish()
    expired_command.finish()
    _age(active.path, seconds=96 * 60 * 60)
    _age(active_command.path, seconds=96 * 60 * 60)
    _age(expired_subagent.path, seconds=25 * 60 * 60)
    _age(retained_command.path, seconds=25 * 60 * 60)
    _age(expired_command.path, seconds=73 * 60 * 60)

    manager.sweep()

    assert active.path.exists()
    assert active_command.path.exists()
    assert not expired_subagent.path.exists()
    assert retained_command.path.exists()
    assert not expired_command.path.exists()


@pytest.mark.parametrize("commands_enabled", [False, True])
def test_retired_shell_logs_follow_the_enabled_commands_policy(
    tmp_path: Path, commands_enabled: bool
) -> None:
    manager = TemporaryFileManager(
        tmp_path,
        retention={"commands" if commands_enabled else "subagents": timedelta(hours=1)},
    )
    retired = manager.root / "bash" / "old-command.log"
    retired.parent.mkdir(parents=True)
    retired.write_text("retired shell output", encoding="utf-8")
    _age(retired, seconds=2 * 60 * 60)

    manager.sweep()

    assert retired.exists() is not commands_enabled


@pytest.mark.parametrize("redirected", ["artifacts", "temp", "commands", "bash"])
def test_sweep_never_follows_redirected_category_directories(
    tmp_path: Path, redirected: str
) -> None:
    data_dir = tmp_path / "data"
    manager = TemporaryFileManager(data_dir)
    outside = tmp_path / "outside"
    outside.mkdir()
    parts = ["artifacts", "temp", "bash" if redirected == "bash" else "commands"]
    depth = parts.index(redirected)
    link = data_dir.joinpath(*parts[: depth + 1])
    category = outside.joinpath(*parts[depth + 1 :])
    link.parent.mkdir(parents=True, exist_ok=True)
    category.mkdir(parents=True, exist_ok=True)
    operator_file = category / "unrelated.log"
    operator_file.write_text("must survive", encoding="utf-8")
    _age(operator_file, seconds=100 * 60 * 60)
    link_directory(link, outside)

    manager.sweep()

    assert operator_file.read_text(encoding="utf-8") == "must survive"


@pytest.mark.parametrize("overlaps", [False, True], ids=["single-lease", "overlapping-leases"])
def test_finish_is_idempotent_and_restarts_retention_clock(tmp_path: Path, overlaps: bool) -> None:
    manager = TemporaryFileManager(
        tmp_path,
        retention={"subagents": timedelta(seconds=1)},
    )
    lease = manager.create("subagents", ".md")
    other = manager.reopen(lease.path) if overlaps else None
    _age(lease.path, seconds=60)

    lease.finish()
    first_finished_mtime = lease.path.stat().st_mtime
    lease.finish()
    manager.sweep()

    assert lease.path.exists()
    assert lease.path.stat().st_mtime == first_finished_mtime
    if other is not None:
        other.finish()
        manager.sweep()
        assert lease.path.exists()
        assert lease.path.stat().st_mtime > first_finished_mtime


def test_failed_completion_timestamp_preserves_retention_and_retries(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    retention = {"commands": timedelta(seconds=1)}
    manager = TemporaryFileManager(tmp_path, retention=retention)
    lease = manager.create("commands", ".log")
    _age(lease.path, seconds=60)
    now = time.time()
    monkeypatch.setattr(temp_files_module, "time", SimpleNamespace(time=lambda: now))

    def unavailable(*_args: Any, **_kwargs: Any) -> None:
        raise PermissionError("File timestamp temporarily unavailable")

    with monkeypatch.context() as patch:
        patch.setattr(os, "utime", unavailable)
        lease.finish()
        manager.sweep()
        assert lease.path.exists()

    manager.sweep()
    restarted = TemporaryFileManager(tmp_path, retention=retention)
    restarted.sweep()
    assert lease.path.exists()
    now += 2
    restarted.sweep()
    assert not lease.path.exists()


@pytest.mark.parametrize("removed", [False, True], ids=["kept", "removed"])
@pytest.mark.parametrize("during_sweep", [False, True], ids=["before-sweep", "during-sweep"])
def test_reopen_protects_a_finished_file_until_its_new_lease_finishes(
    tmp_path: Path, removed: bool, during_sweep: bool, monkeypatch: pytest.MonkeyPatch
) -> None:
    manager = TemporaryFileManager(tmp_path, retention={"subagents": timedelta(seconds=1)})
    first = manager.create("subagents", ".md")
    first.path.write_text("first period", encoding="utf-8")
    first.finish()
    if removed:
        first.path.unlink()
    else:
        _age(first.path, seconds=60)

    leases = []

    def reopen() -> None:
        leases.append(manager.reopen(first.path))
        _age(first.path, seconds=60)

    if during_sweep:
        original_scandir = os.scandir

        def reopen_before_listing(path: Any = ".") -> Any:
            if path == first.path.parent and not leases:
                reopen()
            return original_scandir(path)

        with monkeypatch.context() as patch:
            patch.setattr(os, "scandir", reopen_before_listing)
            manager.sweep()
    else:
        reopen()
        manager.sweep()
    lease = leases[0]

    assert lease.path == first.path
    assert lease.path.read_text(encoding="utf-8") == ("" if removed else "first period")
    # Retention counts from the end of the latest period.
    lease.finish()
    manager.sweep()
    assert lease.path.exists()
    _age(lease.path, seconds=60)
    manager.sweep()
    assert not lease.path.exists()


def test_reopen_rejects_paths_outside_the_category_folders(tmp_path: Path) -> None:
    manager = TemporaryFileManager(tmp_path, retention={"subagents": timedelta(seconds=1)})
    rejected = [
        manager.root / "unknown" / "tmp_1.md",
        manager.root / "subagents" / "nested" / "tmp_1.md",
        manager.root / "tmp_1.md",
        tmp_path / "elsewhere" / "subagents" / "tmp_1.md",
    ]

    for path in rejected:
        with pytest.raises(ValueError):
            manager.reopen(path)
        assert not path.exists()


@pytest.mark.parametrize("active", [False, True], ids=["inactive-file", "active-lease"])
def test_a_failed_reopen_preserves_the_existing_protection_state(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, active: bool
) -> None:
    manager = TemporaryFileManager(tmp_path, retention={"subagents": timedelta(seconds=1)})
    lease = manager.create("subagents", ".md")
    if not active:
        lease.finish()
    _age(lease.path, seconds=60)

    def fail_touch(_path: Path, mode: int = 0o666, exist_ok: bool = True) -> None:
        raise OSError("read-only")

    with monkeypatch.context() as patch:
        patch.setattr(Path, "touch", fail_touch)
        with pytest.raises(OSError, match="read-only"):
            manager.reopen(lease.path)
    manager.sweep()

    assert lease.path.exists() is active


def test_start_sweeps_expired_crash_leftovers(tmp_path: Path) -> None:
    stale_dir = DataDirectoryLayout(tmp_path).subagent_temporary
    stale_dir.mkdir(parents=True)
    stale = stale_dir / "crash-leftover.md"
    stale.write_text("partial", encoding="utf-8")
    _age(stale, seconds=60)
    manager = TemporaryFileManager(
        tmp_path,
        retention={"subagents": timedelta(seconds=1)},
    )

    manager.start()

    assert not stale.exists()


@pytest.mark.asyncio
async def test_periodic_sweep_and_async_close(tmp_path: Path) -> None:
    manager = TemporaryFileManager(
        tmp_path,
        retention={"subagents": timedelta(milliseconds=1)},
        sweep_interval_seconds=0.01,
    )
    lease = manager.create("subagents", ".md")
    lease.finish()
    _age(lease.path, seconds=1)

    manager.start()
    for _ in range(20):
        if not lease.path.exists():
            break
        await asyncio.sleep(0.01)
    await manager.aclose()

    assert not lease.path.exists()


async def _wait_for(event: threading.Event) -> None:
    for _ in range(500):
        if event.is_set():
            return
        await asyncio.sleep(0.01)
    raise AssertionError("worker never reached the blocking filesystem call")


@pytest.mark.asyncio
async def test_background_sweep_keeps_the_event_loop_responsive(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manager = TemporaryFileManager(
        tmp_path,
        retention={"subagents": timedelta(seconds=1)},
    )
    lease = manager.create("subagents", ".md")
    lease.finish()
    _age(lease.path, seconds=60)
    category_dir = lease.path.parent
    entered = threading.Event()
    release = threading.Event()
    original_scandir = os.scandir

    def slow_scandir(path: Any = ".") -> Any:
        if path == category_dir:
            entered.set()
            release.wait(timeout=5)
        return original_scandir(path)

    monkeypatch.setattr(os, "scandir", slow_scandir)

    manager.start()
    try:
        await _wait_for(entered)
        # The directory listing is still blocked, yet the loop keeps ticking.
        loop = asyncio.get_running_loop()
        ticked_at = loop.time()
        for _ in range(5):
            await asyncio.sleep(0.01)
        assert loop.time() - ticked_at < 1
        assert not release.is_set()
        assert lease.path.exists()
    finally:
        release.set()
    for _ in range(500):
        if not lease.path.exists():
            break
        await asyncio.sleep(0.01)
    await manager.aclose()

    assert not lease.path.exists()


@pytest.mark.asyncio
@pytest.mark.parametrize("stopped_first", [False, True], ids=["direct", "after-stop"])
async def test_aclose_awaits_an_in_flight_sweep_that_stops_between_files(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    stopped_first: bool,
) -> None:
    manager = TemporaryFileManager(
        tmp_path,
        retention={"subagents": timedelta(seconds=1)},
    )
    leases = [manager.create("subagents", ".md") for _ in range(3)]
    for lease in leases:
        lease.finish()
        _age(lease.path, seconds=60)
    entered = threading.Event()
    release = threading.Event()
    unlinked: list[Path] = []
    original_unlink = Path.unlink

    def slow_unlink(path: Path, missing_ok: bool = False) -> None:
        if not unlinked:
            entered.set()
            release.wait(timeout=5)
        unlinked.append(path)
        original_unlink(path, missing_ok=missing_ok)

    monkeypatch.setattr(Path, "unlink", slow_unlink)

    manager.start()
    await _wait_for(entered)
    if stopped_first:
        manager.stop()
    closing = asyncio.create_task(manager.aclose())
    try:
        # aclose runs until the first wait for the sweep to settle.
        await asyncio.sleep(0)
        assert not closing.done()
    finally:
        release.set()
        await closing

    assert len(unlinked) == 1
    assert sum(lease.path.exists() for lease in leases) == 2


def test_one_unlink_failure_does_not_block_other_cleanup(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    manager = TemporaryFileManager(
        tmp_path,
        retention={"subagents": timedelta(seconds=1)},
    )
    blocked = manager.create("subagents", ".md")
    removable = manager.create("subagents", ".md")
    blocked.finish()
    removable.finish()
    _age(blocked.path, seconds=60)
    _age(removable.path, seconds=60)
    original_unlink = Path.unlink

    def selective_unlink(path: Path, missing_ok: bool = False) -> None:
        if path == blocked.path:
            raise OSError("busy")
        original_unlink(path, missing_ok=missing_ok)

    monkeypatch.setattr(Path, "unlink", selective_unlink)

    manager.sweep()

    assert blocked.path.exists()
    assert not removable.path.exists()


def test_short_temp_paths_retry_collisions_without_truncating_logs(tmp_path, monkeypatch):
    from core.utils import ids

    manager = TemporaryFileManager(tmp_path)
    values = iter((1, 1, 2))
    monkeypatch.setattr(ids.secrets, "randbits", lambda _bits: next(values))
    first = manager.create("commands", ".log")
    first.path.write_text("keep", encoding="utf-8")
    second = manager.create("commands", ".log")
    assert first.path.name == "tmp_000000000001.log"
    assert second.path.name == "tmp_000000000002.log"
    assert first.path.read_text(encoding="utf-8") == "keep"
