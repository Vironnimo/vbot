# Worktree Workflow

This document explains how `scripts/worktree.py` is meant to be used, what it creates, how vBot behaves inside a worktree, and what an agent or human needs to know so the workflow stays predictable.

The short version:

- stay on `main` in the primary checkout
- create one worktree per task
- list active managed worktrees when you need orientation
- work from inside that worktree directory
- start and stop the complete vBot + fake Provider test instance from inside the worktree with `scripts/test-env.py`
- merge the finished task branch into `main` with `worktree.py merge` once everything is committed
- delete the worktree only when abandoning it without merging

## What the script does

`scripts/worktree.py` manages parallel vBot checkouts under `.worktrees/`.

The entrypoint owns checkout creation, listing and command dispatch. `WorktreeContext` (`_worktree_context.py`) supplies explicit repository and executing-checkout identity, subprocesses and port locking. `WorktreeMerge` (`_worktree_merge.py`) owns merge landing, rollback and repair transactions; `WorktreeRemoval` (`_worktree_removal.py`) owns service shutdown, data ownership and checkout cleanup, including the private checkouts used by the push check. Private `_worktree_lock.py`, `_worktree_ports.py`, `_worktree_records.py`, `_worktree_seed.py`, and `_worktree_args.py` own portable locks/repair keepers and their leases, paired-port selection, marker/Git read projections, dependency seeding from another checkout, and command grammar. Behavioral tests are grouped under `tests/scripts/test_worktree*.py`, with reusable repository fixtures in `worktree_helpers.py`.

For each created worktree it does all of the following:

- creates a Git worktree under `.worktrees/<name>`
- creates a dedicated data directory at `<repo>-data/<name>`, a sibling of the repository root (for `C:/Development/projects/vBot`: `C:/Development/projects/vBot-data/<name>`)
- initializes the canonical empty data-directory structure through `core/storage/layout.py`
- writes `settings.json` in that data directory with a dedicated `server_port`, a paired local fake-Provider endpoint, and chat/fallback/image/speech fake Models
- writes a `.vbot-worktree` marker into the worktree root, which also records the assigned `server_port`
- copies the primary checkout's downloaded native executables (`resources/native/`), so provisioning the search engine only verifies the pinned digest instead of downloading it
- copies the primary checkout's `webui/node_modules` (without the Vite and Vitest caches) when npm's record of that installation (`node_modules/.package-lock.json`) matches the worktree's `webui/package-lock.json`: every installed package equals its locked entry, and only optional packages for other platforms may be missing (the comparison the commit hook's stale-package check uses, `scripts/_webui_packages.py`); otherwise it runs `npm install` in `webui/`

`create` does not build the frontend: `scripts/test-env.py start` builds it before every start, and most tasks never serve the WebUI. On Windows the copy takes seconds where `npm install` takes minutes, because writing thousands of small files dominates either way. The `npm install` fallback, needed when the branch changes frontend dependencies or the primary checkout's installation is stale, prints a progress line and then stays silent until done: on a cold npm cache it takes several minutes. Wait for the final `name:`/`path:`/`port:` block rather than cancelling.

The Worktree utility does not seed an Agent or copy machine-local Workspace content. Runtime creates the bootstrap Identity Agent and first Session on the first server start. Once you are inside the worktree, `python scripts/test-env.py start` uses the Worktree's own data dir, starts its Settings-declared fake Provider, builds the WebUI, and starts vBot. Direct `python cli/main.py server start` starts only vBot and therefore leaves fake-Model calls unavailable.

## Basic model

There are four separate things involved:

1. Git worktree
2. Dedicated data directory
3. Dedicated vBot server port
4. Dedicated fake-Provider port

For a worktree named `feature-a`, the expected layout is:

```text
vBot/.worktrees/feature-a/
vBot-data/feature-a/
```

The primary development checkout remains independent and uses:

```text
repo root          -> current branch, usually main
vBot-data/dev      -> primary development data dir
22333              -> primary development server port
```

Data directories stay outside the user profile, so a folder excluded from antivirus scanning for development (such as Windows Defender's exclusion of the projects folder) covers their database and log writes too. They stay outside the repository, because an Agent Workspace inside it would inherit the repository's Git context and ignore rules: `git` commands would act on vBot itself and the Search Tool would skip every file. Worktrees created before this layout keep their `~/.vbot-<name>` data directory until deleted; `delete` and `merge` recognize it from the marker.

The separately installed application retains the product defaults `~/.vbot` and `22332`. Development ports follow that default: the primary development server uses the next port (`22333`), and the first generated Worktree server port starts at `22334`; its paired fake Provider uses `32334`. Additional Worktrees get the next server port whose paired fake-Provider port is also unassigned and unbound.

## Normal workflow

### 1. Stay on `main` in the primary checkout

The intended setup is:

- main checkout stays on `main`
- each worktree gets its own task branch

That means you can keep spawning new worktrees from `main` without moving your
primary checkout away from `main`.

### 2. Create a worktree

From the repository root:

```bash
python scripts/worktree.py create my-task
```

Worktree names must be a single safe path segment. They may contain letters,
numbers, dots, underscores, and hyphens, and must start with a letter or number.
They must not end with a dot. `dev` is reserved, case-insensitively, for the
primary checkout. Creation refuses an existing `vBot-data/<name>` (including a
link) before changing it; choose another name or inspect the old directory.

This creates:

- `.worktrees/my-task/`
- `vBot-data/my-task/`
- a branch named `my-task`

It also prints the assigned port, data dir, path, and local URL.

If creation fails after Git has created the worktree, the script attempts to
clean up the partial worktree, its proven-owned data dir, and the managed branch.
A failure before ownership is recorded leaves the data directory for inspection.

### 3. Enter the worktree

From the repository root:

```bash
cd .worktrees/my-task
```

From this point on, use normal relative commands inside the worktree.

Examples:

```bash
python cli/main.py server status
python cli/main.py server start
python scripts/test-env.py start
python -m pytest tests/scripts/test_test_env.py
cd webui && npx vitest run src/lib/__tests__/i18n.test.js
```

### 4. List managed worktrees

From the repository root:

```bash
python scripts/worktree.py list
```

The list output includes each marker-backed worktree's name, path, branch, data
dir, port, and whether the task branch was created by the script.

### 5. Do the work inside the worktree

Treat the worktree as its own checkout.

- edit files there
- run tests there
- run the server there
- run frontend builds there

Do not assume a process launched from the main checkout will magically operate on
the worktree. The important boundary is the current working directory.

### 6. Merge the finished task into `main`

When every change is committed and the tests covering it pass, merge from anywhere. The merge runs no tests. It first checks, without touching `main`, whether the branch conflicts with it (`git merge-tree`), and reports a conflict before anything else. Then the merge commit passes the commit hook's static checks against the merged result, in a private landing checkout:

```bash
python scripts/worktree.py merge my-task
```

The command blocks while other sessions' merges or repair windows finish, then merges the task branch into `main` with `--no-ff`, removes the worktree, its dedicated data dir, and the managed branch. A merge that changes `webui/package-lock.json` also installs the merged WebUI packages in `main` (`npm ci`) once `main` has the merge. See "Merging a finished task" below for the conflict flow.

### 7. Stop the worktree server and delete the worktree without merging

For abandoned or cancelled tasks:

```bash
python scripts/worktree.py delete my-task
```

This deletes:

- the Git worktree at `.worktrees/my-task`
- the dedicated data dir `vBot-data/my-task` when its ownership records match
- the managed branch `my-task` if the script created that branch itself

On success, the command prints `status: deleted`.

Before removing anything, `delete` and `merge` stop the worktree's vBot server and fake Provider with `scripts/test-env.py stop`. A program other than vBot listening on the recorded `server_port` counts as nothing to stop: it is left running, and cleanup continues.
Unverified data is kept and reported as `data-status: preserved (ownership
unverified)`, including for older worktrees without ownership records.

If the worktree was created from an existing branch with `--from`, the existing
branch is not deleted.

## Create modes

### Default mode: create a new branch from the current HEAD

```bash
python scripts/worktree.py create my-task
```

This is the normal mode for parallel task work.

If your main checkout is on `main`, the new branch is created from `main`.

This is what you usually want when you say:

"I want to start several worktrees from main."

### Existing-branch mode: check out an already existing branch

```bash
python scripts/worktree.py create my-fix --from some-existing-branch
```

This checks out an existing branch into a new worktree instead of creating a new
branch.

Use this only when you explicitly want that exact branch.

Important:

- `--from` does not create a new branch
- `delete` does not delete that borrowed branch afterward

### Do not use `--from main` for normal parallel feature work

If your main checkout already uses `main`, then `--from main` is usually the
wrong tool for normal task branches.

For parallel work based on `main`, the intended workflow is:

```bash
python scripts/worktree.py create feature-one
python scripts/worktree.py create feature-two
python scripts/worktree.py create feature-three
```

That leaves the primary checkout on `main` and creates one new task branch per
worktree.

## Merging a finished task

`python scripts/worktree.py merge <name>` is the only supported way to land a task branch while other sessions are running. It serializes all merges and protected repair windows through an OS-level file lock in the shared Git directory — exactly one merge touches `main` at a time, and a second caller simply waits inside its own command until the first is done. Never hand-merge into `main` while sessions are running; a manual merge can collide with an automated one.

The command refuses to run when the primary checkout is not on `main` or, once it holds the merge lock, has uncommitted changes.

`main` never holds a merge in progress. The command makes the merge commit in a private landing checkout, a detached linked worktree `.worktrees/.landing-<name>-<id>` that starts from `main`, and checks it there through the commit hook. The landing checkout starts with the task worktree's mypy cache (else the primary checkout's) and, when the hook checks WebUI sources and `main` has installed WebUI packages, packages matching the merged `webui/package-lock.json`: a copy of `main`'s or the worktree's, or else a fresh `npm ci`. Only a commit that passed its check moves `main`, by a fast-forward (`git merge --ff-only`). When another commit reached `main` during the check, the command makes and checks the merge again onto the new `main`, up to three checks in all. When the merge changed `webui/package-lock.json` and `main` has installed WebUI packages, the command then runs `npm ci` in `main`'s `webui/`, because the WebUI checks refuse packages that differ from the lock.

A merge that ends early, even a killed one, therefore leaves `main` as it was; only a kill within the fast-forward itself, which takes well under a second, can leave `main` part-way. The landing checkout is removed when the merge ends. A running merge holds its lock file `.worktrees/.landing-<name>-<id>.lock`, which the OS frees when the process dies, so `create`, `delete`, `merge` and `scripts/push.py` remove every landing checkout whose lock is free, as they do the checkouts of killed pushes (`.worktrees/.push-*`). A commit check that a killed merge left running in its landing checkout touches nothing outside it.

Merges of earlier versions of this script staged the merge in `main`, so a killed one can leave `main` mid-merge (`.git/MERGE_HEAD`, with the merged files staged). A merge rolls such a leftover back safely before anything else: it restores only the files that merge changed, and only while each is still exactly as the merge left it, so other sessions' staged and unstaged work stays. When a file the leftover merge changed was changed again, it leaves the merge in place, lists those files as `changed-since-merge:`, and refuses; conclude or undo that merge by hand then. `git merge --abort` would discard other sessions' staged changes too.

On success it prints `status: merged` with the merge commit, removes the worktree, its data dir, and the managed branch (branches borrowed via `--from` are kept), and exits 0. Exit code 2 means conflicts or a merged result the commit check rejected; exit code 1 means refusal, timeout, a failed `npm ci`, a repair window that ended during the check, a `main` that cannot be fast-forwarded (local changes to the merged files, or `main` moving during each of three checks), or cleanup failure. A failed `npm ci` for the landing checkout leaves `main` unchanged. A failed `npm ci` in `main` after the merge landed prints `status: merged` first; the worktree is still removed, and `npm ci` in `main`'s `webui/` fixes the packages later (typically a file that a dev server or test watcher using `main`'s `webui/node_modules` holds on Windows; stop it first).

A rejected merge commit leaves `main` unchanged and prints the check's report. Bring `main` into your branch (`git rebase main`), fix the reported problems, commit, and retry the merge.

### Conflicts and the protected repair window

A conflicted merge rolls back completely — `main` stays untouched — and prints the conflicted files plus recovery hints:

1. Open the window with `python scripts/worktree.py repair-start <name>`. A small detached keeper process holds the merge lock on your behalf, so no other session can move `main` while you fix. The window expires after 15 minutes (`--window` to change); expiry is harmless because all fixing happens in your worktree and `main` stays clean until your final merge. A merge of the task that runs when the window expires keeps it open until that merge is done.
2. Fix in your own worktree: bring `main` into your branch (`git rebase main`), resolve, and commit.
3. Retry `python scripts/worktree.py merge <name>`. The command recognizes its own open window when it is ready to land and merges under it without waiting again: it holds the window's lease file (`vbot-merge.lock.lease` in the shared Git directory), and the keeper holds the merge lock on, past the window's deadline if need be, until the merge releases the lease. Success closes the window automatically. A window that ended before then no longer protects the merge; the command then waits for the merge lock like any other merge. A keeper that stops during the merge's check makes the merge refuse to move `main`.

Because `main` cannot move during a repair, every conflict is resolved exactly once against a frozen base — concurrent sessions cannot invalidate each other's resolutions into an endless loop. If you abandon the repair, close the window explicitly with `python scripts/worktree.py repair-finish <name>`; closing a window that already ended is a harmless `already-closed`.

The keeper replaces its holder record atomically. Readers use `core.utils.atomic.read_replaced_text` so a brief Windows sharing violation during replacement does not make an active window appear closed.

## How vBot detects the worktree context

Each worktree gets a marker file:

```text
.worktrees/<name>/.vbot-worktree
```

It stores at least the worktree data dir:

```json
{
  "data_dir": "C:\Development\projects\vBot-data\my-task",
  "managed_branch": true,
  "data_owner": "unique-token-generated-during-creation"
}
```

The matching `vBot-data/my-task/.vbot-worktree-owner.json` binds that token to the
canonical repository and worktree paths. Cleanup requires both records and
refuses redirected data roots. Copying a checkout marker alone does not transfer
data ownership. Older worktrees keep their existing config behavior, but cleanup
preserves their data and does not stop services using it.

The primary checkout's local marker additionally sets `"cwd_only": true`. That scope makes the marker apply when a command is launched from the checkout itself, but not merely because an editable installation imports code from that checkout. Script-generated task-worktree markers omit the field so their module-root fallback continues to work from the installed `vbot` entrypoint.

`Config()` uses the following precedence for the default data dir:

1. `VBOT_DATA_DIR`
2. `.vbot-worktree` in the current working directory
3. repository-root `.vbot-worktree` resolved from the module path, unless it sets `cwd_only: true`
4. `~/.vbot`

That means the worktree behavior depends on where the process is launched from. The primary checkout carries a git-ignored cwd-only `.vbot-worktree` marker selecting `vBot-data/dev` by absolute path (`{"data_dir": "<repo>-data/dev", "cwd_only": true}`, created by hand once per clone); its `settings.json` selects port `22333`. Outside that checkout, a parameterless installed CLI falls through to `~/.vbot` and port `22332`.

If you are inside `.worktrees/my-task`, normal relative entrypoints should use:

- `vBot-data/my-task`
- that worktree's assigned `server_port`

If you launch a command from the main checkout, it uses the primary development instance at `vBot-data/dev`, port `22333`, not the separately installed application at `~/.vbot:22332`.

## What a fresh agent or shell must know

A fresh agent, shell, or terminal does not automatically "know" that it should
work inside a worktree. The deciding factor is the working directory.

If an agent is supposed to work in a specific worktree, set its CWD to that
worktree first.

Good:

```bash
cd .worktrees/my-task
python scripts/test-env.py start
```

Also good:

```bash
Push-Location .worktrees/my-task
python cli/main.py server status
Pop-Location
```

Risky:

```bash
python .worktrees/my-task/scripts/test-env.py start
```

The file path points into the worktree, but the process working directory is
still the main checkout. Script entry points under `scripts/` that import vBot
packages put their own checkout first on the import path, so `test-env.py` and
the server it starts
(launched from that checkout's root) run the worktree's code even though the
editable install points at the main checkout. The default data dir and port,
however, still come from the working directory's `.vbot-worktree` marker, so
this command targets the main checkout's development instance. For the
worktree workflow, prefer changing into the worktree first and then using
relative commands.

Practical rule:

- if you want worktree behavior, enter the worktree first
- once inside, use normal relative commands

## Daily commands

### List managed worktrees

From the repository root:

```bash
python scripts/worktree.py list
```

### Check the local worktree server

From inside the worktree:

```bash
python cli/main.py server status
```

### Start the local worktree server

From inside the worktree, start the complete test instance:

```bash
python scripts/test-env.py start
```

`scripts/test-env.py start` rebuilds the frontend, starts the Settings-declared fake Provider (`scripts/fake-provider.mjs`, needs Node.js) with an owned PID under the Worktree data directory, then starts vBot. Use `python cli/main.py server start` only when intentionally testing vBot without the fake endpoint.

Start a bare worktree server as `python -m server.main`, never `python server/main.py`: the script form imports `core` through the main repo's editable install, and new RPC methods come back `method_not_found`.

### Stop the local worktree server

From inside the worktree:

```bash
python scripts/test-env.py stop
```

### Run tests inside the worktree

Run the tests that cover the change with the test runners directly, from inside the worktree:

```bash
python -m pytest tests/scripts/test_test_env.py
cd webui && npx vitest run src/lib/__tests__/i18n.test.js
```

Commits in the worktree run the tracked pre-commit hook's static checks (formatting, lint, type check), because worktrees share the repository's `core.hooksPath` setting. Neither the hook nor the merge runs tests: run the tests covering your change yourself before you commit. The complete suites run when `main` is pushed (`scripts/push.py`).

## Files generated per worktree

### `.vbot-worktree`

This is the machine-readable marker used by config and cleanup logic.

### `vBot-data/<name>/settings.json`

This contains the dedicated `server_port`, the keyless `providers.custom.fake` endpoint, manual fake Models for chat/fallback/image/speech, and the corresponding default/task-model bindings. Creation seeds only its newly created data directory. The fixture is `scripts/fake-provider-settings.json` from the checkout that runs `worktree.py` (like the data-directory layout), not from the main repository, so a branch that changes it seeds its own version. Its task-model options must be valid for the option schemas vBot builds for those fake Models (for these Custom Provider Models, TTS offers only the `mp3`/`pcm` formats and image generation only `extra_options`), otherwise saving Specialized Models fails on an untouched option; `tests/scripts/test_worktree.py` validates the seeded bindings through the same Task Model check Settings runs.

### Canonical directories and credentials

Worktree creation uses the same canonical initializer as Setup and Runtime, with exclusive root creation required. It creates every canonical directory and seeds no credentials, and leaves `agents/` empty until Runtime's first start. A concurrent creator winning the root creation race causes refusal before any seeding. Credentials a worktree server needs are saved through vBot (Settings, `vbot provider set-key`), which creates the data directory's Secret Store `secrets.json` (`.vorch/domain-maps/secrets.md`); a plaintext `.env` placed there by hand is ignored until `vbot data-store secrets convert --yes` imports it.

## Delete rules and safety

`python scripts/worktree.py delete <name>` is intentionally conservative.

Important behavior:

- it stops services and deletes data only when the expected data path and both
  ownership records match; it checks ownership again after Git removes the checkout
- missing, malformed or mismatched records and redirected roots preserve data;
  `--force` does not override this protection
- it deletes the branch only when the marker says the branch was script-managed
- if the worktree is dirty, delete fails unless you explicitly use `--force`;
  the error output lists each blocking file as an `uncommitted:` line so you
  can decide whether to commit the work or discard it with `--force`
- when `git worktree remove` fails, a non-force delete stops unless
  `git worktree list` confirms Git already deregistered the checkout (Windows
  can keep locked files behind); then it finishes the removal itself
- for proven-owned data, before removing anything it stops the worktree's managed server and fake
  Provider with `scripts/test-env.py stop` for the recorded data dir and port;
  when the worktree no longer has that script, the copy in the checkout running
  `worktree.py` is used, which still refuses to kill a fake Provider it cannot
  verify as its own
- the port comes from the data dir's `settings.json`, else from the marker; with
  neither deletion refuses, because `stop` without a port targets vBot's default
  port `22332`, where the installed application may run. Missing settings do not
  skip the stop when the marker records a port. Both sources accept only integer
  ports from 1 to 65535; JSON booleans and invalid ranges are not ports. After stopping, any remaining
  server claim on the data directory, or a failed claim check, prevents deletion.
  `vbot server stop` also refuses to stop a server whose control record belongs
  to another data directory
- a directory without `.git` is removed without `--force` only when it holds
  nothing except the worktree marker (see "Merge succeeded but cleanup failed").
  Remaining files require restored Git metadata or an explicit `--force`; a
  failed filesystem check refuses deletion. Its branch is read from
  `git worktree list`, never from the enclosing repository. If Git already
  pruned its registration, a managed marker identifies the branch by the
  worktree name; an already-removed branch needs no further cleanup. The branch is
  still deleted with `git branch -d` without `--force`, so unmerged commits keep
  their branch

Ignored files never block a non-force delete. Build artifacts such as
`node_modules/`, `webui/dist/`, `coverage/`, plan files under `docs/plans/`,
and Vite temp config bundles (`*.timestamp-*.mjs`) are all gitignored, so a
worktree that only contains generated artifacts deletes cleanly without
`--force`.

Examples:

```bash
python scripts/worktree.py delete my-task
python scripts/worktree.py delete my-task --force
```

Use `--force` only when you are sure you want to discard worktree-local changes.

## Troubleshooting

### The main checkout moved off `main`

It should not move just because you created a worktree.

To fix the main checkout:

```bash
git switch main
```

### `git worktree list` shows `prunable`

That means Git still remembers a worktree entry whose directory is already gone.

Clean it up with:

```bash
git worktree prune
```

### A command used the wrong data dir or port

Check these first:

1. Are you actually inside the worktree directory?
2. Does `.vbot-worktree` exist in that worktree root?
3. Is `VBOT_DATA_DIR` set in the environment and overriding the marker?
4. Does `vBot-data/<name>/settings.json` contain the expected `server_port`?

### The worktree server will not start because the port is busy

The script chooses the next free port when creating the worktree. If the chosen
port becomes busy later, free the conflicting process or recreate the worktree.

### Delete reported `terminated:` or `leftover:` lines

On Windows, files inside the worktree can be locked by running processes —
the common case is an orphaned `esbuild.exe` service process left behind by a
Vite build, which blocks deletion of `webui/node_modules`. `delete` handles
this automatically:

1. Processes whose executable lives inside the worktree (a literal,
   case-insensitive directory prefix) are terminated and
   reported as `terminated:` lines. These are always disposable build helpers;
   external programs (e.g. your editor) are never touched.
2. If files remain locked by an external process (e.g. an editor language
   server holding a native module), the stuck directory is renamed to
   `.worktrees/.trash-<name>-<timestamp>` and reported as a `leftover:` line.
   The worktree still counts as deleted; trash directories are swept
   automatically on later create/delete runs once the locks are gone.
3. If the emptied directory itself is the working directory of a running
   process, Windows refuses to rename it as well. This is the usual case when
   the delete or merge was started from inside the worktree: the command, and
   the shell that ran it, hold the directory until the command ends, even after
   a `cd` inside the command. Once the checkout is gone, `delete` hands the
   empty directory to a background `remove-released` process and prints a
   `note:` line. That process removes the directory as soon as no process uses
   it, waiting up to five minutes; it removes only an empty directory and leaves
   any new files or a recreated checkout untouched.

In all cases the delete finishes: owned data dir and managed branch are cleaned up.
The worktree name is reusable at once, or after the background removal in case 3.

### The frontend dependency step failed during creation

When the primary checkout's `webui/node_modules` does not match the worktree's lock, `create` runs `npm install` inside the worktree's `webui/` directory and removes the worktree when it fails. Fix the frontend dependency issue, then create the worktree again. Running `npm ci` in the primary checkout's `webui/` makes later creates copy its installation again.

### `merge` reports uncommitted changes in the primary checkout

The merge refuses to run while `main` carries uncommitted changes once no other merge holds the lock. Commit or clean them first. A merge that a killed earlier version of this script left staged in `main` is rolled back automatically first, keeping other sessions' work; see "Merging a finished task".

### A repair window did not shut down

A keeper process exits when its release signal appears, when its window expires while no merge of its task holds the lease, or when it is killed — the OS frees its lock on death either way. If `repair-finish` or a successful merge reports that the keeper did not shut down, wait for the deadline; the lock then frees itself and the next merge proceeds on its own.

### Merge succeeded but cleanup failed

The output prints `status: merged` with the commit and then an explicit cleanup error. The landed commit is safe; finish the removal manually with `python scripts/worktree.py delete <name>` (add `--force` only to discard worktree-local leftovers).

A merge started from inside the worktree no longer fails here: its cleanup hands the held, emptied directory to a background removal (see "Delete reported `terminated:` or `leftover:` lines"). Worktrees branched before that change run their own older copy of this script when the merge is invoked as `python scripts/worktree.py` from inside them, and still fail; so does a removal whose directory still holds the checkout's `.git`. In these cases the merge restores the `.vbot-worktree` marker for a retry (typically while `git worktree list` still shows the entry as `prunable`). Move the shell out in a separate command (a `cd` inside the merge command does not release it), then run `delete <name>` without `--force`. It removes the leftover directory, the data dir, Git's registration, and the merged managed branch. If Git already pruned the registration, the managed marker still identifies the branch; `git branch -d` keeps any unmerged commits reachable.

## Recommended team workflow

1. Keep the primary checkout on `main`.
2. Create one worktree per task with `python scripts/worktree.py create <name>`.
3. Change into that worktree before running any vBot command.
4. Use normal relative entrypoints from inside the worktree.
5. Run the tests covering your change while you work, and commit through the commit hook (static checks).
6. Stop the local worktree server when done.
7. Merge with `python scripts/worktree.py merge <name>` when everything is green. Use `delete <name>` only for abandoned tasks.

If you follow those rules, you can run several independent vBot instances in parallel without sharing ports, logs, or data directories, and several sessions can finish and merge at the same time without stepping on each other.
