# Permission Rules paths

Read when changing how the boundary decides a path: normalization and unsafe forms, links and junctions, how a path pattern covers a subtree, recursive and wildcard accesses, listings that skip refused entries, or case and platform differences. The decision order every check follows is in `../permissions.md` -> Decision order; rule strings in `rule-language.md`.

## Normalization

`normalize_path(path, *, base, home, platform)` gives the lexical and resolved forms exactly as the checks compare them (`_paths.py`):

1. `~`, relative paths joined to `base` (default: the working directory), separators, `.`/`..`, Windows trailing dots and spaces, `\\?\` drive prefixes, 8.3 short names (`GetLongPathNameW` on the longest existing prefix, including names without a tilde).
2. Unsafe forms are recognized lexically before any filesystem access: network paths (UNC, `\\?\UNC\`, `file://host`), device paths (`\\.\`, `\\?\GLOBALROOT`, NT `\??\`), alternate data streams and drive-relative paths. They are refused (`unsafe_form`, `location` names the form) unless an allow rule without wildcards in every layer names the path or a folder above it, and they are never resolved, so a UNC path never contacts SMB.
3. Links and junctions resolve with `os.path.realpath` (non-strict). POSIX resolves the joined path as written, so `link/..` climbs out of the link target as the kernel does; Windows resolves the lexical form, as Win32 does. Both forms must pass every later step; a refusal then names where the link leads (`resolved`).

A restricted check touches the filesystem (`realpath`, 8.3 expansion), and `build` resolves every folder and pattern prefix once.

## Patterns and subtrees

- Segment-pattern intersections are memoized in two process-wide LRU caches, each capped at 32,768 entries; distinct paths cannot grow either cache without bound. The per-segment recursion cache exists only for one comparison.
- A path pattern covers what it names and everything below it, with or without wildcards (`{workdir}/secret*` covers `{workdir}/secrets/key.pem`). Windows matching uses one-to-one Windows case mappings, preserving names such as `straße` and `strasse` as distinct. It assumes normal case-insensitive directories. POSIX matching is case-sensitive.
- Tool paths do not expand placeholders: `{workdir}` in a Tool argument is a file name, as in `ToolContext.resolve_path` (`../tools/file_state.md` -> Path resolution); only `~` expands.
- `check_path(..., glob=, subtree=, pruned=)`: `glob` (a relative rule-syntax pattern, `*.md`) and `subtree` (everything below, or below the glob's matches: a recursive delete, copy or listing) also refuse when a protected location or a deny rule could meet what they reach, segment by segment (`**` always can), except a deny below a folder named in `pruned`, which the access leaves out at every depth; `below` then names the denied part. `git`: a git operation across the files below `path`; below it only vBot's own protected locations refuse, not deny rules or rule files (`commands.md` -> Paths). The reach is case-folded like the path on Windows.
- `check_path(..., deny_only=True)` (command mentions, `permissions/commands.md` -> Paths): only deny rules and protected locations, no base refusals and no unsafe-form refusal; a path that does not exist stays lexical after normalization, without a realpath walk.
- `refusable_below(folder, access) -> tuple[str, ...]`: patterns, relative to a folder, of what below it may still be refused (deny rules, `agent.json`, install dirs for writes, the data directory; `**` is the whole folder). Below a permitted folder only these and links leading out can refuse, because bases and allow rules cover whole subtrees.
- `refused_below(folder, access) -> RefusedBelow`: the same, as a Tool result may name it: `rules`, the deny rules' parts spelled as the rules write them (letter case and closing `/**`, which the comparison keys of `refusable_below` fold on Windows; `spelled_like` in `_paths.py`), and `protected`, a flag for protected locations, whose paths the System Prompt never names. Search notes use it (`../tools/search_files.md`).
- `readable_entries(folder, entries)` keeps the `os.DirEntry`s of a listing that may be read and checks only links and junctions unless `refusable_below` names something. Both cost nothing under full access; listings, suggestions and search exclusions use them (`../tools/file_state.md` -> Path resolution, `../tools/search_files.md`).
- A launch-scoped artifact category is protected even when a general readable directory, explicit allow or approval covers it. The category's owner can grant an exact readable subtree for the current layer fingerprints. At a containing root, recursive and wildcard checks still treat the category as protected. At an authorized subtree, ordinary deny checks apply to its contents. This guards raw Terminal logs (`../tools/terminal.md` -> Permission Rules).

## Paths beyond the Tool target

Listings, missing-path suggestions, diagnostics, search roots and exclusions, image, media, Channel files, instruction files (`project` Tool, Working Project, folder notes), MCP roots and Assistant `file:` references are checked before any access, so no refused path is touched or named beyond a readable folder's entries and deny rules (`tools/file_state.md` -> Path resolution, `chat/request-building.md` for file references, `extensions/mcp.md` for roots).

## Limits

- Hardlinks to files outside the permitted folders are not detected on read: a hardlink is an ordinary file name.
- The library protects only the folders the caller names: which folders count as installation or as readable vBot artifacts (and whether a development checkout is an installation) is the caller's decision (`core/chat/_run_permissions.py`).

## Tests

`tests/core/permissions/test_permission_paths.py` (normalization, unsafe forms without filesystem access, links and junctions; Windows-only cases skip elsewhere) and the subtree, glob and listing cases of `test_permission_boundary.py`.
