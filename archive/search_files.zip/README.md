# Archived search_files Tool

Frozen source at 5bda7dd073d6e154663db9e0eee207caa36da45d. The files retain their original repository paths and Git contents.
The archive contains the Tool implementation and shared ripgrep reader, its focused tests,
domain map, Provider probes and examples, Tool registration and policy, Agent translation,
permission checks, shell/read hints, WebUI rendering and tests, and engine provisioning sources.
The ripgrep executable is provisioned from the checked-in lock file.

Restore in a worktree based on the recorded commit for the original behavior. To bring the Tool
into a later version, reconcile shared files with the current checkout, especially the shell,
Tool registry and Chat file picker. Their archived copies describe the old integration.
MANIFEST.json gives the SHA-256 digest of each original file. This archive is source, not a package.
