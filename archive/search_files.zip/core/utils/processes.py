"""OS process containment, windowless launch, program presence and confirmed tree termination."""

from __future__ import annotations

import asyncio
import contextlib
import ctypes
import functools
import os
import re
import select
import signal
import subprocess
import sys
import threading
import time
import weakref
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol, cast, override

from core.utils.logging import get_logger

if TYPE_CHECKING:
    from core.utils.workers import BoundedWorkerPool


class ProcessIdentity(Protocol):
    @property
    def pid(self) -> int: ...


_LOGGER = get_logger("processes")

HARD_KILL_SIGNAL = getattr(signal, "SIGKILL", 9)
_JOB_OBJECT_LIMIT_BREAKAWAY_OK = 0x00000800
_JOB_OBJECT_LIMIT_SILENT_BREAKAWAY_OK = 0x00001000
_JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
_JOB_OBJECT_BASIC_LIMIT_INFORMATION_CLASS = 2
_JOB_OBJECT_BASIC_PROCESS_ID_LIST_CLASS = 3
_JOB_OBJECT_EXTENDED_LIMIT_INFORMATION_CLASS = 9
_ERROR_MORE_DATA = 234
_WINDOWS_SERVER_JOB_HANDLE: int | None = None
_POSIX_LIFETIME_READ_FD: int | None = None
_POSIX_LIFETIME_WRITE_FD: int | None = None
# The guardian imports only the standard library. It runs by file path in
# isolated mode without site-packages, so neither the child's working directory
# nor its PYTHON* variables can replace a module it imports (a project's own
# ``core`` package, say), and it writes no bytecode into an installed version.
_GUARDIAN_SCRIPT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "process_guardian.py")
_GUARDIAN_INTERPRETER_OPTIONS = ("-I", "-S", "-B", "-X", "utf8")
_GUARDIAN_DISCOVERY_SECONDS = 1.0


@dataclass(frozen=True, slots=True)
class GuardedProcessLaunch:
    """Exact argv plus inherited descriptors for a contained child launch."""

    argv: tuple[str, ...]
    pass_fds: tuple[int, ...] = ()
    child_exit: GuardedChildExit | None = None


class GuardedChildExit:
    """One shell's exit, independent of the guardian's remaining descendants.

    The launching owner calls spawned after Popen and close when it releases
    the process. The child never inherits either end of this private pipe.
    """

    def __init__(self) -> None:
        self._read, self._write = os.pipe()
        os.set_blocking(self._read, False)
        self._code: int | None = None
        self._eof = False
        self._lock = threading.Lock()
        self._release_read = weakref.finalize(self, os.close, self._read)
        self._release_write = weakref.finalize(self, os.close, self._write)

    @property
    def writer(self) -> int:
        return self._write

    def spawned(self) -> None:
        with self._lock:
            if self._write >= 0:
                self._release_write()
                self._write = -1

    def poll(self) -> int | None:
        with self._lock:
            if self._code is None and not self._eof and self._read >= 0:
                try:
                    data = os.read(self._read, 32)
                except BlockingIOError:
                    return None
                if data:
                    self._code = int(data)
                else:
                    self._eof = True
            return self._code

    async def wait(self) -> int | None:
        loop = asyncio.get_running_loop()
        ready: asyncio.Future[None] = loop.create_future()

        def readable() -> None:
            if not ready.done():
                ready.set_result(None)

        descriptor = self._read
        if self.poll() is None and not self._eof and descriptor >= 0:
            loop.add_reader(descriptor, readable)
            try:
                await ready
            finally:
                loop.remove_reader(descriptor)
        return self.poll()

    def wait_blocking(self, timeout: float) -> int | None:
        with self._lock:
            if self._read >= 0:
                select.select([self._read], [], [], timeout)
        return self.poll()

    def close(self) -> None:
        with self._lock:
            self._release_read()
            self._release_write()
            self._read = self._write = -1


def activate_process_containment(*, platform_name: str = os.name) -> None:
    """Make this server process the OS-level lifetime owner of later children."""

    if platform_name == "nt":
        _activate_windows_process_job()
        return
    _activate_posix_lifetime_pipe()


def guarded_process_launch(
    argv: Sequence[str],
    *,
    env: Mapping[str, str],
    controlling_terminal: bool = False,
    report_exit: bool = False,
    platform_name: str = os.name,
) -> GuardedProcessLaunch:
    """Wrap a POSIX child with the private guardian when it needs one.

    The guardian ties the child to the server lifetime while containment is
    active. With *controlling_terminal* it also makes the PTY on the child's
    stdin its controlling terminal, so the caller must start the launch as a
    session leader (``start_new_session=True``) with the PTY slave as stdin.
    *env* is the environment the caller starts the launch with; the child
    receives it, like the caller's working directory, unchanged.
    """

    if not argv:
        raise ValueError("Process argv must not be empty")
    lifetime_fd = _POSIX_LIFETIME_READ_FD
    if platform_name == "nt" or (lifetime_fd is None and not controlling_terminal):
        return GuardedProcessLaunch(tuple(argv))
    options = ["--controlling-terminal"] if controlling_terminal else []
    if lifetime_fd is not None:
        options += ["--lifetime-fd", str(lifetime_fd)]
    child_exit = (
        GuardedChildExit()
        if report_exit and lifetime_fd is not None and sys.platform == "linux"
        else None
    )
    if child_exit is not None:
        options += ["--status-fd", str(child_exit.writer)]
    # Python's startup may set the guardian's LC_CTYPE (PEP 538 locale coercion);
    # the guardian restores the requested value, or its absence, for the child.
    if "LC_CTYPE" in env:
        options.append(f"--lc-ctype={env['LC_CTYPE']}")
    return GuardedProcessLaunch(
        (sys.executable, *_GUARDIAN_INTERPRETER_OPTIONS, _GUARDIAN_SCRIPT, *options, "--", *argv),
        (() if lifetime_fd is None else (lifetime_fd,))
        + (() if child_exit is None else (child_exit.writer,)),
        child_exit,
    )


def find_process_guardian(pid: int) -> Any | None:
    """Return this launch's identity-bearing Linux guardian, if it has one.

    Ownership stays in the kernel process tree; no server registry is needed.
    Only our isolated script with an active lifetime boundary handles a tree
    stop. Ordinary POSIX process groups retain their existing kill semantics.
    """
    if sys.platform != "linux":
        return None
    import psutil  # type: ignore[import-untyped]

    try:
        process = psutil.Process(pid)
        deadline = time.monotonic() + _GUARDIAN_DISCOVERY_SECONDS
        while not (arguments := process.cmdline()):
            # Linux can expose an empty cmdline while exec initializes a live
            # process. Treating it as an ordinary process group loses custody
            # of descendants that the guardian keeps across setsid/double-fork.
            if not process.is_running() or process.status() == psutil.STATUS_ZOMBIE:
                return None
            if time.monotonic() >= deadline:
                raise OSError(f"The command line of process {pid} is not available")
            time.sleep(0.01)
        prefix = (*_GUARDIAN_INTERPRETER_OPTIONS, _GUARDIAN_SCRIPT)
        if tuple(arguments[1 : 1 + len(prefix)]) != prefix:
            return None
        options = arguments[1 + len(prefix) :]
        if "--" in options and "--lifetime-fd" in options[: options.index("--")]:
            return process
    except psutil.NoSuchProcess:
        pass
    return None


def stop_process_guardian(guardian: Any, *, timeout: float = 5.0) -> None:
    """Ask the subreaper to kill and reap its whole tree, then confirm its exit."""
    import psutil  # type: ignore[import-untyped]

    try:
        guardian.terminate()
    except psutil.NoSuchProcess:
        return
    except psutil.AccessDenied as error:
        raise PermissionError(
            "The operating system refused to stop the process guardian"
        ) from error
    try:
        deadline = time.monotonic() + timeout
        while guardian.is_running() and guardian.status() != psutil.STATUS_ZOMBIE:
            if time.monotonic() >= deadline:
                raise OSError("The process guardian could not confirm process-tree termination")
            time.sleep(0.01)
    except psutil.NoSuchProcess:
        return
    except psutil.Error as error:
        raise OSError("The process guardian's termination could not be inspected") from error


def _activate_posix_lifetime_pipe() -> None:
    global _POSIX_LIFETIME_READ_FD, _POSIX_LIFETIME_WRITE_FD

    if _POSIX_LIFETIME_READ_FD is not None:
        return
    read_fd, write_fd = os.pipe()
    os.set_inheritable(read_fd, False)
    os.set_inheritable(write_fd, False)
    _POSIX_LIFETIME_READ_FD = read_fd
    _POSIX_LIFETIME_WRITE_FD = write_fd


def _activate_windows_process_job() -> None:
    """Assign the server to a kill-on-close Windows Job Object."""

    global _WINDOWS_SERVER_JOB_HANDLE

    if _WINDOWS_SERVER_JOB_HANDLE is not None:
        return
    from ctypes import wintypes

    windows_ctypes = cast(Any, ctypes)

    class IoCounters(ctypes.Structure):
        _fields_ = [
            ("ReadOperationCount", ctypes.c_ulonglong),
            ("WriteOperationCount", ctypes.c_ulonglong),
            ("OtherOperationCount", ctypes.c_ulonglong),
            ("ReadTransferCount", ctypes.c_ulonglong),
            ("WriteTransferCount", ctypes.c_ulonglong),
            ("OtherTransferCount", ctypes.c_ulonglong),
        ]

    class BasicLimitInformation(ctypes.Structure):
        _fields_ = [
            ("PerProcessUserTimeLimit", ctypes.c_longlong),
            ("PerJobUserTimeLimit", ctypes.c_longlong),
            ("LimitFlags", wintypes.DWORD),
            ("MinimumWorkingSetSize", ctypes.c_size_t),
            ("MaximumWorkingSetSize", ctypes.c_size_t),
            ("ActiveProcessLimit", wintypes.DWORD),
            ("Affinity", ctypes.c_size_t),
            ("PriorityClass", wintypes.DWORD),
            ("SchedulingClass", wintypes.DWORD),
        ]

    class ExtendedLimitInformation(ctypes.Structure):
        _fields_ = [
            ("BasicLimitInformation", BasicLimitInformation),
            ("IoInfo", IoCounters),
            ("ProcessMemoryLimit", ctypes.c_size_t),
            ("JobMemoryLimit", ctypes.c_size_t),
            ("PeakProcessMemoryUsed", ctypes.c_size_t),
            ("PeakJobMemoryUsed", ctypes.c_size_t),
        ]

    kernel32 = windows_ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.CreateJobObjectW.argtypes = (ctypes.c_void_p, wintypes.LPCWSTR)
    kernel32.CreateJobObjectW.restype = wintypes.HANDLE
    kernel32.SetInformationJobObject.argtypes = (
        wintypes.HANDLE,
        ctypes.c_int,
        ctypes.c_void_p,
        wintypes.DWORD,
    )
    kernel32.SetInformationJobObject.restype = wintypes.BOOL
    kernel32.AssignProcessToJobObject.argtypes = (wintypes.HANDLE, wintypes.HANDLE)
    kernel32.AssignProcessToJobObject.restype = wintypes.BOOL
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    kernel32.CloseHandle.argtypes = (wintypes.HANDLE,)
    kernel32.CloseHandle.restype = wintypes.BOOL

    job = kernel32.CreateJobObjectW(None, None)
    if not job:
        raise windows_ctypes.WinError(windows_ctypes.get_last_error())
    information = ExtendedLimitInformation()
    information.BasicLimitInformation.LimitFlags = (
        _JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE | _JOB_OBJECT_LIMIT_BREAKAWAY_OK
    )
    if not kernel32.SetInformationJobObject(
        job,
        _JOB_OBJECT_EXTENDED_LIMIT_INFORMATION_CLASS,
        ctypes.byref(information),
        ctypes.sizeof(information),
    ):
        error = windows_ctypes.WinError(windows_ctypes.get_last_error())
        kernel32.CloseHandle(job)
        raise error
    if not kernel32.AssignProcessToJobObject(job, kernel32.GetCurrentProcess()):
        error = windows_ctypes.WinError(windows_ctypes.get_last_error())
        kernel32.CloseHandle(job)
        raise error
    _WINDOWS_SERVER_JOB_HANDLE = int(job)


def subprocess_creation_flags(
    *,
    new_process_group: bool = False,
    breakaway: bool = False,
    platform_name: str = os.name,
) -> int:
    """Return platform flags for a windowless child process."""
    if platform_name != "nt":
        return 0

    flags = int(cast(Any, subprocess).CREATE_NO_WINDOW)
    if new_process_group:
        flags |= int(cast(Any, subprocess).CREATE_NEW_PROCESS_GROUP)
    if breakaway and _windows_explicit_breakaway_allowed():
        flags |= int(cast(Any, subprocess).CREATE_BREAKAWAY_FROM_JOB)
    return flags


def _read_cgroup() -> str:
    try:
        with open("/proc/self/cgroup", encoding="utf-8") as handle:
            return handle.read()
    except OSError:
        return ""


def _service_cgroup() -> bool:
    """Whether this process runs inside a service of the user's systemd manager.

    The server's unit is such a service. A system service, such as cron or a CI
    runner, is not: ``systemd-run --user`` cannot move a process out of it.
    """
    for line in _read_cgroup().splitlines():
        *manager, unit = line.rsplit(":", 1)[-1].split("/")
        if (
            unit.endswith(".service")
            and not unit.startswith("user@")
            and any(part.startswith("user@") and part.endswith(".service") for part in manager)
        ):
            return True
    return False


def outside_service_unit(arguments: list[str], *, platform_name: str = os.name) -> list[str]:
    """Return *arguments* so that the process they start survives this systemd service.

    Everything left in a service's control group ends when the service stops. A
    detached process that must outlive the server it was started from runs in a
    scope of its own instead, the counterpart of a Windows job breakaway.
    """
    if platform_name == "nt" or not _service_cgroup():
        return arguments
    return ["systemd-run", "--user", "--scope", "--quiet", "--collect", "--", *arguments]


@functools.cache
def _launch_workers() -> BoundedWorkerPool:
    # Imported on first launch: update and install paths import this module in an
    # interpreter without the application's third-party packages.
    from core.utils.workers import BoundedWorkerPool

    return BoundedWorkerPool(name="process-launch", max_workers=4)


class _ExitSignallingProtocol(asyncio.subprocess.SubprocessStreamProtocol):
    """asyncio's subprocess stream protocol that also records the OS process exit."""

    def __init__(self, limit: int, loop: asyncio.AbstractEventLoop) -> None:
        super().__init__(limit=limit, loop=loop)
        self.exited: asyncio.Future[None] = loop.create_future()

    @override
    def process_exited(self) -> None:
        super().process_exited()
        if not self.exited.done():
            self.exited.set_result(None)


class _ExitSignallingProcess(asyncio.subprocess.Process):
    """An asyncio ``Process`` whose OS exit can be awaited apart from its pipes."""

    def __init__(
        self,
        transport: asyncio.SubprocessTransport,
        protocol: _ExitSignallingProtocol,
        loop: asyncio.AbstractEventLoop,
    ) -> None:
        super().__init__(transport, protocol, loop)
        self.exited = protocol.exited


async def create_subprocess_exec(
    program: str,
    *args: str,
    stdin: int | None = None,
    stdout: int | None = None,
    stderr: int | None = None,
    limit: int = 2**16,
    on_created: Callable[[int], None] | None = None,
    **popen_arguments: Any,
) -> asyncio.subprocess.Process:
    """``asyncio.create_subprocess_exec`` without OS process creation on the Event Loop.

    asyncio's Windows Proactor creates the process and its pipes on the loop
    thread, and ``CreateProcess`` can take a second while the image is mapped
    and scanned. Here that work runs on a launch worker; the started process is
    then attached to the loop's subprocess transport, so the returned
    ``Process`` behaves exactly like asyncio's. Other platforms and loops use
    asyncio's own transport. On every platform the returned process also
    signals its OS exit to :func:`wait_for_exit`.

    *on_created* receives the new process id off the Event Loop, right after the
    process was created and before the call returns; on Windows before the
    process is attached to the loop, so a process created suspended
    (``CREATE_SUSPENDED``) runs nothing until the hook resumes it. When the hook
    raises, the process is killed and the error propagates.
    """
    loop = asyncio.get_running_loop()
    if os.name != "nt" or not isinstance(loop, getattr(asyncio, "ProactorEventLoop", ())):
        # asyncio.create_subprocess_exec, with the exit-signalling protocol.
        transport, protocol = await loop.subprocess_exec(
            lambda: _ExitSignallingProtocol(limit, loop),
            program,
            *args,
            stdin=stdin,
            stdout=stdout,
            stderr=stderr,
            **popen_arguments,
        )
        if on_created is not None:
            try:
                await asyncio.to_thread(on_created, transport.get_pid())
            except BaseException:
                release_transport = True
                try:
                    if os.name == "nt":
                        transport.kill()
                    else:
                        await asyncio.to_thread(
                            _kill_process_tree_posix,
                            _ExitSignallingProcess(transport, protocol, loop),
                        )
                except ProcessLookupError:
                    pass
                except OSError:
                    # close() sends SIGKILL to a live root. Preserve a guardian
                    # which still owns an unkillable child: it keeps retrying
                    # and the child watcher retains the transport until exit.
                    release_transport = (
                        os.name == "nt" or find_process_guardian(transport.get_pid()) is None
                    )
                    _LOGGER.warning("A rejected launch could not be fully stopped", exc_info=True)
                if release_transport:
                    transport.close()
                raise
        return _ExitSignallingProcess(transport, protocol, loop)
    return await _create_windows_subprocess_exec(
        loop, [program, *args], stdin, stdout, stderr, limit, popen_arguments, on_created
    )


async def wait_for_exit(process: asyncio.subprocess.Process) -> int:
    """Return the exit code as soon as the OS process has exited.

    ``Process.wait()`` also waits until every pipe of the process has closed,
    which a descendant that inherited the pipes can delay indefinitely. A
    process from :func:`create_subprocess_exec` reports its exit directly: the
    loop's own exit notification (IOCP on Windows, the child watcher on POSIX)
    resolves the wait, with no periodic check. Any other process falls back to
    ``Process.wait()``. Cancelling the caller never cancels the exit signal.
    """
    if process.returncode is not None:
        return process.returncode
    if not isinstance(process, _ExitSignallingProcess):
        return await process.wait()
    await asyncio.shield(process.exited)
    # asyncio records the exit code before it notifies the protocol.
    return cast(int, process.returncode)


async def _create_windows_subprocess_exec(
    loop: asyncio.AbstractEventLoop,
    argv: list[str],
    stdin: int | None,
    stdout: int | None,
    stderr: int | None,
    limit: int,
    popen_arguments: dict[str, Any],
    on_created: Callable[[int], None] | None = None,
) -> asyncio.subprocess.Process:
    if sys.platform != "win32":
        raise RuntimeError("asyncio's Windows process pipes exist only on Windows")
    from asyncio import windows_utils

    started: list[Any] = []

    def launch() -> Any:
        popen = windows_utils.Popen(
            argv, stdin=stdin, stdout=stdout, stderr=stderr, bufsize=0, **popen_arguments
        )
        started.append(popen)
        if on_created is not None:
            on_created(popen.pid)
        return popen

    try:
        popen = await _launch_workers().run(launch)
    except BaseException:
        # Cancellation waits for a started launch; never leave its process behind.
        for orphan in started:
            _discard_unattached_process(orphan)
        raise
    protocol = _ExitSignallingProtocol(limit, loop)
    waiter = loop.create_future()
    try:
        transport = _attached_transport_type()(
            loop, protocol, argv, False, stdin, stdout, stderr, 0, waiter=waiter, popen=popen
        )
    except BaseException:
        _discard_unattached_process(popen)
        raise
    try:
        await waiter
    except BaseException:
        # The same cleanup asyncio applies to a transport it constructed itself.
        transport.close()
        await transport._wait()
        raise
    return _ExitSignallingProcess(transport, protocol, loop)


@functools.cache
def _attached_transport_type() -> type[Any]:
    """asyncio's Windows subprocess transport, attached to an already started process."""
    from asyncio import windows_events

    base = cast(Any, windows_events)._WindowsSubprocessTransport

    class AttachedWindowsSubprocessTransport(base):  # type: ignore[misc, valid-type]
        def _start(self, *_args: Any, popen: Any, **_kwargs: Any) -> None:
            # asyncio's own _start, minus creating the process on the loop.
            self._proc = popen

            def exited(_future: Any) -> None:
                self._process_exited(popen.poll())

            waiting = self._loop._proactor.wait_for_handle(int(popen._handle))
            waiting.add_done_callback(exited)

    return AttachedWindowsSubprocessTransport


def _discard_unattached_process(popen: Any) -> None:
    with contextlib.suppress(OSError):
        popen.kill()
    for stream in (popen.stdin, popen.stdout, popen.stderr):
        if stream is not None:
            with contextlib.suppress(OSError):
                stream.close()


def _windows_explicit_breakaway_allowed() -> bool:
    """Return whether the immediate Windows Job permits explicit breakaway."""
    from ctypes import wintypes

    windows_ctypes = cast(Any, ctypes)

    class BasicLimitInformation(ctypes.Structure):
        _fields_ = [
            ("PerProcessUserTimeLimit", ctypes.c_longlong),
            ("PerJobUserTimeLimit", ctypes.c_longlong),
            ("LimitFlags", wintypes.DWORD),
            ("MinimumWorkingSetSize", ctypes.c_size_t),
            ("MaximumWorkingSetSize", ctypes.c_size_t),
            ("ActiveProcessLimit", wintypes.DWORD),
            ("Affinity", ctypes.c_size_t),
            ("PriorityClass", wintypes.DWORD),
            ("SchedulingClass", wintypes.DWORD),
        ]

    kernel32 = windows_ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.GetCurrentProcess.argtypes = []
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    kernel32.IsProcessInJob.argtypes = [wintypes.HANDLE, wintypes.HANDLE, wintypes.LPBOOL]
    kernel32.IsProcessInJob.restype = wintypes.BOOL
    kernel32.QueryInformationJobObject.argtypes = [
        wintypes.HANDLE,
        ctypes.c_int,
        ctypes.c_void_p,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
    ]
    kernel32.QueryInformationJobObject.restype = wintypes.BOOL
    in_job = wintypes.BOOL()
    if not kernel32.IsProcessInJob(kernel32.GetCurrentProcess(), None, ctypes.byref(in_job)):
        raise windows_ctypes.WinError(windows_ctypes.get_last_error())
    if not in_job.value:
        return False
    limits = BasicLimitInformation()
    if not kernel32.QueryInformationJobObject(
        None,
        _JOB_OBJECT_BASIC_LIMIT_INFORMATION_CLASS,
        ctypes.byref(limits),
        ctypes.sizeof(limits),
        None,
    ):
        raise windows_ctypes.WinError(windows_ctypes.get_last_error())
    limit_flags = int(limits.LimitFlags)
    if limit_flags & _JOB_OBJECT_LIMIT_SILENT_BREAKAWAY_OK:
        return False
    return bool(limit_flags & _JOB_OBJECT_LIMIT_BREAKAWAY_OK)


@dataclass(frozen=True, slots=True)
class ForeignJob:
    """Another application's Windows Job that holds this process.

    ``name`` and ``pid`` identify the outermost ancestor of this process inside
    that Job, usually the application whose exit ends the Job and every process
    in it. ``confines_children`` is true when a child started with
    ``subprocess_creation_flags(breakaway=True)`` stays inside the Job as well.
    """

    name: str
    pid: int
    confines_children: bool


def foreign_job(*, platform_name: str = os.name) -> ForeignJob | None:
    """Return the Windows Job of another application that holds this process, if any.

    Only the immediate Job is visible. Its outermost member in this process's
    ancestry decides whose it is: a vBot executable (the tray in the Job of the
    logon tasks, a server in its own Job) makes it vBot's, and this process
    itself (its parent is outside the Job, so nothing tells who placed it
    there) makes it unknown; both return ``None``. Windows API failures raise
    ``OSError``.
    """
    if platform_name != "nt":
        return None
    job = _windows_immediate_job()
    if job is None:
        return None
    members, limit_flags = job
    import psutil  # type: ignore[import-untyped]

    current = owner = psutil.Process()
    # Ancestry is best effort: an exited or inaccessible parent ends the walk.
    with contextlib.suppress(psutil.Error):
        while (parent := owner.parent()) is not None and parent.pid in members:
            owner = parent
    if owner.pid == current.pid:
        return None
    try:
        name = str(owner.name())
    except psutil.Error:
        name = "an unidentified process"
    if name.lower().startswith("vbot"):
        return None
    escapes = _JOB_OBJECT_LIMIT_BREAKAWAY_OK | _JOB_OBJECT_LIMIT_SILENT_BREAKAWAY_OK
    return ForeignJob(name, owner.pid, confines_children=not limit_flags & escapes)


def _windows_immediate_job() -> tuple[frozenset[int], int] | None:
    """Return the member pids and limit flags of this process's immediate Job."""
    from ctypes import wintypes

    windows_ctypes = cast(Any, ctypes)

    class BasicLimitInformation(ctypes.Structure):
        _fields_ = [
            ("PerProcessUserTimeLimit", ctypes.c_longlong),
            ("PerJobUserTimeLimit", ctypes.c_longlong),
            ("LimitFlags", wintypes.DWORD),
            ("MinimumWorkingSetSize", ctypes.c_size_t),
            ("MaximumWorkingSetSize", ctypes.c_size_t),
            ("ActiveProcessLimit", wintypes.DWORD),
            ("Affinity", ctypes.c_size_t),
            ("PriorityClass", wintypes.DWORD),
            ("SchedulingClass", wintypes.DWORD),
        ]

    kernel32 = windows_ctypes.WinDLL("kernel32", use_last_error=True)
    kernel32.GetCurrentProcess.argtypes = []
    kernel32.GetCurrentProcess.restype = wintypes.HANDLE
    kernel32.IsProcessInJob.argtypes = [wintypes.HANDLE, wintypes.HANDLE, wintypes.LPBOOL]
    kernel32.IsProcessInJob.restype = wintypes.BOOL
    kernel32.QueryInformationJobObject.argtypes = [
        wintypes.HANDLE,
        ctypes.c_int,
        ctypes.c_void_p,
        wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD),
    ]
    kernel32.QueryInformationJobObject.restype = wintypes.BOOL
    in_job = wintypes.BOOL()
    if not kernel32.IsProcessInJob(kernel32.GetCurrentProcess(), None, ctypes.byref(in_job)):
        raise windows_ctypes.WinError(windows_ctypes.get_last_error())
    if not in_job.value:
        return None
    limits = BasicLimitInformation()
    if not kernel32.QueryInformationJobObject(
        None,
        _JOB_OBJECT_BASIC_LIMIT_INFORMATION_CLASS,
        ctypes.byref(limits),
        ctypes.sizeof(limits),
        None,
    ):
        raise windows_ctypes.WinError(windows_ctypes.get_last_error())
    capacity = 256
    while True:

        class ProcessIdList(ctypes.Structure):
            _fields_ = [
                ("NumberOfAssignedProcesses", wintypes.DWORD),
                ("NumberOfProcessIdsInList", wintypes.DWORD),
                ("ProcessIdList", ctypes.c_size_t * capacity),
            ]

        listed = ProcessIdList()
        if kernel32.QueryInformationJobObject(
            None,
            _JOB_OBJECT_BASIC_PROCESS_ID_LIST_CLASS,
            ctypes.byref(listed),
            ctypes.sizeof(listed),
            None,
        ):
            count = int(listed.NumberOfProcessIdsInList)
            return frozenset(int(pid) for pid in listed.ProcessIdList[:count]), int(
                limits.LimitFlags
            )
        error = windows_ctypes.get_last_error()
        if error != _ERROR_MORE_DATA or capacity >= 65536:
            raise windows_ctypes.WinError(error)
        capacity = min(65536, max(capacity * 4, int(listed.NumberOfAssignedProcesses) + 64))


TASKKILL_TREE_TIMEOUT_SECONDS = 5


def windows_taskkill_tree(pid: int, *, targets: list[Any] | None = None) -> bool:
    """Best-effort blocking ``taskkill`` of a whole Windows process tree.

    Returns True only after the captured tree has terminated. ``targets``
    retains process identities across failed attempts, including orphaned
    children. Each blocking phase has ``TASKKILL_TREE_TIMEOUT_SECONDS``, so event-loop
    contexts must run it through :func:`kill_process_tree_async` (worker
    thread) instead of calling it directly.
    """
    import psutil  # type: ignore[import-untyped]

    try:
        processes = targets if targets is not None else []
        root = processes[-1] if processes else psutil.Process(pid)
        root_alive = root.is_running()
        if root_alive:
            descendants = root.children(recursive=True)
            processes[:] = (
                [
                    *[child for child in descendants if child not in processes],
                    *processes,
                ]
                if processes
                else [*descendants, root]
            )
    except psutil.NoSuchProcess:
        if not processes:
            return True
        root_alive = False
    except psutil.Error:
        return False
    if root_alive:
        taskkill_failure = _run_taskkill_tree(pid)
        fallback = taskkill_failure is not None
        outcome = f"taskkill {taskkill_failure}" if fallback else "taskkill succeeded"
    else:
        # taskkill /T needs the live root to walk the tree; after the root
        # exited (usual on a retry) only the captured identities remain.
        fallback = True
        outcome = "the root already exited, taskkill not run"
    if fallback:
        # Capture identity-bearing Process objects before root exit can orphan
        # its children. Process.kill also protects against PID reuse.
        for process in reversed(processes):
            try:
                process.kill()
            except psutil.NoSuchProcess:
                pass
            except psutil.Error as error:
                outcome += f"; killing pid={process.pid} failed: {error}"
    _gone, alive = psutil.wait_procs(processes, timeout=TASKKILL_TREE_TIMEOUT_SECONDS)
    if alive:
        _LOGGER.warning(
            "Could not terminate the process tree of pid=%s: %d of %d captured processes "
            "survive (%s)",
            pid,
            len(alive),
            len(processes),
            outcome,
        )
        return False
    if fallback:
        _LOGGER.debug("Terminated the captured process tree of pid=%s directly (%s)", pid, outcome)
    return True


_TASKKILL_DETAIL_MAX_CHARS = 200


def _run_taskkill_tree(pid: int) -> str | None:
    """Run ``taskkill /F /T``; return ``None`` on success or why it failed."""

    try:
        completed = subprocess.run(
            ["taskkill", "/F", "/T", "/PID", str(pid)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            timeout=TASKKILL_TREE_TIMEOUT_SECONDS,
            check=False,
            creationflags=subprocess_creation_flags(),
        )
    except subprocess.TimeoutExpired:
        return f"timed out after {TASKKILL_TREE_TIMEOUT_SECONDS} s"
    except OSError as error:
        return f"could not run: {error}"
    if completed.returncode == 0:
        return None
    # The first stderr line names the cause. Windowless, taskkill runs in a new
    # console and writes in its code page: the OEM code page, or UTF-8 where the
    # system or the user's console settings select it.
    stderr = completed.stderr or b""
    try:
        text = stderr.decode("utf-8")
    except UnicodeDecodeError:
        text = stderr.decode("oem", errors="replace")
    detail = next((line.strip() for line in text.splitlines() if line.strip()), "")
    if len(detail) > _TASKKILL_DETAIL_MAX_CHARS:
        detail = detail[: _TASKKILL_DETAIL_MAX_CHARS - 3] + "..."
    return f"exit code {completed.returncode}" + (f": {detail}" if detail else "")


async def kill_process_tree_async(
    proc: ProcessIdentity, *, targets: list[Any] | None = None
) -> None:
    """Kill a whole process tree without blocking the event loop.

    Same contract as ``kill_process_tree`` - including
    propagating ``ProcessLookupError`` on POSIX - but the Windows ``taskkill``
    subprocess runs in a worker thread so the loop never stalls behind it.
    """
    if os.name == "nt":
        killed = await asyncio.to_thread(windows_taskkill_tree, proc.pid, targets=targets)
        if not killed:
            raise OSError("taskkill could not confirm process-tree termination")
        return

    await asyncio.to_thread(_kill_process_tree_posix, proc)


def _kill_process_tree_posix(proc: ProcessIdentity) -> None:
    """Kill a POSIX process group; re-raises ProcessLookupError."""
    guardian = find_process_guardian(proc.pid)
    if guardian is not None:
        stop_process_guardian(guardian)
        return
    kill_process_group = cast(Any, os).__dict__["killpg"]
    kill_process_group(proc.pid, HARD_KILL_SIGNAL)


def kill_process_tree(proc: ProcessIdentity, *, targets: list[Any] | None = None) -> None:
    """Kill the owned process tree; raise when termination cannot be confirmed."""
    if os.name == "nt":
        if windows_taskkill_tree(proc.pid, targets=targets):
            return
        raise OSError("taskkill could not confirm process-tree termination")
    _kill_process_tree_posix(proc)


# Script hosts that run an installed command-line program from a script
# argument, such as ``node .../node_modules/@openai/codex/bin/codex.js``.
_SCRIPT_HOSTS = frozenset({"node", "nodejs", "bun"})
_COMMAND_SUFFIXES = (".exe", ".cmd", ".bat", ".ps1", ".js", ".mjs", ".cjs")
_PATH_SEPARATORS = re.compile(r"[\\/]")


def process_tree_runs(pid: int, program: str) -> bool:
    """Whether *program* runs, not stopped, as process *pid* or one of its descendants.

    A process runs *program* when its name, its executable, or its first
    argument names it, or, for a script host such as ``node``, when its script
    or the npm package holding the script does. A name matches exactly or as
    ``<program>-...``: ``codex``, ``codex.exe``, ``codex.js`` and ``claude-code``
    name their programs. Returns ``False`` when the tree cannot be inspected, so
    callers fail closed.
    """
    import psutil  # type: ignore[import-untyped]

    wanted = program.strip().casefold()
    if not wanted:
        return False
    try:
        root = psutil.Process(pid)
        processes = [root, *root.children(recursive=True)]
    except psutil.Error:
        return False
    return any(_process_runs(process, wanted) for process in processes)


def _process_runs(process: Any, wanted: str) -> bool:
    import psutil  # type: ignore[import-untyped]

    stopped = {psutil.STATUS_STOPPED, psutil.STATUS_ZOMBIE, psutil.STATUS_DEAD}
    try:
        with process.oneshot():
            if process.status() in stopped:
                return False
            name = process.name()
            exe = _readable(process.exe, "")
            cmdline = _readable(process.cmdline, [])
    except psutil.Error:
        return False
    return _names_program(name, exe, cmdline, wanted)


def _names_program(name: str, exe: str, cmdline: Sequence[str], wanted: str) -> bool:
    """Whether a process with this name, executable and command line runs *wanted*."""
    return any(
        candidate == wanted or candidate.startswith(f"{wanted}-")
        for candidate in _command_names(name, exe, cmdline)
    )


def _readable(read: Any, default: Any) -> Any:
    """One process attribute, or *default* when the OS denies reading it."""
    import psutil  # type: ignore[import-untyped]

    try:
        return read() or default
    except psutil.AccessDenied:
        return default


def _command_names(name: str, exe: str, cmdline: Sequence[str]) -> set[str]:
    """The lowercase program names one process runs under, without executable suffixes."""
    names = {_command_name(name), _command_name(exe)}
    if cmdline:
        names.add(_command_name(cmdline[0]))
    if names & _SCRIPT_HOSTS:
        script = next((argument for argument in cmdline[1:] if not argument.startswith("-")), "")
        names.add(_command_name(script))
        parts = [part.casefold() for part in _PATH_SEPARATORS.split(script) if part]
        if "node_modules" in parts:
            package = parts[len(parts) - parts[::-1].index("node_modules") :][:2]
            if len(package) == 2 and package[0].startswith("@"):
                names.add(package[1])
            elif package:
                names.add(package[0])
    names.discard("")
    return names


def _command_name(path: str) -> str:
    base = _PATH_SEPARATORS.split(path.strip())[-1].casefold()
    for suffix in _COMMAND_SUFFIXES:
        if base.endswith(suffix):
            return base[: -len(suffix)]
    return base
