"""File and content search: one Tool over the bundled ripgrep.

ripgrep selects and matches files; this module turns a call into a ripgrep
query, runs it in bounded phases, and renders pages the Agent can continue.
"""

from __future__ import annotations

import contextlib
import json
import os
import re
from collections.abc import Iterator
from dataclasses import dataclass, field, replace
from pathlib import Path
from typing import Any

from core.permissions import (
    PermissionBoundary,
    PermissionGrant,
)
from core.tools._refused_notes import search_note
from core.tools._search_arguments import (
    interpret_search_call as interpret_search_call,
)
from core.tools._search_arguments import (
    normalize_search_arguments as normalize_search_arguments,
)
from core.tools._search_confinement import confine_flags
from core.tools._search_definition import (
    HELP_EXAMPLES as HELP_EXAMPLES,
)
from core.tools._search_definition import (
    SEARCH_FILES_TOOL_DESCRIPTION as SEARCH_FILES_TOOL_DESCRIPTION,
)
from core.tools._search_definition import (
    SEARCH_FILES_TOOL_NAME as SEARCH_FILES_TOOL_NAME,
)
from core.tools._search_definition import (
    SEARCH_FILES_TOOL_PARAMETERS as SEARCH_FILES_TOOL_PARAMETERS,
)
from core.tools._search_definition import (
    help_text as help_text,
)
from core.tools._search_execution import (
    MAX_CHILD_MEMORY,
    MAX_COMMAND_LINE_BYTES,
    MAX_ENTRIES,
    MAX_PROTOCOL_LINE,
    MAX_SCAN_BYTES,
    ScanResult,
    Scope,
    SearchBoundError,
    SearchExecution,
    SearchRefusedError,
    crlf_line_breaks,
    explain_failure,
    pattern_retry,
)
from core.tools._search_hints import (
    can_miss_literal_text,
    can_span_lines,
    file_name_extensions,
    finds_fixed_text,
    literal_text_note,
    match_count_note,
    repaired_glob_note,
    spanning_note,
    unnamed_files_note,
    wrapped_phrase_note,
    wrapped_phrases,
)
from core.tools._search_query import (
    LIST_MODES,
    MAX_OFFSET,
    SearchArgumentError,
    SearchQuery,
    glob_separators,
)
from core.tools._search_results import (
    Entry,
    Page,
    content_page,
    content_window,
    entry_page,
    order,
    path_label,
    summary,
)
from core.tools._search_roots import (
    _directory_globs,
    _missing_warnings,
    _nothing_searched,
    _preflight_search,
    _resolve_roots,
    _Roots,
    split_glob_lists,
)
from core.tools.contracts import ToolContractError
from core.tools.edit import offered_edit_tool
from core.tools.file_state import os_error_reason
from core.tools.search import SearchBudget, _expand_brace_alternations, display_search_path
from core.tools.tools import (
    JsonObject,
    ToolContext,
    ToolDisplay,
    ToolDisplayPart,
    ToolRegistry,
    display_notice,
    display_text,
    offload_tool_handler,
    tool_failure,
    tool_success,
)
from core.utils.search_binary import require_binary


def _ignored_summary(paths: list[Path], cwd: Path) -> str:
    """Name the shallowest paths ignore files excluded, so empty or listed results are not
    mistaken for everything there is."""
    unique = {os.path.normcase(path): path for path in paths}
    ordered = sorted(unique.values(), key=lambda path: (len(path.parts), str(path).lower()))
    shown = [path_label(path, cwd, directory=path.is_dir()) for path in ordered[:5]]
    listed = ", ".join(shown)
    if len(ordered) > len(shown):
        listed += f" and {len(ordered) - len(shown)} more"
    return f"Ignore rules such as .gitignore excluded {listed}. Add -u to args to include them."


def _mebibytes(size: int) -> str:
    return f"{size // (1024 * 1024)} MiB"


def _bound_failure(error: SearchBoundError, query: SearchQuery, cwd: Path) -> str:
    """Say which bound stopped the search and which call gets results.

    Only the line pass prints records that large, one per matching or context
    line (or match, with -U), so it names the file and how to leave it out. The
    memory bound depends on how many and how large the files are, and on -U.
    """
    stopped = "The search stopped without results"
    if error.bound == "record":
        limit = f"the {_mebibytes(MAX_PROTOCOL_LINE)} limit"
        if error.path is None:
            return f"{stopped}: one result exceeds {limit}. Narrow path or glob."
        # A glob with a slash selects that path below the working directory; a name
        # selects it at any depth, also below a root outside the working directory.
        if error.path.is_relative_to(cwd):
            excluded = "!" + error.path.relative_to(cwd).as_posix()
        else:
            excluded = "!" + error.path.name
        unit = "match" if query.multiline else "line"
        return (
            f"{stopped}: a {unit} in {path_label(error.path, cwd)} exceeds {limit} for one "
            f"result. Exclude that file with glob {json.dumps(excluded, ensure_ascii=False)} to "
            'see the other results, or set output to "files" or "count", which show no lines.'
        )
    limit = f"its {_mebibytes(MAX_CHILD_MEMORY)} memory limit"
    if query.mode in LIST_MODES:
        listed = "files" if query.mode == "list_files" else "directories"
        return (
            f"The listing stopped without results: it exceeded {limit}. Narrow path or glob "
            f"to list fewer {listed}."
        )
    text = (
        f'{stopped}: it exceeded {limit}. Narrow path or glob, or add "--max-filesize", "50M" '
        "to args to skip files over 50M."
    )
    if query.multiline:
        text += " Leave out -U unless matches need to span lines."
    return text


def _scopes(roots: _Roots, cwd: Path, globs: list[str]) -> list[Scope]:
    """Group plain roots by cwd; keep each wildcard root's selection in its own run."""
    if roots.filters:
        return [
            Scope(cwd=anchor, paths=[base.relative_to(anchor).as_posix()], globs=filters)
            for base, (anchor, filters) in roots.filters.items()
        ]
    inside = Scope(cwd=cwd, paths=[], globs=globs)
    scopes: list[Scope] = []
    for root in roots.plain:
        try:
            relative = root.relative_to(cwd).as_posix()
        except ValueError:
            if root.is_dir():
                scopes.append(Scope(cwd=root, paths=["."], globs=globs))
            else:
                scopes.append(Scope(cwd=root.parent, paths=[root.name], globs=globs))
            continue
        inside.paths.append(relative)
        # Explicitly named files bypass globs, so only directories need prefixes.
        if relative != "." and root.is_dir():
            inside.prefixes.append(relative)
    if inside.paths:
        scopes.insert(0, inside)
    for root, glob in roots.globs:
        if root.is_relative_to(cwd):
            scopes.append(
                Scope(cwd=cwd, paths=[root.relative_to(cwd).as_posix()], globs=[glob, *globs])
            )
        else:
            scopes.append(Scope(cwd=root, paths=["."], globs=[glob, *globs]))
    return scopes


def _entry(scope_index: int, scope: Scope, native: bytes, count: int, cwd: Path) -> Entry:
    path = Path(os.path.normpath(os.path.join(scope.cwd, os.fsdecode(native))))
    return Entry(path, display_search_path(path, cwd=cwd), scope_index, native, count)


# Paths named in the warnings about files ripgrep could not read, before "N more".
_UNREADABLE_SHOWN = 5


@dataclass
class _Found:
    """Everything the counting or listing passes found, over all scopes."""

    entries: list[Entry] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    files_searched: int | None = None
    complete: bool = True
    # Paths that ignore files excluded from the walk.
    ignored: list[Path] = field(default_factory=list)
    # Paths ripgrep could not read, as warnings, and how many more it did not name.
    unreadable: list[str] = field(default_factory=list)
    unreadable_unnamed: int = 0
    # Listings retain selection before applying a regex to names, so an empty
    # name match never reinterprets a glob that already selected real entries.
    selected_entries: bool = False

    def take(self, index: int, scope: Scope, result: ScanResult, cwd: Path) -> None:
        self.entries.extend(
            _entry(index, scope, path, count, cwd) for path, count in result.entries
        )
        self.take_diagnostics(result)

    def take_diagnostics(self, result: ScanResult) -> None:
        self.warnings.extend(result.warnings)
        self.ignored.extend(result.ignored)
        self.unreadable.extend(result.unreadable)
        self.unreadable_unnamed += result.unreadable_unnamed
        if result.unreadable or result.unreadable_unnamed:
            self.complete = False
        if result.stopped_by is not None:
            reason = ""
            if result.stopped_by == "output":
                reason = f", when their paths reached the {_mebibytes(MAX_SCAN_BYTES)} output limit"
            self.warnings.append(
                f"The search stopped after {len(result.entries)} files{reason}; narrow path or "
                "glob to see the rest."
            )
        if result.stopped_by is not None or result.interrupted or result.warnings:
            self.complete = False
        if result.files_searched is not None:
            self.files_searched = (self.files_searched or 0) + result.files_searched

    def read_failures(self) -> list[str]:
        """Name the first paths ripgrep could not read and count the others.

        A root full of locked files, such as a browser profile, otherwise filled
        every warning slot with them.
        """
        named = sorted(set(self.unreadable))
        shown = named[:_UNREADABLE_SHOWN]
        rest = len(named) - len(shown) + self.unreadable_unnamed
        if rest:
            more = " more" if shown else ""
            shown.append(f"Could not read {rest}{more} {'path' if rest == 1 else 'paths'}.")
        return shown

    def finish(self, query: SearchQuery) -> None:
        seen: set[str] = set()
        unique = []
        for entry in self.entries:
            key = os.path.normcase(entry.path)
            if key not in seen:
                seen.add(key)
                unique.append(entry)
        self.entries = unique
        order(self.entries, query)


def _list_directories(
    execution: SearchExecution, query: SearchQuery, roots: _Roots, found: _Found
) -> None:
    """List the directories below the roots that ripgrep's walker enters, empty ones too.

    ripgrep lists files only. Its walk reports the paths it skips (ignore rules,
    hidden paths, excluding globs), and the directories are walked here without
    them. With -t or -T, only directories holding a selected file are listed.
    --max-depth and the selecting globs apply to the directories themselves.
    """
    depth = None
    selection = []
    for argument in query.rg_args:
        if argument.startswith("--max-depth="):
            with contextlib.suppress(ValueError):
                depth = int(argument.removeprefix("--max-depth="))
        else:
            selection.append(argument)
    query.rg_args = selection
    follow = False
    case_sensitive = False
    iglobs = []
    for argument in query.rg_args:
        if argument in {"--follow", "--no-follow"}:
            follow = argument == "--follow"
        elif argument in {"--glob-case-insensitive", "--no-glob-case-insensitive"}:
            case_sensitive = argument.startswith("--no-")
        elif argument.startswith("--iglob="):
            iglobs.append((argument.removeprefix("--iglob="), False))
    # ripgrep 15 applies its case-insensitive glob group after its regular globs.
    typed = any(arg.startswith(("--type=", "--type-not=")) for arg in query.rg_args)

    def candidates(scope: Scope) -> Iterator[Path]:
        listing = execution.list_scan(query, scope, directories=True)
        found.take_diagnostics(listing)
        skipped = set(listing.skipped)
        filters = [*((glob, case_sensitive) for glob in scope.globs), *iglobs]
        paths = (
            path
            for name in scope.paths
            if (root := scope.cwd / name).is_dir()
            for path in _walk_directories(
                root,
                skipped,
                depth,
                follow,
                execution.budget,
                execution.permissions,
                execution.context.permission_access,
            )
            if _directory_selected(path, [root] if scope.prefixes else [], filters, scope.cwd)
        )
        if not typed:
            yield from paths
            return
        if not any(not glob.startswith("!") for glob, _ in filters):
            holding = _type_holders(listing, scope, skipped)
            yield from (path for path in paths if path in holding)
            return
        # A positive glob selects directories and can reopen ignored ones.
        # Check files under the selected directories with the type filter alone:
        # a positive rg glob on files would override their required type.
        type_query = replace(
            query, rg_args=[arg for arg in query.rg_args if not arg.startswith("--iglob=")]
        )
        unnamed = listing.unreadable_unnamed
        for batch in _directory_batches(paths, scope.cwd):
            type_scope = Scope(
                scope.cwd, paths=[path.relative_to(scope.cwd).as_posix() for path in batch]
            )
            typed_listing = execution.list_scan(type_query, type_scope, directories=True)
            # Both walks can encounter the same errors, even beyond rg's diagnostic cap.
            overlap = min(unnamed, typed_listing.unreadable_unnamed)
            unnamed -= overlap
            typed_listing.unreadable_unnamed -= overlap
            typed_listing.ignored = []
            found.take_diagnostics(typed_listing)
            holding = _type_holders(typed_listing, scope, skipped)
            yield from (path for path in batch if path in holding)

    directories: dict[Path, None] = {}
    for path in (
        path for scope in _scopes(roots, execution.cwd, query.globs) for path in candidates(scope)
    ):
        if path in directories:
            continue
        if len(directories) == MAX_ENTRIES:
            found.warnings.append(
                f"The search stopped after {MAX_ENTRIES} directories; narrow path or glob "
                "to see the rest."
            )
            found.complete = False
            break
        directories[path] = None
    if execution.budget.stopped:
        found.complete = False
    selected = list(directories)
    found.selected_entries = bool(selected)
    if query.name_patterns:
        names = _matching_names(execution, query, [path.name for path in selected])
        selected = [path for path in selected if path.name in names]
    found.entries = [
        Entry(path, display_search_path(path, cwd=execution.cwd) + "/") for path in selected
    ]


def _type_holders(listing: ScanResult, scope: Scope, skipped: set[Path]) -> set[Path]:
    holding: set[Path] = set()
    for native, _ in listing.entries:
        parents = (scope.cwd / os.fsdecode(native)).parents
        if not any(parent in skipped for parent in parents):
            for parent in parents:
                if parent in holding:
                    break
                holding.add(parent)
    return holding


def _directory_batches(paths: Iterator[Path], cwd: Path) -> Iterator[list[Path]]:
    batch: list[Path] = []
    size = 0
    for path in paths:
        cost = len(os.fsencode(path.relative_to(cwd))) + 3
        if batch and size + cost > MAX_COMMAND_LINE_BYTES:
            yield batch
            batch = []
            size = 0
        batch.append(path)
        size += cost
    if batch:
        yield batch


def _matching_names(execution: SearchExecution, query: SearchQuery, names: list[str]) -> set[str]:
    """Match listed names as a content search matches lines, with the same pattern repairs."""
    unique = list(dict.fromkeys(names))
    try:
        return execution.match_names(query, query.name_patterns, unique)
    except SearchRefusedError as error:
        retry = None if query.literal else pattern_retry(str(error), query.name_patterns, query)
        if retry is None:
            raise
        patterns, flag, note = retry
        if flag is not None:
            query.rg_args.append(flag)
        matched = execution.match_names(query, patterns, unique)
        query.notes.append(note)
        return matched


def _walk_directories(
    root: Path,
    skipped: set[Path],
    depth: int | None,
    follow: bool,
    budget: SearchBudget,
    permissions: PermissionBoundary,
    grant: PermissionGrant,
) -> Iterator[Path]:
    """Yield the directories below root that ripgrep's walker enters.

    Links, Windows junctions included, are entered only with --follow, as by
    ripgrep; a link back to a directory being walked is not entered again.
    Unreadable directories are left out, since ripgrep already warned about them,
    and so are those the permission rules refuse to read.
    """
    pending = [(root, 0, frozenset({_identity(root)}))]
    while pending and budget.keep_going():
        directory, level, ancestors = pending.pop()
        if depth is not None and level >= depth:
            continue
        try:
            with os.scandir(directory) as entries:
                children = sorted(
                    (
                        entry
                        for entry in entries
                        if permissions.check_path(entry.path, "read") is None
                        or grant.search_read_allowed(entry.path, root)
                    ),
                    key=lambda entry: entry.name,
                    reverse=True,
                )
        except OSError:
            continue
        for child in children:
            path = Path(child.path)
            try:
                linked = child.is_symlink() or child.is_junction()
                if child.name == ".git" or not child.is_dir() or (linked and not follow):
                    continue
            except OSError:
                continue
            if path in skipped:
                continue
            identity = _identity(path)
            if identity in ancestors:
                continue
            yield path
            pending.append((path, level + 1, ancestors | {identity}))


def _identity(path: Path) -> tuple[int, int] | str:
    try:
        status = os.stat(path)
    except OSError:
        return os.path.normcase(path)
    return (status.st_dev, status.st_ino)


def _directory_selected(
    path: Path, roots: list[Path], globs: list[tuple[str, bool]], cwd: Path
) -> bool:
    """Apply ordered globs to one directory as ripgrep applies them to files."""
    selected = all(glob.startswith("!") for glob, _ in globs)
    names = []
    with contextlib.suppress(ValueError):
        names.append(path.relative_to(cwd).as_posix())
    names.extend(path.relative_to(root).as_posix() for root in roots if path.is_relative_to(root))
    for glob, case_sensitive in globs:
        negated = glob.startswith("!")
        body = glob_separators(glob[1:] if negated else glob).rstrip("/")
        anchored = "/" in body
        body = body[2:] if body.startswith("./") else body.lstrip("/")
        for alternative in _expand_brace_alternations(body):
            if any(
                Path(name if anchored else name.rsplit("/", 1)[-1]).full_match(
                    alternative, case_sensitive=case_sensitive
                )
                for name in names
            ):
                selected = not negated
                break
    return selected


def _restart_past_the_end(query: SearchQuery, total: int) -> None:
    """Show the first page when offset passes the last result, as after a changed query."""
    if total and query.offset >= total:
        query.notes.append(
            f"offset {query.offset} is past the last result, so the first page is shown."
        )
        query.offset = 0


@dataclass
class _Outcome:
    page: Page
    found: _Found
    total: int
    lines_total: int


def _names_matching(
    execution: SearchExecution, query: SearchQuery, scopes: list[Scope], patterns: list[str]
) -> tuple[list[Entry], _Found]:
    """Return the searched files whose name or shown path the patterns match.

    The second value is the listing they were taken from; its ``ignored`` names
    the paths ignore files excluded, which are the ones they excluded from the search.
    """
    listed = _Found()
    for index, scope in enumerate(scopes):
        listed.take(index, scope, execution.list_scan(query, scope), execution.cwd)
    listed.finish(query)
    names = [entry.shown_path for entry in listed.entries]
    names += [entry.path.name for entry in listed.entries]
    try:
        matched = execution.match_names(query, patterns, names)
    except SearchRefusedError:
        # Unmatched names were not checked, so no claim about them holds.
        listed.complete = False
        return [], listed
    named = [
        entry
        for entry in listed.entries
        if entry.shown_path in matched or entry.path.name in matched
    ]
    return named, listed


# Shown names of files whose names match a content pattern, before "and N more".
_NAMED_FILES_SHOWN = 5


def _note_named_files(execution: SearchExecution, query: SearchQuery, scopes: list[Scope]) -> None:
    """Name the files a file-list search's pattern matches by name, as the Agent may mean them.

    Without such files, a pattern naming an extension the searched files have
    states that none has a matching name; other patterns get no note.
    """
    patterns = query.patterns
    if len(patterns) != 1 or query.inverted:
        return
    extensions = file_name_extensions(patterns[0])
    if extensions is None:
        return
    named, listed = _names_matching(execution, query, scopes, patterns)
    if execution.budget.stopped or not listed.complete:
        return
    if named:
        shown = ", ".join(entry.label for entry in named[:_NAMED_FILES_SHOWN])
        rest = len(named) - _NAMED_FILES_SHOWN
        more = f", and {rest} more (add --files to args to list them)" if rest > 0 else ""
        query.notes.append(
            f"The listed files contain text matching pattern; files whose names match it: "
            f"{shown}{more}."
        )
        return
    suffixes = {entry.path.suffix.casefold() for entry in listed.entries}
    if any(f".{extension}" in suffixes for extension in extensions):
        query.notes.append(
            "The listed files contain text matching pattern; no file name matches it."
        )


def _recount(
    execution: SearchExecution, query: SearchQuery, scopes: list[Scope], patterns: list[str]
) -> _Found | None:
    """Count a variant of the query for a note; ``None`` when that count did not finish."""
    found = _Found()
    try:
        for index, scope in enumerate(scopes):
            result = execution.count_scan(query, patterns, scope)
            found.take(index, scope, result, execution.cwd)
    except SearchRefusedError, SearchBoundError:
        return None
    if not found.complete or execution.budget.stopped:
        return None
    found.finish(query)
    return found


def _note_wrapped_phrases(
    execution: SearchExecution,
    query: SearchQuery,
    scopes: list[Scope],
    patterns: list[str],
    *,
    matched: bool,
) -> bool:
    """Count the matches a line break between two words of a phrase hid from the search.

    Returns whether a note now says how many there are and which call finds
    them; ``matched`` when the search found others within lines. One more
    counting pass runs, and only for fixed text with a space in it. It gets half
    the remaining time, and running out of it leaves the note out without
    making the search's own result partial.
    """
    if (
        patterns is not query.patterns
        or query.mode not in {"content", "files_with_matches", "count"}
        or query.inverted
        or "--line-regexp" in query.rg_args
    ):
        return False
    phrases = wrapped_phrases(patterns, literal=query.literal)
    if phrases is None:
        return False
    spanning, pattern = phrases
    variant = replace(
        query, rg_args=[*query.rg_args, "--no-fixed-strings", "--multiline"], literal=False
    )
    budget = SearchBudget(
        execution.context, timeout_seconds=execution.budget.remaining_seconds() / 2
    )
    spare = SearchExecution(execution.binary, execution.context, budget, execution.cwd)
    found = _recount(spare, variant, scopes, spanning)
    matches = sum(entry.count for entry in found.entries) if found is not None else 0
    if found is None or not matches:
        return False
    files = sum(1 for entry in found.entries if entry.count)
    query.notes.append(
        wrapped_phrase_note(
            pattern,
            matches,
            files,
            matched=matched,
            literal=query.literal,
            multiline=query.multiline,
        )
    )
    return True


def _note_no_match(
    execution: SearchExecution,
    query: SearchQuery,
    scopes: list[Scope],
    patterns: list[str],
    listed: _Found,
    repair_note: str | None = None,
) -> None:
    """Point a pattern that matched neither contents nor names to what it may mean.

    A regex whose text occurs literally names -F, and one that matches only
    across lines names -U. Otherwise a pattern shaped like file names says that
    no name matches it either, and how to list similar names; ``listed`` is the
    listing the names were taken from.
    """
    if len(patterns) != 1 or query.inverted:
        return
    if (
        repair_note is not None
        and query.mode in {"content", "files_with_matches"}
        and not (query.before or query.after or query.only_matching)
        and listed.complete
        and not execution.budget.stopped
    ):
        filtered = bool(query.globs) or any(arg.startswith("--iglob=") for arg in query.rg_args)
        note = repaired_glob_note(query.patterns[0], patterns[0], filtered=filtered)
        if note is not None:
            query.notes[query.notes.index(repair_note)] = note
            return
    # A repaired pattern's note already says how it was read; line feeds widened
    # to match CRLF line ends leave the pattern as written.
    as_written = patterns is query.patterns or patterns == crlf_line_breaks(query.patterns, query)
    if as_written and not query.literal and can_miss_literal_text(query.patterns[0]):
        literal = replace(query, rg_args=[*query.rg_args, "--fixed-strings"], literal=True)
        found = _recount(execution, literal, scopes, query.patterns)
        files = sum(1 for entry in found.entries if entry.count) if found else 0
        if files:
            query.notes.append(literal_text_note(query.patterns[0], files))
            return
    if patterns is query.patterns and not query.multiline and can_span_lines(patterns[0]):
        spanning = replace(query, rg_args=[*query.rg_args, "--multiline"])
        found = _recount(execution, spanning, scopes, patterns)
        files = sum(1 for entry in found.entries if entry.count) if found else 0
        if files:
            query.notes.append(spanning_note(files))
            return
    if query.mode not in {"content", "files_with_matches"} or not listed.complete:
        return
    if execution.budget.stopped:
        return
    note = unnamed_files_note(
        patterns[0],
        file_list=query.mode == "files_with_matches",
        files=[(entry.shown_path, entry.path.name) for entry in listed.entries],
    )
    if note is not None:
        query.notes.append(note)


def _note_match_count(
    execution: SearchExecution,
    query: SearchQuery,
    scopes: list[Scope],
    patterns: list[str],
    lines: int,
) -> None:
    """Say how many matches the counted lines hold when some line holds several.

    Only text the Agent can mean to count occurrences of qualifies: fixed text,
    not a shape such as ``.`` or ``\\w+``.
    """
    if query.count_matches or query.multiline or query.inverted:
        return
    if not query.literal and not all(finds_fixed_text(pattern) for pattern in patterns):
        return
    matching = replace(query, count_matches=True)
    found = _recount(execution, matching, scopes, patterns)
    matches = sum(entry.count for entry in found.entries) if found else 0
    if matches > lines:
        query.notes.append(match_count_note(matches))


def _search(execution: SearchExecution, query: SearchQuery, roots: _Roots) -> _Outcome:
    execution.widen_type_case(query)
    found = _Found()
    if query.mode == "list_dirs":
        _list_directories(execution, query, roots, found)
    scopes = _scopes(roots, execution.cwd, query.globs)
    if query.mode == "list_files":
        for index, scope in enumerate(scopes):
            found.take(index, scope, execution.list_scan(query, scope), execution.cwd)
        found.selected_entries = bool(found.entries)
        if query.name_patterns:
            # A listing's pattern matches a name or a shown path.
            names = [entry.shown_path for entry in found.entries]
            names += [entry.path.name for entry in found.entries]
            matched = _matching_names(execution, query, names)
            # In an inverted search rg returns the non-matching names. Both
            # spellings must then be present for the file to qualify.
            accepts = all if query.inverted else any
            found.entries = [
                entry
                for entry in found.entries
                if accepts((entry.shown_path in matched, entry.path.name in matched))
            ]
    if query.mode in LIST_MODES:
        found.finish(query)
        total = len(found.entries)
        _restart_past_the_end(query, total)
        return _Outcome(entry_page(found.entries, query), found, total, total)

    patterns = (
        execution.multiline_patterns(query)
        if query.multiline and not query.literal
        else query.patterns
    )
    repair_note = None
    whole_budget = execution.budget
    if query.mode == "content":
        execution.budget = SearchBudget(execution.context, whole_budget.remaining_seconds() * 0.8)
    count_budget = execution.budget
    try:
        try:
            results = [execution.count_scan(query, patterns, scope) for scope in scopes]
        except SearchRefusedError as error:
            retry = None if query.literal else pattern_retry(str(error), patterns, query)
            if retry is None:
                raise
            patterns, flag, note = retry
            if flag is not None:
                query.rg_args.append(flag)
                if flag in {"--pcre2", "--multiline"} and query.multiline:
                    patterns = execution.multiline_patterns(query)
            results = [execution.count_scan(query, patterns, scope) for scope in scopes]
            query.notes.append(note)
            repair_note = note
    finally:
        execution.budget = whole_budget
    if count_budget is not whole_budget and count_budget.timed_out and whole_budget.keep_going():
        found.warnings.append(
            "Counting stopped to leave time to return matching lines; totals are partial. "
            "Narrow path or glob to search the rest."
        )
    for index, (scope, result) in enumerate(zip(scopes, results, strict=True)):
        found.take(index, scope, result, execution.cwd)
    if (roots.globs or roots.filters) and len(scopes) > 1 and found.files_searched:
        # Separate root selections can search the same file. Matching entries are
        # deduplicated below, but native totals do not identify the unmatched files.
        found.files_searched = None
    found.finish(query)
    lines_total = sum(entry.count for entry in found.entries)
    if (
        not lines_total
        and query.mode in {"content", "files_with_matches", "count"}
        and found.complete
        and not execution.budget.stopped
    ):
        # A filename match cannot satisfy a search of file contents.
        named, listed = _names_matching(execution, query, scopes, patterns)
        found.ignored = listed.ignored
        if (
            not _note_wrapped_phrases(execution, query, scopes, patterns, matched=False)
            and not named
        ):
            _note_no_match(execution, query, scopes, patterns, listed, repair_note)
    elif query.mode == "files_without_match" and not found.entries and found.complete:
        # Its NUL-separated list has no statistics. Reuse the ignore walk
        # with the actual file filters to distinguish an empty selection.
        for scope in scopes:
            listing = execution.list_scan(query, scope, directories=True)
            found.take_diagnostics(listing)
            found.selected_entries |= bool(listing.entries)
        if found.complete and not found.selected_entries:
            found.files_searched = 0
    elif not found.entries:
        # Only a result without entries names the paths ignore files excluded.
        for scope in scopes:
            found.ignored.extend(execution.ignored_scan(query, scope))
    _restart_past_the_end(query, lines_total if query.mode == "content" else len(found.entries))
    if lines_total and not query.offset and found.complete and not execution.budget.stopped:
        if query.mode == "files_with_matches":
            _note_named_files(execution, query, scopes)
        elif query.mode == "count":
            _note_match_count(execution, query, scopes, patterns, lines_total)
        _note_wrapped_phrases(execution, query, scopes, patterns, matched=True)
    if query.mode != "content":
        page = entry_page(found.entries, query)
        return _Outcome(page, found, len(found.entries), lines_total)
    window = content_window(found.entries, query.offset, query.limit)
    events: dict[tuple[int, bytes], list[dict[str, Any]]] = {}
    for index, scope in enumerate(scopes):
        selected = [(entry, skip) for entry, skip in window if entry.scope == index]
        if not selected:
            continue
        scope_events, problems = execution.line_events(
            query,
            patterns,
            scope,
            {entry.native: entry.count for entry, _ in selected},
            max(skip for _, skip in selected) + query.limit,
        )
        found.take(index, scope, problems, execution.cwd)
        events.update(((index, path), value) for path, value in scope_events.items())
    page = content_page(window, events, query)
    return _Outcome(page, found, lines_total, lines_total)


def _left_out_note(roots: list[Path], cwd: Path, permissions: PermissionBoundary) -> str | None:
    """Name what the rules leave out below the searched folders, or ``None``.

    Without a count: what an excluding glob keeps ripgrep from reading is never
    touched, so the search cannot tell whether anything was there. The note
    names the deny rules' parts instead, relative to the working directory.
    """
    if not permissions.restricted:
        return None
    parts: dict[str, None] = {}
    protected = False
    for root in roots:
        if not root.is_dir():
            continue
        refused = permissions.refused_below(root, "read")
        protected = protected or refused.protected
        shown = path_label(root, cwd)
        for pattern in refused.rules:
            parts.setdefault(pattern if shown == "." else f"{shown}/{pattern}")
    if not parts and not protected:
        return None
    return search_note(list(parts), protected=protected)


def _expand_directory_filters(
    query: SearchQuery, roots: _Roots, cwd: Path, context: ToolContext
) -> None:
    if roots.filters:
        for base, (anchor, filters) in roots.filters.items():
            scoped = replace(query, globs=filters)
            _directory_globs(scoped, [base], anchor, context.permissions, context.permission_access)
            roots.filters[base] = anchor, scoped.globs
    else:
        _directory_globs(query, roots.paths, cwd, context.permissions, context.permission_access)


def search_files_handler(context: ToolContext, arguments: JsonObject) -> JsonObject:
    try:
        query = interpret_search_call(arguments, edit_tool=offered_edit_tool(context))
        if query.mode == "help":
            return tool_success({"content": help_text()})
        try:
            binary = require_binary()
        except ValueError as error:
            return tool_failure("tool_not_ready", str(error))
        budget = SearchBudget(context)
        cwd = Path(os.path.abspath(context.effective_cwd.expanduser()))
        execution = SearchExecution(binary, context, budget, cwd)
        if query.mode == "reference":
            text = execution.reference_text(query.reference_args)
            return tool_success({"content": text})
        confine_flags(query, cwd, context.permissions, context.permission_access)
        try:
            roots = _resolve_roots(
                query, cwd, context.permissions, context.permission_access, context=context
            )
        except OSError as error:
            target = path_label(Path(error.filename), cwd) if error.filename else "the search paths"
            if getattr(error, "winerror", None) == 123:
                return tool_failure(
                    "invalid_arguments",
                    f"Nothing was searched. Invalid path spelling: {target}. "
                    "Send a local file path, a file: URL, or a glob in glob.",
                )
            return tool_failure(
                "search_error",
                f"Nothing was searched. Could not check {target}: {os_error_reason(error)}. "
                "Check access to this path and retry.",
            )
        execution.roots = roots.paths
        context.record_worked_paths(*roots.paths)
        missing = _missing_warnings(
            query,
            roots,
            cwd,
            context.offers,
            context.permissions,
            arguments.get("args"),
            context.permission_access,
        )
        if not roots.paths:
            return tool_failure("path_not_found", _nothing_searched(missing, roots, query))
        _expand_directory_filters(query, roots, cwd, context)
        if (
            roots.paths
            and all(path.is_file() for path in roots.paths)
            and (
                query.globs
                or any(
                    arg.startswith(("--type=", "--type-not=", "--iglob=")) for arg in query.rg_args
                )
            )
        ):
            query.notes.append(
                "glob and type filters have no effect on explicitly named files. "
                "Pass their directory in path to filter its files."
            )
        before_search = replace(query, notes=list(query.notes), rg_args=list(query.rg_args))
        outcome = _search(execution, query, roots)
        if (
            not outcome.total
            and outcome.found.complete
            and not budget.stopped
            and (
                (query.mode in LIST_MODES and not outcome.found.selected_entries)
                or outcome.found.files_searched == 0
            )
        ):
            separated = split_glob_lists(query)
            if separated is not None:
                query = before_search
                query.notes.append(
                    "The written glob selected no files, so its separate wildcard filters "
                    f"were read as glob {json.dumps(separated, ensure_ascii=False)}."
                )
                query.globs = separated
                if roots.filters:
                    roots = _resolve_roots(
                        query, cwd, context.permissions, context.permission_access, context=context
                    )
                    execution.roots = roots.paths
                    context.record_worked_paths(*roots.paths)
                    _expand_directory_filters(query, roots, cwd, context)
                outcome = _search(execution, query, roots)
        if not outcome.total and outcome.found.complete and query.patterns:
            if any(re.match(r"^(?:rg|ripgrep|grep)\s+-", pattern) for pattern in query.patterns):
                query.notes.append(
                    "The command-looking text was used as the search pattern. "
                    "Put the search text in pattern, its options in args and its target in path."
                )
            if any(not pattern.isascii() for pattern in query.patterns) and not any(
                arg.startswith("--encoding=") for arg in query.rg_args
            ):
                query.notes.append(
                    "For files in a non-UTF-8 encoding without a Unicode BOM, pass their "
                    'encoding in args, for example ["-E", "latin1"].'
                )
        left_out = _left_out_note(roots.paths, cwd, context.permissions)
        if left_out:
            query.notes.append(left_out)
    except (SearchArgumentError, ToolContractError) as error:
        return tool_failure("invalid_arguments", str(error))
    except ValueError:
        return tool_failure(
            "search_error",
            "No results were returned. The search engine returned unreadable data. "
            "Retry with a narrower path or glob; if this repeats, repair the vBot installation.",
        )
    except SearchRefusedError as error:
        patterns = query.patterns or query.name_patterns
        return tool_failure(
            "search_error", explain_failure(str(error), patterns, executed=error.patterns)
        )
    except SearchBoundError as error:
        # Only native runs raise it, and they start after query and cwd are set.
        return tool_failure("search_error", _bound_failure(error, query, cwd))
    except OSError as error:
        return tool_failure(
            "search_error",
            f"search_files could not run the search: {os_error_reason(error)}. Retry the call.",
        )
    if budget.cancelled_by_user or context.was_cancelled_by_user():
        return tool_failure("cancelled_by_user", "Search aborted by the user")
    page, found = outcome.page, outcome.found
    warnings = list(dict.fromkeys([*missing, *found.read_failures(), *found.warnings]))
    if budget.timed_out:
        warnings.append(
            "The search stopped at its 30-second limit, so results are partial. Narrow path "
            "or glob to search the rest."
        )
    elif budget.stopped:
        warnings.append("The Run was cancelled, so results are partial.")
    complete = found.complete and not budget.stopped
    if query.mode in {"count", "files_without_match", *LIST_MODES}:
        files = len(found.entries)
    else:
        files = sum(1 for entry in found.entries if entry.count)
    data: dict[str, Any] = {
        "summary": summary(
            page,
            query,
            total=outcome.total,
            files=files,
            lines_total=outcome.lines_total,
            files_searched=found.files_searched,
            complete=complete,
        )
    }
    end = page.offset + page.returned
    if page.returned and end < outcome.total and end <= MAX_OFFSET:
        data["next_offset"] = end
    if query.notes:
        data["note"] = " ".join(dict.fromkeys(query.notes))
    if warnings:
        data["warnings"] = warnings[:20]
    if roots.missing:
        data["searched_paths"] = [path_label(path, cwd) for path in roots.paths]
    if found.ignored and (
        not outcome.total
        or query.mode in LIST_MODES
        or (query.mode == "count" and not outcome.lines_total)
    ):
        data["skipped"] = _ignored_summary(found.ignored, cwd)
    if page.lines:
        data["content"] = "\n".join(page.lines)
    if query.mode in {"content", "count"}:
        unit = (
            "matches"
            if (query.count_matches or query.multiline) and not query.inverted
            else "lines"
        )
        context.add_display_count(outcome.lines_total, unit, at_least=not complete)
    else:
        unit = "directories" if query.mode == "list_dirs" else "files"
        context.add_display_count(outcome.total, unit, at_least=not complete)
    return tool_success(data)


def _display_parts(arguments: JsonObject) -> list[ToolDisplayPart]:
    # The row has two slots: the search text, then its scope and options.
    try:
        fields = normalize_search_arguments(arguments, preserve_pattern_list=True)
    except ValueError:
        # A refused call still has a row. Show the arguments that led to it.
        return [ToolDisplayPart(json.dumps(arguments, ensure_ascii=False))]
    if not isinstance(fields, dict):
        return []
    parts = []
    options = []
    for name in ("pattern", "path", "glob", "output", "context", "args", "limit", "offset"):
        value = fields.get(name)
        values = value if isinstance(value, list) else [value]
        if name in {"output", "context", "limit", "offset"}:
            if value is not None:
                options.append(f"{name}={value}")
            continue
        items = [item for item in values if isinstance(item, str)]
        if not items:
            continue
        if name == "pattern":
            if len(items) == 1:
                term = items[0]
                text = (
                    term if term and term.strip() == term else json.dumps(term, ensure_ascii=False)
                )
            else:
                text = json.dumps(items, ensure_ascii=False)
            parts.append(ToolDisplayPart(text))
        elif name == "args":
            options.append(
                " ".join(
                    json.dumps(item, ensure_ascii=False)
                    if not item or re.search(r"\s", item)
                    else item
                    for item in items
                )
            )
        else:
            names = [
                item if item.strip() == item else json.dumps(item, ensure_ascii=False)
                for item in items
                if item
            ]
            if names:
                options.append(", ".join(names))
    if options:
        parts.append(ToolDisplayPart(" · ".join(options)))
    return parts or [ToolDisplayPart("List files in the working directory")]


def _display_details(arguments: JsonObject, result: JsonObject | None) -> list[JsonObject]:
    """Show the result, including its scope, interpretations and omissions."""
    data = result.get("data") if isinstance(result, dict) and result.get("ok") is True else None
    if not isinstance(data, dict):
        return []
    blocks = [
        display_notice("info", text)
        for field in ("summary", "note", "skipped")
        if isinstance(text := data.get(field), str) and text.strip()
    ]
    if data.get("content"):
        blocks.append(display_text("results", source="result", path=("data", "content")))
    warnings = data.get("warnings")
    for warning in warnings if isinstance(warnings, list) else []:
        if isinstance(warning, str) and warning.strip():
            blocks.append(display_notice("warning", warning))
    return blocks


def register_search_files_tool(registry: ToolRegistry) -> None:
    available = True
    hint = None
    try:
        require_binary()
    except ValueError as error:
        available, hint = False, str(error)
    registry.register(
        SEARCH_FILES_TOOL_NAME,
        SEARCH_FILES_TOOL_DESCRIPTION,
        SEARCH_FILES_TOOL_PARAMETERS,
        offload_tool_handler(search_files_handler),
        summary="Search file contents or find files by name.",
        family="files",
        result_schema={"type": "object"},
        display=ToolDisplay(parts_builder=_display_parts, detail_builder=_display_details),
        parallel_safe=True,
        open_input_schema=True,
        argument_normalizer=normalize_search_arguments,
        preflight=_preflight_search,
        ready=lambda: available,
        readiness_hint=hint,
    )
