"""Argument dialects and requested images for the image and media generation Tools.

analyze_image also takes image URLs and data: URLs (``resolve_analysis_images``);
the generation Tools take local image files only (``resolve_local_images``).
"""

from __future__ import annotations

import json
import os
import re
import stat
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

from core.model_tasks.artifacts import os_error_reason
from core.permissions import PermissionBoundary
from core.tools._image_downloads import ImageDownloadError, download_images, image_address
from core.tools._path_suggestions import corrected_paths
from core.tools.call_syntax import SpellingAliases, normalize_call_arguments
from core.tools.contracts import ToolContract
from core.tools.search import display_search_path
from core.tools.tools import ToolContext
from core.utils.file_status import stat_or_none
from core.utils.paths import file_url_path

# Names other image Tools and Agents use for analyze_image fields.
ANALYZE_FIELD_ALIASES = SpellingAliases(
    {
        "images": (
            "image",
            "image_path",
            "image_paths",
            "image_file",
            "image_files",
            "image_url",
            "image_urls",
            "path",
            "paths",
            "file",
            "files",
            "file_path",
            "file_paths",
            "url",
            "urls",
        ),
        "prompt": ("question", "query", "instruction", "instructions", "task"),
    }
)

_SOURCE_IMAGE_ALIASES = (
    "source_image",
    "input_image",
    "input_images",
    "reference_image",
    "reference_images",
    "image_path",
    "image_paths",
)
_OUTPUT_DIR_ALIASES = ("output_directory", "out_dir", "save_dir", "output_folder")

# Names other image generators use for generate_image fields.
GENERATION_FIELD_ALIASES = SpellingAliases(
    {
        "source_images": _SOURCE_IMAGE_ALIASES,
        "output_dir": _OUTPUT_DIR_ALIASES,
    }
)

# Names other video generators use for generate_video fields.
VIDEO_FIELD_ALIASES = SpellingAliases(
    {
        "first_frame": ("start_frame", "start_image", "first_frame_image"),
        "last_frame": ("end_frame", "end_image", "last_frame_image"),
        "output_dir": _OUTPUT_DIR_ALIASES,
    }
)

# Names other music generators use for generate_music fields.
MUSIC_FIELD_ALIASES = SpellingAliases(
    {
        "source_images": _SOURCE_IMAGE_ALIASES,
        "output_dir": _OUTPUT_DIR_ALIASES,
    }
)

# Keys an image item object may use for its one path or address.
_ITEM_KEYS = frozenset(
    {"path", "file", "file_path", "filepath", "url", "image_url", "image", "src"}
)
# Keys that describe an item without naming another image.
_ITEM_DECORATION = frozenset({"type", "detail", "alt"})
_IMAGE_SUFFIXES = frozenset(
    {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".tif", ".tiff", ".avif", ".heic", ".heif"}
)
_FOLDER_EXAMPLES = 6
# A suggestion must share most of the missing file's name, not only its extension.
_MIN_STEM_RATIO = 0.6


class UnusableImageError(ValueError):
    """A requested image cannot be used; ``code`` is the Tool error code."""

    def __init__(
        self,
        code: str,
        message: str,
        *,
        retryable: bool = False,
        attempts_made: int | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.retryable = retryable
        self.attempts_made = attempts_made


def _item(value: Any) -> Any:
    """Unwrap {"path": ...}, {"url": ...} and {"type": "image_url", "image_url": {...}}."""
    if not isinstance(value, dict):
        return value
    named = [key for key in value if key not in _ITEM_DECORATION]
    if len(named) != 1 or named[0].casefold() not in _ITEM_KEYS:
        return value
    return _item(value[named[0]])


def image_list(value: Any) -> Any:
    """Return an images value as a list of path strings where the intent is exact."""
    if isinstance(value, str):
        text = value.strip()
        if text.startswith("["):
            try:
                parsed = json.loads(text)
            except ValueError:
                parsed = None
            if isinstance(parsed, list):
                return [_item(item) for item in parsed]
        return [text] if text else value
    if isinstance(value, dict):
        return [_item(value)]
    if isinstance(value, list):
        return [_item(item) for item in value]
    return value


def analysis_image_label(items: list[str], index: int) -> str:
    """Name the original input, never a download's internal file or encoded payload."""
    text = items[index].strip()
    address = image_address(text)
    source = "data: URL" if address and address[:5].casefold() == "data:" else address or text
    return f"Image {index + 1} ({source})"


def normalize_analyze_image_arguments(contract: ToolContract, arguments: Any) -> Any:
    """Return canonical analyze_image arguments for calls written in other dialects."""
    return normalize_call_arguments(
        contract,
        arguments,
        field_aliases=ANALYZE_FIELD_ALIASES,
        field_normalizers={"images": image_list},
    )


def normalize_generate_image_arguments(contract: ToolContract, arguments: Any) -> Any:
    """Return canonical generate_image arguments for calls written in other dialects."""
    return normalize_call_arguments(
        contract,
        arguments,
        field_aliases=GENERATION_FIELD_ALIASES,
        field_normalizers={"source_images": image_list},
        empty_as_omitted=("output_dir", "aspect_ratio", "resolution"),
    )


_SECONDS = re.compile(r"\s*(\d+(?:\.\d+)?)\s*(?:s|sec|secs|seconds?)\s*", re.IGNORECASE)


def _seconds(value: Any) -> Any:
    """Read "6s" or "6 seconds" as 6; anything else is left for the contract to check."""
    if isinstance(value, str):
        match = _SECONDS.fullmatch(value)
        if match is not None:
            return match[1]
    return value


def normalize_generate_video_arguments(contract: ToolContract, arguments: Any) -> Any:
    """Return canonical generate_video arguments for calls written in other dialects."""
    return normalize_call_arguments(
        contract,
        arguments,
        field_aliases=VIDEO_FIELD_ALIASES,
        field_normalizers={"duration": _seconds},
        empty_as_omitted=(
            "output_dir",
            "first_frame",
            "last_frame",
            "resolution",
            "aspect_ratio",
            "size",
        ),
    )


def normalize_generate_music_arguments(contract: ToolContract, arguments: Any) -> Any:
    """Return canonical generate_music arguments for calls written in other dialects."""
    return normalize_call_arguments(
        contract,
        arguments,
        field_aliases=MUSIC_FIELD_ALIASES,
        field_normalizers={"source_images": image_list},
        empty_as_omitted=("output_dir",),
    )


def _local_path_text(text: str, field: str) -> str:
    """Turn a file: URL into a path; refuse web and data addresses with the reason."""
    address = image_address(text)
    if address is not None and address[:5].casefold() == "data:":
        raise UnusableImageError(
            "invalid_arguments",
            f"{field} must be local image files; data: URLs cannot be opened. Save the "
            "image to a file first, then pass that file's path.",
        )
    if address is None and text.casefold().startswith("file:"):
        path = file_url_path(text)
        if path is not None:
            return path
        # A file on another computer, which only Windows paths can name.
        address = text
    if address is not None:
        raise UnusableImageError(
            "invalid_arguments",
            f"{field} must be local image files; web addresses such as {address} cannot be "
            "opened. Save the image to a file first, then pass that file's path.",
        )
    return text


def _call(field: str, paths: list[str], single: bool) -> str:
    """Render the corrected argument as the Agent would write it."""
    return json.dumps({field: paths[0] if single else paths}, ensure_ascii=False)


def _folder_problem(
    folder: Path, label: str, field: str, cwd: Path, single: bool, permissions: PermissionBoundary
) -> UnusableImageError:
    try:
        with os.scandir(folder) as listing:
            entries = permissions.readable_entries(folder, listing)
        images = sorted(
            Path(entry.path)
            for entry in entries
            if Path(entry.name).suffix.casefold() in _IMAGE_SUFFIXES and entry.is_file()
        )[:_FOLDER_EXAMPLES]
    except OSError as error:
        return UnusableImageError(
            "image_read_error",
            f"{label} is a folder whose contents could not be read: {os_error_reason(error)}. "
            "Pass the path of a readable image file.",
        )
    if not images:
        return UnusableImageError(
            "image_read_error",
            f"{label} is a folder with no image files, not an image. "
            "Pass the path of an image file instead.",
        )
    example = _call(field, [display_search_path(image, cwd=cwd) for image in images], single)
    files = "an image file" if single else "image files"
    return UnusableImageError(
        "image_read_error",
        f"{label} is a folder, not an image. Pass {files} from it, for example {example}.",
    )


def _similar_images(missing: Path, cwd: Path, permissions: PermissionBoundary) -> list[Path]:
    """Existing files that the missing image most likely means, best first."""
    stem = missing.stem.casefold()
    return [
        item
        for item in corrected_paths(missing, cwd, permissions=permissions)
        if item.is_file()
        and SequenceMatcher(None, stem, item.stem.casefold()).ratio() >= _MIN_STEM_RATIO
    ]


def resolve_local_image(context: ToolContext, raw_path: Any, field: str) -> Path:
    """Resolve one requested image, such as a video frame, like ``resolve_local_images``."""
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise UnusableImageError("invalid_arguments", f"{field} must be a local image path.")
    return resolve_local_images(context, [raw_path], field, single=True)[0]


def _requested_items(raw_paths: Any, field: str, one: str, many: str) -> list[str]:
    """Return the requested image strings, trimmed, or refuse an unusable shape."""
    if not isinstance(raw_paths, list):
        raise UnusableImageError("invalid_arguments", f"{field} must be a list of {many}.")
    if not raw_paths:
        raise UnusableImageError("invalid_arguments", f"{field} is empty; pass at least one {one}.")
    for index, raw in enumerate(raw_paths):
        if not isinstance(raw, str) or not raw.strip():
            raise UnusableImageError(
                "invalid_arguments", f"{field}[{index}] must be a non-empty {one}."
            )
    return [raw.strip() for raw in raw_paths]


def _present(context: ToolContext, images: list[tuple[Path, str]], *, source: bool) -> None:
    """Show the requested images in the Tool row, including unavailable ones."""
    for path, name in images:
        context.add_display_media(path, "image", filename=name, source=source)


def _named(paths: list[Path]) -> list[tuple[Path, str]]:
    return [(path, path.name) for path in paths]


def _check_local(
    context: ToolContext,
    items: list[str],
    local: dict[int, Path],
    field: str,
    single: bool,
) -> None:
    """Refuse folders and missing files among the local images of ``items``."""
    cwd = context.resolve_path(".", access="display")
    missing: list[tuple[int, str, list[Path]]] = []
    for index, path in local.items():
        try:
            status = stat_or_none(path)
        except OSError as error:
            raise UnusableImageError(
                "image_read_error",
                f"{items[index]} could not be checked: {os_error_reason(error)}. "
                "Pass a readable copy, or ask the user to restore access.",
            ) from error
        if status is not None and stat.S_ISDIR(status.st_mode):
            raise _folder_problem(path, items[index], field, cwd, single, context.permissions)
        if status is None:
            missing.append((index, items[index], _similar_images(path, cwd, context.permissions)))
        elif not stat.S_ISREG(status.st_mode):
            raise UnusableImageError(
                "image_read_error",
                f"{items[index]} is not an image file. Pass the path of a readable image file.",
            )
    if missing:
        raise UnusableImageError(
            "image_not_found", _missing_message(items, missing, field, cwd, single)
        )


def preflight_image_paths(raw_paths: Any, field: str, *, allow_urls: bool = False) -> list[str]:
    """Collect explicit local paths without opening them or downloading images."""
    items = _requested_items(raw_paths, field, "local image path", "local image paths")
    return [
        _local_path_text(text, field)
        for text in items
        if not (allow_urls and image_address(text) is not None)
    ]


def resolve_local_images(
    context: ToolContext, raw_paths: Any, field: str, *, single: bool = False
) -> list[Path]:
    """Resolve requested local image files against the working directory.

    Missing files fail together, each with similar existing files and, when every
    missing file has one, the corrected call. Nothing is substituted. The Tool
    row shows the requested files as the images the call started from.
    """
    items = _requested_items(raw_paths, field, "local image path", "local image paths")
    local = {
        index: context.resolve_path(_local_path_text(text, field), access="read")
        for index, text in enumerate(items)
    }
    _present(context, _named(list(local.values())), source=True)
    _check_local(context, items, local, field, single)
    return list(local.values())


async def resolve_analysis_images(
    context: ToolContext, raw_paths: Any, field: str, *, attachment_store: Any
) -> list[Path]:
    """Resolve local paths, image URLs and data: URLs to local files, in order.

    Local files are checked first, so a missing file fails before any download.
    Downloaded images are stored as attachments; every failure names its image.
    """
    items = _requested_items(
        raw_paths, field, "local image path or image URL", "local image paths or image URLs"
    )
    addresses = {
        index: address
        for index, text in enumerate(items)
        if (address := image_address(text)) is not None
    }
    local = {
        index: context.resolve_path(_local_path_text(text, field), access="read")
        for index, text in enumerate(items)
        if index not in addresses
    }
    try:
        _check_local(context, items, local, field, False)
        await context.revalidate_permissions()
        downloaded = await download_images(
            addresses,
            field=field,
            attachment_store=attachment_store,
            several=len(items) > 1,
            permissions=context.permission_access,
        )
    except UnusableImageError:
        _present(context, _named(list(local.values())), source=False)
        raise
    except ImageDownloadError as error:
        _present(context, _named(list(local.values())), source=False)
        raise UnusableImageError(
            error.code, str(error), retryable=error.retryable, attempts_made=error.attempts_made
        ) from error
    images = [
        (local[index], local[index].name) if index in local else downloaded[index]
        for index in range(len(items))
    ]
    _present(context, images, source=False)
    return [path for path, _ in images]


def _missing_message(
    items: list[str],
    missing: list[tuple[int, str, list[Path]]],
    field: str,
    cwd: Path,
    single: bool,
) -> str:
    lines = []
    for _, raw, similar in missing:
        if similar:
            names = ", ".join(display_search_path(item, cwd=cwd) for item in similar)
            lines.append(f"No image at {raw} (similar: {names}).")
        else:
            lines.append(f"No image at {raw}, and no similar file is beside it.")
    if all(similar for _, _, similar in missing):
        corrected = list(items)
        for index, _, similar in missing:
            corrected[index] = display_search_path(similar[0], cwd=cwd)
        call = _call(field, corrected, single)
        meant = "that file" if len(missing) == 1 else "those files"
        lines.append(f"If you meant {meant}, pass {call}.")
    else:
        lines.append("Check the missing paths or obtain readable copies, then pass their paths.")
    return "\n".join(lines)
