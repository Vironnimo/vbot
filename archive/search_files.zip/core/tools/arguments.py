"""Strict semantic helpers for already schema-validated Tool arguments.

An invalid value raises ``ToolContractError``, which refuses the call as
``invalid_arguments``; call these helpers before the call has any effect.
"""

from __future__ import annotations

import math
import re
from itertools import pairwise
from typing import overload

from core.tools.contracts import ToolContractError

# The read tool prefixes every line with an unpadded ``N| `` reference gutter. This
# separator is the single source of truth shared by the read builder and the
# detector below, so the two never drift apart.
LINE_NUMBER_GUTTER_SEPARATOR = "|"
# File Tools number text lines at LF, CRLF, and lone CR only - the boundaries
# editors use and, for LF and CRLF, ripgrep. Form feed, vertical tab, NEL, and the
# Unicode line/paragraph separators are ordinary characters within a line.
TEXT_LINE_BREAK = re.compile(r"\r\n|[\n\r]")
# A block is treated as the gutter (not ordinary content that merely contains a
# pipe) only when at least this share of its non-blank lines carry a consecutive
# ``N|`` prefix (with or without its separator space after model reproduction).
# Two consecutive numbered lines is the minimum signal: a lone ``1|value`` line
# or a sparse pipe table must still pass through.
_LINE_NUMBER_GUTTER_MIN_LINES = 2
_SUPPORTED_LINE_ENDINGS = ("\r\n", "\n", "\r")


def optional_string(value: object, *, field_name: str) -> str | None:
    """Return a trimmed optional string, preserving a present blank as blank."""
    if value is None:
        return None
    if not isinstance(value, str):
        raise ToolContractError(f"{field_name} must be a string")
    return value.strip()


def required_string(value: object, *, field_name: str, strip: bool = True) -> str:
    """Return a required non-blank string.

    ``strip=False`` keeps the original value verbatim (for fields where leading
    or trailing whitespace is meaningful) while still rejecting a blank value.
    """
    if not isinstance(value, str) or not value.strip():
        raise ToolContractError(f"{field_name} must be a non-empty string")
    return value.strip() if strip else value


@overload
def optional_int(
    value: object,
    *,
    field_name: str,
    default: int,
    minimum: int | None = ...,
    maximum: int | None = ...,
) -> int: ...


@overload
def optional_int(
    value: object,
    *,
    field_name: str,
    default: None = ...,
    minimum: int | None = ...,
    maximum: int | None = ...,
) -> int | None: ...


def optional_int(
    value: object,
    *,
    field_name: str,
    default: int | None = None,
    minimum: int | None = None,
    maximum: int | None = None,
) -> int | None:
    """Return an optional strict integer with inclusive bounds."""
    if value is None:
        return default
    number = _to_int(value, field_name)
    _check_int_range(number, field_name=field_name, minimum=minimum, maximum=maximum)
    return number


def required_int(
    value: object,
    *,
    field_name: str,
    minimum: int | None = None,
    maximum: int | None = None,
) -> int:
    """Return a required strict integer with inclusive bounds."""
    if value is None:
        raise ToolContractError(f"{field_name} must be an integer")
    number = _to_int(value, field_name)
    _check_int_range(number, field_name=field_name, minimum=minimum, maximum=maximum)
    return number


@overload
def optional_number(
    value: object,
    *,
    field_name: str,
    default: float,
    minimum: float | None = ...,
    minimum_exclusive: bool = ...,
) -> float: ...


@overload
def optional_number(
    value: object,
    *,
    field_name: str,
    default: None = ...,
    minimum: float | None = ...,
    minimum_exclusive: bool = ...,
) -> float | None: ...


def optional_number(
    value: object,
    *,
    field_name: str,
    default: float | None = None,
    minimum: float | None = None,
    minimum_exclusive: bool = False,
) -> float | None:
    """Return an optional strict real number with an optional lower bound."""
    if value is None:
        return default
    number = _to_float(value, field_name)
    _check_float_minimum(
        number, field_name=field_name, minimum=minimum, exclusive=minimum_exclusive
    )
    return number


def optional_bool(value: object, *, field_name: str, default: bool) -> bool:
    """Return an optional strict boolean."""
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    raise ToolContractError(f"{field_name} must be a boolean")


def split_text_lines(text: str, *, keepends: bool = False) -> list[str]:
    """Split like ``str.splitlines`` but only at ``TEXT_LINE_BREAK`` boundaries."""
    lines: list[str] = []
    start = 0
    for match in TEXT_LINE_BREAK.finditer(text):
        lines.append(text[start : match.end() if keepends else match.start()])
        start = match.end()
    if start < len(text):
        lines.append(text[start:])
    return lines


def _split_supported_line_ending(line: str) -> tuple[str, str]:
    for ending in _SUPPORTED_LINE_ENDINGS:
        if line.endswith(ending):
            return line[: -len(ending)], ending
    return line, ""


def _is_gutter_number(text: str) -> bool:
    # read writes gutters with ASCII digits; other digit characters are content.
    return text.isascii() and text.isdigit()


def line_number_gutter_candidates(
    text: str,
    *,
    allow_continuations: bool = True,
    require_consecutive: bool = True,
) -> tuple[str, ...]:
    """Return raw-text candidates for a complete pasted ``read`` gutter block.

    Auto-recovery is intentionally strict: every physical line must carry a
    consecutive ``N|``/``N:C|`` gutter. The
    first candidate removes the current display separator space; the second
    preserves post-pipe whitespace for compact gutters reproduced without that
    separator. Returning both lets the edit matcher resolve the otherwise
    ambiguous boundary through the actual file content.
    """
    if not isinstance(text, str):
        return ()

    lines = split_text_lines(text, keepends=True)
    if len(lines) < _LINE_NUMBER_GUTTER_MIN_LINES:
        return ()

    numbers: list[int] = []
    separated_lines: list[str] = []
    compact_lines: list[str] = []
    for physical_line in lines:
        body, ending = _split_supported_line_ending(physical_line)
        prefix, separator, rest = body.lstrip().partition(LINE_NUMBER_GUTTER_SEPARATOR)
        line_number, colon, character = prefix.partition(":")
        if (
            not separator
            or not _is_gutter_number(line_number)
            or int(line_number) < 1
            or (colon and (not _is_gutter_number(character) or int(character) < 1))
            or (colon and not allow_continuations)
        ):
            return ()
        numbers.append(int(line_number))
        separated_lines.append((rest[1:] if rest.startswith(" ") else rest) + ending)
        compact_lines.append(rest + ending)

    if require_consecutive and any(
        current != previous + 1 for previous, current in pairwise(numbers)
    ):
        return ()

    separated = "".join(separated_lines)
    compact = "".join(compact_lines)
    if compact == separated:
        return (separated,)
    return separated, compact


def strip_line_number_gutters(text: str) -> str | None:
    """Strip a read gutter (``N| `` or ``N:C| ``) from each line that carries one.

    Unlike :func:`line_number_gutter_candidates`, this is per-line and partial:
    lines without a gutter pass through unchanged, and there is no minimum line
    count or consecutiveness requirement. Returns the stripped text when at least
    one line had a gutter removed, otherwise ``None`` so the caller can skip a
    pointless retry with unchanged text.
    """
    if not isinstance(text, str):
        return None

    lines = split_text_lines(text, keepends=True)
    stripped_any = False
    result_lines: list[str] = []

    for physical_line in lines:
        body, ending = _split_supported_line_ending(physical_line)
        prefix, separator, rest = body.lstrip().partition(LINE_NUMBER_GUTTER_SEPARATOR)
        line_number, colon, character = prefix.partition(":")
        if (
            separator
            and _is_gutter_number(line_number)
            and int(line_number) >= 1
            and (not colon or (_is_gutter_number(character) and int(character) >= 1))
        ):
            content = rest[1:] if rest.startswith(" ") else rest
            result_lines.append(content + ending)
            stripped_any = True
        else:
            result_lines.append(physical_line)

    if not stripped_any:
        return None
    return "".join(result_lines)


def _to_int(value: object, field_name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ToolContractError(f"{field_name} must be an integer")
    return value


def _to_float(value: object, field_name: str) -> float:
    if isinstance(value, bool):
        raise ToolContractError(f"{field_name} must be a number")
    if isinstance(value, (int, float)):
        number = float(value)
    else:
        raise ToolContractError(f"{field_name} must be a number")
    if not math.isfinite(number):
        raise ToolContractError(f"{field_name} must be a finite number")
    return number


def _check_int_range(
    number: int, *, field_name: str, minimum: int | None, maximum: int | None
) -> None:
    if minimum is not None and maximum is not None and not (minimum <= number <= maximum):
        raise ToolContractError(
            f"{field_name} must be between {minimum} and {maximum}; received {number}"
        )
    if minimum is not None and number < minimum:
        raise ToolContractError(f"{field_name} must be at least {minimum}; received {number}")
    if maximum is not None and number > maximum:
        raise ToolContractError(f"{field_name} must be at most {maximum}; received {number}")


def _check_float_minimum(
    number: float, *, field_name: str, minimum: float | None, exclusive: bool
) -> None:
    if minimum is None:
        return
    if exclusive and number <= minimum:
        raise ToolContractError(
            f"{field_name} must be greater than {minimum:g}; received {number:g}"
        )
    if not exclusive and number < minimum:
        raise ToolContractError(f"{field_name} must be at least {minimum:g}; received {number:g}")


__all__ = [
    "LINE_NUMBER_GUTTER_SEPARATOR",
    "TEXT_LINE_BREAK",
    "line_number_gutter_candidates",
    "strip_line_number_gutters",
    "optional_bool",
    "optional_int",
    "optional_number",
    "optional_string",
    "required_int",
    "required_string",
    "split_text_lines",
]
