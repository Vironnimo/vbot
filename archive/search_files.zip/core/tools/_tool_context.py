"""Per-call identity, execution-group configuration, and runtime hooks."""

from __future__ import annotations

import asyncio
import inspect
import json
import os
import re
from collections.abc import Awaitable, Callable, Collection, Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, cast

from core.computers import normalize_execution
from core.permissions import (
    ApprovalRequirement,
    PermissionBoundary,
    PermissionDenied,
    PermissionGrant,
)
from core.runs import RunExecutionOwner, RunKind, is_unattended_run_kind
from core.runs.run import ApprovalAnswer
from core.secrets._references import map_strings
from core.skills.policy import SkillPackageRef
from core.tools._display_diff import (
    MAX_DISPLAY_DIFF_LINES,
    display_diff_line_count,
    display_file_diff,
)
from core.tools._tool_display import (
    _normalize_display_fact,
    display_memory_changes,
    display_notice,
    display_results,
    display_text,
)
from core.tools.change_tracker import ChangeTracker
from core.tools.contracts import JsonObject, ToolContract, ToolContractError
from core.tools.model_names import model_tool_name
from core.tools.tool_loading import TOOL_TRANSPORT_NAMES
from core.utils.file_status import is_link_status
from core.utils.paths import file_url_path

if TYPE_CHECKING:
    from core.chat.messages import ReplySurface
    from core.memory import MemoryPromptMode

_DISPLAY_MEDIA_KINDS = ("image", "video", "audio")
# An allowlist entry that allows every Tool.
TOOL_ALLOWLIST_WILDCARD = "*"


def builtin_payload_owner(tool_name: str) -> str:
    """Return the result-payload owner name of the built-in Tool *tool_name*.

    Extension owners are safe ids without ``:``, so the two kinds never collide.
    """
    return f"tool:{tool_name}"


def _path_argument(path: str | Path, *, windows: bool) -> str | Path:
    """Repair only padding and quoting that cannot be literal in the host grammar."""
    if windows and isinstance(path, str):
        text = path.strip()
        if len(text) >= 2 and text[0] == text[-1] == '"':
            return text[1:-1]
        # An outer tab or line break cannot belong to a Windows name. Plain
        # spaces can, so keep them literal unless part of such invalid padding.
        # In particular, a trailing space alone must still reach the write guard.
        padding_chars = " \t\r\n\v\f"
        text = path.strip(padding_chars)
        padding = (
            path[: len(path) - len(path.lstrip(padding_chars))]
            + path[len(path.rstrip(padding_chars)) :]
        )
        if text and any(character in "\t\r\n\v\f" for character in padding):
            return text
    # Single quotes are legal on Windows. POSIX also permits double quotes and
    # backslashes and outer whitespace. Path objects always remain literal.
    # Existence must not redirect a missing literal to another file.
    return path


class ToolApprovalCancelledError(Exception):
    """Only this Tool's pending approval was cancelled by the user."""


class ToolSecretCommitError(Exception):
    """A prepared Secret changed or became unavailable before its use."""


class ToolAuthorityUnavailableError(Exception):
    """A prepared Tool lost readiness while it waited."""

    def __init__(self, result: JsonObject) -> None:
        super().__init__("Tool is no longer ready")
        self.result = result


class UnusablePathError(ToolContractError):
    """A path that names no file on this computer, refused before any filesystem access.

    ``reason`` completes "cannot use path X: ..." for callers that name the path
    in their own sentence, such as the change pipeline.
    """

    def __init__(self, tool_name: str, path: str, reason: str) -> None:
        self.reason = reason
        super().__init__(
            f'{model_tool_name(tool_name)} was not run: cannot use path "{path}": {reason}.'
        )


_SEPARATOR = re.compile(r"([\\/])")
_COLON_IN_NAME = (
    'Windows file and folder names cannot contain ":". Use another character, such as "-"'
)
_NO_FULL_PATH = (
    "it does not lead to a complete path on this computer. Send an absolute path, or one "
    "relative to the working directory"
)


def _local_path_text(text: str, *, windows: bool) -> str | None:
    """Return the path a ``file:`` URL names, ``text`` itself when it is no such URL.

    ``None`` for a URL naming a file on another computer. On POSIX ``file:``
    must be followed by ``/``, since ``file:notes.txt`` is a legal file name there.
    """
    if text[:5].casefold() != "file:" or not (windows or text[5:6] == "/"):
        return text
    return file_url_path(text)


def _names(path: Path) -> tuple[str, ...]:
    return path.parts[1:] if path.anchor else path.parts


def _windows_name_problem(text: str, candidate: Path, access: PathResolveAccess) -> str | None:
    """Return why Windows cannot use the names of ``candidate``, or ``None``.

    A ``:`` inside a name makes Windows read the path as another drive's current
    folder or an alternate data stream; in a folder name it can lead to a file
    outside the working directory. A final name keeps one for a read, which
    opens that stream; a change or a working directory could only fail on it.
    Windows drops the dots and spaces that end a name, so a change refuses such
    a name and names the path it would change instead; a read just opens it.
    """
    names = _names(candidate)
    if any(":" in name for name in names[:-1]) or (access != "read" and names and ":" in names[-1]):
        return _COLON_IN_NAME
    if access != "write" or all(name in {".", ".."} or name[-1:] not in " ." for name in names):
        return None
    pieces = _SEPARATOR.split(text)
    kept = [
        piece if piece in {".", ".."} or _SEPARATOR.fullmatch(piece) else piece.rstrip(" .")
        for piece in pieces
    ]
    if any(piece and not shortened for piece, shortened in zip(pieces, kept, strict=True)):
        return "Windows file and folder names cannot end with a dot or space. Choose another name"
    named = "".join(kept)
    return (
        "Windows drops the dot or space at the end of a file or folder name, so this path "
        f'names "{named}". Send "{named}" if you mean that path'
    )


def _drive_relative_problem(text: str, candidate: Path) -> str:
    """Explain a drive letter without ``/`` after it, as in ``D:notes.txt``."""
    drive = candidate.drive
    rest = text[len(drive) :] if text[: len(drive)].casefold() == drive.casefold() else text
    return (
        f'"{drive}" needs "/" after it. Send "{drive}/{rest}" for that path on drive {drive}, '
        f'or "{rest}" for one in the working directory'
    )


def is_link_entry(path: Path) -> bool:
    """Return whether the final path component is a symbolic link or Windows junction."""
    try:
        info = os.lstat(path)
    except OSError:
        return False
    return is_link_status(info)


ToolEmitHook = Callable[[str, JsonObject], None | Awaitable[None]]
ToolCancellationHook = Callable[[], bool]
# A cancel callback may return an awaitable; the Run awaits it within its
# cancellation cleanup budget before it ends (``core.runs.Run.request_cancel``).
ToolCancelCallback = Callable[[], Awaitable[object] | None]
ToolCancelRegistrationHook = Callable[[ToolCancelCallback], None]
ToolCancelCheckHook = Callable[[], bool]
ToolCallCancelRegistrar = Callable[[str, ToolCancelCallback], None]
ToolCallCancelCheck = Callable[[str], bool]
ToolNoteHook = Callable[[str], None]
ToolApprovalHook = Callable[
    ["ToolContext", str, Sequence[ApprovalRequirement], JsonObject, Path | None],
    Awaitable[ApprovalAnswer],
]
ToolApprovalRefreshHook = Callable[[bool], Awaitable[tuple[PermissionBoundary, JsonObject]]]
ToolApprovalWaitHook = Callable[[Awaitable[ApprovalAnswer]], Awaitable[ApprovalAnswer]]


# (skill_name, wrapped_content, loaded_package) -> newly_activated. The content
# feeds epoch deduplication; the Tool Result carries the durable activation.
ToolSkillActivationHook = Callable[[str, str, SkillPackageRef | None], bool]
ToolCallSkillActivationHook = Callable[[str, str, str, SkillPackageRef | None], bool]
ToolResultPersistedCallback = Callable[[], None]
ToolResultPersistedHook = Callable[[ToolResultPersistedCallback], None]
ToolCallResultPersistedRegistrar = Callable[[str, ToolResultPersistedCallback], None]
ToolDeliveryReceipt = tuple[str, str, str]
ToolDeliveryReceiptHook = Callable[[str, ToolDeliveryReceipt], None]
ToolTurnEndHook = Callable[[str], None]
# (tool_call_id, registry names) for the Tools a successful ``load_tools`` call
# loaded; Chat records them with that call's Tool Result.
ToolLoadHook = Callable[[str, Sequence[str]], None]
# (tool_call_id, absolute paths) of the files and folders a call worked in;
# Chat gives the Agent the folder instructions governing them.
ToolWorkedPathsHook = Callable[[str, Sequence[Path]], None]
# (tool_call_id, tool_name, payload) -> payload_id. Chat stages the payload and
# persists it with this call's Tool Result in the same Session transaction.
ToolResultPayloadHook = Callable[[str, str, Any], str]
# What a Tool does with a path it resolves; see ``ToolContext.resolve_path``.
type PathResolveAccess = Literal["read", "write", "start_dir", "display"]
ToolHandler = Callable[["ToolContext", JsonObject], JsonObject | Awaitable[JsonObject]]
ToolPreflight = Callable[["ToolContext", JsonObject], Awaitable[None]]
ToolCallHook = Callable[["ToolContext", str, JsonObject, Sequence[Any]], Awaitable[JsonObject]]


@dataclass(frozen=True)
class ToolContext:
    """Runtime-owned execution identity passed to a single tool call."""

    agent_id: str
    session_id: str
    run_id: str
    tool_call_id: str
    tool_name: str
    tool_call_index: int
    workspace: Path
    vbot_root: Path
    data_root: Path
    # The Run's Permission Boundary (``core.permissions``): every access a Tool
    # makes for the Agent is checked against it before any effect. Required, so
    # a caller that forgets the boundary fails the type check instead of running
    # with full access; a caller outside any Agent passes ``UNRESTRICTED``.
    permissions: PermissionBoundary = field(repr=False, compare=False)
    # Canonical immutable Session generation; no read authority without one.
    session_generation_id: str | None = None
    approval_hook: ToolApprovalHook | None = field(default=None, repr=False, compare=False)
    approval_refresh_hook: ToolApprovalRefreshHook | None = field(
        default=None, repr=False, compare=False
    )
    approval_wait_hook: ToolApprovalWaitHook | None = field(default=None, repr=False, compare=False)
    permission_access: PermissionGrant = field(init=False, repr=False, compare=False)
    public_arguments: JsonObject = field(
        default_factory=dict, init=False, repr=False, compare=False
    )
    secret_commit_hook: Callable[[], Awaitable[None]] | None = field(
        default=None, init=False, repr=False, compare=False
    )
    authority_recheck: Callable[[], None] | None = field(
        default=None, init=False, repr=False, compare=False
    )
    approval_rejected: bool = field(default=False, init=False, repr=False, compare=False)
    _approval_waited: bool = field(default=False, init=False, repr=False, compare=False)
    _approved_invocations: set[str] = field(
        default_factory=set, init=False, repr=False, compare=False
    )
    _permission_rechecks: list[Callable[[], Awaitable[None]]] = field(
        default_factory=list, init=False, repr=False, compare=False
    )
    # Operator-selected computer authority, captured for this Tool round.
    # Model arguments can select only within these Session grants.
    execution: JsonObject = field(default_factory=lambda: normalize_execution(None))
    # Completed Agentic Loop Iteration whose Assistant response requested this
    # Tool Call. Direct callers that do not execute inside Chat leave it at 0.
    iteration_number: int = 0
    # The executing Run's choices, so self-delegation does not reread a newer
    # Session or Agent configuration while this Run is still working.
    agent_model: str | None = None
    agent_thinking_effort: str | None = None
    execution_owner: RunExecutionOwner | None = field(default=None, repr=False)
    # Working directory for relative-path resolution by file/shell tools. ``None``
    # falls back to ``workspace`` (the identity-agent home) so every existing
    # caller and identity session keeps today's behavior; a project session
    # supplies the repo cwd, which is a runtime field separate from workspace
    # (workspace stays the memory-tool home).
    cwd: Path | None = None
    # Project the owning run belongs to, or ``None`` for an identity run. A tool
    # (the subagent tool especially) reads this to inherit the parent run's
    # project end-to-end: a child spawned from a project run gets a project-keyed
    # child session/run and a parent link that records the project. ``None`` means
    # the global/identity path, exactly unchanged.
    project_id: str | None = None
    # The project whose skill pool this run resolves against. Equals ``project_id``
    # for a project run and ``None`` for an identity run in the Agent's Workspace;
    # for an identity Session working in a Project (``project_id`` is ``None``)
    # it is that Project, so the ``skill`` tool loads the same skills the run's
    # catalog advertises. Kept separate from ``project_id`` so skill resolution
    # follows the working Project without changing subagent addressing.
    skill_project_id: str | None = None
    # The Project the owning Run works in: its Session's working Project (for a
    # project run its ``project_id``), or ``None`` for the Agent's Workspace. A
    # Sub-Agent of an Identity Agent spawned from this Run works there too.
    working_project_id: str | None = None
    memory_prompt_mode: MemoryPromptMode = "agent_user"
    project_memory_enabled: bool = False
    # The Agent whose Skills this call reads and changes when it is not the calling
    # Agent: the Agent a Librarian Session is bound to. ``None`` (every other
    # Session) is the calling Agent; read :attr:`skill_subject_id`.
    skill_agent_id: str | None = None
    # Kind of the Run that dispatched this call, or ``None`` outside Runs (direct
    # callers). ``core.runs.is_unattended_run_kind`` tells background Runs apart.
    run_kind: RunKind | None = None
    # Host-attributed human input in this Run, including a delivered Steer.
    # Run origin stays immutable; Models cannot supply this execution fact.
    direct_user_input: bool = False
    # The Session is linked to a Parent Agent (a Sub-Agent Session): it uses only
    # the Secrets bound to or passed into it, none granted to its Agent.
    subagent_session: bool = False
    # A program consumes the structured result instead of its bounded Model view.
    programmatic: bool = False
    # Immediate host-dispatched parent, including the fixed call_tool transport.
    parent_tool_name: str | None = None
    tool_call_hook: ToolCallHook | None = field(default=None, repr=False, compare=False)
    # The admitted Run's reply destination, unaffected by another chat using the
    # same Session. Runtime-only; never supplied by Model arguments.
    reply_surface: ReplySurface | None = None
    emit_hook: ToolEmitHook | None = None
    cancellation_hook: ToolCancellationHook | None = None
    cancel_registration_hook: ToolCancelRegistrationHook | None = None
    cancel_check_hook: ToolCancelCheckHook | None = None
    background_registration_hook: Callable[[Callable[[], bool]], None] | None = None
    note_hook: ToolNoteHook | None = None
    skill_activation_hook: ToolSkillActivationHook | None = None
    result_persisted_hook: ToolResultPersistedHook | None = None
    delivery_receipt_hook: ToolDeliveryReceiptHook | None = field(
        default=None, repr=False, compare=False
    )
    request_turn_end_hook: ToolTurnEndHook | None = field(default=None, repr=False, compare=False)
    result_payload_hook: ToolResultPayloadHook | None = field(
        default=None, repr=False, compare=False
    )
    _delivery_receipts: list[ToolDeliveryReceipt] = field(
        default_factory=list, init=False, repr=False, compare=False
    )
    _turn_end_requested: bool = field(default=False, init=False, repr=False, compare=False)
    # On-demand Tools the Model was not shown a definition of yet, by registry
    # name, with the Provider definition ``load_tools`` returns for each.
    loadable_tools: Mapping[str, JsonObject] = field(
        default_factory=dict, repr=False, compare=False
    )
    # On-demand Tools the Model was told it can load whose definition cannot be
    # loaded now (not ready, or not offered on this route), by registry name.
    unloadable_tools: frozenset[str] = field(default_factory=frozenset, repr=False, compare=False)
    tool_load_hook: ToolLoadHook | None = field(default=None, repr=False, compare=False)
    _loaded_tools: list[str] = field(default_factory=list, init=False, repr=False, compare=False)
    worked_paths_hook: ToolWorkedPathsHook | None = field(default=None, repr=False, compare=False)
    _worked_paths: list[Path] = field(default_factory=list, init=False, repr=False, compare=False)
    allowed_skills: Sequence[str] | None = None
    skill_ceiling: frozenset[str] | None = None
    # Environment credentials made available by Skills active in this Session.
    # Bash combines these transient grants with the Agent's permanent Tool settings.
    skill_env_keys: Sequence[str] = field(default_factory=tuple)
    tool_settings: Mapping[str, Any] | None = None
    # Identity proof captured from the calling Agent, never Model arguments.
    delegation_bindings: Mapping[str, str | int] = field(default_factory=dict)
    # Delegated capabilities must inherit the same Run restrictions as direct calls.
    tool_restriction: Sequence[str] | None = None
    tool_denial_resolver: Callable[[str], str | None] | None = field(
        default=None, repr=False, compare=False
    )
    # Grants for Session-scoped tools whose authority is derived while building
    # the Session request state, such as an Extension's Session-private Tools.
    session_tool_grants: Sequence[str] = field(default_factory=tuple)
    # Exact model-facing contract used for this Provider cycle. Direct callers and
    # legacy execution paths leave it unset and use the Tool's canonical contract.
    input_contract: ToolContract | None = field(
        default=None,
        repr=False,
        compare=False,
    )
    # Canonical dispatch retains the selected Tool's result contract so outer
    # dispatch adapters never have to resolve a changing catalog a second time.
    result_contract: ToolContract | None = field(
        default=None, init=False, repr=False, compare=False
    )
    # Registry names of the Tools the Model was shown for this Provider cycle,
    # for ``offers``; ``None`` when the call comes without a Model request.
    offered_tools: Collection[str] | None = field(default=None, repr=False, compare=False)
    # The Tool allowlist canonical dispatch checked this call against (``None``
    # allows every Tool), retained for ``can_call``.
    dispatch_allowed_tools: Sequence[str] | None = field(
        default=None, init=False, repr=False, compare=False
    )
    presentation_facts: list[JsonObject] = field(
        default_factory=list,
        repr=False,
        compare=False,
    )
    # Images, videos and audio the user sees in the call's details, recorded
    # via ``add_display_media``.
    presentation_media: list[JsonObject] = field(default_factory=list, repr=False, compare=False)
    # User-facing detail blocks in the order recorded, for Tools whose display
    # declares ``details``.
    presentation_details: list[JsonObject] = field(default_factory=list, repr=False, compare=False)
    # The Secrets this call used, as ``NAME.field (sink)``, shown with every display.
    presentation_secret_uses: list[str] = field(default_factory=list, repr=False, compare=False)
    # Each Secret value dispatch put into a ``files`` sink argument, with the
    # reference text it replaced: the file edit Tools match old text that holds
    # the reference text itself (``secrets/agent-secrets.md`` -> References and sinks).
    secret_literals: dict[str, str] = field(default_factory=dict, repr=False, compare=False)
    # Exact values substituted for external arguments in this dispatch. The
    # transport can redact their echoes without changing the outbound request.
    external_secret_values: frozenset[str] = field(
        default_factory=frozenset, init=False, repr=False, compare=False
    )
    prepared_secret_literals: dict[str, str] = field(
        default_factory=dict, repr=False, compare=False
    )
    # The widget the call shows inline in the chat, recorded via ``show_display_widget``;
    # empty when it shows none.
    presentation_widget: JsonObject = field(default_factory=dict, repr=False, compare=False)
    # The Portal whose card shows after the call, via ``show_display_portal``.
    presentation_portal: JsonObject = field(default_factory=dict, repr=False, compare=False)
    # Request-only media: never included in result envelopes or lifecycle events.
    result_media: list[JsonObject] = field(default_factory=list, repr=False, compare=False)
    # Session-scoped file-content tracker for git-style change statistics.
    # ``None`` keeps direct/legacy callers working without change tracking.
    change_tracker: ChangeTracker | None = field(
        default=None,
        repr=False,
        compare=False,
    )

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "permission_access",
            PermissionGrant(
                self.permissions, computer_id=str(self.execution.get("computer_id", "server"))
            ),
        )

    async def request_approval(
        self,
        reason: str,
        requirements: Sequence[ApprovalRequirement],
        *,
        arguments: JsonObject,
        cwd: Path | None = None,
    ) -> bool:
        """Ask for this prepared invocation, without holding execution slots."""
        if self.approval_hook is None or self.is_cancelled():
            return False
        invocation = self._approval_identity(arguments, cwd)
        object.__setattr__(self, "_approval_waited", True)
        waiting = asyncio.ensure_future(
            self.approval_hook(self, reason, requirements, arguments, cwd)
        )
        # The wrapper includes slot reacquisition; stopping the Tool must also
        # interrupt that wait after the approval Future has already settled.
        finishing = (
            asyncio.ensure_future(self.approval_wait_hook(waiting))
            if self.approval_wait_hook
            else waiting
        )

        def cancel_wait() -> None:
            if not finishing.done():
                finishing.cancel()
            if not waiting.done():
                waiting.cancel()

        self.on_cancel(cancel_wait)
        try:
            allowed = await finishing
        except asyncio.CancelledError:
            current = asyncio.current_task()
            if (
                finishing.cancelled()
                and self.was_cancelled_by_user()
                and not self.is_cancelled()
                and current is not None
                and not current.cancelling()
            ):
                raise ToolApprovalCancelledError from None
            raise
        if self.is_cancelled():
            raise asyncio.CancelledError
        if self.was_cancelled_by_user():
            raise ToolApprovalCancelledError
        if not allowed and not self.is_cancelled() and not is_unattended_run_kind(self.run_kind):
            object.__setattr__(self, "approval_rejected", True)
        if allowed is True:
            self._approved_invocations.add(invocation)
        return bool(allowed) and not self.is_cancelled()

    def invocation_approved(self, arguments: JsonObject, *, cwd: Path | None = None) -> bool:
        """Whether the operator approved this exact invocation in this Tool call."""
        return self._approval_identity(arguments, cwd) in self._approved_invocations

    def _approval_identity(self, arguments: JsonObject, cwd: Path | None) -> str:
        return json.dumps(
            [
                self.tool_name,
                arguments,
                str(cwd.resolve()) if cwd else None,
                normalize_execution(self.execution),
            ],
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )

    def mask_prepared_secrets[T](self, value: T) -> T:
        """Mask exact values prepared for this call, including short values and TOTP."""

        def hide(text: str) -> str:
            for literal, reference in sorted(
                self.prepared_secret_literals.items(), key=lambda item: len(item[0]), reverse=True
            ):
                if literal:
                    text = text.replace(literal, reference)
            return text

        return cast(T, map_strings(value, hide))

    async def commit_prepared_secrets(self) -> None:
        """Atomically consume deferred Secret grants immediately before their effect."""
        if self.secret_commit_hook is not None:
            await self.secret_commit_hook()

    def add_permission_recheck(self, callback: Callable[[], Awaitable[None]]) -> None:
        self._permission_rechecks.append(callback)

    async def revalidate_permissions(
        self, *, enforce_cancel: bool = True, force_refresh: bool = False
    ) -> None:
        """Recheck live authority and each prepared access without asking again."""
        if enforce_cancel and self.is_cancelled():
            raise asyncio.CancelledError
        if enforce_cancel and self.was_cancelled_by_user():
            raise ToolApprovalCancelledError
        if self.authority_recheck is not None:
            self.authority_recheck()
        force_refresh = force_refresh or self._approval_waited
        if not self._permission_rechecks and not force_refresh:
            return
        if self.approval_refresh_hook is not None:
            boundary, execution = await self.approval_refresh_hook(force_refresh)
            if normalize_execution(execution) != normalize_execution(self.execution):
                raise ToolContractError(
                    "The Computer changed while the Tool was waiting. Call it again."
                )
            object.__setattr__(self, "permissions", boundary)
            self.permission_access.boundary = boundary
            object.__setattr__(self, "_approval_waited", False)
        for callback in self._permission_rechecks:
            await callback()
        if enforce_cancel and self.is_cancelled():
            raise asyncio.CancelledError
        if enforce_cancel and self.was_cancelled_by_user():
            raise ToolApprovalCancelledError
        if self.authority_recheck is not None:
            self.authority_recheck()

    async def authorize(
        self,
        requirements: Sequence[ApprovalRequirement],
        *,
        reason: str,
        arguments: JsonObject,
        cwd: Path | None = None,
    ) -> bool:
        """Approve exact missing accesses, then refresh the Run's authority."""
        if not await self.request_approval(reason, requirements, arguments=arguments, cwd=cwd):
            return False
        if self.approval_refresh_hook is None:
            return False
        boundary, execution = await self.approval_refresh_hook(True)
        if normalize_execution(execution) != normalize_execution(self.execution):
            return False
        object.__setattr__(self, "permissions", boundary)
        self.permission_access.boundary = boundary
        object.__setattr__(self, "_approval_waited", False)
        if self.invocation_approved(arguments, cwd=cwd):
            self.permission_access.approve(requirements)
        return True

    @property
    def skill_subject_id(self) -> str:
        """Return the id of the Agent whose Skills this call works on."""
        return self.skill_agent_id or self.agent_id

    @property
    def effective_cwd(self) -> Path:
        """Return the working directory for relative-path resolution.

        Falls back to ``workspace`` when no project cwd was supplied, so file and
        shell tools resolve against the project repo in a project session and
        against the agent workspace everywhere else.
        """
        return self.cwd if self.cwd is not None else self.workspace

    def path_target(self, path: str | Path, *, access: PathResolveAccess) -> Path:
        """Interpret an explicit Tool path while retaining its lexical identity."""
        if "\x00" in str(path):
            name = model_tool_name(self.tool_name)
            raise ToolContractError(
                f"{name} was not run: the path {json.dumps(str(path))} contains a NUL "
                f"character (U+0000), which no file path can contain. Remove it and call "
                f"{name} again."
            )
        windows = os.name == "nt"
        spelling = _path_argument(path, windows=windows)
        if isinstance(spelling, str):
            local = _local_path_text(spelling, windows=windows)
            if local is None:
                raise UnusablePathError(
                    self.tool_name,
                    spelling,
                    "it names a file on another computer. Send the path of a file on this computer",
                )
            spelling = local
        candidate = Path(spelling)
        # Windows invents a sibling home for ~name; that spelling is an ordinary
        # filename here. An explicitly relative ./~name is literal on every host.
        if str(spelling).startswith("~") and (os.name != "nt" or candidate.parts[0] == "~"):
            candidate = candidate.expanduser()
        problem = _windows_name_problem(str(spelling), candidate, access) if windows else None
        target = candidate if candidate.is_absolute() else self.effective_cwd / candidate
        if problem is None and not target.is_absolute():
            problem = (
                _drive_relative_problem(str(spelling), candidate)
                if candidate.drive and not candidate.root
                else _NO_FULL_PATH
            )
        if problem is not None:
            raise UnusablePathError(self.tool_name, str(path), problem)
        return target

    def resolve_path(
        self,
        path: str | Path,
        *,
        access: PathResolveAccess,
        follow_final_link: bool = True,
    ) -> Path:
        """Resolve one user-supplied path against this call's working directory.

        ``access`` says what the call does with the path: ``read``, ``write`` or
        ``start_dir`` (a process starts there) are checked against
        :attr:`permissions` and raise :class:`~core.permissions.PermissionDenied`
        before anything touches the target; ``display`` (a path only shown, or one
        whose access another check covers) is never checked.

        ``follow_final_link=False`` resolves only the parent directory, so a final
        symbolic link or junction names the link entry itself (as Delete or Move
        of that entry requires) and the final name keeps the requested spelling.
        A path containing NUL is refused before anything touches the filesystem.
        A ``file:`` URL names its local path. :class:`UnusablePathError` refuses,
        also before any access, a path that would lead elsewhere than it names:
        a file on another computer, and on Windows a ``:`` inside a name or a
        drive letter without ``/`` after it (another drive's current folder).
        """
        target = self.path_target(path, access=access)
        if access != "display" and self.permissions.restricted:
            refusal = self.permission_access.check_path(target, access, base=self.effective_cwd)
            if refusal is not None:
                raise PermissionDenied(refusal)
        if follow_final_link or target.name in {"", ".", ".."}:
            resolved = target.resolve()
        else:
            resolved = target.parent.resolve() / target.name
        if not resolved.is_absolute():
            # ntpath.realpath falls back to a drive-relative result for a stream
            # name below a missing folder.
            colon = any(":" in name for name in _names(target))
            raise UnusablePathError(
                self.tool_name, str(path), _COLON_IN_NAME if colon else _NO_FULL_PATH
            )
        return resolved

    def can_call(self, tool_name: str) -> bool:
        """Return whether this Run lets the Agent call the Tool named *tool_name*.

        True when the Tool is in the allowlist canonical dispatch checked this call
        against and the Run does not deny it. A result names another Tool only when
        this is true, so the Agent is never pointed at a Tool it cannot call.
        *tool_name* is the registry name.
        """
        allowed = self.dispatch_allowed_tools
        if (
            allowed is not None
            and TOOL_ALLOWLIST_WILDCARD not in allowed
            and tool_name not in allowed
        ):
            return False
        return self.tool_denial(tool_name) is None

    def tool_denial(self, tool_name: str) -> str | None:
        """Return why this Run refuses *tool_name* right now, or ``None``.

        The transport Tools are exempt: they run no Tool themselves, and each
        target they reach is checked on its own.
        """
        denial = self.tool_denial_resolver
        if denial is None or tool_name in TOOL_TRANSPORT_NAMES:
            return None
        return denial(tool_name)

    def offers(self, tool_name: str) -> bool:
        """Return whether the Agent was shown the Tool named *tool_name* and may call it.

        Text that points the Agent at another Tool names one the Model knows, also
        where several Tools are callable for the same purpose. Without a Model
        request (``offered_tools`` is ``None``) every callable Tool counts as shown.
        """
        shown = self.offered_tools
        return (shown is None or tool_name in shown) and self.can_call(tool_name)

    def add_display_count(self, value: int, unit: str, *, at_least: bool = False) -> None:
        """Record one presentation-only count without changing the Tool result."""
        fact = _normalize_display_fact(
            {"kind": "count", "value": value, "unit": unit, "at_least": at_least}
        )
        if fact is None:
            raise ValueError("Invalid Tool display count")
        self.presentation_facts.append(fact)

    def add_display_line_changes(self, *, added: int, removed: int) -> None:
        """Record added and removed line counts without changing the Tool result."""
        for change, value in (("added", added), ("removed", removed)):
            fact = _normalize_display_fact(
                {"kind": "line_change", "change": change, "value": value}
            )
            if fact is None:
                raise ValueError("Invalid Tool display line change")
            self.presentation_facts.append(fact)

    def add_display_file_change(
        self,
        path: str,
        change: str,
        before: str | None,
        after: str | None,
        *,
        destination: str | None = None,
    ) -> JsonObject:
        """Record one changed file's bounded diff without changing the Tool result.

        ``None`` text means absent or not text. The changed files of one call
        form one ``file_changes`` detail block at the place of the first, and
        share one diff line budget. Returns the recorded change, whose ``added``
        and ``removed`` count every changed line.
        """
        block = next(
            (item for item in self.presentation_details if item["type"] == "file_changes"), None
        )
        if block is None:
            block = {"type": "file_changes", "files": []}
            self.presentation_details.append(block)
        shown = sum(display_diff_line_count(item) for item in block["files"])
        recorded = display_file_diff(
            path,
            change,
            before,
            after,
            destination=destination,
            line_budget=max(0, MAX_DISPLAY_DIFF_LINES - shown),
        )
        block["files"].append(recorded)
        return recorded

    def add_display_notice(self, level: str, text: str, *, subject: str | None = None) -> None:
        """Record one notice detail block (``info``, ``warning`` or ``error``) for the user."""
        self.presentation_details.append(display_notice(level, text, subject=subject))

    def record_secret_uses(self, uses: Sequence[str]) -> None:
        """Name Secrets this call used (``GITHUB.password (terminal)``), never their values."""
        for use in uses:
            if use not in self.presentation_secret_uses:
                self.presentation_secret_uses.append(use)

    def add_display_text(self, label: str, text: str) -> None:
        """Record one labelled text detail block, such as output the result does not hold."""
        self.presentation_details.append(display_text(label, text=text))

    def add_display_results(self, items: Sequence[Mapping[str, str | None]]) -> None:
        """Record the things a call found as one results detail block (``display_results``)."""
        self.presentation_details.append(display_results(items))

    def add_display_media(
        self,
        path: Path | str,
        media_type: str,
        *,
        filename: str | None = None,
        source: bool = False,
    ) -> None:
        """Show one image, video or audio file in the call's details.

        ``media_type`` is a media type such as ``image/png`` or only its kind
        (``image``, ``video``, ``audio``); other kinds are not shown. A file the
        call read, looked at or produced is shown as media; ``source=True``
        marks one it started from, such as a generation's reference image.
        ``filename`` names a file whose path does not, such as a download. The
        display carries the absolute path only internally; the server turns it
        into a signed file address before any client sees it, and a missing
        file still shows as unavailable.
        """
        kind = media_type.partition("/")[0] if isinstance(media_type, str) else ""
        if kind not in _DISPLAY_MEDIA_KINDS:
            return
        absolute = Path(path).absolute()
        item: JsonObject = {
            "path": str(absolute),
            "kind": kind,
            "filename": filename or absolute.name,
        }
        if source:
            item["role"] = "source"
        self.presentation_media.append(item)

    def show_display_widget(self, widget_id: str, title: str) -> None:
        """Show the widget stored as this call's result payload *widget_id* in the chat.

        The display carries only the payload id; the server turns it into a
        signed widget address before any client sees it.
        """
        self.presentation_widget.clear()
        self.presentation_widget.update({"id": widget_id, "title": title})

    def show_display_portal(self, portal_id: str, title: str, port: int) -> None:
        """Show a card for Portal *portal_id* after this call in the chat.

        The display carries no credential: the WebUI reads the Portal's live
        state and its access by id.
        """
        self.presentation_portal.clear()
        self.presentation_portal.update({"id": portal_id, "title": title, "port": port})

    def add_display_memory_changes(
        self,
        scope: str,
        changes: Sequence[Mapping[str, str | None]],
        *,
        revision: int | None = None,
    ) -> None:
        """Record the entries a call changed in one Memory scope, and its revision."""
        self.presentation_details.append(display_memory_changes(scope, changes, revision=revision))

    async def emit(self, event_type: str, payload: JsonObject) -> None:
        """Emit a tool lifecycle event through the runtime hook, when present."""
        if self.emit_hook is None:
            return

        result = self.emit_hook(event_type, payload)
        if inspect.isawaitable(result):
            await result

    def is_cancelled(self) -> bool:
        """Return whether the owning run has requested cancellation."""
        if self.cancellation_hook is None:
            return False

        return self.cancellation_hook()

    def on_cancel(self, callback: ToolCancelCallback) -> None:
        """Register a cancel callback for this call when the runtime exposes a hook.

        An awaitable the callback returns is awaited within the Run's cancellation
        cleanup budget, so the Run ends only after that cleanup (or the budget).
        """
        if self.cancel_registration_hook is None:
            return

        self.cancel_registration_hook(callback)

    def was_cancelled_by_user(self) -> bool:
        """Return whether this call was cancelled by the user, when the hook is wired."""
        if self.cancel_check_hook is None:
            return False

        return self.cancel_check_hook()

    def add_note(self, content: str) -> None:
        """Add a kernel-internal note through the runtime hook, when present."""
        if self.note_hook is None:
            return

        self.note_hook(content)

    def activate_skill(
        self, name: str, content: str, package: SkillPackageRef | None = None
    ) -> bool | None:
        """Record a skill activation through the session hook, when present.

        Returns ``True`` for a fresh activation, ``False`` when the skill was
        already active in the session, ``None`` when no hook is wired (the
        caller then treats the activation as fresh).
        """
        if self.skill_activation_hook is None:
            return None

        return self.skill_activation_hook(name, content, package)

    @property
    def tool_calls_available(self) -> bool:
        """Whether this call can dispatch other Tools in its owning Run."""
        return self.tool_call_hook is not None

    async def call_tool(
        self, name: str, arguments: JsonObject, positional: Sequence[Any] = ()
    ) -> JsonObject:
        """Dispatch a Tool through the owning Run and return its result envelope.

        *positional* values fill the Tool's parameters in schema order, as in a
        Python call.
        """
        if self.tool_call_hook is None:
            raise RuntimeError("Programmatic Tool calls are unavailable outside an active Run")
        return await self.tool_call_hook(self, name, arguments, positional)

    def after_result_persisted(self, callback: ToolResultPersistedCallback) -> None:
        """Run *callback* only after this Tool Result enters Session history."""
        if self.result_persisted_hook is None:
            return
        self.result_persisted_hook(callback)

    def record_delivery_receipt(
        self,
        receipt_id: str,
        content_hash: str,
        effect_kind: str,
    ) -> None:
        """Request a receipt atomically persisted with this successful Tool Result."""
        if self.delivery_receipt_hook is None:
            raise RuntimeError("Delivery receipts are unavailable for this Tool call")
        if not all(
            isinstance(value, str) and value for value in (receipt_id, content_hash, effect_kind)
        ):
            raise ValueError("delivery receipt fields must be non-empty strings")
        self._delivery_receipts.append((receipt_id, content_hash, effect_kind))

    @property
    def result_payloads_available(self) -> bool:
        """Return whether this call runs in a Session that can keep result payloads."""
        return self.result_payload_hook is not None

    def attach_result_payload(self, payload: Any) -> str:
        """Keep one JSON *payload* with this call's Tool Result and return its id.

        The payload is persisted in the same transaction as the Tool Result, so a
        call that raises, is cancelled, or whose batch is never persisted leaves
        nothing behind. Only Tools running in a Session can attach payloads;
        check :attr:`result_payloads_available` first. The owner is the Tool's
        Extension, which reads the payload back with
        ``ExtensionHost.load_result_payload``, or ``builtin_payload_owner`` of a
        built-in Tool.
        """
        if self.result_payload_hook is None:
            raise RuntimeError("Result payloads are unavailable for this Tool call")
        return self.result_payload_hook(self.tool_call_id, self.tool_name, payload)

    def request_turn_end(self) -> None:
        """Ask Chat to finish the Run after its complete Tool batch is durable."""
        if self.request_turn_end_hook is None:
            raise RuntimeError("Graceful turn completion is unavailable for this Tool call")
        object.__setattr__(self, "_turn_end_requested", True)

    def record_loaded_tools(self, names: Sequence[str]) -> None:
        """Record that this call gave the Model the definitions of *names* (registry names).

        Chat makes the Tools part of the prompt epoch's Tool knowledge once this
        call succeeded, in the same Session transaction as its Tool Result.
        """
        self._loaded_tools.extend(names)

    def record_worked_paths(self, *paths: Path) -> None:
        """Record absolute paths of files or folders this call read, changed or ran in.

        Chat gives the Agent the folder instructions that govern them, with this
        call's Tool Result. Recorded whatever the call's outcome; a worker thread
        of the call can record too.
        """
        self._worked_paths.extend(paths)

    def _commit_worked_paths(self) -> None:
        """Hand the recorded paths to the batch owner once the call finished."""
        if self._worked_paths and self.worked_paths_hook is not None:
            self.worked_paths_hook(self.tool_call_id, tuple(self._worked_paths))

    def _commit_owned_effects(self) -> None:
        """Hand successful-call effects to the batch owner after validation."""
        if self.delivery_receipt_hook is not None:
            for receipt in self._delivery_receipts:
                self.delivery_receipt_hook(self.tool_call_id, receipt)
        if self._turn_end_requested and self.request_turn_end_hook is not None:
            self.request_turn_end_hook(self.tool_call_id)
        if self._loaded_tools and self.tool_load_hook is not None:
            self.tool_load_hook(self.tool_call_id, tuple(self._loaded_tools))

    def _retain_result_contract(self, contract: ToolContract) -> None:
        """Keep the canonical dispatch selection for this call's result checks."""
        object.__setattr__(self, "result_contract", contract)

    def _retain_dispatch_allowlist(self, allowed_tools: Sequence[str] | None) -> None:
        """Keep the allowlist canonical dispatch checked this call against."""
        object.__setattr__(
            self,
            "dispatch_allowed_tools",
            None if allowed_tools is None else tuple(allowed_tools),
        )


@dataclass(frozen=True)
class ToolCall:
    """A provider-requested tool invocation to schedule."""

    id: str
    name: str
    arguments: Any


@dataclass(frozen=True)
class ToolExecutionConfig:
    """Runtime fields shared by every tool call in one execution group."""

    agent_id: str
    session_id: str
    run_id: str
    workspace: Path
    vbot_root: Path
    data_root: Path
    # See ``ToolContext.permissions``.
    permissions: PermissionBoundary = field(repr=False, compare=False)
    # Canonical immutable Session generation; no read authority without one.
    session_generation_id: str | None = None
    approval_hook: ToolApprovalHook | None = field(default=None, repr=False, compare=False)
    approval_refresh_hook: ToolApprovalRefreshHook | None = field(
        default=None, repr=False, compare=False
    )
    execution: JsonObject = field(default_factory=lambda: normalize_execution(None))
    # Completed Agentic Loop Iteration that produced this execution group.
    iteration_number: int = 0
    agent_model: str | None = None
    agent_thinking_effort: str | None = None
    execution_owner: RunExecutionOwner | None = field(default=None, repr=False)
    # Working directory for relative-path resolution; ``None`` falls back to
    # ``workspace`` so existing execution groups keep today's behavior. See
    # ``ToolContext.cwd`` for the contract.
    cwd: Path | None = None
    # Project of the owning run, threaded onto every ``ToolContext`` built from
    # this group. ``None`` is the identity path. See ``ToolContext.project_id``.
    project_id: str | None = None
    # Effective skill project for this group; see ``ToolContext.skill_project_id``.
    skill_project_id: str | None = None
    # Working Project of the owning Run; see ``ToolContext.working_project_id``.
    working_project_id: str | None = None
    memory_prompt_mode: MemoryPromptMode = "agent_user"
    project_memory_enabled: bool = False
    # Agent whose Skills this group works on; see ``ToolContext.skill_agent_id``.
    skill_agent_id: str | None = None
    # Kind of the owning Run; see ``ToolContext.run_kind``.
    run_kind: RunKind | None = None
    direct_user_input: bool = False
    # See ``ToolContext.subagent_session``.
    subagent_session: bool = False
    programmatic: bool = False
    parent_tool_name: str | None = None
    tool_call_hook: ToolCallHook | None = field(default=None, repr=False, compare=False)
    reply_surface: ReplySurface | None = None
    allowed_tools: Sequence[str] | None = None
    emit_hook: ToolEmitHook | None = None
    cancellation_hook: ToolCancellationHook | None = None
    cancel_registration_hook: ToolCancelRegistrationHook | None = None
    cancel_check_hook: ToolCancelCheckHook | None = None
    tool_call_cancel_registrar: ToolCallCancelRegistrar | None = None
    tool_call_cancel_check: ToolCallCancelCheck | None = None
    note_hook: ToolNoteHook | None = None
    skill_activation_hook: ToolCallSkillActivationHook | None = None
    tool_call_result_persisted_registrar: ToolCallResultPersistedRegistrar | None = None
    tool_delivery_receipt_registrar: ToolDeliveryReceiptHook | None = None
    tool_turn_end_registrar: ToolTurnEndHook | None = None
    tool_result_payload_registrar: ToolResultPayloadHook | None = None
    allowed_skills: Sequence[str] | None = None
    skill_ceiling: frozenset[str] | None = None
    skill_env_keys: Sequence[str] = field(default_factory=tuple)
    tool_settings: Mapping[str, Any] | None = None
    delegation_bindings: Mapping[str, str | int] = field(default_factory=dict)
    session_tool_grants: Sequence[str] = field(default_factory=tuple)
    # Model-facing contracts of the Tools in this cycle's Model request, by registry
    # name; empty when the group runs without a Model request. On-demand Tools
    # have one before they are loaded, so a direct call runs.
    input_contracts: Mapping[str, ToolContract] = field(default_factory=dict)
    # See ``ToolContext.loadable_tools``; these Tools count as not shown.
    loadable_tools: Mapping[str, JsonObject] = field(default_factory=dict)
    # See ``ToolContext.unloadable_tools``.
    unloadable_tools: Collection[str] = frozenset()
    tool_load_registrar: ToolLoadHook | None = None
    worked_paths_registrar: ToolWorkedPathsHook | None = None
    # Session-scoped file-content tracker for git-style change statistics.
    # ``None`` keeps direct/legacy execution groups without change tracking.
    change_tracker: ChangeTracker | None = field(
        default=None,
        repr=False,
        compare=False,
    )
