"""Built-in read tool: text files, directories, and image/audio/video media."""

from __future__ import annotations

import base64
import codecs
import io
import json
import os
import stat
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any

from core.attachments import AttachmentError, AttachmentTooLargeError, sniff_media_type
from core.model_tasks import SpeechError
from core.storage.layout import DataDirectoryLayout
from core.tools._path_suggestions import missing_file_message
from core.tools._permission_preflight import authorize_paths
from core.tools._read_arguments import (
    READ_HIDDEN_PARAMETERS,
    change_command_refusal,
    message_id_refusal,
    normalize_read_arguments,
)
from core.tools._read_text import (
    DEFAULT_LINE_LIMIT,
    MAX_FILE_BYTES,
    _size_text,
    read_position,
    render_directory_listing,
    render_matching_lines,
    render_matching_path,
    render_text_file,
    render_text_page,
    render_text_path,
)
from core.tools._refused_notes import listing_note
from core.tools._swarm_references import wiki_page_call
from core.tools.arguments import optional_int, split_text_lines
from core.tools.contracts import ToolContractError
from core.tools.edit import offered_edit_tool
from core.tools.file_state import FileReadState, os_error_reason
from core.tools.model_names import BASH_TOOL_NAME, SHELL_MODEL_NAME
from core.tools.read_extract import (
    ExtractionError,
    ExtractionLimitExceededError,
    detect_extractable_document,
    document_label,
    ensure_document_input_size,
    extract_document_text,
    identifies_document,
    unreadable_document_problem,
)
from core.tools.search import display_search_path
from core.tools.tools import (
    JsonObject,
    ToolContext,
    ToolDisplay,
    ToolDisplayPart,
    ToolHandler,
    ToolRegistry,
    run_tool_worker,
    tool_failure,
    tool_success,
)
from core.utils.file_status import stat_or_none

# A NUL byte within this leading window marks a file as binary (the classic
# heuristic): text — even non-UTF-8 text shown with replacement chars — has none.
_BINARY_DETECTION_BYTES = 8192
_FILE_PROBE_BYTES = 64 * 1024


@dataclass(frozen=True)
class _PreparedAudio:
    resolved: Path
    label: str
    raw: bytes
    media_type: str
    # Read stamp captured before the bytes; recorded after a successful transcription.
    stamp: tuple[float, int] | None = None


READ_TOOL_NAME = "read"
READ_TOOL_DESCRIPTION = (
    "Read a text file with line numbers, list a directory, view an image, transcribe "
    "an audio file, or extract the text of a PDF, Word, Excel or Jupyter file. Text "
    'lines start with "N| " (the line number, not file content). Use this instead '
    "of cat, head, tail, Get-Content or ls in the shell."
)
READ_TOOL_PARAMETERS: JsonObject = {
    "type": "object",
    "properties": {
        "path": {
            "type": "string",
            "minLength": 1,
        },
        "offset": {
            "type": "integer",
            "description": (
                "Line to start at, counting from 1. A negative number counts back from "
                "the end: -50 shows the last 50 lines. Omit to read from the start."
            ),
        },
        "limit": {
            "type": "integer",
            "minimum": 1,
            "description": (
                "Maximum number of lines to show. Omit to show up to 2000 lines. "
                "Output is capped at 50 KB."
            ),
        },
        "encoding": {
            "type": "string",
            "description": (
                "Read as text in this encoding, such as utf-8 or utf-16. Omit to detect "
                "command-log encodings and use UTF-8 for other text files."
            ),
        },
    },
    "required": ["path"],
}


class _FileInputTooLargeError(Exception):
    """Raised when a bounded full-file consumer reaches its input ceiling."""

    def __init__(self, max_bytes: int) -> None:
        self.max_bytes = max_bytes
        super().__init__(f"file exceeds input limit {max_bytes}")


def _path_label(path: Path, cwd: Path) -> str:
    """Show a path relative to the working directory, absolute outside it."""
    return display_search_path(path, cwd=cwd)


def _call_cwd(context: ToolContext) -> Path:
    """Return the working directory in the resolved form that tool paths use."""
    try:
        return context.effective_cwd.resolve()
    except OSError, RuntimeError:
        return context.effective_cwd


def _read_file_bytes_with_limit(resolved: Path, max_bytes: int) -> bytes:
    """Read at most one byte beyond a full-file consumer's input ceiling."""
    with resolved.open("rb") as handle:
        raw = handle.read(max_bytes + 1)
    if len(raw) > max_bytes:
        raise _FileInputTooLargeError(max_bytes)
    return raw


def _attachment_input_limit(attachment_store: Any, file_size: int) -> int:
    """Run the AttachmentStore preflight and return a bounded read ceiling."""
    ensure_within_limit = getattr(attachment_store, "ensure_within_limit", None)
    if callable(ensure_within_limit):
        ensure_within_limit(file_size)
    configured_limit = getattr(attachment_store, "max_size_bytes", None)
    if (
        isinstance(configured_limit, int)
        and not isinstance(configured_limit, bool)
        and configured_limit > 0
    ):
        return configured_limit
    return max(file_size, 1)


def _media_size_problem(
    label: str, kind: str, size: int, limit: int, *, at_least: bool = False
) -> str:
    measured = f"{'at least ' if at_least else ''}{_size_text(size)}"
    alternative = (
        "a resized or compressed image" if kind == "image" else "a shorter or compressed recording"
    )
    return (
        f"Could not read {label}: the {kind} ({measured}) exceeds the {_size_text(limit)} limit. "
        f"Read {alternative} within that limit."
    )


def make_read_handler(
    attachment_store: Any,
    speech_service: Any,
    file_state: FileReadState,
    *,
    speech_max_size_bytes: int,
) -> ToolHandler:
    """Create a read handler bound to the attachment store and speech service.

    Closes over the services so the text path stays dependency-free while images
    are passed in memory and audio is transcribed via speech-to-text.
    Mirrors the image-generation tool's factory pattern. ``file_state`` records
    each read so the write guard can detect unread or externally-changed
    files (see ``file_state.py``). Reads take no part in change statistics:
    the tracker diffs every mutation against actual on-disk content.
    """

    if (
        not isinstance(speech_max_size_bytes, int)
        or isinstance(speech_max_size_bytes, bool)
        or speech_max_size_bytes <= 0
    ):
        raise ValueError("speech_max_size_bytes must be a positive integer")

    def prepare_read(context: ToolContext, arguments: JsonObject) -> JsonObject | _PreparedAudio:
        encoding = arguments.get("encoding")
        if encoding is not None:
            try:
                # TextIOWrapper accepts only byte-to-text codecs. Validate against
                # an empty in-memory stream before opening the requested path.
                with io.TextIOWrapper(io.BytesIO(), encoding=encoding):
                    pass
                encoding = codecs.lookup(encoding).name
            except LookupError, ValueError:
                return tool_failure(
                    "invalid_arguments",
                    f"Unknown text encoding {arguments['encoding']!r}. "
                    'Use a text encoding such as "utf-8", "utf-16", "utf-16-le" or "utf-16-be".',
                )
            arguments = {**arguments, "encoding": encoding}
        try:
            resolved = context.resolve_path(arguments["path"], access="read")
        except RuntimeError as error:
            return tool_failure("invalid_path", str(error))
        cwd = _call_cwd(context)
        label = _path_label(resolved, cwd)

        try:
            status = stat_or_none(resolved)
        except OSError as error:
            return tool_failure(
                "file_read_error", f"Could not read {label}: {os_error_reason(error)}."
            )
        if status is None:
            positions = {
                name: arguments[name]
                for name in ("offset", "limit")
                if isinstance(arguments.get(name), int) and arguments[name] > 0
            }
            page = wiki_page_call(resolved, cwd, context.offers, positions=positions)
            return tool_failure(
                "file_not_found",
                missing_file_message(
                    resolved, cwd, permissions=context.permissions, elsewhere=page
                ),
            )
        context.record_worked_paths(resolved)
        if stat.S_ISDIR(status.st_mode):
            if arguments.get("pattern") is not None:
                return tool_failure(
                    "invalid_arguments", _directory_search_message(arguments, label)
                )
            return _list_directory(resolved, arguments, label, context)
        if not stat.S_ISREG(status.st_mode):
            return tool_failure("not_a_file", f"{label} is neither a file nor a directory.")

        # Capture the stamp before reading bytes, but record it only after a
        # successful read: an external write landing during the read leaves the
        # stamp older than the new content, so the next full-file write errs toward
        # a (harmless) re-read, while a failed read never counts as seen.
        stamp = file_state.stamp(resolved)
        result = read_resolved(context, arguments, resolved, label)
        if isinstance(result, _PreparedAudio):
            return replace(result, stamp=stamp)
        if result.get("ok") is True and stamp is not None:
            file_state.record_stamp(context.session_generation_id, resolved, stamp)
        return result

    def read_resolved(
        context: ToolContext, arguments: JsonObject, resolved: Path, label: str
    ) -> JsonObject | _PreparedAudio:
        def read_error(error: OSError) -> JsonObject:
            reason = os_error_reason(error, reading=resolved)
            return tool_failure("file_read_error", f"Could not read {label}: {reason}.")

        filtering = arguments.get("pattern") is not None

        def read_text(*, command_log: bool) -> JsonObject:
            try:
                if filtering:
                    content = render_matching_path(
                        resolved, arguments, label, command_log=command_log
                    )
                else:
                    content = render_text_path(resolved, arguments, command_log=command_log)
                    if not content.content:
                        return tool_success({"content": f"[{label} is empty.]"})
            except UnicodeError:
                return tool_failure(
                    "invalid_arguments",
                    f"Could not decode {label} using encoding={arguments.get('encoding')!r}. "
                    "Pass the file's text encoding, including its byte order "
                    '(such as "utf-16-le") when it has no byte order mark.',
                )
            except ValueError as error:
                return tool_failure("invalid_arguments", str(error))
            except OSError as error:
                return read_error(error)
            return tool_success(content.data())

        # A command's log holds what its programs wrote: text, whatever its first
        # bytes look like, also when they start like an image or a PDF.
        if arguments.get("encoding") is not None:
            return read_text(command_log=False)
        if _is_command_log(context, resolved):
            return read_text(command_log=True)

        try:
            file_size = resolved.stat().st_size
            with resolved.open("rb") as handle:
                probe = handle.read(_FILE_PROBE_BYTES)
        except OSError as error:
            return read_error(error)

        # A BOM identifies a text encoding reliably; keep the ordinary UTF-8
        # default and name the exact explicit read instead of a binary/shell hint.
        bom_encoding = next(
            (
                encoding
                for marks, encoding in (
                    ((codecs.BOM_UTF32_LE, codecs.BOM_UTF32_BE), "utf-32"),
                    ((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE), "utf-16"),
                )
                if probe.startswith(marks)
            ),
            None,
        )
        if bom_encoding is not None:
            notice = (
                f'{label} uses {bom_encoding.upper()}. Pass encoding="{bom_encoding}" '
                "to read it as text."
            )
            return (
                tool_failure("invalid_arguments", notice)
                if filtering
                else tool_success({"content": f"[{notice}]"})
            )

        media_type = sniff_media_type(probe, resolved.name)
        kind = detect_extractable_document(resolved.name, media_type)
        if (
            filtering
            and kind is None
            and (media_type.startswith(("image/", "audio/", "video/")) or _looks_binary(probe))
        ):
            return tool_failure(
                "invalid_arguments",
                f"pattern selects text lines, but {label} is not a text file ({media_type}). "
                f"Read it without pattern.",
            )
        if media_type.startswith("image/"):
            try:
                input_limit = _attachment_input_limit(attachment_store, file_size)
                raw = _read_file_bytes_with_limit(resolved, input_limit)
            except AttachmentTooLargeError:
                return tool_failure(
                    "attachment_error",
                    _media_size_problem(label, "image", file_size, attachment_store.max_size_bytes),
                )
            except AttachmentError as error:
                return tool_failure(
                    "attachment_error",
                    f"Could not read {label} ({_size_text(file_size)}): {str(error).rstrip('.')}. "
                    "Ask the user to check the image and attachment settings.",
                )
            except _FileInputTooLargeError as error:
                return tool_failure(
                    "attachment_error",
                    _media_size_problem(
                        label, "image", error.max_bytes + 1, error.max_bytes, at_least=True
                    ),
                )
            except OSError as error:
                return read_error(error)
            return _read_image(context, resolved, raw, media_type)
        if media_type.startswith("audio/"):
            if file_size > speech_max_size_bytes:
                return tool_failure(
                    "audio_too_large",
                    _media_size_problem(label, "audio", file_size, speech_max_size_bytes),
                )
            try:
                raw = _read_file_bytes_with_limit(resolved, speech_max_size_bytes)
            except _FileInputTooLargeError:
                return tool_failure(
                    "audio_too_large",
                    _media_size_problem(
                        label,
                        "audio",
                        speech_max_size_bytes + 1,
                        speech_max_size_bytes,
                        at_least=True,
                    ),
                )
            except OSError as error:
                return read_error(error)
            return _PreparedAudio(resolved=resolved, label=label, raw=raw, media_type=media_type)
        if media_type.startswith("video/"):
            return _read_video(label, media_type)
        # PDF/Office/notebook extraction runs before the binary check: pdf/docx/xlsx
        # are full of NUL bytes that would otherwise be dismissed as binary, and
        # ipynb is JSON that would dump as unreadable raw text.
        if kind is not None:
            try:
                input_limit = ensure_document_input_size(file_size)
                raw = _read_file_bytes_with_limit(resolved, input_limit)
            except (ExtractionLimitExceededError, _FileInputTooLargeError) as error:
                if isinstance(error, _FileInputTooLargeError):
                    try:
                        ensure_document_input_size(error.max_bytes + 1)
                    except ExtractionLimitExceededError as limit_error:
                        error = limit_error
                return tool_failure("document_too_large", str(error))
            except OSError as error:
                return read_error(error)
            extracted = _read_extracted_document(
                resolved.name,
                raw,
                kind,
                arguments,
                label,
                identified=identifies_document(media_type) or _looks_binary(probe),
            )
            if extracted is not None:
                return extracted
            del raw
        if _looks_binary(probe):
            if filtering:
                return tool_failure(
                    "invalid_arguments",
                    f"pattern selects text lines, but {label} is a binary file. "
                    "Read it without pattern.",
                )
            return _read_binary_notice(context, label)
        return read_text(command_log=False)

    async def read_handler(context: ToolContext, arguments: JsonObject) -> JsonObject:
        if "command" in arguments:
            return tool_failure(
                "invalid_arguments",
                change_command_refusal(arguments["command"], offered_edit_tool(context)),
            )
        if "message_id" in arguments:
            return tool_failure(
                "invalid_arguments", message_id_refusal(arguments["message_id"], context.offers)
            )
        prepared = await run_tool_worker(prepare_read, context, arguments)
        if isinstance(prepared, _PreparedAudio):
            result = await _read_audio(
                speech_service,
                prepared.resolved,
                prepared.raw,
                prepared.media_type,
                prepared.label,
            )
            if result.get("ok") is True and prepared.stamp is not None:
                file_state.record_stamp(
                    context.session_generation_id, prepared.resolved, prepared.stamp
                )
            return result
        return prepared

    return read_handler


def _read_extracted_document(
    name: str, raw: bytes, kind: str, arguments: JsonObject, label: str, *, identified: bool
) -> JsonObject | None:
    """Return rendered text for a PDF/Office/notebook file, or ``None`` to fall through.

    A document whose text cannot be extracted fails when its bytes are that
    document or binary (*identified*): a damaged PDF has no other readable form.
    Text that only carries a document's extension, such as invalid notebook JSON,
    returns ``None`` and reads as text. The rendered text is numbered-gutter-free
    (it is a rendering, not editable source) but still passes through the shared
    line/byte truncation. An empty extraction (e.g. a scanned PDF with no text
    layer) becomes an explicit note.
    """
    try:
        extracted = extract_document_text(raw, kind)
    except ExtractionLimitExceededError as error:
        return tool_failure("document_too_large", str(error))
    except ExtractionError as error:
        if not identified:
            return None
        return tool_failure(
            "document_unreadable",
            f"The text of {label} cannot be extracted. "
            f"{unreadable_document_problem(kind, error, len(raw))} "
            "Report the file to the user instead of retrying.",
        )

    header = f"[Extracted text from {name} ({document_label(kind)})]:"
    try:
        if arguments.get("pattern") is not None:
            lines = split_text_lines(extracted, keepends=True)
            page = render_matching_lines(lines, arguments, label)
            return tool_success(page.prefixed(f"{header}\n").data())
        position = read_position(arguments)
        limit = optional_int(arguments.get("limit"), field_name="limit", minimum=1)
    except ValueError as error:
        return tool_failure("invalid_arguments", str(error))

    page = render_text_page(
        extracted,
        position.line,
        limit,
        number=False,
        start_character=position.character,
    )
    if not page.content.strip():
        page = replace(page, content="(no extractable text)")
    return tool_success(page.prefixed(f"{header}\n").data())


def _read_image(
    context: ToolContext,
    resolved: Path,
    raw: bytes,
    media_type: str,
) -> JsonObject:
    """Pass loaded pixels to Chat without creating a persistent attachment."""
    context.add_display_media(resolved, media_type)
    context.result_media.append(
        {
            "path": str(resolved),
            "filename": resolved.name,
            "media_type": media_type,
            "base64": base64.b64encode(raw).decode("ascii"),
        }
    )
    return tool_success({"content": f"Loaded image {resolved.name} ({media_type})."})


async def _read_audio(
    speech_service: Any,
    resolved: Path,
    raw: bytes,
    media_type: str,
    label: str,
) -> JsonObject:
    """Transcribe an audio file to text via speech-to-text.

    Transcription is plain text, which is a legal tool result on every provider,
    so no message injection is needed. STT failures return a failure envelope;
    a completed transcription without words is a successful no-speech result.
    """
    try:
        result = await speech_service.transcribe(raw, filename=resolved.name, media_type=media_type)
    except SpeechError as error:
        return tool_failure(
            "transcription_failed",
            f"Could not transcribe {label} ({_size_text(len(raw))}): {str(error).rstrip('.')}. "
            "Ask the user to check speech-to-text availability or provide a transcript.",
        )

    text = getattr(result, "text", None)
    if not isinstance(text, str) or not text.strip():
        return tool_success(
            {"content": f"[No speech recognized in {label} ({_size_text(len(raw))}).]"}
        )

    return tool_success({"content": f"[Transcription of {resolved.name} ({media_type})]:\n{text}"})


def _is_command_log(context: ToolContext, resolved: Path) -> bool:
    """Whether *resolved* is a command's log, which holds what its programs wrote."""
    try:
        logs = DataDirectoryLayout(context.data_root).command_temporary.resolve()
    except OSError, RuntimeError:
        return False
    return resolved.is_relative_to(logs)


def _looks_binary(raw: bytes) -> bool:
    """Return whether the leading bytes contain a NUL, marking the file binary.

    Checked only after media routing, so image/audio/video files (which contain
    NUL bytes) are still handled by their own branches. A NUL is the reliable
    text/binary signal: text has none, binaries almost always do — including
    files that decode as valid UTF-8 but are really data.
    """
    return b"\x00" in raw[:_BINARY_DETECTION_BYTES]


def _read_binary_notice(context: ToolContext, label: str) -> JsonObject:
    """Return a short notice for a binary file instead of decoding it to garbage.

    The notice points to the shell only when the Agent has it.
    """
    notice = f"{label} is a binary file, so it is not shown as text."
    if context.offers(BASH_TOOL_NAME):
        notice += f" A {SHELL_MODEL_NAME} command for this file type can inspect it."
    return tool_success({"content": f"[{notice}]"})


def _read_video(label: str, media_type: str) -> JsonObject:
    """Return a path note for video; no provider wire accepts raw video."""
    return tool_success(
        {"content": f"[{label} is a video ({media_type}); this model cannot view video.]"}
    )


def _list_directory(
    resolved: Path, arguments: JsonObject, label: str, context: ToolContext
) -> JsonObject:
    """List a directory's entries; reading a directory never counts as reading a file.

    Entries the permission rules refuse to read are left out and named in a note.
    """
    try:
        with os.scandir(resolved) as scan:
            entries = list(scan)
    except OSError as error:
        return tool_failure("file_read_error", f"Could not list {label}: {os_error_reason(error)}.")
    readable = context.permissions.readable_entries(resolved, entries)
    root = context.path_target(arguments["path"], access="read")
    known = {entry.path for entry in readable}
    readable.extend(
        entry
        for entry in entries
        if entry.path not in known
        and context.permission_access.listing_read_allowed(root / entry.name, root)
    )
    try:
        page = render_directory_listing(readable, arguments, label)
    except ValueError as error:
        return tool_failure("invalid_arguments", str(error))
    kept = {entry.path for entry in readable}
    # Folders first: when the note counts the rest, it still names what holds the most.
    hidden = sorted(
        (_entry_label(entry) for entry in entries if entry.path not in kept),
        key=lambda name: (not name.endswith("/"), name.casefold()),
    )
    if hidden:
        note = listing_note(hidden)
        content = "\n".join((page.content, note)) if readable else note
        page = replace(page, content=content)
    return tool_success(page.data())


def _entry_label(entry: os.DirEntry[str]) -> str:
    """The entry's name as the listing shows it: a directory ends with ``/``."""
    try:
        directory = entry.is_dir()
    except OSError:
        directory = False
    return f"{entry.name}/" if directory else entry.name


def _directory_search_message(arguments: JsonObject, label: str) -> str:
    """Name the search_files call that finds matching lines across a directory."""
    call: dict[str, Any] = {"pattern": arguments["pattern"], "path": label}
    if arguments.get("ignore_case") is True:
        call["args"] = ["-i"]
    if arguments.get("context"):
        call["context"] = arguments["context"]
    rendered = ", ".join(
        f"{key}={json.dumps(value, ensure_ascii=False)}" for key, value in call.items()
    )
    return (
        f"{label} is a directory, and read shows the lines of one file. To find matching "
        f"lines in its files, call search_files({rendered})."
    )


def _normalized_for_display(arguments: Any) -> JsonObject:
    """Return the arguments the handler would see, or the raw call if they are invalid."""
    try:
        normalized = normalize_read_arguments(arguments)
    except ToolContractError, ValueError:
        normalized = arguments
    return normalized if isinstance(normalized, dict) else {}


def _display_parts(arguments: JsonObject) -> list[ToolDisplayPart]:
    path = _normalized_for_display(arguments).get("path")
    if not isinstance(path, str) or not path.strip():
        return []
    return [ToolDisplayPart(path, kind="path", truncate="start", tooltip="always", copyable=True)]


def _read_line_range_facts(
    arguments: JsonObject, _result: JsonObject | None
) -> tuple[JsonObject, ...]:
    """Describe an explicitly bounded read without coupling the UI to read arguments."""
    arguments = _normalized_for_display(arguments)
    if "offset" not in arguments and "limit" not in arguments:
        return ()

    raw_offset = arguments.get("offset", 1)
    if isinstance(raw_offset, str) and ":" in raw_offset:
        raw_offset = raw_offset.partition(":")[0]
    start = _display_line_number(raw_offset)
    limit = _display_line_number(arguments.get("limit", DEFAULT_LINE_LIMIT))
    if start is None or limit is None:
        return ()
    return ({"kind": "line_range", "start": start, "end": start + limit - 1},)


def _display_line_number(value: object) -> int | None:
    """Accept canonical integers and their pre-normalization decimal spelling."""
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value if value >= 1 else None
    if isinstance(value, str) and value.isdecimal():
        parsed = int(value)
        return parsed if parsed >= 1 else None
    return None


async def _preflight_read(context: ToolContext, arguments: JsonObject) -> None:
    path = arguments.get("path")
    if isinstance(path, str) and path:
        await authorize_paths(context, [(path, "read", {})], arguments=arguments)


def register_read_tool(
    registry: ToolRegistry,
    *,
    attachment_store: Any,
    speech_service: Any,
    file_state: FileReadState,
    speech_max_size_bytes: int,
) -> None:
    """Register the read tool with a vBot tool registry."""
    registry.register(
        READ_TOOL_NAME,
        READ_TOOL_DESCRIPTION,
        READ_TOOL_PARAMETERS,
        make_read_handler(
            attachment_store,
            speech_service,
            file_state,
            speech_max_size_bytes=speech_max_size_bytes,
        ),
        summary="Read files, directories, images and documents.",
        family="files",
        result_schema={"type": "object", "required": ["content"]},
        display=ToolDisplay(parts_builder=_display_parts, fact_builder=_read_line_range_facts),
        parallel_safe=True,
        open_input_schema=True,
        # A command that changes a file, or a Swarm Board post in place of a path,
        # reaches the handler, which refuses it.
        unadvertised_parameters={**READ_HIDDEN_PARAMETERS, "command": {}, "message_id": {}},
        argument_normalizer=normalize_read_arguments,
        preflight=_preflight_read,
    )


__all__ = [
    "DEFAULT_LINE_LIMIT",
    "MAX_FILE_BYTES",
    "render_text_file",
    "READ_TOOL_DESCRIPTION",
    "READ_TOOL_NAME",
    "READ_TOOL_PARAMETERS",
    "make_read_handler",
    "register_read_tool",
]
