# vBot User Guide

This guide covers installing, configuring, using, operating, and integrating vBot. If you only want the shortest path to a running installation, start with the [README](README.md#get-started).

## Start here

A new installation takes three steps:

1. Run the standard Installer for your operating system.
2. Use the shared setup offered by the Installer, or open `http://127.0.0.1:22332/` or `vbot tui` after the server starts.
3. Connect a Provider or subscription and choose a Model, then finish and send your first message. You can continue to select optional components, or skip the guide at any step and configure everything yourself.

| I want to… | Go to |
|---|---|
| Install vBot or choose a Desktop/remote-client shape | [Installation](#installation) |
| Connect a Provider and start chatting | [First-run setup](#first-run-setup) |
| Understand Agents, Projects, and Sessions | [Agents, Projects, and Sessions](#agents-projects-and-sessions) |
| Reach an Agent through a messaging Channel | [Channels](#channels) |
| Schedule work | [Cron](#cron) and [Bootstrap](#bootstrap) |
| Diagnose or automate vBot | [CLI reference](#cli-reference), [Server API](#server-api), and [Operational notes](#operational-notes) |
| Develop vBot itself | [Development and verification](#development-and-verification) |

## Contents

- [Start here](#start-here)
- [Installation](#installation)
- [Requirements](#requirements)
- [Updating and uninstalling](#updating-and-uninstalling)
- [First-run setup](#first-run-setup)
- [Data directory and configuration](#data-directory-and-configuration)
- [Running the server](#running-the-server)
- [WebUI and Desktop](#webui-and-desktop)
- [Agents, Projects, and Sessions](#agents-projects-and-sessions)
- [Chat, Queue, and Built-in Commands](#chat-queue-and-built-in-commands)
- [Skills, Tools, and Sub-Agents](#skills-tools-and-sub-agents)
- [Settings and specialized Models](#settings-and-specialized-models)
- [Channels](#channels)
- [Cron](#cron)
- [Bootstrap](#bootstrap)
- [Extensions and Home Assistant](#extensions-and-home-assistant)
- [CLI reference](#cli-reference)
- [Server API](#server-api)
- [Development and verification](#development-and-verification)
- [Operational notes](#operational-notes)

## Installation

vBot installs as a self-contained package for your user account. The package brings its own Python runtime, dependencies and built WebUI, so installing it needs no Git, no Node.js and no Python packages. Server data stays separate in `~/.vbot`. A standard installation is one command; use the options only for another directory, port, update channel, Desktop shape or Autostart policy.

### Windows

Open a normal, non-elevated PowerShell and run:

```powershell
irm https://raw.githubusercontent.com/Vironnimo/vbot/main/scripts/install.ps1 | iex
```

The Installer reads the release identity `vbot-release.json` of the latest release, downloads the installer `vBot-<version>-windows-x86_64-<shape>.exe` of the version it names from that release's HTTPS `github.com` downloads, checks that it matches the SHA-256 digest the identity records and carries no invalid Authenticode signature, and runs it silently. vBot is installed for your user account into `%LOCALAPPDATA%\Programs\vBot`; no Windows service is installed. The Installer registers the logon Autostart task, starts vBot and waits until the server answers its health check. It refuses to run from an elevated PowerShell, and it refuses an installation directory that already exists: update an existing installation with `vbot update` (or `vBot.exe update` in its directory) instead.

The application has its own `vBot.exe` tray. Click the tray icon to open vBot (Desktop, or the browser for the Server package) and right-click it for server, update and log actions. The icon shows whether the server is running, stopped or updating, or needs attention; **Status…** shows the version, server, data directory and update progress. Desktop is opened independently from the tray or with `vbot desktop`; closing it never stops the server. Open Desktop windows keep their version until reopened after an update. WebView may still use several Windows processes.

### Linux and Raspberry Pi

vBot runs on 64-bit Linux for ARM64 (aarch64) and x86-64, for example on a Raspberry Pi 5 with the 64-bit Raspberry Pi OS. Run:

```bash
curl -fsSL https://raw.githubusercontent.com/Vironnimo/vbot/main/scripts/install.sh | bash
```

The Installer needs only `curl` and `python3`; the package brings its own CPython 3.14. It downloads the server package `vbot-linux-<arch>-server.zip` of the latest release, checks it against the SHA-256 digest its release identity `vbot-release.json` records, installs it into `~/.local/share/vbot` and links the `vbot` command to `~/.local/bin/vbot`. It then registers the systemd user unit `vbot.service`, enables login lingering with `sudo loginctl enable-linger` so that the server starts at boot without anyone logging in, and starts the server. When lingering cannot be enabled, the Installer warns and prints the command; until then the server starts only once you log in. If vBot is already installed in the selected directory, the Installer says so and points to `vbot update`.

Linux packages contain the server only. Use the WebUI in a browser, or connect a Windows Desktop Client from another computer.

Both Installers offer unfinished shared setup when run in an interactive terminal. Use `-Setup browser` on Windows or `--setup browser` on Linux to open it in the browser, or `-Setup later` / `--setup later` to leave it for your next WebUI or TUI visit. Deferring setup does not mark it as skipped. Automatic setup, including the Windows graphical Installer's browser action, stays closed when retained data already records completion or a skip; explicitly choosing terminal or browser setup reopens the guide. The first-run setup is described in [First-run setup](#first-run-setup).

As with any `curl | bash` or `irm | iex` command, inspect [install.sh](scripts/install.sh) or [install.ps1](scripts/install.ps1) and run the downloaded file locally if you do not want to execute network content directly.

### Install shapes

Windows offers three shapes; Linux installs the Server shape.

| I want to… | Shape | Windows option | Local server/WebUI | Desktop | Autostart |
|---|---|---|---|---|---|
| Run vBot and use it in a browser | Server | (default) | Yes | No | Yes unless disabled |
| Run vBot and also use the Desktop app | Server + Desktop | `-Desktop` | Yes | Yes | Yes unless disabled |
| Connect this computer to an existing vBot server | Desktop Client | `-DesktopClient` | No | Yes | Never |

`-Desktop` and `-DesktopClient` are mutually exclusive. A Desktop Client installs only the CLI and Desktop for a remote server; it owns no server and no server data.

### Update channels

Every installation follows one update channel, which `vbot update` installs from:

- `release` (default): the latest published GitHub release.
- `main`: the newest main build. After every push to `main` whose CI and package builds pass, the signed packages of that commit replace the previous ones on the rolling GitHub prerelease `main-build`. A main build is not a release: it carries unreleased changes, and `releases/latest` never points to it.

Install the newest main build with `-Main` on Windows or `--main` on Linux; that installation then updates from main. An existing installation can switch channels (see [Updating](#updating)).

The Installers and `vbot update` fetch only release files from `github.com` and never use the GitHub API, so its limit for anonymous requests does not affect computers behind a shared IP address. When a download does not match its recorded digest, run the Installer again: a newer main build replaces its files in place and may have done so meanwhile.

### Installer options

Windows options are passed through the ScriptBlock form:

| Option | Meaning |
|---|---|
| `-InstallDir <path>` | Installation directory; default `%LOCALAPPDATA%\Programs\vBot`. It must not exist yet |
| `-Main` | Install the newest main build; updates then follow main |
| `-Version <tag>` | Install a specific release, such as `v0.2.0` or `0.2.0`; cannot be combined with `-Main` |
| `-DataDir <path>` | Server data directory; default `~\.vbot` |
| `-HostName <host>` | Server bind host; default from the access mode, `127.0.0.1` for `local` |
| `-Access <mode>` | Server access mode: `local` (default), `lan` or `authenticated`; its options `-AllowNetwork`, `-AllowHost`, `-PublicUrl`, `-TrustedProxy`, `-TlsCert`, `-TlsKey` are described in [Server access](#server-access) |
| `-Port <port>` | Server port; default `22332` |
| `-Desktop` | Install Server + Desktop |
| `-DesktopClient` | Install only the Desktop Client for an existing remote server |
| `-NoAutostart` | Register no logon task; start the server only when `-Setup terminal` or `-Setup browser` is explicitly selected |
| `-Setup <mode>` | `auto` (default) opens setup in an interactive terminal after server startup; `terminal` or `browser` selects its surface; `later` defers setup without changing its saved status |
| `-AllowElevatedInstall` | Allow an elevated PowerShell; for disposable automation only, never for a persistent installation |

<details>
<summary>Windows examples</summary>

```powershell
& ([scriptblock]::Create((irm https://raw.githubusercontent.com/Vironnimo/vbot/main/scripts/install.ps1))) -Main
& ([scriptblock]::Create((irm https://raw.githubusercontent.com/Vironnimo/vbot/main/scripts/install.ps1))) -Desktop
& ([scriptblock]::Create((irm https://raw.githubusercontent.com/Vironnimo/vbot/main/scripts/install.ps1))) -DesktopClient
& ([scriptblock]::Create((irm https://raw.githubusercontent.com/Vironnimo/vbot/main/scripts/install.ps1))) -NoAutostart -Port 9000
```

</details>

Linux options are passed after `bash -s --`:

| Option | Meaning |
|---|---|
| `--dir <path>` | Installation directory; default `~/.local/share/vbot` or `$VBOT_DIR` |
| `--main` | Install the newest main build; updates then follow main |
| `--version <version>` | Install an exact release in `X.Y.Z` or `vX.Y.Z` form; cannot be combined with `--main` |
| `--data-dir <path>` | Server data directory; default `~/.vbot` |
| `--host <host>` | Server bind host; default from the access mode, `127.0.0.1` for `local` |
| `--access <mode>` | Server access mode: `local` (default), `lan` or `authenticated`; its options `--allow-network`, `--allow-host`, `--public-url`, `--trusted-proxy`, `--tls-cert`, `--tls-key` are described in [Server access](#server-access) |
| `--port <port>` | Server port; default `22332` |
| `--no-autostart` | Register no systemd user unit; start the server only when `--setup terminal` or `--setup browser` is explicitly selected |
| `--setup <mode>` | `auto` (default) opens setup in an interactive terminal after server startup; `terminal` or `browser` selects its surface; `later` defers setup without changing its saved status |
| `-h`, `--help` | Show Installer help |

<details>
<summary>Linux examples</summary>

```bash
curl -fsSL https://raw.githubusercontent.com/Vironnimo/vbot/main/scripts/install.sh | bash -s -- --main
curl -fsSL https://raw.githubusercontent.com/Vironnimo/vbot/main/scripts/install.sh | bash -s -- --version v0.2.0
curl -fsSL https://raw.githubusercontent.com/Vironnimo/vbot/main/scripts/install.sh | bash -s -- --no-autostart --port 9000
```

</details>

A selected release determines the initial installation, not a permanent version pin: subsequent `vbot update` calls follow the release channel. Both Installers verify that the downloaded release identity names the requested version and channel.

Both Installers report each step with a status label; `NO_COLOR=1` disables color. When the Windows Installer fails, it prints the path of its technical log. Automatic setup is deferred when the server is not started or no interactive terminal is available. To suppress the guide during automated installation, pass `-Setup later` or `--setup later`. With `-NoAutostart` or `--no-autostart`, explicitly choosing terminal or browser setup starts the server once without registering Autostart; otherwise start it yourself with `vbot server start`, then run `vbot setup` when you want the guide.

### Server access

The server's access mode decides who may connect:

| Mode | Who may connect | Default bind address |
|---|---|---|
| `local` (default), This computer only | This computer | `127.0.0.1` |
| `lan`, Home network without login | This computer, private networks (`10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`, link-local, IPv6 ULA) and each network added with `-AllowNetwork`/`--allow-network`, such as a VPN's `100.64.0.0/10` | `0.0.0.0` |
| `authenticated`, With login (internet) | Anyone who presents the credential of a paired device | `127.0.0.1` behind a reverse proxy, `0.0.0.0` with direct TLS |

Choose the mode at installation with `-Access`/`--access`. `authenticated` also needs `-PublicUrl`/`--public-url` (the `https://` address browsers use) and HTTPS: either `-TrustedProxy`/`--trusted-proxy` with the address of the reverse proxy that terminates HTTPS, or `-TlsCert`/`--tls-cert` with `-TlsKey`/`--tls-key` for the server's own certificate, which it reloads when the files change. `vbot application access show` prints the current setting; `vbot application access set <mode> [options]` changes it for the next `vbot server restart`. The server refuses to start with options that do not fit its mode.

Give each `authenticated` server its own hostname, such as `vbot.example.com`, and keep unrelated services off that hostname. Browser sign-in cookies are shared across ports: running another service or another vBot server at a different port on the same hostname does not isolate the credential. Use separate hostnames for separate servers, including development instances.

`local` and `lan` have no login: everyone they admit can use vBot with your account's permissions. Both refuse requests forwarded by a reverse proxy, so a proxy in front of vBot needs `authenticated`. On the server's own computer the CLI, TUI, tray and Desktop keep working in every mode through a local access token, and the tray's **Open in browser** signs that browser in. They send that token only to the address the server listens on, such as `http://127.0.0.1:22332`; a name such as `localhost` may lead to another program, so `--url http://localhost:22332` gets no token. `vbot devices list|approve|deny|rename|revoke` manages the paired devices. Removing a device also signs out the browsers it signed in through a sign-in link, such as the Desktop's window; devices it approved by code stay. Internal file and preview links issued to the removed device also stop working, and its open transfers end. While the server cannot read its device list, signed-in devices keep their sign-in and wait until the server can check it again.

A CLI on another computer signs in to an `authenticated` server once:

```bash
vbot devices pair https://vbot.example.com
```

It shows a code; approve it in the WebUI of a signed-in device (Settings > Access & devices > Add device) or with `vbot devices approve <code>` on the server's computer. In a terminal the command waits until the code is approved; from a script it returns after 50 seconds and the same command keeps waiting for the same code. Approve the code only in vBot at the address the command names: whoever gets it approved elsewhere signs in as your CLI. The device token is stored for the current user on that computer (encrypted with Windows DPAPI on Windows, an owner-only file elsewhere) and never printed. Afterwards every command, including `vbot tui`, reaches that server with `--url https://vbot.example.com`, or with the environment variable `VBOT_SERVER_URL=https://vbot.example.com`. `vbot devices logout https://vbot.example.com` revokes the device on the server and removes the stored token. Pairing needs the server's `https://` address, and a device token is only ever sent there; a `local` or `lan` server needs no pairing. An SSH tunnel to a server that requires login therefore does not sign in: use the server's `https://` address, or run `vbot` on the server's computer over SSH.

`lan` trusts the source address of each connection. Anything that forwards outside traffic with a private or loopback source address lets those clients in without login: router port forwarding with source NAT, Windows `netsh interface portproxy`, Docker's port publishing, or an SSH or VPN tunnel that ends on the server. Make vBot reachable from outside your home network only in `authenticated` mode.

In every mode the server answers only to an IP address or a name it knows as its own: `localhost`, this computer's name (also as `<name>.local`), its bind address and the public URL's host. This stops DNS rebinding, where a website points its own name at your server. If you reach vBot through another name, such as a DNS name in your home network, add it with `-AllowHost`/`--allow-host` (once per name); otherwise the browser gets "Access denied: unknown host name".

Behind a reverse proxy, the proxy must pass the browser's `Host` through, append the client's address to `X-Forwarded-For`, set `X-Forwarded-Proto` to `https`, and pass WebSocket upgrades. Caddy's `reverse_proxy` does this by default. For nginx:

```nginx
map $http_upgrade $connection_upgrade {
    default upgrade;
    ''      close;
}

server {
    # listen 443 ssl; server_name and certificates as usual
    location / {
        proxy_pass http://127.0.0.1:22332;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection $connection_upgrade;
        proxy_buffering off;
    }
}
```

A server started from a development checkout keeps its access mode in its data directory (`access/server.json`): `vbot server start`, `vbot server restart` and restarts the server schedules itself serve what it records. To change it, start the server once with the access options, for example `python -m server.main --access lan --data-dir ~/.vbot-alt`. A server that cannot read the record refuses to start.

### Development checkout

A Git clone of this repository is a development checkout, not an installation. Set it up with `pip install -e ".[dev]"` as described in [Development checkout](#development-checkout), and update it with Git, not with `vbot update`. In a checkout, `vbot update`, `vbot uninstall`, `vbot autostart` and `vbot application` refuse and name what to do instead; start its server with `vbot server start` or `python server/main.py`.

## Requirements

- **Windows:** 64-bit Windows on x86-64 and a normal user account.
- **Linux:** 64-bit Linux on ARM64 (aarch64) or x86-64 with `curl` and `python3`, and systemd for Autostart. A Raspberry Pi needs the 64-bit Raspberry Pi OS; the Installer refuses other architectures.
- A Provider Connection and Model are required before an Agent can complete a Run. Configure them in the shared setup or through the normal Provider and Agent settings.
- Browser automation is optional and uses the bundled `playwright-cli` Skill through the `bash` Tool. Install Node.js 18 or newer, npm, and `@playwright/cli` on the server host when needed; the Skill includes setup instructions. See [Browser automation](resources/skills/playwright-cli/SKILL.md).

## Updating and uninstalling

### Updating

Run the same command on Windows and Linux, or choose Update in the Windows tray:

```bash
vbot update
```

`vbot update` installs the newest package of the installation's update channel. A separate updater saves the operation and continues even if the calling terminal or vBot Run exits. A human CLI invocation normally waits for the final result, shows readable progress with elapsed time, and returns a failing exit code when the update fails. The final summary reports the version and verified outcome once; when the channel still publishes the active version, it reports that vBot is already up to date. `--output plain` returns the structured operation record for scripts. Read-only `update status` reports the saved record. The tray's **Status…** window shows the same progress while an update runs and its result afterwards. No Agent is created for a human or tray update.

vBot looks for a newer version of its update channel every few hours but never installs one by itself. When one is published, the tray menu item reads **Update to vBot <version>** and shows a notification, and the WebUI shows a notice until you dismiss it; a Linux server without a tray reaches you through that WebUI notice. Otherwise the tray offers **Check for updates**, which asks right away. `vbot application status` shows the last answer under `update_check`.

```bash
vbot update --detach           # return the saved operation id immediately
vbot update status            # inspect the latest saved operation
vbot update status OPERATION_ID
vbot update --no-restart       # prepare a candidate without changing the active version
vbot update activate OPERATION_ID
```

An update downloads the signed package of the channel, verifies its signature, and prepares the new version under `versions/<id>` beside the active one, with the same shape and server target and the Extension dependencies it needs. It then stops the server right away, like `vbot server stop`: active Runs are cancelled and keep their history up to that point, and queued messages are discarded. Then it creates a data snapshot of every canonical database and the JSON configuration documents. It verifies the candidate before switching `active-version` to it and verifies normal startup. If the candidate fails its verification start, the updater restores that snapshot, but only when the candidate changed the data and no other vBot server uses the data directory, and keeps the previous version once its startup is verified. After the candidate passed verification, the snapshot is never restored automatically; apart from this rollback, vBot restores a data snapshot on its own only to repair a damaged or missing database (see Data-store maintenance). If recovery cannot establish a safe result, the operation reports that it needs attention; when a data restore was interrupted, it names the `vbot data-store snapshot restore <snapshot-id> --all --yes` command that finishes it. An open Desktop switches through its restart handoff.

Switch the update channel, then update:

```bash
vbot application channel main      # or: vbot application channel release
vbot update
vbot application status            # shows the version, shape, channel and the newest published version
```

The channel cannot change while an update is pending. `vbot update` never goes back to an older version: after switching from main to release, it installs nothing until a release newer than the running main build appears (a release of the same version counts as older, since main builds of a version follow its release). The refusal changes nothing and names the way back, `vbot application channel main`. To choose a release deliberately, use `vbot update <version>`, replacing `<version>` with its `X.Y.Z` version or `vX.Y.Z` tag. The selected signed release must declare version-switch support; the first release shipping that support is the earliest eligible target. Earlier releases are not supported downgrade targets. This command keeps the configured update channel and current data. It verifies the selected version before activation, and a failed verification retains the original installation and restores only changes made by that failed attempt. The startup check covers vBot's core data. Extensions do not run during it; their own database compatibility is checked when they open normally, and an Extension failure can leave that Extension unavailable while the server starts. A deliberately supplied `--package <file>` remains available for local builds; a supported installation also requires version-switch support in that candidate.

To undo the last activated version change, including one whose normal server startup failed:

```bash
vbot rollback
```

This uses the retained previous installation and keeps current data. A previously stopped server stays stopped; a failed startup that had intended to restart a running server is recovered with that intent. An unresponsive owned server can be stopped through the normal bounded lifecycle path. A Desktop Client changes its application version without touching server data.

If the previous version cannot use current data, rollback retains the current installation and reports its saved pre-update snapshot. Restoring that data is a separate, explicit decision: it discards data changes after the snapshot. Use the exact snapshot id printed by the result:

```bash
vbot rollback --restore-data <snapshot-id> --yes
```

The restore first saves and protects the current data. If the target fails verification, the updater restores that safety snapshot before verifying the original installation, provided no competing server or data change appears during recovery. Both restores block new canonical database opens and recheck existing writers before replacing data; a conflict preserves the data and requires inspection. Credentials and access state follow the data-store restore exclusions; external project files and other files outside data snapshots are not rewound. An interrupted restore remains offline for inspection instead of replaying a destructive step. `vbot update status <operation-id>` records the requested snapshot, whether restoration started, and the safety snapshot; a started restore alone does not mean completion. Agents can request a normal rollback, but the data-reset form requires the user's terminal because it can remove the originating Run's history and continuation.

The application version and its data snapshot remain retained together until another activated version change replaces that recovery point. Ordinary snapshot cleanup cannot remove the retained snapshot; insufficient space fails the new snapshot instead. Historical releases before version-switch support remain installable through the existing Installer version option when their packages are available, but are not eligible targets of this supported return path.

When called through Bash in a vBot Run, the command saves its operation before returning and automatically arranges a continuation in the same Session. The updater waits for the whole Tool batch to enter Session history, registers that continuation, and then stops the server, which cancels the originating Run together with every other active Run. The continuation checks the saved result; acceptance alone is not update success. Do not create an additional Bootstrap for this update path.

### Uninstalling

Start the guided removal or reset flow:

```bash
vbot uninstall
```

The command shows the installation directory before offering three explicit scopes:

| Scope | Application | Runtime data |
|---|---|---|
| Application only | Removed | Preserved |
| Data only / reset | Preserved | Permanently deleted |
| Application and data | Removed | Permanently deleted |

Application-only removal asks you to type `YES`; any data-removing scope displays the resolved data directory and requires typing `DELETE`. A data-only reset preserves the previous server state: a running server restarts with fresh data, while a stopped server remains stopped. A server that runs but does not answer its health check is left untouched and the reset is refused; try again once it responds.

<details>
<summary>Non-interactive Uninstall commands</summary>

```bash
vbot uninstall --app-only --yes
vbot uninstall --data-only --yes
vbot uninstall --all --yes
```

Automation must choose exactly one scope and confirm it with `--yes`. Uninstall takes no target options: it always acts on the installation that runs it, with that installation's recorded server and data directory.

</details>

<details>
<summary>What removal does on each platform</summary>

Application removal refuses while an update is pending. It stops the installation's server and removes its Autostart registration. On Windows it then hands the removal to the registered per-user uninstaller, which also removes the Start-menu entries and the command path; the command reports that the uninstaller has started. On Linux it disables `vbot.service`, removes the `~/.local/bin/vbot` link when it points to this installation, and deletes the installation directory. The data directory is kept unless you chose `--all` or `--data-only`.

The command refuses while you are inside the installation directory, and refuses to delete a data directory that is a filesystem root or the home directory, contains or lies inside the installation, or contains your current directory. A Desktop Client owns no server data, so it offers only application removal.

</details>

## First-run setup

Installation, WebUI and TUI share one optional setup guide and one saved progress record for the server. If setup has not been completed or explicitly skipped, the WebUI and TUI open it automatically. vBot has already created an initial Identity Agent and its first Session, so you do not need to create an Agent before getting started.

1. Choose a Provider.
2. Connect an API key, an OAuth subscription, or a keyless local Connection such as Ollama.
3. Select the Agent's chat Model.
4. Finish and start chatting, or continue to choose bundled Skills, Extensions and optional services.

Every step lets you end the guide, including the first one. Saved choices stay in place; untouched options keep their defaults. Skipping the guide before setting a Provider and Model leaves those for you to configure manually before the first Agent can work. Setup is not a prerequisite for using the normal settings or CLI commands.

Once the initial Agent has a configured Provider and Model, setup stays completed, including when you configured them manually. Explicitly skipping also prevents automatic re-entry. Expired keys, unavailable Models or later removal of Providers do not reopen setup. Reopening the guide yourself keeps your existing settings and does not enable automatic setup again.

Run `vbot setup` to reopen the guide in a terminal, or `vbot setup --browser` to open it in the WebUI. Add `--if-needed` to either command to open only pending setup; completed or skipped setup exits successfully without opening a guide or requiring a terminal. The TUI and WebUI also offer an action to reopen setup. Non-interactive commands use the same server state:

```bash
vbot setup status
vbot setup finish
```

`status` reports the saved state and step. `finish` ends the guide for every Accessor without configuring missing choices: it records completion when the initial Agent is configured, otherwise a skip. A successful chat response, rather than the setup status, confirms that the selected Provider and Model can currently answer.

The WebUI is the recommended place to manage Connections and Accounts because it keeps credentials out of command history. A fresh server installation seeds global Agent defaults with thinking effort `high` and leaves temperature unset, so Agents request their Model's recommended temperature - or none at all, leaving the choice to Provider and API defaults - unless configured more specifically. Installation and updates preserve an existing `settings.json`, so these fresh-install defaults never replace an existing instance's choices.

<details>
<summary>Equivalent Provider CLI examples</summary>

```bash
vbot provider key set openrouter --stdin --refresh-models
vbot provider connect openai --connection openai:subscription
vbot provider usage --connection openai:subscription
vbot provider enable ollama
vbot model refresh openrouter
```

vBot learns from Provider responses: when a Provider rejects a sampling parameter or a reasoning effort for a Model, vBot retries without it and leaves it out of later requests. Such a lesson expires after 30 days; `vbot model forget-wire-facts <provider>[/<model-id>] [--connection <id>]` drops it at once, for example after the Provider fixed the Model.

A key passed to `provider key set` may be retained by shell history. Prefer the WebUI, a protected environment variable, or a shell-specific history-safe workflow when entering a real secret.

</details>

A Provider describes an external model service and Adapter behavior. A Connection describes one authentication and endpoint mode under that Provider. An Account is a credential slot on a Connection; the default slot is named `default`, and additional named Accounts can coexist.

API keys resolve from the process environment first and the data directory's Secret Store second; OAuth tokens live in the Secret Store as well (see Credentials and the Secret Store below). A keyless local Connection such as Ollama still has enabled and reachability state even though it has no credential.

### Optional components and services

The guide's components step lets you enable or disable bundled Skills and Extensions. These are the same choices available in the normal managers; leaving the step keeps their current configuration. Optional services are a separate step in the same guide and can also be configured later.

A packaged vBot server can install and manage SearXNG for web search. Setup reuses an existing local Docker or Podman runtime, or offers to install Podman and prepare the required environment. The plan names the additional steps before you approve them. Windows can require a system authorization dialog, WSL 2 and a restart; Linux uses the host's package manager and system authorization. When a host action is needed, follow the displayed instructions and resume setup afterwards. The work takes place on the server computer, even when you open the guide elsewhere.

The managed SearXNG container listens only on the server's loopback address. Setup enables JSON search, runs a test search and then selects the verified service for vBot's web search. You can instead keep another search provider or configure an existing SearXNG URL. Managed installation is unavailable in a development checkout; configuring an existing service is still supported.

The same service controls are available without the guide:

```bash
vbot service install searxng
vbot service status searxng
vbot service stop searxng
vbot service start searxng
vbot service update searxng
vbot service remove searxng
```

Install and update use existing prerequisites unless you add `--install-prerequisites`; that option permits the missing host setup shown by `service status`. On Linux, a local interactive terminal can run the fixed package-manager command through `sudo` after vBot verifies that the selected server belongs to this installation. The terminal guide temporarily suspends itself for the system password prompt. `--json` never prompts; remote targets and Agent Runs cannot request terminal authorization either. When terminal authorization is unavailable, an `action_required` result includes the command to run on the server.

Service operations run in the background, so read their saved result with `service status` before treating them as finished. Closing the guide does not cancel an accepted operation. After an authorization request, restart or other reported interruption, resolve the host action and repeat the requested service action to resume.

An update keeps the previous container until the replacement passes its search check, and restores it when the check fails. Stopping SearXNG leaves the web-search selection in place. Removing it deletes vBot's managed containers while retaining their configuration, downloaded images and the shared container runtime. Removal restores the previous search configuration only if vBot still uses that managed SearXNG URL; later user changes remain intact.

### Custom Providers

Settings can add a user-owned OpenAI-compatible endpoint without adding files under `resources/`. Use **Settings → Providers → Add custom** to set its stable id, display name, endpoint URL, authentication, optional Model discovery path, and manual Models. The initial Adapter choice is `openai_compatible`; each Custom Provider has one implicit `default` Connection. API keys are write-only and are stored as `VBOT_CUSTOM_<ID>_API_KEY` in the selected data directory's Secret Store, never in `settings.json`.

The equivalent secret-free `settings.json` shape is:

```json
{
  "providers": {
    "custom": {
      "local-ai": {
        "name": "Local AI",
        "adapter": "openai_compatible",
        "base_url": "http://127.0.0.1:8080/v1",
        "auth": "none",
        "models_endpoint": "/models",
        "defaults": {},
        "models": {
          "chat-model": {
            "name": "Chat Model",
            "context_window": 32768,
            "max_output_tokens": 4096,
            "capabilities": {
              "input_modalities": ["text"],
              "output_modalities": ["text"],
              "task_types": ["chat", "text_output"],
              "tools": true,
              "vision": false,
              "json_mode": false,
              "reasoning": false,
              "supported_parameters": [],
              "supported_voices": [],
              "task_options": {}
            }
          }
        }
      }
    }
  }
}
```

Use `"auth": "api_key"` for standard `Authorization: Bearer` authentication and enter the key through Settings or `provider custom save --api-key-stdin`. Omit or clear `models_endpoint` to use manual Models only. Discovery and manual Models can coexist: a manual record overrides discovered facts for the same wire id, while other discovered Models remain available. Saving through the WebUI/RPC reloads Providers and Models immediately; after direct file editing, validate with `vbot doctor settings` and restart vBot.

```bash
vbot provider custom save local-ai --name "Local AI" --base-url http://127.0.0.1:8080/v1 --auth none --models-endpoint /models --model chat-model
vbot provider custom list
vbot model refresh local-ai
vbot provider custom delete local-ai
```

`custom save` replaces the Custom Provider's endpoint, authentication, discovery path and Model list; repeated `--model` flags create conservative chat Model entries. What its options cannot express survives the replacement: the sampling defaults, the capabilities already stored for a Model id that stays in the list, and the `wire` block. `--wire-file <path>` replaces the `wire` block with the JSON object in that file, and `--clear-wire` removes it. Use the WebUI for the full manual capability editor. Deleting a Custom Provider removes its generated data-directory API keys but deliberately keeps Agent/default/task Model references, which remain visible as unavailable until reconfigured.

#### Wire profile

By default vBot speaks plain OpenAI Chat Completions to a Custom Provider: an effort goes out as `reasoning_effort`, and reasoning text is read from the usual response fields. When the endpoint ignores the effort, returns its reasoning in another field, or rejects a request field, describe its wire in the optional `wire` object of the record (**Settings → Providers → Edit → Advanced: wire profile**). It takes the body of vBot's bundled `resources/wire/<provider>.json` files - `defaults`, `protocols`, `connections` (only `default`), `rules`, and per-Model `models` entries - without `format_version`:

```json
"wire": {
  "defaults": {
    "reasoning": {"dialect": "thinking_toggle"},
    "response": {"reasoning_fields": ["reasoning_content"]},
    "request": {"parameters": {"temperature": {"mode": "drop"}}}
  },
  "rules": [
    {"when": {"prefix": "qwen"}, "set": {"reasoning": {"levels": ["low", "high"]}}}
  ],
  "models": {
    "chat-model": {"set": {"replay": {"history_field": "reasoning_content"}}}
  }
}
```

Later layers win: protocol defaults, `defaults`, `protocols`, `connections`, the Model's own facts (such as its Reasoning switch), matching `rules` in order, facts vBot learned from live traffic, the Model entry's `set`, and its `connections`. A manual Model whose Reasoning switch is off therefore sends no reasoning fields whatever `defaults` says; turn the switch on, or set `"reasoning": {"supported": true}` in a rule or Model entry.

A WebUI/RPC save applies the block immediately and refuses entries vBot would ignore, listing each one. In a hand-edited `settings.json`, `vbot doctor settings` reports such entries as warnings, and vBot ignores them. To check a Model against the live endpoint, run `python scripts/verify_wire_profile.py --provider local-ai --model chat-model` from the vBot source tree; `--write` stores the entry the evidence supports under `wire.models` in the data directory's `settings.json`, which a running vBot applies after a restart.

## Data directory and configuration

The normal runtime data directory is `~/.vbot`. Select another target with `--data-dir` on server and RPC-backed CLI commands, or set `VBOT_DATA_DIR`. Run `vbot home` to print the absolute application and currently selected data directories; pass `--data-dir` to inspect an explicit target.

Setup, Runtime, direct `core/storage/layout.py` use, and managed Worktree creation all initialize this same non-destructive structure:

```text
<data-dir>/
├── artifacts/
│   ├── attachments/
│   ├── speech/
│   ├── models/
│   ├── debug/
│   ├── performance/
│   └── temp/
│       ├── atomic/
│       ├── bash/
│       ├── subagents/
│       ├── terminals/
│       └── web_fetch/
├── statistics/
├── agents/
├── archive/
├── bootstrap/
├── calendar/
├── channels/
├── cron/
├── extensions/
├── logs/
├── processes/
├── projects/
├── prompts/
├── recall/
├── skills/
├── terminals/
├── data-store.json
└── settings.json
```

`artifacts/attachments/`, `artifacts/speech/`, `artifacts/models/`, `artifacts/debug/`, and `artifacts/performance/` contain durable domain-owned artifacts; the performance folder keeps the newest 20 Recordings. The `artifacts/temp/` children remain separate: atomic replacement staging, 72-hour retained Bash output, Terminal output and Web Fetch snapshots, and 24-hour retained Sub-Agent activity. `statistics/` holds only the disposable local Statistics index, which is derived from Sessions; the automatic Provider usage history is the canonical `provider-usage.db` at the data root (see Data-store maintenance below). The tracked system Model DB remains `resources/models/`; only the complete instance runtime Model DB moves under `artifacts/models/`.

Independent roots keep their established ownership: `agents/` contains Identity Agent configs, default Workspaces, and private Skills; `projects/` contains Project metadata; `skills/` contains global user Skills; `bootstrap/`, `calendar/`, `channels/`, `cron/`, `extensions/`, `prompts/`, `recall/`, `terminals/`, `logs/`, and `archive/` retain their existing records. Sessions of every Agent and Project live in `sessions.db`. Custom absolute Workspaces remain outside the data directory. `processes/` is reserved for future persistent process records and is not the Bash-output location.

Other entries appear at the data root when first needed:

- the canonical databases `sessions.db`, `channels.db`, and `provider-usage.db`, and Extension databases next to other Extension state under `extension-data/<extension>/`; every database is registered in `data-store.json` (see Data-store maintenance below);
- `snapshots/`, `config-backups/`, `incidents/` and `quarantine/` for data snapshots, configuration backups and recovery, `data-store.lock`, and `data-maintenance.json` while an offline data operation is incomplete;
- `secrets.json`, the encrypted Secret Store, when the first credential or OAuth token is saved (see Credentials and the Secret Store below);
- `setup.json`, the shared first-run progress and durable completed or skipped decision;
- `runtime/` with the control records of a running server, `speech-engines/` after local speech setup, and `embedding-engines/` after a local embedding Model is installed;
- `pre-generation-1/` only in a data directory converted from vBot 0.4.4 or earlier (see below).

The initializer creates a `settings.json` holding only `format_version` 1 when Settings is absent and never rewrites an existing one; it seeds no credentials. The installer adds the fresh-install Agent defaults to that new `settings.json` only when it creates the data directory; the server port stays in the installation record. The initializer writes `data-store.json` only into a data directory it has just created; an existing directory without it is refused (see Data directories from older versions).

### Data directories from older versions

vBot reads only its current data format: the canonical paths, databases registered in `data-store.json`, and JSON documents with a `format_version`. Setup and Runtime never convert or dual-read older data. vBot 0.4.4 and earlier wrote data directories in an older format, which this version cannot use: it refuses such a directory at startup, as it refuses every existing directory without `data-store.json`. To start fresh, move the old directory aside or choose a data directory path that does not exist yet; vBot creates a new data directory there. To keep old data, open it with the vBot version that wrote it and copy out what you still need.

A data directory converted from such a version can still hold `pre-generation-1/`: the files the conversion replaced, including old copies of credential files such as OAuth tokens. vBot never reads it. Treat it like the data directory, and delete it once the converted data has worked for a while and a data snapshot exists.

### Credentials and the Secret Store

API keys, bot tokens and other credentials saved through Settings, the CLI or an Extension, and every OAuth login, live in the data directory's Secret Store, `<data-dir>/secrets.json`. Each entry is encrypted with AES-256-GCM; the file names the stored credentials (environment-variable names such as `OPENAI_API_KEY`) but holds no readable value. A credential set in the process environment that starts the server still takes precedence over a stored one with the same name.

The store's key never lies in the data directory as plain data:

- On Windows, Windows DPAPI protects the key for the Windows account that created the store. A copy of the data directory opens only under that account on the same computer; on another computer or account, enter the credentials again.
- On Linux, the key is a separate file, `~/.config/vbot/keys/<store id>.key`, readable only by its owner; vBot also looks in `$XDG_CONFIG_HOME/vbot/keys/`, where earlier versions created keys. `VBOT_SECRET_KEY_FILE` names another location, and then only that file is used; an existing file there is used as the key of a new store. vBot never overwrites a key file. **Back the key file up separately**: a data-directory backup alone cannot decrypt the credentials, which is the point of keeping it apart.

On Windows, credential names ignore case as environment variables do: `GITHUB_TOKEN` and `github_token` are one credential, and saving it under one spelling replaces the others.

Snapshots and configuration backups copy `secrets.json` like any other configuration document; they too stay readable only with the key. Restoring them never rolls the store back on its own: a snapshot restore and `config-backup restore --all` keep the current `secrets.json`, so credentials saved or converted after the backup stay. To restore the store from a configuration backup, name it: `vbot data-store config-backup restore <backup-id> --file secrets.json --yes`.

When the key is missing or wrong, vBot never replaces the store: the server still starts, every stored credential reports as not configured, the log warns once, `vbot data-store status` and `vbot doctor config` report the problem, and `secrets.json` stays untouched. Restore the key (or start the server under the Windows account that created the store) and restart. Only when the key is lost for good, `vbot data-store secrets reset --yes` moves the old store to `quarantine/secret-store/` and starts a new empty one; every credential and OAuth login must then be entered again. While the server runs, `reset` asks it first and refuses unless the server cannot open the store either and would find the new key; its message names where the command and the server look for the key, so run it under the same account and `VBOT_SECRET_KEY_FILE` as the server. If `secrets.json` is missing while a store lies in quarantine, `vbot data-store status` and `vbot doctor config` name it; stop the server and move it back to restore its credentials.

Manage individual stored credentials from the command line:

```bash
vbot data-store secrets list
vbot data-store secrets set GITHUB_TOKEN
vbot data-store secrets unset GITHUB_TOKEN
```

`list` shows every stored credential name, whether it is usable and where the server takes its value from (`process_environment`, `data_dir`), never a value. `set` asks for the value without showing it, or reads it from standard input when piped (`printf '%s' "$TOKEN" | vbot data-store secrets set GITHUB_TOKEN`); a value is never accepted as a command-line argument. `unset` removes the stored value; a variable of that name in the server's process environment still applies. With a running server these commands go through it and take effect at once; with a stopped local server they change the Secret Store directly and the next start loads it.

Earlier versions kept credentials in plaintext, in `<data-dir>/.env` and `<data-dir>/oauth/*.json`. The application updater converts them: the updated version imports and verifies them at its verification start, and its first regular start deletes the plaintext files and their copies in configuration backups, data snapshots and the restore quarantine. A failed or rolled-back update keeps the plaintext files for the previous version. vBot no longer reads these files otherwise: a `.env` or OAuth token file created later, or one in a data directory that was not updated through the application updater, is ignored with a warning in the log, in `vbot data-store status` and in `vbot doctor config` until it is converted:

```bash
vbot data-store secrets status
vbot data-store secrets convert --yes
vbot data-store secrets reset --yes
```

`status` shows the store's state, how many credentials and OAuth logins it holds, damaged entries, where the key is searched, ignored plaintext files and what to do with each, never a value. `convert` stops the target server, imports the plaintext files, deletes those it fully imported, and starts the server again. It never overwrites a value saved in vBot since: such an entry is reported as differing, and the file stays until you delete it or remove those lines. A line it cannot import, for example one with an invalid name, is reported by file and line number, never with its content; that file stays in place. A `.env` or OAuth file that is a symbolic link or junction is imported, but vBot never deletes the link or the file it points to: delete the link yourself once the credentials are in the store. These commands work only with a local target and its matching `--data-dir`. `LOG_LEVEL` is no longer read from `.env`; set it in the server's process environment.

### Data-store maintenance

The canonical databases, such as the Session database `<data-dir>/sessions.db` and the Provider usage history `<data-dir>/provider-usage.db`, are authorized by `<data-dir>/data-store.json`, which records each database's identity and format generation. FTS, Recall, Vector, Statistics, data snapshots under `snapshots/`, and quarantine bundles under `quarantine/` are derived or recovery data and never replace canonical history. Runtime refuses an existing root without a valid marker and never searches legacy files to guess how to initialize it. A damaged or missing canonical database is restored automatically from the newest verified data snapshot; the damaged files move to quarantine and a recovery incident under `incidents/` records the possible loss interval.

Inspect the canonical databases and their recovery state through the live server or the local offline commands:

```bash
vbot data-store status
vbot data-store snapshot list
vbot data-store snapshot create --reason manual
vbot data-store snapshot verify <snapshot-id>
vbot data-store incident acknowledge <incident-id>
vbot data-store snapshot restore <snapshot-id> --yes
vbot data-store snapshot restore <snapshot-id> --database sessions --yes
vbot data-store snapshot restore <snapshot-id> --documents --yes
vbot data-store snapshot restore <snapshot-id> --all --yes
vbot data-store unregister ext.<extension>.<name> --yes
vbot data-store convert --yes
vbot data-store config-backup list
vbot data-store config-backup show <backup-id>
vbot data-store config-backup restore <backup-id> --file settings.json --yes
vbot data-store config-backup restore <backup-id> --all --yes
```

`status` reports safe operational metadata per database, including the Session search index state, registered data snapshots, and every unacknowledged recovery incident without returning Session content; for a stopped local server it reads the data directory directly. Ordinary status uses the Session search lifecycle markers and includes the latest coverage check from the current server process, when available, with its time. `vbot data-store status --verify-search` checks index coverage against stored entries now; it can take longer on large histories and also works read-only when the local server is stopped. Snapshot creation is an explicit backup, through the running server, of every canonical database and of the JSON configuration documents (settings, Agents, Projects, Channels, prompt layouts, Cron and Bootstrap jobs, Calendar events, the Skill policy, Terminal state, MCP connections and the encrypted Secret Store with credentials, OAuth tokens and webhook secrets; attachment and speech metadata stay out, like the files they describe). A recovery incident remains visible until the exact incident is acknowledged; acknowledgement does not delete snapshots or quarantine evidence.

Restore is offline maintenance: it requires `--yes`, checks the snapshot first, stops the exact target server when it runs and starts it again afterwards, and must be rehearsed on a copied data directory first. Without a selector it restores every database in the snapshot; `--database` restores only the named ones; `--documents` restores the JSON documents as one set, alone or together with `--database`; `--all` restores the complete snapshot, moves databases registered after the snapshot to quarantine, and takes no other selector. Restored documents become exactly the snapshot's: documents created after it are removed, and every replaced or removed document is kept under `quarantine/json-documents/`. The Secret Store `secrets.json` is the exception: it stays as it is, so credentials saved since the snapshot are kept (see Credentials and the Secret Store). An interrupted restore keeps the server from starting until a restore is repeated and completes. If the guard file `data-maintenance.json` itself is damaged, vBot cannot tell which restore it guarded and says so: delete that file by hand, and if in doubt, restore a data snapshot or configuration backup afterwards.

Configuration backups protect the configuration files, which change far more often than data snapshots are taken: the JSON configuration documents listed above, `SOUL.md`, `USER.md` and `MEMORY.md` of each Agent Workspace in its default location (`agents/<id>/workspace/`), and System Prompt overrides under `prompts/` and `agents/<id>/prompts/`. A running server backs them up when it starts, checks every 5 minutes and backs up what changed, and backs up once more when it stops. Each distinct file content is stored once under `config-backups/`, so an unchanged file costs nothing. vBot keeps the newest 10 backups, plus the newest one of every hour for 48 hours, of every day for 30 days and of every week for 52 weeks. A JSON document that could not be read as such when it was backed up is marked as damaged and is never restored from that backup. Workspaces at a custom path, other Workspace files and Skills (which keep their own history) are not covered.

`config-backup list` shows the backups, newest first, with the files each one changed; `show` compares one backup's files with the current ones (`same`, `differs`, `missing`). `restore` requires `--yes` and either `--file <path>` (repeatable, as `show` names it) or `--all`. It stops the target server when it runs, restores, and starts it again; when every selected file already matches, it changes nothing and leaves the server running. An interrupted restore keeps the server from starting until the same restore is repeated, or until `--all` restores another backup instead, which also works when the interrupted restore's backup was lost; other restores are refused until then. Before it changes anything it backs up the current state as `before restore <backup-id>`, so restoring that backup takes the restore back. A restore never deletes files: files created after the backup stay, and files whose folder no longer exists (a deleted or renamed Agent, Project or Channel), that are damaged in the backup, or that are reached through a symbolic link or junction (which backups never read) are refused when named and left alone by `--all`. `--all` also leaves the Secret Store `secrets.json` as it is; name it with `--file secrets.json` to restore it.

`unregister` releases the database of a removed Extension. While it stays registered, data snapshots keep copying it, and once its file is gone, snapshot creation and updates refuse until it is released. The files move to `quarantine/` and the registration is dropped. It accepts only Extension databases (`ext.<extension>.<name>`), is refused while an Extension has the database open, and requires `--yes`. Earlier snapshots keep their copy, and restoring that database from one registers it again.

`convert` brings documents an older vBot wrote to the current format, such as Project configurations from before the main instruction file loaded on its own; each Project keeps the instruction files it loaded. The application updater does this during an update; run it yourself for a data directory the updater does not update, for example a development checkout's, or after restoring older documents from a backup. vBot does not read such a document until it is converted, and `vbot doctor config` names the command. It requires `--yes`, stops the target server when it runs and starts it again, and changes nothing when every document is current.

The Session database stores Runs, Messages, Tool invocations/results and checkpoints relationally.

Desktop owns separate per-user settings because it can connect to different servers. On Windows they live under `%APPDATA%\vbot`; on Linux they live under `$XDG_CONFIG_HOME/vbot` or `~/.config/vbot`. Remembered servers, wakeword configuration, and imported wakeword Models are Desktop-local and are not server Settings.

Use the WebUI Settings view or the cataloged CLI Settings paths for validated changes:

```bash
vbot config list
vbot config describe server.port
vbot config set server.port 9000
vbot config patch --set web_search.provider searxng --set web_search.searxng.base_url https://searxng.example/
vbot config raw
vbot doctor settings
vbot doctor config
```

Bare `vbot config` is equivalent to `config list`; `config get`, `set`, `unset`, and atomic multi-operation `patch` use public paths rather than internal `settings.json` keys. `config effective` shows the normalized public document, while `config raw` is diagnostic only. `doctor settings` strictly validates the target `settings.json`; `doctor config` checks every JSON document vBot keeps in the data directory, from Agent, Project and Channel files to the Secret Store and attachment metadata, and warns about plaintext credential files it ignores. At runtime, malformed root Settings fall back safely, invalid top-level Settings sections are omitted while valid siblings remain active, and invalid individual Agent or Project records are skipped. The source file is not silently rewritten, and mutations that could overwrite invalid source state are blocked until it is repaired.

## Running the server

Run in the foreground from a development checkout:

```bash
python server/main.py
```

Use the lifecycle commands for a managed background process:

```bash
vbot server start
vbot server status
vbot server restart
vbot server stop
```

An installation's lifecycle commands always act on its recorded server, with the host, port and data directory chosen at installation; a `--host`, `--port` or `--data-dir` that names another target is rejected. In a development checkout, select the target at the leaf command:

```bash
python cli/main.py server start --host 127.0.0.1 --port 9000 --data-dir ~/.vbot-alt
```

Manage Autostart of an installation separately when needed:

```bash
vbot autostart enable
vbot autostart status
vbot autostart disable
```

On Windows, Autostart is a per-user Task Scheduler logon task that starts the vBot tray, which starts the server. On Linux, it is the systemd user unit `vbot.service`, which runs the server and restarts it after a failure, together with login lingering so that the server starts at boot; while that unit exists, `vbot server start`, `stop` and `restart` go through `systemctl --user`.

The default host is `127.0.0.1` and the default port is `22332`. Confirm the exact vBot health contract with:

```bash
curl http://127.0.0.1:22332/health
```

The expected body is exactly `{"status":"ok"}`.

## WebUI and Desktop

The WebUI at `http://127.0.0.1:22332/` provides Chat, Agent and Project management, Cron, System Prompt editing, Settings, Logs, Statistics, and Debug views. It connects to the server-owned runtime, so closing the browser does not stop a Run.

Launch the optional Desktop accessor with:

```bash
vbot desktop
vbot desktop --host 192.168.1.50 --port 22332
```

On Windows, `-Desktop` and `-DesktopClient` installations also create a `vBot Desktop` Start-menu entry that launches Desktop without a console window. `vbot desktop` remains the equivalent command for terminal use.

Without explicit host and port, Desktop opens its Connection screen and auto-connects only when a remembered last-used server exists. It does not silently assume localhost. Probe failures return to the same screen with the target prefilled, and the native Server menu can switch or reconnect at runtime.

Desktop loads the same server-served WebUI. A local folder picker would browse the client machine rather than a remote server, so Project paths remain server-side paths entered through the same WebUI field.

Desktop Voice runs wakeword detection and microphone capture locally. Up to eight built-in or imported pyopen-wakeword TFLite Models (wake phrases) can listen at the same time. Each phrase has its own action per server under **When heard** in Settings → Voice: **Send a command** records what you say next and sends it to the phrase's Agent or the server's **Default Agent**; **Start or end Live voice** and **Start Live voice** control a Live voice call instead. Hey Nabu and Okay Nabu react to each other, so give them the same action. Imported Models are validated and stored on the Desktop machine; training happens outside vBot. Nothing is uploaded unless a command phrase matches. After a match, the command recording, including about 0.3 s of locally buffered audio immediately before detection, is sent to the active server's speech transcription endpoint; a recording ends after 1 s of silence and after 2 minutes at the latest.

**Echo cancellation** (Windows, on by default) removes what the computer plays through its default output device from the microphone signal, so Chat text-to-speech, Live voice replies, or other audio from loudspeakers do not trigger wake phrases and disturb command recordings less. It needs no setup; with headphones it has nothing to remove and stays harmless. For loudspeaker use, place the microphone near you: a headset microphone lying on the desk, especially one with built-in noise suppression, hears too little of your voice and distorts the echo too much for wake phrases to work reliably.

## Agents, Projects, and Sessions

### Live voice companion (preview)

Live voice can operate Chat and coding-agent Terminals while you speak. Choose its Model under **Settings -> Voice -> Live voice**; once a Model is chosen, a compact control appears at the bottom of the Main menu, above the microphone and connection indicators. It runs on OpenAI GPT-Live (an OpenAI API key or the ChatGPT subscription login under **Settings -> Providers**) or on xAI Grok Voice (an xAI API key or SuperGrok login). Then choose **Start Live** and allow microphone access. The same button becomes **Stop Live** while connected. Clearing the Live voice Model hides the control and ends an active voice connection. GPT-Live always hands app work to a backend Model of the same Provider (default `gpt-5.6-terra`); choose that Model and its **Backend reasoning** effort in the Live voice settings. Grok Voice operates vBot itself by default; pick a Grok backend Model in its settings to delegate app work instead. Grok Voice audio passes through the vBot server, which relays it to xAI. No separate vBot Agent or speech Task Model needs configuring.

Use a browser over **localhost or HTTPS**. The Desktop app also works with remote plain-HTTP servers it knew when it started; after adding a new server, restart the Desktop app before using the microphone with it. In the Desktop app, wake phrases keep working during a Live call: a command phrase pauses the call while your command records, and the voice Model is told to ignore speech that starts with a wake phrase. A wake phrase can also start or end Live voice (its **When heard** action), and on Windows an optional global shortcut (**Settings -> Voice -> Live voice shortcut**) starts and stops it. The voice connection remains active across Chat/Terminals navigation; **Stop Live** closes it. Providers bill connected voice time, including idle time, separately from backend Model usage.

Example requests: "Open Terminals and start four Codex terminals in /home/me/project", "Maximize the second terminal", "Put the fourth terminal first", or "Open Joel's chat and tell him to continue". Codex and Claude Code must already be installed and authenticated **on the vBot server**; working directories refer to that server. The companion can start the requested number of coding terminals (subject to the existing server capacity), read and send terminal input, select/reorder tiles, and maximize/restore the existing layout. It can close individual terminals and create, select, rename, or delete user and Agent groups. Closing stops the terminal and removes its tile; deleting a group stops every running terminal in it. It uses exact Session targets for chat messages and preserves normal Queue behavior.

While listening, it receives new vBot Run completion/failure updates, can relay Agent questions, and can summarize replies on request. It does not infer completion from quiet terminal output. Ending voice does not stop coding terminals or vBot Runs. Errors use the usual app notifications; sent chat messages remain in their normal Sessions.

The integration has offline protocol/action tests and a keyless browser check. Real GPT-Live speech, account access, and Model-selected actions remain unverified until an eligible API key is available. An uncertain operation is not automatically repeated; inspect the destination before asking again.

### Identity Agents

An Identity Agent is durable personal identity under `<data-dir>/agents/<agent-id>/`. It owns a Workspace containing `SOUL.md`, `USER.md`, and `MEMORY.md`, a `memory` Tool, private Skills, permissions, and Sessions. A custom absolute Workspace is allowed; relative file and shell Tools use the active working directory, which is a separate concept.

Create and inspect Identity Agents through the WebUI or CLI:

```bash
vbot agent list
vbot agent create coder "Coding Agent" --model openrouter/anthropic/claude-sonnet-4
vbot agent show coder
vbot agent update coder --thinking-effort high
vbot agent rename coder researcher
```

`agent update --project <project-id>` sets the Agent's default Project: every new Session of the Agent works in that Project for its whole life, so relative file and shell work uses its repository, without moving the Agent's Workspace or Memory. Existing Sessions keep the Project or Workspace they started in. `--clear-project` removes the default, so new Sessions work in the Workspace. Workspace relocation is a separate operation: use `--workspace <absolute-path>` or `--default-workspace`, optionally with `--copy-workspace-files` to copy `SOUL.md`, `USER.md`, and `MEMORY.md` into the destination.

Agent create/update also expose delegation policy through `--subagent-allow <agent> ...` and Agent Policy through `--compaction-policy <json-object>` / `--clear-compaction-policy`. `--clear-model` and `--clear-fallback-models` restore global-default inheritance. Create/update output includes the saved id, Workspace, default Project, effective Model, effective Policy, and provenance; Workspace moves also report copied and backed-up files. Creating an Agent without an Agent or global-default Model is allowed for onboarding, but the result explicitly warns that it cannot run and points to `vbot model list --task chat` followed by `agent update --model`.

`agent rename <current-id> <new-id>` moves the complete Identity Agent tree, including Sessions, the internal Workspace, Memory, prompts, and private Skills. Live Channel targets, non-terminal Cron jobs, bare Identity Agent delegation entries, and functional Sub-Agent parent links are retargeted; historical provenance remains unchanged. The operation refuses collisions and runs while either id is busy, and rolls back server-owned changes if a reference cannot be updated.

### Projects and Project Agents

A Project registers a server-side repository path, an ordered list of Sources, optional auto-load files, Project defaults, and Sessions. vBot detects the agent definitions, Skills and instruction files the repository already has for other coding tools (OpenCode, Claude Code, Codex, GitHub Copilot, Cursor, Gemini CLI and the shared `.agents/skills/`) and lists each as a Source you can switch on or off and reorder. When two active Sources define the same Agent or Skill name, the earlier one wins and the other is shown as shadowed. Each Agent gets the vBot Tools for everything its definition allows, even where the other tool restricts it further; a status (ready, limited, needs attention) shows how completely it carried over. Foreign Model names map to vBot Models through the Project's Model mappings.

Project Agents are Config Agents scanned from the Project Team. They are profiles rather than identities: they have no Workspace, private Memory, private Skills, or `memory` Tool. Their runtime configuration resolves from repository definitions, Project defaults and capability ceilings, and vBot-owned overrides. Their Sessions live under the Project anchor and their address is `agent@project`.

```bash
vbot project add ./my-repo --name "My Project" --format opencode
vbot agent update coder --project my-project
vbot project list
vbot project show my-project
vbot project set my-project --default-agent orchestrator
vbot project override set my-project orchestrator temperature 0.3
vbot session create orchestrator@my-project
```

Project registration and Team scanning never write to the repository. Normal Agent Tools may write there during a Run when the Project is the working directory.

Project `add`/`set` can replace the Tool Whitelist and bundled/global/Project Skill policy lists. `override set`/`override clear` manage one Project Agent's vBot-owned model, temperature, thinking-effort, or Compaction Policy tier without editing the repository. `project remove --copy-rooted-agent-files` preserves `SOUL.md`, `USER.md`, and `MEMORY.md` before Identity Agents that use the Project as their default Project and have custom Workspaces are reset to their default Workspace; removal output lists every affected Agent and file effect. Identity Agent Sessions that work in the Project stay readable but cannot run until the Project is restored.

### Working in a Project and Project Context Loading

Every Session of an Identity Agent works either in the Agent's Workspace or in one registered Project, fixed when the Session is created. In a Project, relative file and shell work, `@`-mentions, Project Skills, and Project context use that repository, while the Agent keeps its bare address, identity-owned Session storage, Workspace, Memory, private Skills, and permissions. A new Session works in the Agent's default Project (`agent update --project`) unless it is started with `vbot chat --project <project-id>` or `--workspace`; changing the default Project never moves an existing Session. A Sub-Agent of an Identity Agent works where its Parent works. When the Project is removed, its Sessions stay readable but cannot run until the Project is restored.

Commands at Session start let the Agent begin with data it would otherwise fetch first, such as `git status`. Set them for a Project (WebUI Project settings, or `vbot project set PROJECT_ID --context-commands "git status --short" ...`) or for an Identity Agent's Sessions in its Workspace (WebUI Agent settings, or `vbot agent update AGENT_ID --context-commands ...`). When a new Session starts, including Sessions of Sub-Agents, scheduled jobs and Channels, vBot runs them in the Project folder or the Workspace in the Agents' shell, at most 10 commands of 60 seconds each, and gives the Agent their exit codes and output with its first message; a Session in a Project runs only the Project's commands. Forks and later messages run nothing, and a restricted Agent's commands follow its Permission Rules. A new Project starts with `git --no-optional-locks status --short --branch`, which also tells the Agent when the folder is no Git repository; remove the line in the Project settings, or clear the list with `vbot project set PROJECT_ID --context-commands`, to turn it off.

An Identity Agent with the `project` Tool sees the registered Projects in its System Prompt. Before working in a registered Project that is not its current working Project, it calls `project` with the Project id and waits for the result. The Tool returns the Project's current auto-load files, absolute cwd, and Project Skills; it does not change the Session's Project, the Agent's cwd, default Project, Workspace, Session owner, Skill scope, permissions, or identity. Subsequent file work therefore uses absolute paths. Every `bash` call that should run in the Project sets `workdir` to the returned cwd again: `bash` starts a new one-shot shell for each call, so `cd` and other shell-state changes never persist into the next call.

### Sessions

Sessions are explicit, append-only conversation histories. Server and product paths create the Session before sending Chat content. Runs, Tool events, Usage, Compaction checkpoints, titles, Channel metadata, and Continuation state persist with the Session.

```bash
vbot session list coder
vbot session create coder --make-current
vbot session fork coder SESSION_ID --target-agent reviewer
vbot session rename coder SESSION_ID --title "Research notes"
vbot session policy set coder SESSION_ID --policy '{"enabled":false,"trigger":{"type":"context_ratio","threshold":0.8},"strategy":{"type":"summary_tail","tail_tokens":15000,"summary_model":null}}'
vbot session delete coder SESSION_ID --yes
```

`session list` returns at most 40 Sessions by default. Use `--limit`, run the `Next:` command it prints for the following page, or explicitly request `--all` to collect every page.

Deleting an Agent, Project, or Session moves its vBot-owned state into the archive rather than erasing it (see [Archive](#archive)). Project source repositories are never archived or removed.

### Archive

Deleting an Identity Agent, a Project, or a Session creates one archive entry (`arc_` plus 12 characters), and the command prints its id together with the command that restores it. An Agent's entry holds its configuration, Workspace, Memory, private Skills, and Sessions; a Workspace outside the Agent's own directory (`<data-dir>/agents/<agent-id>/`) stays where it is, and the delete names its absolute path. A Project's entry holds its vBot metadata and Sessions; the repository is never touched. Each entry is restored or deleted as a whole, and deleting the same id again creates another entry.

```bash
vbot archive list --kind agent
vbot archive show arc_7k2m9q4xw1ab
vbot archive restore arc_7k2m9q4xw1ab
vbot archive restore arc_7k2m9q4xw1ab --as coder-2
vbot archive purge arc_7k2m9q4xw1ab --yes
vbot archive purge --all --kind session --agent coder --yes
```

- `list` shows entries newest first, 50 per page (`--limit`, `--cursor`, or `--all` for every page), filtered by `--kind` (`agent`, `project`, `session`, `owner_group`, `files`), `--agent`, and `--project`. Each row says whether the entry can be restored and, if not, why.
- `show` lists the entry's Sessions and files and whether a restore is possible, naming every reason that blocks it. Run it before restoring.
- `restore` brings back the Agent, Project, or Session with its Sessions, the Agent's place in the Agent list, the delegation lists that named it, and the default Project of the Identity Agents that used the Project; Sessions working in a restored Project can run again, also under a new id. When the id is in use again, it refuses and names the conflict; `--as <new-id>` restores under another id, and the restored Sessions then lose their Channel links. Entries of kind `owner_group` (an Extension's Sessions) and `files` (archive folders of older vBot versions) can only be deleted.
- `purge` deletes entries permanently and cannot be undone, so it requires `--yes`. Name the entries, or select them with `--all` and the `list` filters. `--all` never deletes entries that may contain folders you own (kind `files`, and rows marked `user_folders=yes`): it lists them as kept, and only naming them deletes them. Usage already recorded stays in Statistics, and uploaded attachments are not deleted. A purge that does not finish reports the entry as pending and exits non-zero; vBot continues it automatically, and running the same command again continues it at once. An entry that another command restored or deleted in the meantime is reported as gone; one that a restore still holds is reported as skipped, and `vbot archive show <entry-id>` shows its state.
- `vbot agent delete <agent-id> --permanent --yes`, `vbot project remove <project-id> --permanent --yes`, and `vbot session delete <agent> <session-id> --yes --permanent` delete immediately instead of archiving. Deleting an Agent this way leaves the entries of Sessions deleted earlier; remove them with `vbot archive purge --all --kind session --agent <agent-id> --yes`.
- vBot deletes an entry permanently once its retention period has ended: 30 days after it was archived by default, checked every hour. `list` names the period and each entry's `purge_at`, the date its period ends. Change it with `vbot config set archive.retention_days 14` (1 to 3650 days); `vbot config set archive.retention_days null` keeps entries until you purge them. A changed period applies to existing entries at once, so a shorter one deletes older entries at the next check. Entries of kind `files`, entries that may contain folders you own, and entries vBot found in its archive folder without their record (`origin=recovered`, for example after restoring a data snapshot) are never deleted automatically. Entries that an older vBot version archived count their period from the first start after updating. When vBot cannot read the period because `settings.json` is damaged, it deletes no entry automatically until the setting reads again; `list` says so, and `vbot doctor settings` shows the problem.
- The entries' files live under `<data-dir>/archive/`; use these commands instead of moving or deleting files there by hand.

## Chat, Queue, and Built-in Commands

One Session admits one active Run. New messages sent while it is busy enter its Queue and execute in order; WebUI and Channels surface queued state. Cancellation is cooperative and stops further model or Tool progression as quickly as possible, but already-running external work may not be hard-abortable.

The composer accepts plain text, uploaded attachments, `@` file mentions, Built-in Commands, and Skill triggers. Image, audio, video, and text/file inputs are normalized into content blocks; Provider adapters receive only formats they support. Audio transcription is cached on the attachment after its first successful transcription.

Built-in Commands are owned by Chat and work in the WebUI; Channels support the same set except `/agent`:

| Command | Behavior |
|---|---|
| `/help` | Show the current command catalog |
| `/status` | Show Agent, Session, Model, Run, and Queue status |
| `/stop` | Cancel the active Run for this Session |
| `/new` | Create and move to a new Session after the current Run finishes |
| `/rename [title]` | Set the Session title; no title clears it |
| `/model` | Show the effective Model; `/model <value>` sets it and `/model reset` clears the override |
| `/agent` | Show available personal and Project Team Agents |
| `/agent <address> [task]` | Move the whole Session to another Agent and optionally start a takeover task; unavailable through Channels |
| `/handoff [agent:<address>] [instruction]` | Create a fresh target Session with an Agent-generated handoff and start the receiving Agent |
| `/learn [request]` | Ask an Identity Agent to author or improve a Skill |
| `/reflect [focus]` | Fork and review an Identity Agent Session through the Reflection policy |
| `/compact [instruction]` | Manually create a Compaction checkpoint while no Run is active |

`/agent` changes Session ownership; `/handoff` creates a new target Session and leaves the source intact. Through a Channel, `/handoff` relays the target's first response once but does not change the Channel's configured Agent or future routing.

### Full-screen terminal conversations

Run `vbot tui` in a terminal to choose an Agent and resume or start a Session. It connects to the same server as the WebUI: a remote server by its `https://` address with `--url` (after `vbot devices pair` when it requires login, [Server access](#server-access)), or through SSH or a local SSH tunnel (a tunnel only to a `local` or `lan` server). Closing the TUI leaves server Runs running.

```bash
vbot tui
vbot tui --agent coder
vbot tui --agent coder@my-project
vbot tui --agent coder --session SESSION_ID
vbot tui --agent coder --project my-project
vbot tui --host 127.0.0.1 --port 22332
vbot tui --url https://vbot.example.com
```

Enter inserts a new line; Ctrl+S or Alt+Enter sends. F1 shows keyboard help. F2 opens Sessions, F3 starts a new conversation, F4 selects Model/effort and shows Usage, F5 opens activity, F6 manages the Queue and Steer, F7 answers Extension requests, F8 handles files, and F9 opens Commands and Skills. Ctrl+Space completes `/commands`, Skills and `@` server files. Ctrl+X stops the current Run; F10 stops its related work through Stop all; Ctrl+Q detaches. F11 offers Session actions, Tool controls and saved drafts; F12 jumps to the latest output when you are reading older messages.

The timeline renders Markdown and code, with expandable Reasoning and Tool details. Ctrl+O loads older history; Ctrl+B returns to the Parent or previous conversation. Ctrl+G copies or exports the loaded conversation. Upload paths and download destinations are on the terminal machine; `@` file references are on the server. Images, audio, video and Extension pages are links rather than embedded browser content. A request with an unknown send outcome stays marked uncertain until you reconnect and inspect the Session; the client never automatically sends it again.

Unsent drafts and pending attachments survive detach and restart on the terminal computer, stored per server in `~/.vbot-tui-state/`. F11 restores a draft without sending it. Two terminals editing the same saved draft retain both versions. File dialogs let you browse or type a local path; downloads never overwrite an existing file. Edit server file mentions directly in the composer. If an Extension rejects a form, its values remain available for correction.

### Chat from the command line

`vbot chat` sends one message to an Agent Session, waits for the Run, and prints the answer, which makes it usable from scripts and other tools:

```bash
vbot chat "Summarize the open issues"                     # new Session of the main Agent
vbot chat --agent coder@my-project -c "Continue with the next step"
git diff | vbot chat --agent reviewer --model openrouter/anthropic/claude-sonnet-4
vbot chat --session SESSION_ID --json "What changed?"
vbot chat --agent coder --project my-project "Run the tests"  # new Session in a Project
```

Without `-c` or `--session`, every call starts a new Session; `-c` continues the Agent's most recently active conversation (automated Cron, Channel, Sub-Agent, and reflection Sessions are skipped), and `--session` continues a specific one. A new Session works in the Agent's default Project; `--project <project-id>` starts it in another Project and `--workspace` in the Agent's Workspace. The message comes from the argument or, when it is `-` or omitted, from piped stdin. `--model`, `--thinking-effort`, and `--temperature` are saved on the Session and also apply to its later messages; omitting them keeps what the Session already has.

The answer goes to stdout. Tool calls, Tool errors, and retries appear on stderr in a terminal (or with `--output human`), followed by the Session id, Model, and a command to continue. `--json` prints one object with the answer, Tool calls, Usage, and ids instead. A Built-in Command such as `/status` prints its reply. The exit code is 0 for a completed Run or handled command and 1 for a failed or cancelled Run; when the Session is busy, the message is queued, the command exits 1 and names the queue item without waiting. Ctrl-C cancels the Run and exits 130.

## Skills, Tools, and Sub-Agents

Skills are instruction packages loaded from bundled resources, `<data-dir>/skills`, the active Project's Skill Sources, trusted Extensions, and an Identity Agent's private `skills/` directory. The effective catalog also respects Agent and Project allowlists and Skill requirements.

An Agent can load a Skill through the `skill` Tool. Users can explicitly trigger a load with `/skill-name` or `$skill-name`; the original user message remains part of the request. The catalog text is pinned when a Session first builds its prompt, while activation remains live: a newly authored and allowed Skill can be triggered immediately and is announced to an existing Session without rewriting its pinned prompt prefix.

The WebUI and RPC Skill manager can author global and private Identity Agent Skills. Project Skills remain repository-owned and are edited through normal file Tools. Bundled Skills are read-only. `/learn` is an Identity-Agent authoring workflow over the same validated Skill core.

In **Configure -> Skills**, use the **+** beside search to install a Skill. Paste a link or upload a `.skill`, ZIP or TAR archive from your computer, choose global or private Agent storage, and check the source. If it contains several Skills, select one. The preview shows the destination and any existing copy; replacing a different package requires an explicit choice. After installation the manager opens the saved Skill. The same dialog links to folder setup and custom Skill creation.

The CLI also installs a complete Skill from a directory, `.skill`/ZIP/TAR archive, archive-download URL, or public GitHub repository/Skill directory:

```bash
vbot skill install ./research.skill --scope agent:coder
vbot skill install https://github.com/owner/repo/tree/main/skills/research --scope global
vbot skill install https://github.com/owner/repo --scope global --dry-run
```

Use `--path <directory>` when a source contains multiple Skills. `--dry-run` validates without writing; an identical package is unchanged, while replacing different files requires `--replace --yes` and removes local modifications too. Public skills.sh and ClawHub Skill links are also supported; other catalogs can supply their repository or archive-download link. Installation preserves supporting files and binary assets without running scripts or installing dependencies. Local paths refer to the server machine; a remote CLI does not upload client files.

An Identity Agent can follow the bundled `vbot-docs` Skill and install for itself with `--scope own`, including while a Project is loaded. Outside a Run, use `agent:<id>` or `global` explicitly. Private Skills become available to their owner subject to requirements and disable policy; global installs retain the Agent's existing Skill selection. Installation does not grant Tools or credentials. Use `skill inventory` to inspect saved packages and the Agent's `skill` Tool to verify its effective catalog. Uninstall with `skill delete <name> --scope global|agent:<id> --yes`.

Tools are runtime capabilities exposed according to Agent, Project, Extension, and Settings policy. Inspect the public catalog and one Agent's complete System Prompt with:

```bash
vbot tool list
vbot skill list
vbot skill read SKILL_NAME --scope global
vbot skill create librarian --scope agent:coder --file SKILL.md
vbot prompt preview coder
```

The CLI Skill manager authors only global and private Identity Agent scopes; `inventory` exposes package ids and editable scopes; `inspect <inventory-id>` reads the complete original Skill even for read-only sources. It supports `install`, `read`, `create`, `update`, `delete`, `file write`, and `file remove`. Project Skills stay repository-owned and bundled Skills stay read-only. The Prompt manager likewise supports default and `agent:<id>` scopes, custom user blocks, and complete layout order/enabled-state updates. Use `prompt show <block-id>` to read the full content before an update.

The `subagent` Tool delegates a bounded task to an authorized Identity or Project Agent in a child Session. Identity Agents may be allowed to target all Agents or an explicit list; Project Agents remain confined to their own Team. Every Sub-Agent works in the background: the call returns its id at once, and each answer the Sub-Agent gives reaches the parent automatically, waking it when idle, together with a line naming what the Sub-Agent still has running. The parent can message a Sub-Agent (`send`), list its whole tree, and stop any Sub-Agent below it with everything that Sub-Agent started. Sub-Agents can ask their parent questions with `message_parent`, and shell commands, Terminals and nested Sub-Agents work the same at every depth. When you write in a Sub-Agent's Session yourself, you take it over: its answers then go to you and no longer to the parent. Stop ends only the current Run; `/stop all` (and Stop all in the WebUI) also stops the Session's background commands, Terminals and Sub-Agents.

Default limits are four levels of nesting and eight Sub-Agents working at the same time in one Agent tree (a top-level Session plus all Sub-Agents below it). Both are configurable in Settings. Each Sub-Agent Session gets one supplemental activity file under `<data-dir>/artifacts/temp/subagents/` that records all its turns, retained for 24 hours after the latest one ends; canonical child history remains in its Session.

## Settings and specialized Models

Settings centralizes validated runtime policy. Major areas include:

- Agent defaults for Model, fallback Model, temperature, thinking effort, Tools, and Skills
- Sub-Agent authorization, nesting depth, and the number of Sub-Agents working at the same time
- Reflection cadence and review behavior for Identity Agents
- Compaction strategy, trigger, Model selection, and Agent, Project, or Session overrides
- Conversation search (Recall): keyword search, optional search by meaning with its embedding Model, and the search index status with a rebuild
- Web Search Provider configuration
- Specialized Models for speech (Voice page), images, video, music and decisions (Tools page)
- Provider Connections, Accounts, credentials, enabled state, and local reachability
- Channels and denied-chat discovery
- trusted Extensions and Extension settings
- Session title generation, local-model context, Appearance, Logs, and Debug behavior
- Desktop notifications shown by the Windows tray
- Desktop-local Voice settings when running inside Desktop

For an Agent's primary chat Model, list the currently selectable catalog through the running server:

```bash
vbot model list --task chat
vbot model list --provider openai --task chat --capability tools
vbot model list --task chat --query claude --query opus   # every word in id, name or family
```

The result contains only Models with at least one usable Connection (including enabled keyless Connections) and prints the exact id accepted by `agent create --model` or `agent update --model`. It also includes the effective context window, capabilities/task types, and `reachable: no` for a local Model whose service is currently down. Additional repeatable filters are `--capability`, `--task`, `--input-modality`, and `--output-modality`; `--min-context-window` applies a token floor.

### Google Antigravity subscription

Install Google's Antigravity CLI on the **vBot server** and launch `agy` as the user who runs that server. Sign in to your personal Google AI Pro or Ultra account. In vBot, open **Settings → Providers → Add Provider → Google Antigravity** and connect the CLI login. Choose a Model from that Provider for your Agent. The CLI checks the five-hour and weekly allowances and lists the Models available to your account. Text chat and vBot Tools use the subscription. Google AI Studio remains the separate API-key Provider.

Google describes using its CLI as the backend of a third-party Agent as unsupported under personal plans and warns that third-party use can lead to account suspension. [Google's Antigravity FAQ](https://antigravity.google/docs/faq)

### Recall

Recall searches canonical persisted Session history; it does not replace curated `MEMORY.md`. Available first-party backends are `canonical_scan` for direct chronological scanning, `sqlite_fts` for indexed substring and relevance search, `vector` for semantic Passage search through the configured `text_embedding` Model, and `hybrid` for fused lexical and semantic results. SQLite indexes under `<data-dir>/recall/` are derived and disposable; incompatible schemas or embedding spaces rebuild rather than migrate.

The `session_search` Tool exposes Recall to Agents. For complete transcripts, including the current Session's Messages before a Compaction checkpoint, the bundled `vbot-docs` Skill teaches read-only queries through the shell Tool.

### Compaction and Continuation

Compaction appends a checkpoint Projection and never rewrites or deletes older Session records. Automatic Compaction runs only at safe completed Model boundaries according to the effective Policy; `/compact` invokes the selected strategy manually when no Run is active. Older detail remains discoverable through Recall and the `vbot-docs` Skill's Session search.

When a visible Run is interrupted, Continuation retains a private checkpoint regardless of whether the cause was user Cancel, a Provider or network failure, a timeout, a process restart, or an internal failure. The WebUI exposes no checkpoint banner or recovery controls. The next normal user message receives the checkpoint automatically alongside the new instruction, and a complete response resolves it.

### Specialized Models

Specialized bindings keep non-chat tasks independent from the Agent's primary Model:

| Task type | Used for |
|---|---|
| `speech_to_text` | WebUI microphone input, audio attachments, and Desktop Voice transcription |
| `text_to_speech` | Agent speech output and the speech synthesis endpoint |
| `text_embedding` | semantic and hybrid Recall |
| `decision` | the `classify` Tool: typed answers about texts |
| `image_generation` | image generation and editing, including source-image workflows when the target supports them |

The `generate_image` Tool writes generated files into a caller-owned `image-gen/` directory. Identity Agents always use `<Workspace>/image-gen/`, also in Sessions that work in a Project; Project Config Agents use `<Project cwd>/image-gen/`. The Tool returns the absolute local paths, and Chat exposes referenced files through signed `/api/files/` URLs without keeping a second image copy in the data directory.

In Settings, the speech and Live voice Models are on the Voice page, the embedding Model under Memory → Conversation search, the image, video and music Models under Tools → Images, video & music, and the Decision model under Tools → Decision Model. Use Settings for target-specific option forms, or inspect and bind them through the CLI:

```bash
vbot task-model list
vbot task-model target list text_embedding
vbot task-model option list image_generation openai/gpt-image-1::api-key
vbot task-model set text_embedding openai/text-embedding-3-small::api-key
vbot task-model clear text_embedding
```

### Decision Model and the classify Tool

Configure an OpenRouter key, then select a **Decision model** in **Settings → Tools → Decision Model**. Available targets include `typesafe/jev-1.13` and `~typesafe/jev-latest`; the latter follows upstream updates. If targets are missing, refresh the Model DB after configuring the key.

Agents then get the `classify` Tool. It sends each text separately to the Decision Model and returns, per question, a probability of yes, one of the given options, or a level on a scale, for example to filter or label many files or messages. One call judges at most 100 texts of at most about 32,000 tokens each. The Decision Model answers fast and cheaply but gives no reasons and cannot count, calculate or compare dates; confidence measures how concentrated its answer is, not whether it is correct. Each request is recorded as `decision` Usage in Statistics. The Agent's Chat Model remains independent.

### Local speech recognition

Qwen3 ASR (1.7B or 0.6B), Parakeet TDT v3 and Nemotron 3.5 ASR run on the **vBot server machine**, including when
the WebUI or Desktop connects from another computer. They require no paid API
or subscription. Each is its own Model: in **Settings → Voice → Speech models → Speech to text**,
select one and choose **Install**; Settings shows its download size and license first.
Setup runs on the server and continues if you leave Settings; while it runs, the top of
**Settings → General** shows it with its progress, and **Cancel** there stops it and keeps
what it already downloaded. The first local
speech-to-text install prepares the speech engine (environment checks, downloads,
installation and verification); every install then downloads the selected Model
with a progress bar, so another local speech-to-text Model reuses the engine and
downloads only its Model. A failed setup offers **Try again**. Once installed, the
Model works offline. In a development checkout, setup installs the engine into the
server's own Python and then asks you to **Restart server**. This interrupts active
Runs, reconnects the interface and checks local speech availability again.

In a packaged installation, setup creates a managed speech environment
under the data directory and runs speech in a child worker; it never installs
packages into the released runtime. In a development checkout, setup uses the
server's Python environment and the shipped `local-speech` extra, without replacing
the running Desktop launchers. It preserves a working compatible
PyTorch installation, prepares CUDA 12.8 support for a detected NVIDIA GPU, or
uses the platform's CPU/Apple build. NVIDIA drivers must support that build;
verification runs a small GPU calculation before offering restart. Other GPU
platforms can use a manually installed [PyTorch build](https://pytorch.org/get-started/locally/).
`Automatic` uses CUDA/ROCm when available, then Apple MPS,
otherwise CPU. CPU execution is available but can be slow. This extra is separate
from the normal server and Desktop dependencies; it does not install NeMo, vLLM,
or the separate `qwen-asr` package. All three engines use native Transformers adapters.

In **Settings → Voice → Speech models → Speech to text**, select
**Qwen3 ASR 1.7B (local)**, **Qwen3 ASR 0.6B (local)**, **Parakeet TDT v3 (local)**, or
**Nemotron 3.5 ASR Streaming 0.6B (local)**; searching for **local** finds
all four. Expand its options to choose device, precision,
or a model directory. Qwen and Nemotron offer a **Language** list: **Automatic**
detects the language in each recording, or choose one of the languages the model
supports (Nemotron also tells regional variants such as English (US) and English (UK)
apart). Qwen also accepts a vocabulary/context hint. Parakeet detects language
automatically. Nemotron's native streaming engine reuses
computed context inside each recording segment; the current Chat still returns
the complete transcript after submission. You can also select a Model through the CLI
(the earlier ids `local/qwen3-asr` and `local/qwen3-tts` no longer exist; choose a Model again if one was saved):

```bash
vbot task-model set speech_to_text local/qwen3-asr-1.7b
vbot task-model set speech_to_text local/qwen3-asr-0.6b
vbot task-model set speech_to_text local/parakeet
vbot task-model set speech_to_text local/nemotron3.5-asr
```

Installing downloads exactly the files of one fixed revision of the public checkpoint
from Hugging Face into the data directory and checks each file's SHA-256 before it is
used. Setup first checks that the disk has room for the missing files plus 512 MB.
Files that the server's Hugging Face cache already holds (`HF_HUB_CACHE` or `HF_HOME`,
otherwise `~/.cache/huggingface/hub`) are reused instead of downloaded again, and
**Try again** resumes an interrupted download. Transcription never downloads: Chat shows
model-loading and transcription phases
with elapsed time above the composer and in the microphone tooltip, and an already
loaded model skips loading. Failures release
the microphone for another attempt. You can also point
**Model directory** at a complete Transformers checkpoint of the same engine on the server;
it is then loaded instead of the installed Model.
Recordings are processed by the local engine, without a transcription API call.

After every server start, loading a local model takes a while. Chat, terminal
dictation and Desktop Voice therefore ask the server to start loading as soon as a
recording begins, so part of the load happens while you speak. To have the model ready before the first
recording, turn on **Load at server start** in the engine's options: the server
then loads it in the background after starting and whenever you change this
binding. The model stays in memory until you unload it or stop the server.

Local speech models stay loaded independently, so STT and TTS can remain ready
at the same time. In **Settings → Voice → Speech models → Local speech memory**, each loaded
model has its own **Unload from memory** button. Unloading STT leaves TTS loaded,
even while TTS is generating audio. A model's button is disabled while that model
is busy. The installed files stay on disk; the next use loads that model again.
Changing a model's device, precision or directory replaces only its own cached model.
Shutdown releases all models; inference failure releases only the failed engine.
Loading and inference run outside the server Event Loop; cancelling a request
waits for already-started inference to finish safely.

All existing microphone and audio-attachment paths use the selected engine.
Long recordings are split into segments of at most 30 seconds, preferring a quiet
boundary and preserving every audio sample. Returned segment times describe these
audio chunks, not word-level alignment. The current interface returns a completed
transcript; it does not stream partial text or distinguish speakers. Desktop Voice
allows up to ten minutes for a transcription response, including loading the model.

The pretrained Models are [Qwen3-ASR-1.7B-hf](https://huggingface.co/Qwen/Qwen3-ASR-1.7B-hf),
[Qwen3-ASR-0.6B-hf](https://huggingface.co/Qwen/Qwen3-ASR-0.6B-hf) (Apache-2.0),
[NVIDIA Parakeet TDT 0.6B v3](https://huggingface.co/nvidia/parakeet-tdt-0.6b-v3)
(CC-BY-4.0), and [NVIDIA Nemotron 3.5 ASR Streaming 0.6B](https://huggingface.co/nvidia/nemotron-3.5-asr-streaming-0.6b)
(OpenMDW-1.1). See [Third-party notices](THIRD_PARTY_NOTICES.md#local-speech-models).

### Local speech synthesis

In **Settings → Voice → Speech models → Text to speech**, search
for **local** and select **Qwen3-TTS 1.7B (local)**, **Qwen3-TTS 0.6B (local)** or
**Chatterbox Multilingual V3 (local)**. Choose **Install** for that voice model; Settings
shows its download size and license first. Setup continues across navigation, reports its
phase and the model download's progress, and offers retry on failure. Both Qwen3-TTS
sizes share one engine installation and download only their own model. TTS becomes
available as soon as setup finishes; its isolated environment does not require a
server restart.

Both engines support German and require no paid API. Qwen3-TTS offers nine preset
voices and automatic or explicit language selection on both CustomVoice sizes, and
style instructions on the 1.7B model.
Chatterbox explicitly uses the multilingual **V3** checkpoint, with language,
expressiveness and guidance controls and the upstream built-in voice/watermark.
No voice-cloning input is exposed by this integration.

After saving the binding and options, enter a short text and choose **Generate
voice preview**. The first request loads the installed model, then generates audio;
turn on **Load at server start** in the engine's options to have it loaded in the
background after the server starts and whenever you change this binding, as for speech
recognition. Live status and elapsed time remain
visible; the audio player appears when the complete WAV is ready. The Agent's
existing `generate_speech` Tool uses the same saved engine and voice options.
Local requests accept up to 5,000 characters and split longer passages within
that limit at sentence/word boundaries. STT and TTS models stay loaded independently;
each model has its own **Unload from memory** button.

The optional `local-tts` extra installs uv, which prepares separate managed SDK
environments under `<data-dir>/speech-engines/`: Qwen3-TTS on the server's Python,
Chatterbox on Python 3.13, the newest its dependencies support. After an update that
changes an environment's Python, its target reads as not installed until you install it
again. Fixed recipes
in `pyproject.toml` install Qwen's SDK and a pinned official Chatterbox revision
containing V3 (the PyPI 0.1.7 source predates V3). The server's STT packages are
not downgraded. Setup installs matching Torch/torchaudio builds and verifies
imports and, on NVIDIA systems, GPU execution. Chatterbox currently uses upstream's
Torch 2.6 / CUDA 12.6 combination; GPUs requiring a newer Torch are not supported
by that recipe. Qwen uses Torch 2.11 / CUDA 12.8. CPU and Apple builds are selected
on systems without a detected NVIDIA GPU. Installation requires internet access and
downloads, verifies and reuses cached model files as described for speech recognition;
an installed voice runs offline, and there is no offline switch to configure.

Model sources and licenses: [Qwen3-TTS](https://github.com/QwenLM/Qwen3-TTS)
(Apache-2.0) and [Chatterbox](https://github.com/resemble-ai/chatterbox) (MIT).
See [Third-party notices](THIRD_PARTY_NOTICES.md#local-speech-models).

### Web page reading and extraction services

The `web_fetch` Tool reads public pages, extracts document text, and shows image URLs to vision-capable Models. Long pages arrive as compact excerpts with saved references for further reading and searching. Those follow-up reads do not fetch again. References stay available to the same Agent in the same Session for 72 hours.

Under **Settings → Tools → Web page reading**, choose **Direct (no service)** or opt into Firecrawl, Tavily, Exa, or Parallel. Direct fetching is the default and requires no extraction-service account. Optional services can improve results on blocked or JavaScript-heavy pages:

- **Only when direct fetch fails** sends failed, blocked or unreadable pages to the selected service.
- **Prefer this service** uses it first for page URLs and tries direct fetching if it fails.
- Enter the service's API key in the same panel; it is saved under the displayed variable name in the data directory's Secret Store, and a variable of that name in the server's process environment takes precedence. Firecrawl, Tavily and Exa share their keys with Web Search; Parallel uses `PARALLEL_API_KEY`. Key presence alone does not enable a service.

The selected service receives requested URLs and may charge for extraction. Free allowances, paid rates and rendering capabilities vary; check [Firecrawl pricing](https://www.firecrawl.dev/pricing), [Tavily credits](https://docs.tavily.com/documentation/api-credits), [Exa pricing](https://exa.ai/pricing), or [Parallel pricing](https://docs.parallel.ai/getting-started/pricing). Saved-page reading and searching do not incur another service request. Pages requiring authentication or interactive challenges can still fail; the Tool reports missing content instead of claiming a complete extraction.

### Desktop notifications

An installed vBot on Windows shows Windows notifications from its `vBot.exe` tray. Under **Settings → General → Desktop notifications**, switch each kind on or off; all are on by default:

- **Run completed** and **Run failed**: an Agent Run in a Session finished or ended with an error.
- **Automation failed**: a Cron job failed.
- **Update result**: an application update finished or failed.
- **New version available**: the update channel publishes a newer vBot version, once per version and at most once a day.
- **Server stopped**: the local vBot server stopped unexpectedly.

Background work such as Subagents, Channel replies and reflections never notifies, and a cancelled Run does not either. A notification about a Session is skipped while you are already looking at that Session. Clicking it opens the Session (in Desktop, or in the browser for the Server package); it disappears when you open that Session or switch to the vBot Desktop window. The switches are the Settings paths `notifications.run_completed`, `notifications.run_failed`, `notifications.automation_failed`, `notifications.update_result`, `notifications.update_available`, and `notifications.server_stopped`, so `vbot config` reads and changes them too.

## Channels

Telegram, Discord, Slack, Mattermost, WhatsApp and email Channels route inbound messages to one Identity Agent. Project Agents cannot own a Channel. A Channel names its bot credentials by variable name rather than holding the token itself, for example `TELEGRAM_BOT_TOKEN_MAIN` or `DISCORD_BOT_TOKEN_MAIN`. The value comes from the server's process environment or from the data directory's Secret Store, where `vbot channel token set <channel-id> --stdin` saves it.

Create and manage a Channel in Settings or with positional Channel ids in the CLI:

```bash
vbot channel add tg-main --platform telegram --agent assistant --token-env TELEGRAM_BOT_TOKEN_MAIN
vbot channel list
vbot channel status tg-main
vbot channel update tg-main --allow 123456789
vbot channel identity tg-main
vbot channel identity tg-main --user 123456789
vbot channel access tg-main --group -100123456789
vbot channel admin grant tg-main --group -100123456789 --user 987654321
vbot channel admin revoke tg-main --group -100123456789 --user 987654321
vbot channel enable tg-main
vbot channel disable tg-main
vbot channel remove tg-main
```

An empty allowlist means deny all inbound chats, not allow everyone. To discover an id safely, message the bot once and inspect `vbot channel status <channel-id>` or Settings; each active adapter keeps the 20 most recent denied chats in memory. Allowing a chat restarts the adapter and clears that observation list. The allowlist gates inbound traffic only; an Agent using `channel_send` with an explicit platform target can send to any supported chat the bot account can reach. WhatsApp is limited to your self chat in both directions.

Group behavior is configurable from the CLI with `--response-mode mention|all`, list-replacing `--mention-pattern`, and `--observe-unaddressed true|false`. `channel identity` shows or sets the Channel account's own identity from previously seen participants; that identity is an admin in every group and cannot be demoted. `channel access` lists durable participants and roles for one group. `admin grant` and `admin revoke` are additive, idempotent one-user actions scoped to that group. Channel create/update/enable/disable output returns the saved config; `channel status` separately reports listener health and denied chats.

Direct-message Session routing is controlled by `dm_scope`: `per_conversation` is the default, while `main`, `per_peer`, and `per_account_channel_peer` provide broader or narrower sharing. Group chats always use a shared conversation anchor. `/new` advances that anchor to a new active Session without changing the Agent-wide current Session used by WebUI and Desktop.

Groups respond only when addressed by default: a platform mention, a reply to the bot, or a configured case-insensitive mention regex. Telegram also derives an exact case-insensitive wake name from the bot's current visible Telegram name at Channel start; BotFather privacy mode must be disabled for Telegram to deliver these plain name-addressed group messages. `response_mode: all` responds to every allowed group message. With `observe_unaddressed` enabled, otherwise-unaddressed group messages become untrusted background notes without starting a Run. Every seen group participant is assigned `admin` or `member` by stable platform user id: admins retain the Agent's full Tool access. In Settings > Integrations > Channels > Group access, choose the default member Tools and optionally replace that selection for each group: None, Selected Tools, or All Agent Tools. The initial default is `web_search` and `web_fetch`; every selection remains limited by the Agent's own Tool access. Removing a group override restores the Channel default. Group Built-in Commands and reserved `run:` button taps require `admin`. Role enforcement is dispatch-only, so grants/revokes do not alter the System Prompt or provider Tool definitions; added access affects new messages only, while removed access applies before the next Tool call, including queued and active Runs. DMs remain governed by the chat allowlist.

All adapters ingest supported media and files and preserve Channel Session context. Telegram and Discord show activity and reply to the triggering group message. Telegram supports outbound inline buttons and deterministic Extension tap handlers; the other adapters reject button payloads. A reserved `run:<payload>` Telegram button wakes the Agent with the complete keyboard state instead of invoking an Extension handler.

Channels serialize work per conversation and share bounded Queue capacity. Only the final Assistant text from a completed Run is relayed; reasoning, Tool events, and intermediate output remain available in the vBot Session and server event streams.


### WhatsApp: use your existing account

This Channel links vBot as a device to your existing WhatsApp account using [Baileys](https://github.com/WhiskeySockets/Baileys). You keep your number and phone app; no second SIM is required. This is an unofficial connection, not a WhatsApp Business bot. Account restrictions and upstream protocol changes are possible.

1. Install Node.js **22 or newer** with npm on the machine running the vBot server. A packaged vBot installation also needs this optional prerequisite.
2. In **Settings > Channels**, create a WhatsApp Channel for your Agent. Keep the allowed chat ID `self`. It starts disabled until setup/pairing.
3. Select **Install WhatsApp support**. This downloads pinned dependencies into the Channel's data directory; wait until installation finishes.
4. Select **Connect WhatsApp**, then scan the QR from your phone's **Settings > Linked devices > Link a device**.
5. Open your WhatsApp self chat (message yourself) and send a new message. Only messages you write there can start Runs; other conversations and vBot's own replies are ignored.

The same server operations are available through the CLI. QR codes remain in Settings, never terminal output:

```bash
vbot channel add wa-main --platform whatsapp --agent assistant --allow self
vbot channel whatsapp setup wa-main
vbot channel whatsapp status wa-main
vbot channel whatsapp pair wa-main
```

Setup is asynchronous: inspect status until `installed: True`, then pair. No token flag is accepted. `self` is also the only supported `channel_send` target. An empty allowlist disables inbound messages. The connection restores saved pairing after server restarts. After logging out the linked device, use **Link again with a new QR code** or `vbot channel whatsapp pair wa-main --reset`. Re-pairing keeps the old auth files in a `revoked_*` directory; remove old linked devices in WhatsApp itself. Protect `<data-dir>/channels/<id>/whatsapp/` like account credentials. If a vBot update requires newer bridge files, disable the Channel and run setup again.

### Slack

Slack uses its official [Socket Mode](https://docs.slack.dev/apis/events-api/using-socket-mode/) connection, so the vBot server needs no public webhook URL. Create a Slack app, enable Socket Mode and create an **app-level token** (`xapp-…`) with `connections:write`. Separately install the app to your workspace to obtain its **bot token** (`xoxb-…`). These are different credentials and require different variable names.

Configure these bot scopes before installation (reinstall the app after changing scopes):

- `chat:write`, `files:read`, `files:write`
- `channels:read`, `channels:history`, `groups:read`, `groups:history`
- `im:read`, `im:history`, `mpim:read`, `mpim:history`

Under Event Subscriptions, subscribe to bot events `message.channels`, `message.groups`, `message.im` and `message.mpim`. Enable the App Home Messages tab and allow users to send messages. Invite the bot to each channel it should use, including private channels. An `app_mention` subscription alone does not supply the message events this adapter consumes.

In vBot Settings choose Slack and enter the bot-token and app-token variable names. Both must already resolve in the server's process environment or the data directory's Secret Store. Alternatively, save the Channel disabled, then supply each secret separately through UTF-8 stdin:

```bash
vbot channel add slack-main --platform slack --agent assistant --token-env SLACK_BOT_TOKEN --app-token-env SLACK_APP_TOKEN --disabled
vbot channel token set slack-main --stdin
vbot channel token set slack-main --slot app --stdin
vbot channel enable slack-main
vbot channel status slack-main
```

The `token set` commands read their respective secret from stdin; never put a token in an argument. Send the bot a DM or a channel message, inspect denied chats in Settings/status, then allow the exact conversation ID (`D…`, `C…` or `G…`). IDs are strings, not numbers. In mention-only groups, mention the bot or use a configured wake regex, including inside threads. Messages in threads share the parent conversation's Session; responses return to the thread. File upload uses Slack's current external-upload flow.

### Mattermost

Use an existing Mattermost server and create a [bot account](https://developers.mattermost.com/integrate/reference/bot-accounts/) with a token. The server administrator may need to enable bot accounts. Add the bot to the relevant team/channels and grant the permissions needed to read messages, post and share files. vBot connects to the server's REST API and WebSocket; no public vBot webhook is required.

In Settings choose Mattermost, enter the server URL (for example `https://chat.example.org`, including a deployment subpath if present) and the bot-token variable name. Do not include `/api/v4` or credentials in the URL. Managed-token setup is also available:

```bash
vbot channel add mm-main --platform mattermost --agent assistant --server-url https://chat.example.org --token-stdin
vbot channel status mm-main
vbot channel update mm-main --allow <conversation-id>
```

Send a DM or channel message to discover its ID through denied chats. Allowlist entries are Mattermost conversation IDs, not team IDs or usernames. Group mention policy and thread behavior match the Slack behavior described above.

### Email

An email Channel reads one mail account over IMAP and answers over SMTP. vBot never marks, moves or deletes mails: it opens folders read-only and remembers per folder which mails it has handled. On its first connection it starts with the mails that arrive from then on; an older backlog is not read.

The Channel's token is the account password. Most providers require an **app password** for IMAP/SMTP access:

- **Gmail:** turn on 2-step verification, then create an app password under Google Account > Security > App passwords. Servers: `imap.gmail.com` and `smtp.gmail.com` (port 465).
- **GMX** and **web.de:** enable IMAP/POP3 access in the mailbox settings (and create an app password if 2-factor authentication is on). Servers: `imap.gmx.net` and `mail.gmx.net`, or `imap.web.de` and `smtp.web.de` (port 587 with STARTTLS).
- **Outlook.com and Microsoft 365** accept only OAuth2 sign-in for IMAP/SMTP, which vBot does not support.

In Settings choose Email and fill in the address and servers, or use the CLI with the password on stdin:

```bash
vbot channel add mail-main --platform email --agent assistant --email-address bot@example.com --imap-host imap.example.com --smtp-host smtp.example.com --trusted-authserv-id mx.example.com --allow user@example.com --token-stdin
vbot channel status mail-main
vbot channel update mail-main --email-folder INBOX Invoices
```

The SMTP security defaults to SSL on port 465 and STARTTLS on other ports (`--smtp-security`); the login name defaults to the address (`--email-username`). On `update`, the email flags change only the fields they name.

Replace the example account, hosts and trusted authentication-server names with your own. Configure `--trusted-authserv-id` with the `Authentication-Results` names confirmed by your receiving server's administrator; the server must strip forged headers claiming those names. Never copy trusted names from an untrusted mail. An empty list authenticates no sender, including for existing Channels; Settings exposes the same list as Trusted authentication servers.

Allowed chats are sender addresses. Each allowed sender gets its own conversation; a reply threads under the mail it answers. vBot answers a mail only when a trusted receiving server verified the sender's domain (DKIM or DMARC); this verifies the domain, not the individual mailbox's identity. An allowed sender whose mail was not verified appears among the denied chats. If your server does not verify senders, `--require-sender-authentication false` turns the check off. Mails from other senders, automatic replies, bounces and mailing-list mails start no conversation; Cron jobs with an email trigger can act on them. The Agent can write to any address with `channel_send`. A body starting with a Command such as `/new` executes that Command.

### Initial integration coverage

WhatsApp, Slack and Mattermost support incoming text/media, outgoing text/files, shared Commands, Session routing and Queue/access enforcement. Slack and Mattermost currently have no typing indicator, inline buttons, fetched quoted-message content, or offline history backfill. Mention-only group threads still need an explicit mention or wake regex. Recent received IDs are retained across restarts to suppress replays; this does not guarantee exactly-once processing after a crash.

Connection handshakes, routing, file APIs, access rejection, WhatsApp self-chat/echo filtering, credential handling and QR setup are covered by local automated tests. Pairing and end-to-end delivery with real accounts still need a live smoke test.

## Cron

Cron schedules one-time or recurring Agent Runs, a Run at every occurrence of a calendar event, a Run whenever a request reaches the job's webhook URL, or a Run whenever an email Channel receives a mail. Names default from the prompt when omitted and need not be unique; the generated job id is the identity. A job may target an Identity Agent or `agent@project`, use an existing Session, or create a fresh Session each time it fires.

The WebUI groups them under **Automations**, with visible **Schedules** and **Webhooks** entries. Both share the Agent, Project, Session, prompt, delivery and notification settings. For a new Identity-Agent Session, choose a fixed Project or the Agent's Workspace; a pinned Session and a Project Agent show their own Project. Advanced settings optionally select a Model and Reasoning level for this automation's Runs without changing the Agent or Session settings.

```bash
vbot cron create assistant --name "Morning priorities" --prompt "Summarize today's priorities" --cron "0 9 * * *"
vbot cron create reviewer@my-project --name "Repository review" --prompt "Review the repository status" --every 60 --repeat 3
vbot cron create assistant --name "Standup prep" --prompt "Prepare my notes for the standup" --event EVENT_ID --event-time "start - 30m"
vbot cron create assistant --name "Price watch" --prompt "Report the new price" --every 60 --watch https://example.com/product --deliver app
vbot cron create assistant --name "GitHub pushes" --prompt "Summarize the pushed commits" --webhook --deliver chat --channel CHANNEL_ID --chat CHAT_ID
vbot cron create assistant --name "Repository events" --prompt "Review the received changes" --webhook --working-project PROJECT_ID --model PROVIDER/MODEL --thinking-effort low --deliver app
vbot cron create assistant --name "Invoices" --prompt "File the invoice and tell me the amount" --email CHANNEL_ID --email-from @supplier.example --email-subject invoice --deliver app
vbot cron create assistant --name "Workspace check" --prompt "Review the workspace" --every 60 --no-project --deliver app
vbot cron secret JOB_ID --rotate
vbot cron list
vbot cron show JOB_ID
vbot cron update JOB_ID --status paused
vbot cron update JOB_ID --clear-model --clear-thinking-effort
vbot cron enable JOB_ID
vbot cron disable JOB_ID
vbot cron delete JOB_ID
```

Recurring expressions contain exactly five fields and have a minimum cadence of one minute. On create, omitting `--session` gives each fire a fresh Session. On update, omission preserves the target; `--clear-session` restores fresh Sessions. Use `show` to read the full prompt before replacing it. `--every` takes whole minutes; `--repeat` limits future fires. A fire missed while vBot was not running (server off, computer asleep) starts once when vBot runs again, for the most recent missed time; earlier missed times do not run separately, and the Run is told when it was due. `--event` binds the job to a calendar event: it runs once at every occurrence, at `--event-time` (`start` or `end`, optionally `+` or `-` up to 31 days such as `30m`, `2h` or `1d`; default `start`), follows moved occurrences and skips removed ones, and is deleted with its event. The Run receives the event's title, time, location and description with the prompt. An occurrence missed while vBot was not running still starts late while it is relevant: until the event starts when the job was due before it, until it ends when due during it, and otherwise until the next occurrence starts. Invalid individual job records are skipped and preserved for repair; a malformed Cron store disables scheduling and blocks mutations rather than overwriting the source.

Use `--working-project <project-id>` or `--no-project` to fix where new Sessions of an Identity Agent work; omitting both on create fixes its current Default Project once, and omitting them on update keeps the saved choice. A pinned Session or Project Agent keeps its own Project. `--model` and `--thinking-effort` apply only to this job's Runs; `--thinking-effort default` selects the Model's default. Updates preserve omitted override fields; `--clear-model` and `--clear-thinking-effort` restore the Session or Agent settings individually.

Each job says where a Run's final answer goes: to vBot with a notification, to a chat of the target Agent's Channel, or nowhere. Choose it in the WebUI under Automations, where a new job delivers to vBot, let an Agent choose it with the `cron` Tool, which delivers to the chat or vBot conversation the job was created from, or set it with `--deliver app|chat|none` (a chat with `--channel`, `--chat` and optionally `--thread`); jobs created with the CLI without `--deliver` deliver nowhere, and `vbot cron show` reports `delivery`. A Run with nothing worth reporting answers `[SILENT]`: nothing is delivered and no notification appears. Each Run sees the job's previous answer, so a job can report only what changed. When a job fails twice in a row, or a failure stops it, a job that delivers to a chat sends a short alert there, and one that delivers to vBot shows its failed Run with a notification; a failure without a Run, such as a failed check or a missing target Agent, shows the alert as a desktop notification instead.

A recurring job can watch a command or a web page: before each Run, vBot runs the command or fetches the URL, without a Model, and starts the Run only when the output changed since the last check. The Run receives the changes and the current output. The first check only records the output. A command runs in the shell Agents use (PowerShell on Windows, bash elsewhere), in the job's Working Project directory or Workspace, including a pinned Session's context; a non-zero exit code or more than 60 seconds is a failed check. A page is compared by its readable text; an error status or no answer within 30 seconds is a failed check. Failed checks count like failed Runs: five failures in a row stop the job, and the alerts reach the user like those of failed Runs. To have the job run at every due time anyway, with the current output and any change, set Start a Run to At every due time (`--watch-runs always`). Set the check in the WebUI under Automations (Change check), let an Agent set it with the `cron` Tool, or use `--watch <command-or-url>` (an `http://` or `https://` address is a page) and `vbot cron update JOB_ID --clear-watch`; `vbot cron show` reports `watch`, `last_checked_at`, `last_changed_at` and `last_check_error`.

A webhook job (`--webhook`, WebUI Automations > Webhooks, or `schedule: "webhook"` in the `cron` Tool) runs whenever a POST request reaches its URL, `/api/hooks/JOB_ID` on vBot's server address, and proves the job's secret: with the header `Authorization: Bearer <secret>`, or as a GitHub webhook whose secret is the job's secret (`X-Hub-Signature-256`). vBot makes the secret and keeps it in the encrypted Secret Store, never in the job file; creating the job shows it, `vbot cron secret JOB_ID` or Show under Automations > Webhooks shows it again, and `--rotate` or Replace replaces it, after which requests with the old secret are refused. Services on the internet, such as GitHub, reach the URL only while vBot is open to the internet with a public URL ([Server access](#server-access)); in `lan` mode the URL works from the home network, and in `local` mode only from this computer. The Run receives each request's arrival time, selected headers (such as `X-GitHub-Event`) and its body as data, at most 16,000 characters of each body; a body over 256 KB is refused. Requests that arrive during a Run wait and start one more Run together, at most 10 requests and 16,000 characters, the oldest dropped first; requests wait across a restart, and a paused job keeps its waiting requests until it is enabled. A paused, deleted or non-webhook job, and a request without the right secret, all get the same 404 answer; too many requests from one address get 429. vBot answers 202 as soon as a request is stored, before its Run starts.

For signed webhook requests, vBot keeps a fingerprint of each accepted body for as long as it accepts the signing secret, including across restarts. A repeat of the same signed body gets 202 without queuing another Run. GitHub's setup ping also gets 202 without queuing a Run. Bearer requests can submit identical bodies separately.

An email job (`--email CHANNEL_ID`, WebUI Automations > Schedules with Repeats On each new email, or `schedule: "email"` in the `cron` Tool) runs on matching mail that no Channel conversation takes. `--email-from` matches a From header address or a domain such as `@example.com` and can be repeated. If the Channel has trusted authentication servers, a From filter also requires those servers to verify the From domain. Without them, the From header alone is used and can be forged. The individual mailbox remains unverified. `--email-subject` matches part of the subject, ignoring case. On update, omitted filters stay, and `--clear-email-from` and `--clear-email-subject` remove them. A job without filters takes any mail handed to it.

The Run receives sender, recipients, subject, times, text (at most 16,000 characters), attachment names and the From-domain verification result. These are labeled as mail data. The Run can list attachments. The job remembers recent Message-IDs across restarts. Mails that arrive during a Run wait and start one more Run together, at most 10 mails and 16,000 characters, the oldest dropped first. A paused job takes no mails. Jobs of Project Agents cannot run on mail, because Channels belong to Identity Agents. `vbot cron show` reports `email` with the last mail's time and the mails waiting.

## Bootstrap

Bootstrap schedules an Agent Run after the server has fully reached its ready point. It is CLI-only and supports a one-shot next-startup check or one Run after every startup. Multiple jobs may run in the same startup; jobs targeting the same Session stay ordered while independent Sessions can run concurrently.

```bash
vbot bootstrap create assistant --name "Startup health" --prompt "Check server status and logs" --mode always
vbot bootstrap create --current-session --name "Verify vBot update" --prompt "Check server status and the latest logs, then report whether the update succeeded. Do not repeat the update." --mode once
vbot bootstrap list
vbot bootstrap show JOB_ID
vbot bootstrap update JOB_ID --prompt "Check status, logs, and Provider health"
vbot bootstrap disable JOB_ID
vbot bootstrap enable JOB_ID
vbot bootstrap delete JOB_ID
```

Creation requires `--mode once|always`. A job created, updated, or enabled is armed for a future startup and cannot fire immediately in the current process. `--current-session` is available only from Bash inside a vBot Run and uses that Run's exact Agent/Project/Session context; otherwise pass an Agent address and optional `--session` explicitly. A completed one-shot is immutable history. Failed one-shots may be rearmed with `enable`.

Updates called from a vBot Run automatically arrange their own once-Bootstrap in the same Session; do not add another. Human and tray updates do not create a Bootstrap or Agent. For a server restart from a Run in a development checkout, for example after updating it with Git, create a one-shot Bootstrap with `--current-session` before a restart, verify its full prompt and target with `vbot bootstrap show JOB_ID`, and give it a prompt that runs `vbot server status`, `vbot log list`, and `vbot log read` on the latest log before reporting the result. `vbot update --no-restart` does not need a Bootstrap unless a later startup check is wanted.

## Extensions and Home Assistant

Extensions are trusted Python code loaded into the Runtime process. They may register Tools, hooks, Recall backends, System Prompt blocks, settings fields, Channel interaction handlers, and Skills. Because they run with the same OS permissions as vBot, install only code you trust.

vBot scans direct children of `<data-dir>/extensions/` plus configured Extension roots. Supported entry points are a `.py` file, a package `__init__.py`, or a package `extension.py`. Code changes can be reloaded live:

```bash
vbot extensions list
vbot extensions reload
vbot extensions enable homeassistant
vbot extensions show homeassistant
```

Inspect an Extension with `extensions show <name>` and change a field with `extensions set <name> <field> <value>`. Use `--stdin` for secrets so they do not enter shell history:

```bash
vbot extensions set homeassistant url http://homeassistant.local:8123
Get-Content .\hass-token.txt | vbot extensions set homeassistant token --stdin
```

For the Extension API, hook contracts, capabilities, and examples, use the [vbot-docs Skill](resources/skills/vbot-docs/SKILL.md), its [Extension authoring guide](resources/skills/vbot-docs/references/extensions.md), and its [runnable templates](resources/skills/vbot-docs/assets/extensions). Bundled Swarm, MCP, and Computer Use operation is covered in the Skill's [Extension usage reference](resources/skills/vbot-docs/references/extension-usage.md).

### Home Assistant

Home Assistant ships as a bundled Extension. In Settings → Extensions → Home Assistant, enter the server URL and a Long-Lived Access Token created from the Home Assistant profile Security page. The secret is stored under `HASS_TOKEN` in the data directory's Secret Store and is never returned by the read API. Changes take effect without a restart; until a token exists, the Tools remain hidden and the Extension reports that it is waiting for configuration.

| Tool | Behavior |
|---|---|
| `ha_list_entities` | List entities, optionally filtered by domain or area |
| `ha_get_state` | Read the full state of one entity |
| `ha_list_services` | Discover services and parameters |
| `ha_call_service` | Invoke a service such as turning on a light or setting a thermostat |

`ha_call_service` blocks `shell_command`, `command_line`, `python_script`, `pyscript`, `hassio`, and `rest_command` because those domains can execute arbitrary code or make outbound requests. Entity, domain, and service identifiers are validated before a request is sent.

## CLI reference

Commands read as `vbot <area> <command> [target] [options]`, with deeper subcommands where needed. Start with `vbot --help`, then `vbot <area> --help`. Collection names accept singular and plural forms, such as `vbot provider list` and `vbot providers list`.

Use `vbot help`, `vbot project`, or `vbot project override` to discover the next action without executing anything. Related actions have readable paths such as `project override set`, `session policy set`, `channel token set`, `prompt layout reset`, `task-model option set`, and `skill file write`. Existing compound spellings remain compatible. Extensions use `extensions show <name>`, `extensions set <name> <field> <value>`, and `extensions run <name> <operation>`.

Management commands share an explicit completion marker: `OK` for a completed command, `WARN` for pending work or a reported limitation, and `ERROR` for failure. This does not turn saved configuration into proof of runtime readiness. Notices go to stderr; stdout retains complete data and content, including JSON. Long commands report elapsed time and available operation phases before completion. Terminals get color and status symbols where supported, with long record rows arranged as separate fields. `NO_COLOR=1` disables color. `--output plain` preserves the stable data layout and suppresses extra progress/completion notices; `--output human` requests readable record layout in a capture. Update, server lifecycle, and Doctor retain their dedicated reports.


```bash
vbot server restart
vbot providers list
vbot provider connect openai
```

The last command starts OpenAI Subscription sign-in. OAuth commands select the only OAuth Connection automatically; when there are multiple candidates, specify `--connection` using an id from the displayed list. `vbot provider list --details` preserves all Connection and Account fields; `provider status <provider-id>` narrows those details to one Provider. The Provider overview distinguishes configured, disabled, missing-credential and local reachability states; configured does not establish live upstream access.

Installed commands use `vbot`. From a development checkout, `python cli/main.py` and `python -m cli.main` expose the same parser. Most management commands call the running server through RPC and accept `--host`, `--port`, and `--data-dir` on the leaf command, or `--url` with a server's address such as `https://vbot.example.com`. Without these options they use `VBOT_SERVER_URL` when it is set, else the local server; `--host`/`--port` and `--url` cannot be combined. Server lifecycle, home, desktop, update, uninstall, autostart, doctor, and `data-store` offline maintenance include local work and do not merely proxy management RPC.

| Area | Commands |
|---|---|
| Server | `server start`, `server stop`, `server restart`, `server status` |
| First-run setup | `setup`, `setup --browser`, `setup --if-needed`, `setup status`, `setup finish` |
| Optional services | `service status`, `service install`, `service start`, `service stop`, `service update`, `service remove` (service id: `searxng`) |
| Paths | `home [--data-dir ...]` |
| Desktop | `desktop [--host ... --port ...]` |
| Installation lifecycle | `update`, `update status`, `update activate`, `uninstall`, `autostart enable`, `autostart disable`, `autostart status`, `application status`, `application channel`, `application dependencies` |
| Agents | `agent list`, `agent show`, `agent create`, `agent update`, `agent rename`, `agent reorder`, `agent delete` |
| Projects | `project add`, `project list`, `project show`, `project set`, `project override set`, `project override clear`, `project detect`, `project remove` |
| Sessions | `session list`, `session create`, `session fork`, `session rename`, `session policy set`, `session delete`, `session channel link` |
| Archive | `archive list`, `archive show`, `archive restore`, `archive purge` |
| Terminal | `tui [--agent ...] [--session ... \| --project ...] [--host ... --port ... \| --url ...]` |
| Devices | `devices list`, `devices approve`, `devices deny`, `devices rename`, `devices revoke`, `devices pair <url>`, `devices logout <url>` |
| Chat | `chat [<prompt>] [--agent ...] [-c \| --session ...] [--model ...] [--thinking-effort ...] [--temperature ...] [--json]` |
| Data store | `data-store status`, `data-store snapshot list|create|verify|restore`, `data-store config-backup list|show|restore`, `data-store incident acknowledge`, `data-store unregister` |
| Channels | `channel add`, `channel list`, `channel update`, `channel token set`, `channel enable`, `channel disable`, `channel status`, `channel identity`, `channel access`, `channel admin grant`, `channel admin revoke`, `channel whatsapp setup/status/pair`, `channel remove` |
| Tools and Skills | `tool list`, `skill list`, `skill inventory`, `skill inspect`, `skill install`, `skill read`, `skill enable`, `skill disable`, `skill share`, `skill unshare`, `skill create`, `skill update`, `skill delete`, `skill file write`, `skill file remove` |
| Memory | `memory list`, `memory add`, `memory replace`, `memory remove` |
| System Prompt | `prompt list`, `prompt show`, `prompt update`, `prompt reset`, `prompt create`, `prompt remove`, `prompt layout set`, `prompt layout reset`, `prompt preview` |
| Providers | `provider list`, `provider status`, `provider usage`, `provider history list`, `provider history clear`, `provider custom list`, `provider custom save`, `provider custom delete`, `provider key set`, `provider key unset`, `provider enable`, `provider disable`, `provider connect`, `provider disconnect`, `provider connection status` |
| Models | `model list`, `model show`, `model refresh`, `model forget-wire-facts`, `task-model list`, `task-model target list`, `task-model option list`, `task-model set`, `task-model option set`, `task-model option unset`, `task-model clear` |
| Extensions | `extensions list`, `extensions reload`, `extensions enable`, `extensions disable`, `extensions show <name>`, `extensions set <name>`, `extensions operations <name>`, `extensions run <name> <operation>` |
| Cron | `cron list`, `cron show`, `cron create`, `cron update`, `cron delete`, `cron enable`, `cron disable`, `cron secret` |
| Bootstrap | `bootstrap list`, `bootstrap show`, `bootstrap create`, `bootstrap update`, `bootstrap delete`, `bootstrap enable`, `bootstrap disable` |
| Statistics | `statistics overview`, `statistics usage`, `statistics runs`, `statistics compactions`, `statistics errors`, `statistics tools`, `statistics skills` |
| Configuration | `config list`, `config describe`, `config effective`, `config raw`, `config get`, `config set`, `config unset`, `config patch`, `doctor settings`, `doctor config` |
| Diagnostics | `log list`, `log read`, `debug status`, `debug traces`, `debug trace`, `debug clear`, `debug probe`, `performance status`, `performance record start`, `performance record stop`, `performance recordings` (alias `perf`) |

`config set <path> --stdin` reads an exact JSON value without shell-quoting loss. `log read` prints the latest 100 entries by default; `--limit 0` prints all, and `--level` filters first. Provider credential writes and Extension activation can save successfully while a later refresh/load check fails; the nonzero exit and output preserve both outcomes.

Representative syntax:

```bash
vbot provider status openai --connection openai:subscription
vbot provider usage --connection openai:subscription
vbot model refresh openai
vbot statistics usage --since 2026-07-01
vbot log read 2026-07-18.log --level error --limit 100
vbot debug probe openrouter --connection openrouter:api-key
vbot performance record start --label slow-chat --max-seconds 120
vbot performance record stop
```

`performance status` shows the slowest operations since server start, key process and Event Loop gauges, and recent Event Loop stalls with their top stack frames. A Recording captures a timeline of RPC calls, Runs, Tool calls, database transactions and worker pools until `record stop` or its `--max-seconds` limit (default 300, at most 3600); stop prints the trace file path to open at https://ui.perfetto.dev. Only one Recording runs at a time. Traces hold timings, ids and code locations, never message content.

Run `vbot <area> --help` and `vbot <area> <command> --help` for every flag and positional argument. Primary Agent, Project, Session, Channel, Provider, task type, Cron job, and Extension identifiers shown in the examples are positional unless the leaf help explicitly names an option.

## Server API

The server exposes one JSON RPC endpoint, per-Run SSE, app-wide WebSocket events, Log streaming, attachments, speech, images, and health. Who may call it depends on the server's access mode ([Server access](#server-access)); `local` and `lan` have no authentication. Treat access as host-level code-execution authority.

Data-store operations exposed through RPC are `data_store.status`, `data_store.snapshot_create`, `data_store.incident_acknowledge`, and `data_store.unregister`. They return safe health and recovery metadata, publish `resource_changed` with kind `data_store` after successful snapshot, acknowledgement, or unregister mutations, and never include Session content. Offline snapshot listing, verification, and restore stay in the CLI because they must inspect and control the exact local target.

First-run setup uses `setup.get`, `setup.update` with a `step` (`provider`, `model`, `components` or `services`), and `setup.finish`. Each returns the shared `status`, `step`, target `agent_id` and `auto_show` flag. Completion is durable: moving to a step never resets a completed or skipped guide. Changes publish `resource_changed` with kind `setup`.

### RPC envelope

Send `{"method":"...","params":{...}}` to `POST /api/rpc`. Responses use an `ok` result or a structured error. Product paths create Sessions explicitly before Chat input.

The PowerShell example below creates a Session for an Identity Agent. Use `agent@project` as `agent_id` for a Project Agent:

```powershell
$base = "http://127.0.0.1:22332"

$createBody = @{
  method = "session.create"
  params = @{
    agent_id = "coder"
  }
} | ConvertTo-Json -Depth 5

$sessionResponse = Invoke-RestMethod -Method Post -Uri "$base/api/rpc" -ContentType "application/json" -Body $createBody
$sessionId = $sessionResponse.result.session_id
```

### Send and stream Chat

`chat.send` normally waits for the admitted Run and returns its complete result. If the Session is already busy, it can return a queued descriptor instead. A recognized Built-in Command can return a command outcome without starting an ordinary Run.

```powershell
$sendBody = @{
  method = "chat.send"
  params = @{
    agent_id = "coder"
    session_id = $sessionId
    content = "Say hello in one short sentence."
  }
} | ConvertTo-Json -Depth 5

Invoke-RestMethod -Method Post -Uri "$base/api/rpc" -ContentType "application/json" -Body $sendBody
```

`chat.stream` returns a `run_id` and `sse_url` for an admitted Run, or a queued descriptor when the Session is busy:

```powershell
$streamBody = @{
  method = "chat.stream"
  params = @{
    agent_id = "coder"
    session_id = $sessionId
    content = "Explain vBot in two sentences."
  }
} | ConvertTo-Json -Depth 5

$streamResponse = Invoke-RestMethod -Method Post -Uri "$base/api/rpc" -ContentType "application/json" -Body $streamBody
$runId = $streamResponse.result.run_id
$sseUrl = $streamResponse.result.sse_url
curl.exe -N "$base$sseUrl"
```

The complete per-Run timeline can contain `run_started`, `user_message_persisted`, reasoning and output deltas, Tool start/delta/stdout/stderr/result events, `assistant_output`, Model fallback and Usage events, Compaction, and terminal `run_completed`, `run_failed`, or `run_cancelled` events.

Cancel a Run by id:

```powershell
$cancelBody = @{
  method = "chat.cancel"
  params = @{
    run_id = $runId
    reason = "user"
  }
} | ConvertTo-Json -Depth 5

Invoke-RestMethod -Method Post -Uri "$base/api/rpc" -ContentType "application/json" -Body $cancelBody
```

### HTTP and WebSocket endpoints

- `GET /health` — exact vBot health probe
- `POST /api/rpc` — JSON RPC
- `GET /api/runs/{run_id}/events` — per-Run SSE timeline
- `WS /ws` — app-wide lifecycle, reconnect, presence, and resource-change WebSocket events
- `WS /ws/logs` — selected Log WebSocket stream
- `POST /api/upload` — upload an attachment
- `GET /api/attachments/{attachment_id}` — download an attachment
- `POST /api/speech/transcribe` — transcribe audio
- `POST /api/speech/synthesize` — synthesize speech
- `GET /api/speech/artifacts/{artifact_id}` — retrieve a generated speech artifact

## Development and verification

### Extension dependencies in a packaged installation

Extension source remains in `<data-dir>/extensions/` or its configured roots and
keeps its normal reload behavior. In a packaged installation, extra Python
dependencies use a complete managed recipe instead of changing the base runtime:

```bash
vbot application dependencies install --requirements requirements.txt
vbot application dependencies status
vbot server restart
```

Each install command replaces the complete recipe. Requirements must remain
compatible with the base runtime's packages. Updates prepare a compatible
dependency generation before stopping the server; previous generations are
retained for recovery.

### Development checkout

A development checkout is a Git clone of this repository, not an installation.
It runs on Python 3.14, the version the packages bundle; vBot supports no other.
Install the development dependencies, the search engine the search Tools need,
and the WebUI packages:

```bash
pip install -e ".[dev]"
python -m cli.search_runtime
cd webui
npm ci
cd ..
```

Update the checkout with Git (`git pull`), then repeat these steps when
dependencies changed. `vbot update`, `vbot uninstall`, `vbot autostart` and
`vbot application` manage packaged installations only and refuse in a checkout.

Run the Python server and Vite development server separately:

```bash
python server/main.py
```

```bash
cd webui
npm run dev
```

Build or preview the production frontend:

```bash
cd webui
npm run build
npm run preview
```

Enable the tracked Git hooks once per clone. Before each commit they format,
lint and type-check the staged files:

```bash
git config core.hooksPath .githooks
```

Run tests with the test runners directly while working:

```bash
python -m pytest tests/core/tools
cd webui
npx vitest run src/lib
```

Maintainers push `main` with `python scripts/push.py`, which runs every check,
the complete suites included, on the commit it pushes. CI
(`.github/workflows/ci.yml`) runs the complete suites on Linux and Windows on
every push to `main`, alongside the main package builds (`main-build.yml`), and
before every release.

End-to-end testing has no scripted suite: a coding agent tests the running WebUI in a real browser against a deterministic fake Provider, following `.vorch/workflows/e2e-test-workflow.md`. Maintainers start it by hand; neither CI nor the release runs it.

Package builders and maintainers should also read the
[Windows packaging guide](scripts/windows/README.md) and the
[Linux packaging guide](scripts/linux/README.md). Building packages locally does
not publish them; CI builds and signs the published packages.

## Operational notes

- vBot is alpha software. Back up the data directory before upgrades or manual config surgery.
- Agents and trusted Extensions run with the OS permissions of the account that starts vBot. Keep the server on localhost unless a deliberately secured remote topology is required.
- A remote Desktop Client reaches a server in the access mode `lan` over a trusted LAN or VPN plus restrictive firewalling ([Server access](#server-access)). Never forward the port of a `local` or `lan` server to the public internet: neither has a login.
- Bind conflicts normally mean another process already owns the selected port. Use `vbot server status` and stop the conflicting process. A development checkout can also choose another `--port`; an installation keeps the port chosen at installation.
- Process environment credentials override values in the data directory's Secret Store; removing a data-directory key may therefore leave a Connection configured through the process environment.
- Attachment, speech, and image artifacts are durable. Attachments currently have no garbage collector or reference counting, including attachments promoted from images read from disk.
- Complete Bash process output under `temp/bash/` is retained for 72 hours after completion; Sub-Agent activity files under `temp/subagents/` are retained for 24 hours. These temporary files supplement canonical Session history.
- Recall indexes are derived and disposable; deleting `<data-dir>/recall/` does not delete canonical Sessions.
- A database recovery incident stays visible until explicit acknowledgement. Preserve its quarantine bundle and verified snapshots; never delete evidence as part of acknowledgement.
- Update protection creates a verified data snapshot of every canonical database and the JSON configuration documents before replacing current-format code.
- Desktop echo cancellation covers audio played through the Windows default output device. Without it (turned off, another output device, or on Linux), loudspeaker output can trigger a sensitive wakeword Model; choose device placement and sensitivity accordingly.
