"""Repository translation contracts at the public scan and runtime boundaries."""

import json
import sys
from dataclasses import replace
from pathlib import Path

import pytest

from core.agents import TemporaryAgentConfig, TemporaryAgentRegistry
from core.permissions import permission_rules_to_dict
from core.projects import PROJECT_FORMAT_VERSION
from core.projects._resolution_values import profile_tool_access
from core.projects.scan_report import FindingType
from core.projects.sources import SourceSelection, read_profile, scan_project
from core.projects.sources.catalog import detect_sources, refresh_sources, skill_roots
from core.sessions import ChatSessionManager, SessionAddress
from core.tools.availability import ToolAccess, resolve_tool_access
from tests.core.projects.resolver_test_support import (
    AgentResolutionError,
    _openai_configured,
    _resolver,
)
from tests.core.projects.resolver_test_support import (
    agents as agents,
)
from tests.core.projects.resolver_test_support import (
    data_dir as data_dir,
)
from tests.core.projects.resolver_test_support import (
    projects as projects,
)
from tests.core.projects.resolver_test_support import (
    repo as repo,
)
from tests.core.projects.resolver_test_support import (
    template_dir as template_dir,
)
from tests.directory_links import link_directory


def write(root: Path, path: str, content: str) -> Path:
    target = root / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    return target


ALL_TOOLS = frozenset(
    {"read", "search_files", "apply_patch", "bash", "terminal", "status", "skill", "subagent"}
)
NO_SHELL = ALL_TOOLS - {"bash", "terminal"}


@pytest.mark.parametrize(
    ("source", "path", "document", "expected", "status"),
    [
        ("claude", ".claude/agents/reviewer.md", "---\ntools: []\n---\nReview.", set(), "ready"),
        (
            "codex",
            ".codex/agents/reviewer.toml",
            'name = "reviewer"\nmodel = [',
            set(),
            "needs_attention",
        ),
        (
            "claude",
            ".claude/agents/reviewer.md",
            "---\ntools: []\ntools: Read\n---\nReview.",
            set(),
            "needs_attention",
        ),
        (
            "claude",
            ".claude/agents/reviewer.md",
            "---\ntools: [Read\n---\nReview.",
            set(),
            "needs_attention",
        ),
        # A Tool the Agent may use for some commands or paths is granted whole.
        (
            "claude",
            ".claude/agents/reviewer.md",
            "---\ntools: Read(src/**), Bash(git status)\n---\nReview.",
            {"read", "bash"},
            "ready",
        ),
        (
            "claude",
            ".claude/agents/reviewer.md",
            "---\ndisallowedTools: Read(./.env), Bash\n---\nReview.",
            NO_SHELL,
            "ready",
        ),
        (
            "claude",
            ".claude/agents/reviewer.md",
            "---\npermissionMode: acceptEdits\n---\nReview.",
            ALL_TOOLS,
            "ready",
        ),
        (
            "claude",
            ".claude/agents/reviewer.md",
            "---\npermissionMode: dontAsk\n---\nReview.",
            set(),
            "ready",
        ),
        (
            "claude",
            ".claude/agents/reviewer.md",
            "---\nhooks:\n  PreToolUse:\n    - matcher: Bash\n---\nReview.",
            ALL_TOOLS,
            "limited",
        ),
        (
            "opencode",
            ".opencode/agents/reviewer.md",
            "---\npermission:\n  '*': deny\n  read: allow\n---\nReview.",
            {"read"},
            "ready",
        ),
        (
            "opencode",
            ".opencode/agents/reviewer.md",
            "---\npermission:\n  '*': deny\n  task:\n    builder: allow\n"
            "  skill:\n    review: ask\n---\nReview.",
            {"subagent", "skill"},
            "ready",
        ),
        (
            "opencode",
            ".opencode/agents/reviewer.md",
            "---\npermission:\n  bash:\n    '*': allow\n    'git push*': deny\n"
            "  edit: ask\n  todowrite: deny\n---\nReview.",
            ALL_TOOLS,
            # vBot does not ask before edits, so the report flags the dropped approval.
            "limited",
        ),
        # Deny patterns alone keep everything else the shell may run.
        (
            "opencode",
            ".opencode/agents/reviewer.md",
            "---\npermission:\n  shell:\n    'git push*': deny\n---\nReview.",
            ALL_TOOLS,
            "ready",
        ),
        (
            "opencode",
            "opencode.json",
            '{"agent":{"reviewer":{"disable":true}}}',
            set(),
            "needs_attention",
        ),
        (
            "opencode",
            "opencode.jsonc",
            '{\n  // Shared\n  "permission": {"bash": "deny"},\n'
            '  "agent": /* Definitions */ {"reviewer": {"prompt": "Review.",},},\n}',
            NO_SHELL,
            "ready",
        ),
        (
            "opencode",
            "opencode.jsonc",
            '{"agent":{"reviewer":{"prompt":"Review.","tools":{"bash":tru/* comment */e}}}}',
            set(),
            "needs_attention",
        ),
        (
            "codex",
            ".codex/agents/reviewer.toml",
            'name="reviewer"\ndescription="Review"\ndeveloper_instructions="Review."\n'
            'sandbox_mode="read-only"\napproval_policy="on-request"',
            # The sandbox becomes Permission Rules (write: scratch), not a lost Tool.
            ALL_TOOLS,
            "ready",
        ),
        (
            "codex",
            ".codex/config.toml",
            '[features]\nshell_tool=false\n[agents.reviewer]\ndescription="Review"',
            NO_SHELL,
            "limited",
        ),
        (
            "copilot",
            ".github/agents/reviewer.agent.md",
            "---\ntools: [read]\n---\nReview.",
            {"read"},
            "ready",
        ),
        (
            "cursor",
            ".cursor/agents/reviewer.md",
            "---\nreadonly: true\n---\nReview.",
            {"read", "search_files", "status"},
            "ready",
        ),
        (
            "gemini",
            ".gemini/agents/reviewer.md",
            "---\ntools: [read_file]\n---\nReview.",
            {"read"},
            "ready",
        ),
    ],
)
def test_imports_grant_the_tools_an_agent_may_use(repo, source, path, document, expected, status):
    write(repo, path, document)
    sources = [SourceSelection(f"{source}.agents")]
    profile = scan_project(repo, sources=sources).team[0]
    assert read_profile(repo, sources, profile.agent_id, selected=profile) == profile
    assert profile.status == status
    policy = profile_tool_access(profile, tuple(sorted(ALL_TOOLS)))
    assert set(policy.allowed) == expected
    # A Profile selects the Agent's own Tools; the Session's grants still apply to
    # every runnable Profile, including one with an empty Tool list.
    from types import SimpleNamespace

    tools = [SimpleNamespace(name=name, activation="configurable") for name in policy.allowed]
    tools += [SimpleNamespace(name="message_parent", activation="session_grant")]
    actual = resolve_tool_access(policy, tools, "off", session_tool_grants=("message_parent",))
    assert set(actual.allowed_tools) == expected | (
        {"message_parent"} if status != "needs_attention" else set()
    )


_DRIVE_DATA = "C:/data/**" if sys.platform == "win32" else "/c/data/**"


@pytest.mark.parametrize(
    ("files", "source", "expected", "untranslated"),
    [
        pytest.param(
            {
                ".claude/settings.json": json.dumps(
                    {
                        "permissions": {
                            "deny": [
                                "Read(./.env)",
                                "Read(secrets/**)",
                                "Edit(/src/gen/**)",
                                "Read(~/.ssh/**)",
                                "Read(//c/data/**)",
                                "WebFetch(domain:evil.com)",
                                "Bash",
                                "Read(!keep.env)",
                            ],
                            "ask": ["Bash(git push *)"],
                            "additionalDirectories": ["../shared"],
                        }
                    }
                ),
                ".claude/agents/reviewer.md": "---\ndisallowedTools: Bash(rm *)\n---\nReview.",
            },
            "claude",
            {
                # Claude Code anchors: ./ and bare names at any depth below the
                # working directory, /path at the project, //path absolute.
                "allow": ["Edit({workdir}/../shared/**)"],
                "deny": [
                    "Read({workdir}/**/.env)",
                    "Read({workdir}/**/secrets/**)",
                    "Edit({project}/src/gen/**)",
                    "Read(~/.ssh/**)",
                    f"Read({_DRIVE_DATA})",
                    "Web(evil.com)",
                    "Shell(rm *)",
                ],
            },
            {"permissions.deny.Read(!keep.env)", "permissions.ask"},
            id="claude-deny",
        ),
        pytest.param(
            {
                ".claude/settings.json": json.dumps(
                    {
                        "permissions": {
                            "defaultMode": "dontAsk",
                            "allow": [
                                "Bash(git status)",
                                "Edit(src/**)",
                                "WebFetch(domain:docs.python.org)",
                            ],
                            "additionalDirectories": ["~/shared"],
                        }
                    }
                ),
                ".claude/agents/reviewer.md": "---\nname: reviewer\n---\nReview.",
            },
            "claude",
            {
                "read": "work_area",
                "write": "scratch",
                "commands": "listed",
                "web": "listed",
                "allow": [
                    "Shell(git status)",
                    "Edit({workdir}/src/**)",
                    "Web(docs.python.org)",
                    "Read(~/shared/**)",
                ],
            },
            set(),
            id="claude-dont-ask",
        ),
        pytest.param(
            {
                ".claude/settings.json": json.dumps(
                    {
                        "permissions": {
                            "allow": ["Bash(git status)"],
                            "additionalDirectories": ["/x"],
                        }
                    }
                ),
                ".claude/agents/reviewer.md": "---\nname: reviewer\n---\nReview.",
            },
            "claude",
            None,
            set(),
            id="claude-allow-only",
        ),
        pytest.param(
            {
                "opencode.json": json.dumps(
                    {
                        "permission": {
                            "bash": {"*": "deny", "git *": "allow", "git push *": "ask"},
                            "read": {"*.env": "deny", "*.env.example": "allow"},
                            "external_directory": "deny",
                        },
                        "agent": {
                            "reviewer": {
                                "prompt": "Review.",
                                "permission": {
                                    "edit": {"*": "deny", "src/**": "allow"},
                                    "webfetch": {"https://evil.com/*": "deny"},
                                },
                            }
                        },
                    }
                )
            },
            "opencode",
            {
                "read": "work_area",
                "write": "scratch",
                "commands": "listed",
                "allow": ["Edit({workdir}/src/**)", "Shell(git *)", "Shell(git push *)"],
                "deny": ["Read({workdir}/**/*.env)", "Web(evil.com)"],
            },
            {"permission.bash"},
            id="opencode",
        ),
        pytest.param(
            {
                "opencode.json": json.dumps(
                    {"agent": {"reviewer": {"prompt": "R.", "permission": {"bash": "allow"}}}}
                )
            },
            "opencode",
            None,
            set(),
            id="opencode-allow-only",
        ),
        pytest.param(
            {
                ".codex/config.toml": 'sandbox_mode = "workspace-write"\n'
                "[sandbox_workspace_write]\n"
                'writable_roots = ["/var/cache/app"]\nnetwork_access = false\n'
                '[agents.reviewer]\ndescription = "Review"\n'
            },
            "codex",
            {"write": "work_area", "allow": ["Edit(/var/cache/app/**)"]},
            {"sandbox_workspace_write.network_access"},
            id="codex-workspace-write",
        ),
        pytest.param(
            {
                ".codex/agents/reviewer.toml": 'name = "reviewer"\ndefault_permissions = "team"\n'
                '[permissions.team]\nextends = ":read-only"\n'
                '[permissions.team.filesystem]\n"/srv/out" = "write"\n'
                '[permissions.team.filesystem.":workspace_roots"]\n".env" = "deny"\n'
            },
            "codex",
            {
                "write": "scratch",
                "allow": ["Edit(/srv/out)"],
                "deny": ["Read({workdir}/.env)"],
            },
            set(),
            id="codex-permission-profile",
        ),
        pytest.param(
            {
                ".codex/agents/reviewer.toml": 'name = "reviewer"\n'
                'sandbox_mode = "danger-full-access"\n'
            },
            "codex",
            None,
            set(),
            id="codex-full-access",
        ),
    ],
)
def test_repository_permission_settings_translate_to_permission_rules(
    repo, files, source, expected, untranslated
):
    # A repository restricts its Agent only where its own settings restrict;
    # what vBot cannot translate is reported, never silently dropped.
    for path, content in files.items():
        write(repo, path, content)
    sources = [SourceSelection(f"{source}.agents")]
    profile = scan_project(repo, sources=sources).team[0]
    assert read_profile(repo, sources, profile.agent_id, selected=profile) == profile

    rules = profile.permission_rules
    assert (None if rules is None else permission_rules_to_dict(rules)) == expected
    assert {
        item.setting
        for item in profile.translations
        if item.status == "not_supported" and item.setting.startswith(("perm", "sandbox"))
    } == untranslated


@pytest.mark.parametrize("global_denial", [False, True])
def test_opencode_named_exceptions_keep_other_targets_and_skills_denied(
    agents, projects, repo, global_denial
):
    permission = {"task": {"builder": "allow"}, "skill": {"review": "ask"}}
    document = {
        "permission": {"*": "deny"} if global_denial else {},
        "agent": {
            "reviewer": {
                "prompt": "Review.",
                "permission": permission if global_denial else {"*": "deny", **permission},
            },
            "builder": {"prompt": "Build."},
            "other": {"prompt": "Other."},
        },
    }
    write(repo, "opencode.json", json.dumps(document))
    projects.create("repo", "Repo", repo, default_model="openai/gpt-mini")
    resolver = _resolver(
        agents,
        projects,
        _openai_configured(),
        project_skill_names={"repo": frozenset({"review", "private"})},
    )
    resolved = resolver.resolve_agent("repo", "reviewer")
    assert set(resolved.tool_access.allowed) == {"subagent", "skill"}
    assert resolved.tools["subagent"]["allowed_agents"] == ["builder"]
    assert resolved.allowed_skills == ["review"]


def test_mixed_sources_priority_and_new_detection_preserve_winners(repo):
    write(repo, ".claude/agents/reviewer.md", "---\nname: reviewer\n---\nClaude.")
    write(repo, ".opencode/agents/builder.md", "Builder.")
    write(
        repo,
        ".agents/skills/review/SKILL.md",
        "---\nname: review\ndescription: Review code.\n---\nReview.",
    )
    sources = [
        SourceSelection("claude.agents"),
        SourceSelection("opencode.agents"),
        SourceSelection("shared.skills"),
    ]
    write(repo, ".opencode/agents/reviewer.md", "OpenCode.")
    # Neither documentation nor settings for OpenCode's own Agents define Team members.
    write(repo, ".claude/agents/README.md", "Our agents.")
    write(repo, "opencode.json", '{"agent":{"plan":{"model":"anthropic/x"}}}')
    result = scan_project(repo, sources=sources)
    assert [agent.agent_id for agent in result.team] == ["builder", "reviewer"]
    assert result.team[1].source == "claude"
    assert result.shadowed[0].source == "opencode"
    assert result.report.findings_of(FindingType.SLUG_COLLISION)
    write(repo, ".cursor/agents/reviewer.md", "---\nname: reviewer\n---\nCursor.")
    refreshed = refresh_sources(sources, detect_sources(repo))
    assert next(item for item in refreshed if item.id == "cursor.agents").enabled is False
    reordered = scan_project(repo, sources=[sources[1], sources[0], sources[2]])
    assert reordered.team[1].source == "opencode"
    selected = result.team[1]
    write(repo, ".claude/agents/reviewer.md", "---\nname: renamed\n---\nRenamed.")
    fallback = read_profile(repo, sources, "reviewer", selected=selected)
    assert fallback is not None and fallback.source == "opencode"
    (repo / ".claude/agents/reviewer.md").unlink()
    assert read_profile(repo, sources, "reviewer", selected=selected) == fallback


@pytest.mark.parametrize("source", ["claude", "opencode", "codex"])
def test_selected_profile_reloads_inherited_rules_and_only_its_definition(
    repo, monkeypatch, source
):
    from core.projects.sources import _reading as reading

    if source == "claude":
        config = write(repo, ".claude/settings.json", "{}")
        path = write(repo, ".claude/agents/definition.md", "---\nname: reviewer\n---\nBefore.")
        write(repo, ".claude/agents/other.md", "---\nname: other\n---\nOther.")
        changed_config = '{"permissions":{"deny":["Bash"]}}'
        changed_source = "---\nname: reviewer\n---\nAfter."
        expected_reads = {config, path}
    elif source == "opencode":
        config = write(
            repo,
            "opencode.json",
            '{"agent":{"reviewer":{"prompt":"{file:reviewer.txt}"},'
            '"other":{"prompt":"{file:other.txt}"}}}',
        )
        path = write(repo, "reviewer.txt", "Before.")
        write(repo, "other.txt", "Other.")
        changed_config = config.read_text(encoding="utf-8")[:-1] + ',"permission":{"bash":"deny"}}'
        changed_source = "After."
        expected_reads = {config, path}
    else:
        config = write(
            repo,
            ".codex/config.toml",
            "[features]\nshell_tool=true\n"
            '[agents.other]\nconfig_file="agents/role.data"\ndescription="Other role"\n'
            '[agents.reviewer]\nconfig_file="agents/role.data"\ndescription="Selected role"\n'
            '[agents.independent]\nconfig_file="independent.toml"\n',
        )
        path = write(repo, ".codex/agents/role.data", 'developer_instructions="Before."')
        independent = write(repo, ".codex/independent.toml", 'developer_instructions="Other."')
        write(repo, ".codex/agents/standalone.toml", 'name="standalone"')
        changed_config = config.read_text(encoding="utf-8").replace(
            "shell_tool=true", "shell_tool=false"
        )
        changed_source = 'name="reviewer"\ndeveloper_instructions="After."'
        expected_reads = {config, path, independent}
    sources = [SourceSelection(f"{source}.agents")]
    selected = next(
        agent for agent in scan_project(repo, sources=sources).team if agent.agent_id == "reviewer"
    )
    config.write_text(changed_config, encoding="utf-8")
    path.write_text(changed_source, encoding="utf-8")
    original_read = reading.read_text
    reads: list[Path] = []

    def read_text(source_path):
        reads.append(source_path)
        return original_read(source_path)

    monkeypatch.setattr(reading, "read_text", read_text)
    reloaded = read_profile(repo, sources, "reviewer", selected=selected)
    assert reloaded is not None and reloaded.agent_id == "reviewer"
    assert reloaded.body == "After."
    assert set(profile_tool_access(reloaded, tuple(ALL_TOOLS)).allowed) == NO_SHELL
    assert set(reads) == expected_reads
    if source == "codex":
        assert reloaded.description == "Selected role"
        # Every explicit role file still validates the inherited configuration.
        independent.write_text("broken = [", encoding="utf-8")
        invalid = read_profile(repo, sources, "reviewer", selected=selected)
        assert invalid is not None and invalid.unavailable_reason
        # Removing a role must not promote an arbitrary referenced config file
        # into a standalone .toml definition, even if it declares the same name.
        config.write_text("[features]\nshell_tool=false\n", encoding="utf-8")
        assert read_profile(repo, sources, "reviewer", selected=selected) is None


@pytest.mark.parametrize("source", ["claude", "opencode", "codex", "opencode-json", "claude-json"])
@pytest.mark.parametrize("failure", ["malformed", "unreadable", "too_deep"])
def test_a_selected_unavailable_profile_never_uses_a_shadowed_definition(
    agents, projects, repo, deny_access, monkeypatch, source, failure
):
    ecosystem = source.removesuffix("-json")
    if source == "codex":
        path = write(
            repo, ".codex/agents/definition.toml", 'name="reviewer"\nmodel="openai/gpt-5.2"'
        )
        broken = "name = ["
    elif source == "opencode-json":
        path = write(
            repo,
            "opencode.json",
            '{"agent":{"reviewer":{"prompt":"Review.","model":"openai/gpt-5.2"}}}',
        )
        broken = '{"agent":['
    else:
        filename = "reviewer" if source == "opencode" else "definition"
        path = write(
            repo,
            f".{ecosystem}/agents/{filename}.md",
            "---\nname: reviewer\nmodel: openai/gpt-5.2\n---\nSelected.",
        )
        broken = "---\nname: [\n---\nBroken."
        if source == "claude-json":
            path = write(repo, ".claude/settings.json", "{}")
            broken = '{"permissions":['
    write(repo, ".cursor/agents/reviewer.md", "---\nmodel: openai/gpt-5.2\n---\nShadowed.")
    write(repo, ".cursor/agents/healthy.md", "---\nmodel: openai/gpt-5.2\n---\nHealthy.")
    project = projects.create(
        "repo",
        "Repo",
        repo,
        sources=[{"id": f"{ecosystem}.agents"}, {"id": "cursor.agents"}],
    )
    resolver = _resolver(agents, projects, _openai_configured())
    resolver.rescan_project(project)
    if failure == "malformed":
        path.write_text(broken, encoding="utf-8")
    elif failure == "too_deep":
        depth = 64000 if source.endswith("-json") else 1200
        nested = "[" * depth + "0" + "]" * depth
        if source.endswith("-json"):
            broken = '{"unknown":' + nested + "}"
            # The native JSON decoder's stack limit varies by platform. Exercise
            # its failure boundary deterministically for this one input.
            decode = json.loads

            def bounded_decode(document, *args, **kwargs):
                if document == broken:
                    raise RecursionError("JSON metadata nesting limit exceeded")
                return decode(document, *args, **kwargs)

            monkeypatch.setattr(json, "loads", bounded_decode)
        elif source == "codex":
            broken = f'name="reviewer"\nunknown={nested}'
        else:
            broken = f"---\nname: reviewer\nunknown: {nested}\n---\nBroken."
        path.write_text(broken, encoding="utf-8")
    else:
        deny_access(path)
    with pytest.raises(AgentResolutionError) as error:
        resolver.resolve_agent("repo", "reviewer")
    assert type(error.value) is AgentResolutionError
    # A full rescan still reports unreadable definitions and keeps independent
    # Team members; parser limits are configuration failures, not scan crashes.
    rescanned = scan_project(repo, sources=project.sources)
    assert any(member.agent_id == "healthy" for member in rescanned.team)
    assert any(finding.type is FindingType.INVALID_SOURCE for finding in rescanned.report.findings)


def test_a_codex_profile_with_a_non_text_sandbox_mode_keeps_its_finding(repo):
    write(repo, ".codex/agents/reviewer.toml", 'sandbox_mode = ["read-only"]')
    write(repo, ".cursor/agents/healthy.md", "---\nmodel: openai/gpt-5.2\n---\nHealthy.")
    sources = [SourceSelection("codex.agents"), SourceSelection("cursor.agents")]

    scanned = scan_project(repo, sources=sources)
    (reviewer,) = (member for member in scanned.team if member.agent_id == "reviewer")
    assert {member.agent_id for member in scanned.team} == {"healthy", "reviewer"}
    assert reviewer.unavailable_reason is not None
    assert any(
        finding.type is FindingType.INVALID_SOURCE and finding.agent_id == "reviewer"
        for finding in scanned.report.findings
    )
    reloaded = read_profile(repo, sources, "reviewer", selected=reviewer)
    assert reloaded is not None and reloaded.unavailable_reason == reviewer.unavailable_reason


# The old readers: Claude walked its agents folder, OpenCode read only its top level.
@pytest.mark.parametrize(
    ("ecosystem", "legacy_team"), [("claude", ["new", "reviewer"]), ("opencode", ["reviewer"])]
)
def test_legacy_anchor_preserves_unknown_fields_overrides_and_sessions(
    projects, repo, data_dir, ecosystem, legacy_team
):
    write(repo, f".{ecosystem}/agents/reviewer.md", "---\nname: reviewer\n---\nReview.")
    write(repo, f".{ecosystem}/agents/nested/new.md", "---\nname: new\n---\nNew.")
    write(repo, "opencode.json", '{"agent":{"json-only":{"prompt":"JSON definition."}}}')
    other = "opencode" if ecosystem == "claude" else "claude"
    write(repo, f".{other}/agents/builder.md", "Build.")
    projects.create("repo", "Repo", repo)
    path = data_dir / "projects" / "repo" / "project.json"
    stored = json.loads(path.read_text(encoding="utf-8"))
    stored.pop("sources")
    stored["source_format"] = ecosystem
    stored["future_field"] = {"keep": True}
    stored["overrides"] = {"reviewer": {"model": "openai/gpt-5.2"}}
    path.write_text(json.dumps(stored), encoding="utf-8")
    sessions = ChatSessionManager(data_dir)
    try:
        session = sessions.create("reviewer", project_id="repo")
        loaded = projects.get("repo")
        assert [
            agent.agent_id for agent in scan_project(repo, sources=loaded.sources).team
        ] == legacy_team
        assert loaded.overrides == stored["overrides"]
        projects.update("repo", display_name="Renamed")
        saved = json.loads(path.read_text(encoding="utf-8"))
        assert saved["format_version"] == PROJECT_FORMAT_VERSION
        assert saved["future_field"] == {"keep": True}
        assert sessions.get(SessionAddress("repo", "reviewer", session.id)) is not None
        expanded = projects.update(
            "repo",
            sources=[
                {key: value for key, value in source.to_dict().items() if key != "agent_paths"}
                for source in loaded.sources
            ],
        )
        assert "new" in {
            agent.agent_id for agent in scan_project(repo, sources=expanded.sources).team
        }

    finally:
        sessions.close()


def test_profiles_preload_skills_map_models_and_snapshot_temporary_participants(
    agents, projects, repo, data_dir
):
    path = write(
        repo,
        ".claude/agents/reviewer.md",
        "---\nmodel: sonnet\neffort: high\ntools: Read\nskills: [review]\n---\nReview repository.",
    )
    projects.create("repo", "Repo", repo, model_mappings={"sonnet": "openai/gpt-5.2"})
    resolver = _resolver(
        agents, projects, _openai_configured(), project_skill_names={"repo": frozenset({"review"})}
    )
    resolver._profile_skill_content = lambda project_id, name, allowed: "Check regression risks."
    resolved = resolver.resolve_agent("repo", "reviewer")
    assert resolved.model == "openai/gpt-5.2"
    assert resolved.thinking_effort == "high"
    assert '<skill_content name="review">' in resolved.body
    assert "Check regression risks." in resolved.body
    sessions = ChatSessionManager(data_dir)
    try:
        registry = TemporaryAgentRegistry(
            sessions, prepare_config=resolver.prepare_temporary_config
        )
        config = TemporaryAgentConfig(
            model="openai/gpt-mini",
            cwd=repo,
            tool_access=ToolAccess(mode="selected", allowed=("read", "bash")),
            allowed_skills=["review"],
            tools={},
            name="Reviewer",
            repository_profile="reviewer",
        )
        binding = registry.create(
            owner_name="swarm",
            group_id="group",
            participant_id="peer",
            config=config,
            project_id="repo",
        )
        participant = registry.resolve(binding.address, generation_id=binding.generation_id)
        assert participant.model == "openai/gpt-5.2"
        assert participant.tool_access.allowed == ("read",)
        assert not participant.tool_access.fixed
        assert "Check regression risks." in participant.instructions
        explicit = replace(config, model_override="openai/gpt-mini", thinking_effort_override="low")
        chosen = resolver.prepare_temporary_config(explicit, "repo")
        assert (chosen.model, chosen.thinking_effort) == ("openai/gpt-mini", "low")
        assert chosen.tool_access == participant.tool_access
        assert chosen.model_override is chosen.thinking_effort_override is None
        explicit_binding = registry.create(
            owner_name="swarm",
            group_id="group",
            participant_id="explicit",
            config=explicit,
            project_id="repo",
        )
        assert "model_override" not in explicit_binding.config
        assert (
            explicit_binding.config["repository_profile_request"]["model_override"]
            == "openai/gpt-mini"
        )
        assert explicit_binding.config["model"] == "openai/gpt-mini"
        assert explicit_binding.config["thinking_effort"] == "low"
        inherited = resolver.prepare_temporary_config(replace(config, model=""), "repo")
        assert inherited.model == resolved.model
        with pytest.raises(ValueError):
            resolver.prepare_temporary_config(
                replace(explicit, model_override="unknown/model"), "repo"
            )
        with pytest.raises(ValueError):
            replace(explicit, thinking_effort_override="not-an-effort")
        path.write_text("---\ntools: Bash\n---\nChanged.", encoding="utf-8")
        assert (
            registry.create(
                owner_name="swarm",
                group_id="group",
                participant_id="peer",
                config=config,
                project_id="repo",
            )
            == binding
        )
        assert registry.resolve(binding.address, generation_id=binding.generation_id) == participant
        assert (
            registry.create(
                owner_name="swarm",
                group_id="group",
                participant_id="explicit",
                config=explicit,
                project_id="repo",
            )
            == explicit_binding
        )
        with pytest.raises(ValueError, match="differs"):
            registry.create(
                owner_name="swarm",
                group_id="group",
                participant_id="peer",
                config=replace(config, name="Other"),
                project_id="repo",
            )

        def interleaved_prepare(config, project_id):
            registry.create(
                owner_name="swarm",
                group_id="group",
                participant_id="race",
                config=config,
                project_id=project_id,
            )
            path.write_text("---\ntools: []\n---\nLater edit.", encoding="utf-8")
            return resolver.prepare_temporary_config(config, project_id)

        racing = TemporaryAgentRegistry(sessions, prepare_config=interleaved_prepare)
        winner = racing.create(
            owner_name="swarm",
            group_id="group",
            participant_id="race",
            config=config,
            project_id="repo",
        )
        assert (
            "Changed."
            in registry.resolve(winner.address, generation_id=winner.generation_id).instructions
        )
    finally:
        sessions.close()


@pytest.mark.asyncio
async def test_inherit_uses_the_delegating_model_without_requiring_a_project_default(
    agents, projects, repo
):
    write(repo, ".claude/agents/reviewer.md", "---\nmodel: inherit\n---\nReview.")
    projects.create("repo", "Repo", repo)
    resolver = _resolver(agents, projects, _openai_configured())
    agent = await resolver.resolve_delegated_agent_async(
        "repo", "reviewer", caller_model="openai/gpt-mini"
    )
    assert agent.model == "openai/gpt-mini"
    assert agent.model_inherit
    projects.set_override("repo", "reviewer", "model", "openai/gpt-5.2")
    agent = await resolver.resolve_delegated_agent_async(
        "repo", "reviewer", caller_model="openai/gpt-mini"
    )
    assert agent.model == "openai/gpt-5.2"
    assert not agent.model_inherit
    projects.clear_override("repo", "reviewer", "model")
    projects.update("repo", default_model="openai/gpt-5.2")
    write(repo, ".claude/agents/reviewer.md", "---\nmodel: unmapped-wish\n---\nReview.")
    temporary = resolver.prepare_temporary_config(
        TemporaryAgentConfig(
            model="openai/gpt-mini",
            cwd=repo,
            tool_access=ToolAccess(mode="none"),
            allowed_skills=[],
            tools={},
            name="Reviewer",
            repository_profile="reviewer",
        ),
        "repo",
    )
    assert temporary.model == "openai/gpt-5.2"
    # Without any usable default the participant keeps its own Model.
    projects.update("repo", default_model="")
    resolver._global_agent_defaults = lambda: {}
    temporary = resolver.prepare_temporary_config(
        TemporaryAgentConfig(
            model="openai/gpt-mini",
            cwd=repo,
            tool_access=ToolAccess(mode="none"),
            allowed_skills=[],
            tools={},
            name="Reviewer",
            repository_profile="reviewer",
        ),
        "repo",
    )
    assert temporary.model == "openai/gpt-mini"


@pytest.mark.parametrize(
    "owner_policy",
    [
        ToolAccess(mode="none"),
        ToolAccess(mode="selected", allowed=("read",), fixed=True),
        ToolAccess(mode="selected", allowed=("apply_patch",), denied=("write",)),
    ],
)
def test_temporary_profiles_keep_owner_tool_limits_and_materialize_skill_rules(
    agents, projects, repo, owner_policy
):
    write(
        repo,
        "opencode.json",
        json.dumps(
            {"agent": {"reviewer": {"permission": {"skill": {"*": "allow", "private": "deny"}}}}}
        ),
    )
    projects.create("repo", "Repo", repo)
    resolver = _resolver(agents, projects, _openai_configured())
    resolver._skill_pool_names = lambda project_id: frozenset({"review", "private"})
    config = TemporaryAgentConfig(
        model="openai/gpt-mini",
        cwd=repo,
        tool_access=owner_policy,
        allowed_skills=["*"],
        tools={},
        name="Reviewer",
        repository_profile="reviewer",
    )
    prepared = resolver.prepare_temporary_config(config, "repo")
    assert prepared.allowed_skills == ["review"]
    assert not set(prepared.tool_access.allowed) & set(owner_policy.denied)
    assert set(owner_policy.denied) <= set(prepared.tool_access.denied)
    if owner_policy.mode == "none":
        assert prepared.tool_access.fixed and prepared.tool_access.allowed == ()
    elif owner_policy.fixed:
        assert prepared.tool_access.fixed
        assert prepared.tool_access.allowed == owner_policy.allowed
    projects.set_override(
        "repo",
        "reviewer",
        "tool_access",
        {
            "mode": "selected",
            "allowed": ["read", "bash", "apply_patch"],
        },
    )
    overridden = resolver.prepare_temporary_config(config, "repo")
    assert set(overridden.tool_access.allowed) <= set(owner_policy.allowed)
    assert not set(overridden.tool_access.allowed) & set(owner_policy.denied)
    if owner_policy.mode == "none" or owner_policy.fixed:
        assert overridden.tool_access.fixed


@pytest.mark.parametrize("external_target", [False, True], ids=["real-source", "links-only"])
def test_a_skill_folder_linked_to_another_supplies_its_skills_once(repo, external_target):
    folder = repo.parent / "shared-skills" if external_target else repo / ".agents/skills"
    write(folder, "review/SKILL.md", "---\nname: review\ndescription: R.\n---\nR.")
    (repo / ".claude").mkdir()
    link_directory(repo / ".claude/skills", folder)
    if external_target:
        (repo / ".agents").mkdir()
        link_directory(repo / ".agents/skills", folder)
    detected = {item.definition.id for item in detect_sources(repo)}
    assert detected == {"claude.skills" if external_target else "shared.skills"}
    # Projects that already list the linked Source load the folder once.
    sources = [SourceSelection("claude.skills"), SourceSelection("shared.skills")]
    assert skill_roots(repo, sources) == [
        repo / (".claude/skills" if external_target else ".agents/skills")
    ]
    assert skill_roots(repo, list(reversed(sources))) == [repo / ".agents/skills"]
    # The report follows the Project's enabled Source order, like the runtime.
    scanned = scan_project(repo, sources=list(reversed(sources)))
    assert [(row["id"], row["skills"]) for row in scanned.sources] == [
        ("shared.skills", 1),
        ("claude.skills", 0),
    ]
    if not external_target:
        sources[1] = SourceSelection("shared.skills", enabled=False)
        scanned = scan_project(repo, sources=sources)
        assert scanned.sources[0]["skills"] == 1
        assert skill_roots(repo, sources) == [repo / ".claude/skills"]


def test_unavailable_skill_folder_does_not_break_a_different_linked_source(repo, monkeypatch):
    target = repo / "other-skills"
    write(target, "review/SKILL.md", "---\nname: review\ndescription: R.\n---\nR.")
    alias = repo / ".claude/skills"
    alias.parent.mkdir()
    link_directory(alias, target)
    unavailable = repo / ".agents/skills"
    resolve = Path.resolve

    def resolve_path(path, *args, **kwargs):
        if path == unavailable:
            raise PermissionError("Unavailable Skill folder")
        return resolve(path, *args, **kwargs)

    monkeypatch.setattr(Path, "resolve", resolve_path)
    sources = [SourceSelection("claude.skills"), SourceSelection("shared.skills")]
    scanned = scan_project(repo, sources=sources)
    assert scanned.sources[0]["skills"] == 1
    assert scanned.sources[0]["problem"] is None
    assert alias in skill_roots(repo, sources)


def test_skill_folder_sources_load_in_source_order_wherever_they_live(repo, tmp_path):
    write(repo, ".vbot/skills/review/SKILL.md", "---\nname: review\ndescription: R.\n---\nR.")
    write(repo, ".agents/skills/review/SKILL.md", "---\nname: review\ndescription: S.\n---\nS.")
    outside = tmp_path / "elsewhere"
    write(outside, "deploy/SKILL.md", "---\nname: deploy\ndescription: D.\n---\nD.")
    sources = [
        SourceSelection("folder:.vbot/skills"),
        SourceSelection("shared.skills"),
        SourceSelection(f"folder:{outside.as_posix()}"),
        SourceSelection("folder:gone", enabled=False),
    ]

    result = scan_project(repo, sources=sources)

    assert skill_roots(repo, sources) == [
        repo / ".vbot/skills",
        repo / ".agents/skills",
        outside,
    ]
    assert [(row["id"], row["skills"]) for row in result.sources] == [
        ("folder:.vbot/skills", 1),
        ("shared.skills", 1),
        (f"folder:{outside.as_posix()}", 1),
        ("folder:gone", 0),
    ]
    # The folder Source wins the name; a switched-off missing folder is no finding.
    assert [finding.detail for finding in result.report.findings] == [
        "Skill 'review' from shared.skills is shadowed by folder:.vbot/skills."
    ]
