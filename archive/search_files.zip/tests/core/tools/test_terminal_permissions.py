"""A restricted Session's terminal: what start, input at a shell prompt, attach and
status check against its Permission Rules (``_terminal_permissions``)."""

from __future__ import annotations

import asyncio
from dataclasses import replace
from pathlib import Path
from typing import Any, cast

import pytest

import core.tools.shell_environment as shell_environment
import core.tools.terminal as terminal_module
import core.tools.terminal_manager as manager_module
from core.permissions import (
    BoundaryContext,
    PermissionBoundary,
    ScopedArtifactReads,
    normalize_permission_rules,
)
from core.projects import ProjectStore
from core.secrets.agent_secrets import AgentSecrets
from core.sessions import SessionAddress
from core.storage import TemporaryFileManager
from core.storage.temp_files import artifact_owner, terminal_log_scope
from core.tools import _workdir
from core.tools._terminal_permissions import may_attach, permission_scope
from core.tools._terminal_shell_state import ShellState
from core.tools.search_files import register_search_files_tool
from core.tools.terminal import register_terminal_tool
from core.tools.terminal_manager import (
    TerminalInfo,
    TerminalManager,
    TerminalOwner,
    TerminalRenderHost,
)
from core.tools.tools import JsonObject, ToolRegistry
from tests.core.permissions.command_check_support import (
    FakeAnalyzer,
    fake_checker,
    plan,
    restricted,
)
from tests.core.secrets.secrets_test_support import data_directory, open_store
from tests.core.secrets.test_agent_secrets import Clock
from tests.core.tools.read_test_support import make_context as read_context
from tests.core.tools.read_test_support import read_registry
from tests.core.tools.shell_test_support import FakeProjects
from tests.core.tools.terminal_helpers import call, make_context, manager
from tests.core.tools.terminal_manager_helpers import (
    AdapterFactory,
    PendingTriggerService,
    eventually,
)
from tests.core.tools.tools_test_support import dispatch_as_executor
from tests.directory_links import link_directory

__all__ = ["manager"]

_OWNER = TerminalOwner("project-a", "agent-a", "session-a")


def _prompt(folder: Path) -> str:
    """What vBot's PowerShell integration prints before each prompt."""
    return f'\x1b]9;9;"{folder}"\x07\x1b]133;A\x07PS> '


class _Terminal:
    """Calls of one restricted Session against a fake PTY terminal manager."""

    def __init__(
        self,
        manager: tuple[TerminalManager, AdapterFactory],
        tmp_path: Path,
        analyzer: FakeAnalyzer,
        permissions: PermissionBoundary,
    ) -> None:
        self.manager, self.factory = manager
        self.tmp_path = tmp_path
        self.analyzer = analyzer
        self.checker = fake_checker(analyzer)
        self.permissions = permissions

    async def __call__(
        self, arguments: JsonObject, *, session: str = "session-a", restricted: bool = True
    ) -> dict[str, Any]:
        context = make_context(
            self.tmp_path,
            session_id=session,
            permissions=self.permissions if restricted else None,
        )
        result = await call(self.manager, context, arguments, command_checker=self.checker)
        return cast(dict[str, Any], result)


@pytest.fixture
def work(tmp_path: Path) -> Path:
    folder = tmp_path / "work"
    folder.mkdir()
    return folder


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("arguments", "rules", "fragment"),
    [
        pytest.param(
            {"command": "git", "args": ["push"]},
            {"deny": ["Shell(git push *)"]},
            'refuse running "git push", because the rule Shell(git push *) denies it',
            id="denied-program",
        ),
        pytest.param(
            {"workdir": "OUTSIDE"},
            {},
            "refuse working in",
            id="workdir-outside",
        ),
        pytest.param(
            {"command": "/bin/sh"},
            {},
            "vBot cannot check the lines typed into this shell. Start the terminal without command",
            id="shell-without-integration",
        ),
    ],
)
async def test_a_restricted_start_launches_nothing_the_rules_refuse(
    manager: tuple[TerminalManager, AdapterFactory],
    tmp_path: Path,
    work: Path,
    arguments: JsonObject,
    rules: dict[str, object],
    fragment: str,
) -> None:
    outside = tmp_path / "outside"
    outside.mkdir()
    if arguments.get("workdir") == "OUTSIDE":
        arguments = {**arguments, "workdir": str(outside)}
    terminal = _Terminal(manager, work, FakeAnalyzer(plan("git push")), restricted(work, **rules))

    refused = await terminal({"action": "start", **arguments})

    assert refused["error"]["code"] == "permission_denied"
    assert fragment in refused["error"]["message"]
    assert terminal.factory.calls == []


@pytest.mark.asyncio
@pytest.mark.parametrize("selection", ["default", "project", "path"])
async def test_a_denied_workdir_is_refused_before_its_status_is_probed(
    manager: tuple[TerminalManager, AdapterFactory],
    work: Path,
    monkeypatch: pytest.MonkeyPatch,
    selection: str,
) -> None:
    probed: list[object] = []
    original_is_dir = Path.is_dir

    def is_dir(path: Path, **kwargs: Any) -> bool:
        if path == work:
            probed.append(path)
            return False
        return original_is_dir(path, **kwargs)

    def unavailable(path: object) -> bool:
        probed.append(path)
        return False

    monkeypatch.setattr(Path, "is_dir", is_dir)
    monkeypatch.setattr(_workdir, "cwd_exists", unavailable)
    arguments: JsonObject = {"action": "start", "command": "fake-tui"}
    if selection != "default":
        arguments["workdir"] = "project:private" if selection == "project" else str(work)
    terminal_manager, factory = manager
    result = await call(
        terminal_manager,
        make_context(work, permissions=restricted(work, deny=["Read({workdir})"])),
        arguments,
        projects=cast(ProjectStore, FakeProjects({"private": work})),
    )
    assert result["error"]["code"] == "permission_denied"
    assert probed == []
    assert factory.calls == []


@pytest.mark.asyncio
async def test_a_restricted_shell_starts_confined_and_its_prompt_lines_are_checked(
    manager: tuple[TerminalManager, AdapterFactory],
    work: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # The terminal Tool picks the shell an argument-less start runs.
    monkeypatch.setattr(terminal_module, "default_terminal_argv", lambda env: ["pwsh.exe"])
    monkeypatch.setenv("VBOT_DATA_DIR", str(work.parent / "data"))
    login = shell_environment._login_environment
    server = {"OPENAI_API_KEY": "sk-server", "FLAVOR": "release"}
    monkeypatch.setattr(shell_environment, "_login_environment", lambda: {**login(), **server})
    terminal_manager, factory = manager
    factory.initial_output = _prompt(work)
    analyzer = FakeAnalyzer(plan("Remove-Item secret.txt"))
    boundary = restricted(work, deny=["Shell(Remove-Item *)"])
    terminal = _Terminal(manager, work, analyzer, boundary)

    started = await terminal({"action": "start"})
    terminal_id = started["data"]["terminal_id"]
    adapter = factory.adapters[0]

    async def send(**arguments: object) -> dict[str, Any]:
        return await terminal({"action": "input", "terminal_id": terminal_id, **arguments})

    # The shell itself runs nothing, so only its folder is checked; it keeps the
    # Session's rules and starts without vBot's control variables or the credentials
    # vBot knows (``KNOWN_CREDENTIALS``).
    assert analyzer.argvs == []
    assert not {"VBOT_DATA_DIR", "OPENAI_API_KEY"} & set(factory.calls[0][2])
    assert factory.calls[0][2]["FLAVOR"] == "release"
    info = terminal_manager.terminal(terminal_id, _OWNER)
    assert info.permission_scope == permission_scope(boundary)
    assert info.log_path is not None and info.permission_scope is not None
    log_policy = terminal_log_scope(
        work.parent / "temp", artifact_owner(_OWNER.project_id, _OWNER.agent_id, _OWNER.session_id)
    )
    assert log_policy.allows(
        info.log_path.relative_to(log_policy.root).as_posix(), info.permission_scope
    )
    # Typing is not submitting; Enter checks the whole line in the reported folder.
    assert (await send(text="Remove-Item secret"))["ok"] is True
    assert analyzer.lines == []
    refused = await send(key="enter")
    assert refused["error"]["code"] == "permission_denied"
    assert analyzer.lines[-1][:3] == ("Remove-Item secret", "powershell", work)
    # Keys whose effect on the line vBot cannot follow are refused at the prompt.
    completion = await send(key="tab")
    assert completion["error"]["message"].startswith(
        "terminal was not run: the permission rules check each command line typed at this "
        'shell prompt, and key "tab" would change the line'
    )
    assert adapter.writes == ["Remove-Item secret"]

    analyzer.result = plan("Get-ChildItem")
    assert (await send(key="ctrl_c"))["ok"] is True
    assert (await send(text="Get-ChildItem", key="enter"))["ok"] is True
    assert analyzer.lines[-1][0] == "Get-ChildItem"
    # A line that starts another shell would hand the next lines to an unchecked prompt.
    analyzer.result = plan("pwsh")
    nested = await send(text="pwsh\n")
    assert "a prompt vBot cannot check" in nested["error"]["message"]

    # A running program reads its input unchecked.
    adapter.emit("\x1b]133;C\x07")
    await eventually(lambda: not _shell(terminal_manager, terminal_id).at_prompt)
    checked = len(analyzer.lines)
    assert (await send(text="y\n"))["ok"] is True
    assert len(analyzer.lines) == checked


@pytest.mark.asyncio
@pytest.mark.parametrize("competing", [False, True])
async def test_terminal_secret_is_consumed_only_after_approval_and_checks_actual_input(
    manager: tuple[TerminalManager, AdapterFactory],
    work: Path,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    competing: bool,
) -> None:
    monkeypatch.setattr(terminal_module, "default_terminal_argv", lambda env: ["pwsh.exe"])
    terminal_manager, factory = manager
    factory.initial_output = _prompt(work)
    analyzer = FakeAnalyzer(plan("echo actual-secret"))
    checker = fake_checker(analyzer)
    boundary = restricted(work, commands="listed")
    secrets = AgentSecrets(open_store(tmp_path, data_directory(tmp_path)), clock=Clock())
    secrets.reload()
    secrets.create(
        name="TOKEN",
        kind="token",
        values={"value": "echo actual-secret"},
        actor="user",
        lifetime="once",
        session_id="session-a",
        agents=["agent-a@project-a"],
        sinks=["terminal"],
    )
    registry = ToolRegistry()
    registry.set_secrets(secrets)
    register_terminal_tool(
        registry, terminal_manager, ProjectStore(tmp_path / "data"), command_checker=checker
    )
    base = make_context(work, permissions=boundary)
    started = await dispatch_as_executor(registry, base, {"action": "start"})
    assert started["ok"], started
    terminal_id = started["data"]["terminal_id"]
    requests: list[Any] = []
    decision = False

    async def approve(
        _context: Any, _reason: str, requirements: Any, arguments: Any, _cwd: Any
    ) -> bool:
        requests.append((requirements, arguments))
        assert "actual-secret" not in str(arguments)
        if decision and competing:
            secrets.substitute(
                SessionAddress("project-a", "agent-a", "session-a"), "{{secret:TOKEN}}", "terminal"
            )
        return decision

    async def refresh(_force: bool) -> tuple[PermissionBoundary, dict[str, Any]]:
        return boundary, {"computer_id": "server", "allowed_computer_ids": ["server"]}

    def input_context() -> Any:
        return replace(
            make_context(work, permissions=boundary),
            approval_hook=approve,
            approval_refresh_hook=refresh,
        )

    arguments = {"action": "input", "terminal_id": terminal_id, "data": "{{secret:TOKEN}}\r"}
    refused = await dispatch_as_executor(registry, input_context(), arguments)
    assert not refused["ok"] and factory.adapters[0].writes == []
    assert secrets.lookup(SessionAddress("project-a", "agent-a", "session-a"), "TOKEN") is not None
    assert analyzer.lines[-1][0] == "echo actual-secret"
    assert requests[0][1]["data"] == "{{secret:TOKEN}}\r"
    decision = True
    accepted = await dispatch_as_executor(registry, input_context(), arguments)
    if competing:
        assert accepted["error"]["code"] == "secret_unavailable"
        assert factory.adapters[0].writes == []
    else:
        assert accepted["ok"] and factory.adapters[0].writes == ["echo actual-secret\r"]
    assert secrets.lookup(SessionAddress("project-a", "agent-a", "session-a"), "TOKEN") is None


@pytest.mark.asyncio
async def test_a_restricted_session_attaches_and_reads_only_terminals_under_its_rules(
    manager: tuple[TerminalManager, AdapterFactory],
    work: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(manager_module, "default_terminal_argv", lambda env: ["host-shell"])
    terminal_manager, factory = manager
    factory.initial_output = "secret output"
    terminal = _Terminal(manager, work, FakeAnalyzer(plan("host-shell")), restricted(work))
    operator = await terminal_manager.spawn_for_operator(command=None, arguments=[], cwd=work)
    operator_id = operator["terminal_id"]
    own = (await terminal({"action": "start"}, session="session-b"))["data"]["terminal_id"]
    await terminal({"action": "detach", "terminal_id": own}, session="session-b")

    refused = await terminal({"action": "attach", "terminal_id": operator_id})
    status = await terminal({"action": "status", "terminal_id": operator_id})

    assert refused["error"] == {
        "code": "permission_denied",
        "retryable": False,
        "message": f"terminal was not run: the permission rules refuse attaching {operator_id}, "
        "because it was started outside your permission rules (by the user, or by a Session "
        'with other rules). To work in a terminal, start one with terminal {"action": "start"}.',
    }
    assert "screen" not in status["data"]
    assert status["data"]["note"].startswith("Its screen and history are not shown")
    # A terminal another Session started under the same rules, and every terminal
    # for a Session with full access, can be attached.
    assert (await terminal({"action": "attach", "terminal_id": own}))["ok"] is True
    unrestricted = await terminal(
        {"action": "status", "terminal_id": operator_id}, restricted=False
    )
    assert "secret output" in unrestricted["data"]["screen"]


@pytest.mark.asyncio
async def test_an_attachment_cannot_keep_a_terminal_outside_the_sessions_current_rules(
    manager: tuple[TerminalManager, AdapterFactory], work: Path
) -> None:
    terminal_manager, factory = manager
    factory.initial_output = "previously available output"
    terminal = _Terminal(manager, work, FakeAnalyzer(plan("fake-tui")), restricted(work))
    started = await terminal({"action": "start", "command": "fake-tui"}, restricted=False)
    terminal_id = started["data"]["terminal_id"]
    columns = terminal_manager.terminal(terminal_id, _OWNER).columns

    for arguments in (
        {"action": "wait", "pattern": "previously available"},
        {"action": "input", "text": "continue"},
        {"action": "resize", "columns": 90},
        {"action": "kill"},
    ):
        denied = await terminal({**arguments, "terminal_id": terminal_id})
        assert denied["error"]["code"] == "permission_denied"
        assert "previously available output" not in denied["error"]["message"]

    info = terminal_manager.terminal(terminal_id, _OWNER)
    assert not info.finished
    assert info.columns == columns
    assert factory.adapters[0].writes == []
    released = await terminal({"action": "detach", "terminal_id": terminal_id})
    assert released["ok"]
    operator = await terminal_manager.read_for_operator(terminal_id)
    assert "previously available output" in operator["screen"]


@pytest.mark.asyncio
async def test_a_wait_rechecks_scope_before_returning_output(
    manager: tuple[TerminalManager, AdapterFactory], work: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    terminal_manager, factory = manager
    factory.initial_output = "previously available output"
    context = make_context(work)
    started = await call(terminal_manager, context, {"action": "start", "command": "fake-tui"})
    terminal_id = started["data"]["terminal_id"]
    waiting = asyncio.Event()
    resumed = asyncio.Event()
    boundary = PermissionBoundary.UNRESTRICTED

    async def hold_wait(*_args: Any, **_kwargs: Any) -> str:
        waiting.set()
        await resumed.wait()
        return "idle"

    async def refresh(_force: bool) -> tuple[PermissionBoundary, dict[str, Any]]:
        return boundary, context.execution

    monkeypatch.setattr(terminal_manager, "wait", hold_wait)
    context = replace(context, approval_refresh_hook=refresh)
    pending = asyncio.create_task(
        call(terminal_manager, context, {"action": "wait", "terminal_id": terminal_id})
    )
    await asyncio.wait_for(waiting.wait(), timeout=2)
    boundary = restricted(work)
    resumed.set()
    denied = await asyncio.wait_for(pending, timeout=2)

    assert denied["error"]["code"] == "permission_denied"
    assert "previously available output" not in denied["error"]["message"]


@pytest.mark.asyncio
async def test_raw_terminal_logs_use_the_recipient_scope_in_file_tools_and_command_plans(
    tmp_path: Path, work: Path
) -> None:
    data = tmp_path / "data"
    owner = artifact_owner(_OWNER.project_id, _OWNER.agent_id, _OWNER.session_id)
    logs = terminal_log_scope(data, owner)
    context = BoundaryContext(
        workdir=work,
        home=tmp_path,
        data_dir=data,
        scoped_artifact_reads=ScopedArtifactReads(logs.root, logs.allows),
        # Even a broad readable directory must not expose other launch scopes.
        readable_dirs=(data,),
    )
    rules = normalize_permission_rules(
        {"read": "work_area", "allow": [f"Read({logs.root.as_posix()})"]}
    )
    narrow_rules = normalize_permission_rules({"deny": ["Shell(exit)"]})
    broader = PermissionBoundary.build(rules, context)
    bound_extra = PermissionBoundary.build(narrow_rules, context)
    extra = bound_extra.ceiling(source="parent")
    retagged = bound_extra.ceiling(source="extension")
    assert extra is not None and retagged is not None
    launched = PermissionBoundary.build(rules, context, ceilings=(extra,))
    later = PermissionBoundary.build(
        rules,
        context,
        ceilings=(retagged,),
    )
    absent = PermissionBoundary.build(
        normalize_permission_rules({"deny": ["Read({workdir}/later.txt)"]}), context
    ).ceiling(source="parent")
    assert absent is not None
    narrowed = PermissionBoundary.build(rules, context, ceilings=(extra, absent))

    manager = TemporaryFileManager(data)
    folder_launch = launched.with_read_folder((tmp_path / "library").as_posix())
    folder_log = manager.create_terminal_log(owner=owner, scope=permission_scope(folder_launch))
    assert folder_launch.check_path(folder_log.path, "read") is None
    assert launched.check_path(folder_log.path, "read") is not None
    log = manager.create_terminal_log(owner=owner, scope=permission_scope(launched))
    log.path.write_text("terminal sample\n", encoding="utf-8")
    group = log.path.parent
    record = group.with_suffix(".scope")
    legacy = manager.create("terminals", ".log", owner=owner)
    legacy.path.write_text("old terminal sample\n", encoding="utf-8")
    foreign = manager.create_terminal_log(
        owner=artifact_owner(None, "foreign", "example"), scope=permission_scope(launched)
    )
    alias = work / "logs"
    link_directory(alias, group.parent)

    registry = read_registry()
    register_search_files_tool(registry)

    async def dispatch(
        tool: str,
        arguments: JsonObject,
        boundary: PermissionBoundary,
    ) -> JsonObject:
        return await dispatch_as_executor(
            registry, replace(read_context(work, tool), permissions=boundary), arguments
        )

    for boundary in (launched, later, broader):
        report = await dispatch("read", {"path": str(log.path)}, boundary)
        assert report["ok"] and "terminal sample" in report["data"]["content"]
    listing = await dispatch("read", {"path": str(group)}, broader)
    assert listing["ok"] and log.path.name in listing["data"]["content"]
    result = await dispatch(
        "search_files", {"path": str(group), "pattern": "terminal sample"}, broader
    )
    assert result["ok"] and log.path.name in str(result["data"])

    for path in (legacy.path, foreign.path, group.parent, record):
        result = await dispatch("read", {"path": str(path)}, broader)
        assert result["error"]["code"] == "permission_denied"
    for boundary in (broader, narrowed):
        refused = boundary.check_path(alias / record.name, "write")
        assert refused is not None and refused.location == "data_dir"
    assert broader.check_path(data, "read") is None
    mixed_scope = broader.check_path(data, "read", subtree=True)
    assert mixed_scope is not None and mixed_scope.location == "data_dir"
    aliased_log = alias / group.name / log.path.name
    assert broader.check_path(aliased_log, "read") is None
    refused_alias = narrowed.check_path(aliased_log, "read")
    assert refused_alias is not None and refused_alias.location == "data_dir"
    checker = fake_checker(FakeAnalyzer(plan("list", subtree_reads=[group])))
    assert (
        await checker.check_line(broader, "list", shell="bash", cwd=work, env={}, home=tmp_path)
        is None
    )
    refused = await checker.check_line(
        narrowed, "list", shell="bash", cwd=work, env={}, home=tmp_path
    )
    assert refused is not None and refused.location == "data_dir"
    result = await dispatch("search_files", {"path": str(group), "pattern": "sample"}, narrowed)
    assert result["error"]["code"] == "permission_denied"

    initial = read_context(work)

    async def refresh(_force: bool) -> tuple[PermissionBoundary, dict[str, Any]]:
        return narrowed, initial.execution

    waiting = replace(initial, permissions=broader, approval_refresh_hook=refresh)
    denied = await dispatch_as_executor(registry, waiting, {"path": str(log.path)})
    assert denied["error"]["code"] == "permission_denied"

    denying = PermissionBoundary.build(
        normalize_permission_rules({"deny": [f"Read({logs.root.as_posix()}/**/*.log)"]}),
        context,
    )
    unreadable = manager.create_terminal_log(owner=owner, scope=permission_scope(denying))
    denied_path = denying.check_path(unreadable.path, "read")
    assert denied_path is not None and denied_path.reason == "deny_rule"
    denied_result = await dispatch("read", {"path": str(unreadable.path)}, denying)
    assert denied_result["error"]["code"] == "permission_denied"

    record.write_bytes(b"invalid")
    denied = await dispatch("read", {"path": str(log.path)}, broader)
    assert denied["error"]["code"] == "permission_denied"


@pytest.mark.asyncio
async def test_terminal_attention_projects_only_the_state_after_scope_narrows(work: Path) -> None:
    factory = AdapterFactory()
    sink = PendingTriggerService()
    current = PermissionBoundary.UNRESTRICTED

    async def output_allowed(_address: SessionAddress, info: TerminalInfo) -> bool:
        return may_attach(current, info)

    manager = TerminalManager(
        sink,
        adapter_factory=factory,
        render_host=TerminalRenderHost.in_process(),
        output_allowed=output_allowed,
    )
    try:
        await manager.spawn(_OWNER, ["fake-tui"], cwd=work, env=None, origin_run_id="run-a")
        factory.adapters[0].emit("previously available output")
        factory.adapters[0].finish(0)
        await eventually(lambda: bool(sink.submissions))
        (address,), submitted = sink.submissions[-1]
        project = submitted["filter_body"]
        assert "previously available output" in await project(address, submitted["body"])
        current = restricted(work)
        notice = await project(address, submitted["body"])
        assert "previously available output" not in notice
        assert "exited" in notice
    finally:
        await manager.aclose()


def _shell(terminal_manager: TerminalManager, terminal_id: str) -> ShellState:
    state = terminal_manager.shell_state(terminal_id, _OWNER)
    assert state is not None
    return state


@pytest.mark.parametrize(
    ("chunks", "cwd"),
    [
        pytest.param(['\x1b]9;9;"C:\\work"\x07', "\x1b]133;A\x07"], "C:\\work", id="osc-9-9"),
        pytest.param(
            ["\x1b]633;P;Cwd=/srv/a\\x3bb\\\\c\x07\x1b]133;A\x07"], "/srv/a;b\\c", id="633"
        ),
        pytest.param(
            ["\x1b]7;file://localhost/srv/a%20b\x1b\\", "\x1b]133;A\x07"], "/srv/a b", id="osc-7"
        ),
        pytest.param(
            ["\x1b]7;file://elsewhere.example/srv\x07\x1b]133;A\x07"], None, id="other-host"
        ),
        pytest.param(
            ["out\x1b]633;P;Cw", "d=/srv\x07\x1b", "]133;A\x07"], "/srv", id="split-reads"
        ),
    ],
)
def test_the_shell_state_reads_the_prompt_and_folder_its_shell_reports(
    chunks: list[str], cwd: str | None
) -> None:
    state = ShellState("start")

    for chunk in chunks:
        state.feed(chunk)

    assert (state.at_prompt, state.prompt_count, state.cwd) == (True, 1, cwd)
    state.feed("\x1b]133;C\x07")
    assert state.at_prompt is False


@pytest.mark.asyncio
@pytest.mark.parametrize("changed", ["start-rules", "input-rules", "input-prompt"])
async def test_changed_preparation_refuses_effects_with_a_retryable_result(
    manager: tuple[TerminalManager, AdapterFactory],
    tmp_path: Path,
    changed: str,
) -> None:
    terminal_manager, factory = manager
    context = make_context(tmp_path)
    arguments: JsonObject = {
        "action": "start",
        "command": "pwsh" if changed == "input-prompt" else "fake-tui",
    }
    if changed != "start-rules":
        started = await call(terminal_manager, context, arguments)
        arguments = {
            "action": "input",
            "terminal_id": started["data"]["terminal_id"],
            "key": "enter",
        }
    before = len(factory.calls)
    refreshed = False

    async def refresh(_force: bool) -> tuple[PermissionBoundary, dict[str, Any]]:
        nonlocal refreshed
        if changed != "start-rules" and not refreshed:
            refreshed = True
            return PermissionBoundary.UNRESTRICTED, context.execution
        if changed == "input-prompt":
            state = terminal_manager.shell_state(arguments["terminal_id"], _OWNER)
            assert state is not None
            state.feed(_prompt(tmp_path))
            return PermissionBoundary.UNRESTRICTED, context.execution
        return restricted(tmp_path), context.execution

    context = replace(context, approval_refresh_hook=refresh)
    refused = await call(terminal_manager, context, arguments)
    if changed == "input-rules":
        # The resulting terminal scope is itself denied, so this action must
        # use a terminal under the new rules.
        assert refused["error"]["code"] == "permission_denied", refused
        assert refused["error"]["retryable"] is False
    else:
        assert refused["error"]["code"] == "terminal_preparation_changed", refused
        assert refused["error"]["retryable"] is True
    assert len(factory.calls) == before
    assert all(adapter.writes == [] for adapter in factory.adapters)
