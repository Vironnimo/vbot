"""The shell Tool under Permission Rules: refusals launch nothing; a restricted shell is confined.

The command analysis is faked (``command_check_support``); the boundary is real.
"""

from __future__ import annotations

import asyncio
import os
import threading
from collections.abc import AsyncIterator
from dataclasses import replace
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, Mock

import pytest
import pytest_asyncio

import core.tools.shell_environment as shell_environment
from core.permissions.commands.commands import UnresolvedElement
from core.tools import _shell_arguments, _workdir
from core.tools import shell as shell_module
from core.tools.model_names import SHELL_MODEL_NAME
from core.tools.update_handoff import UpdateHandoffs
from tests.core.permissions.command_check_support import (
    PORT,
    UNAVAILABLE,
    FakeAnalyzer,
    plan,
    restricted,
)
from tests.core.tools.shell_test_support import (
    FakeProjects,
    Shell,
    data,
    launched,
    started_shell,
)
from tests.directory_links import link_directory


@pytest_asyncio.fixture
async def shell(tmp_path: Path) -> AsyncIterator[Shell]:
    async with started_shell(tmp_path) as harness:
        yield harness


@pytest.mark.asyncio
@pytest.mark.parametrize("selection", ["default", "project", "path"])
async def test_a_denied_workdir_is_refused_before_its_status_is_probed(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, selection: str
) -> None:
    probed: list[object] = []

    def unavailable(path: object) -> bool:
        probed.append(path)
        return False

    monkeypatch.setattr(_shell_arguments, "is_dir_strict", unavailable)
    monkeypatch.setattr(_workdir, "cwd_exists", unavailable)
    arguments: dict[str, object] = {"command": "echo safe"}
    if selection != "default":
        arguments["workdir"] = "project:private" if selection == "project" else str(tmp_path)
    async with started_shell(
        tmp_path,
        projects=FakeProjects({"private": tmp_path}),
        permissions=restricted(tmp_path, deny=["Read({workdir})"]),
    ) as shell:
        result = await shell.call(arguments)
    assert result["error"]["code"] == "permission_denied"
    assert probed == []
    assert shell.launcher.processes == []


@pytest.mark.asyncio
async def test_shell_review_waits_before_launch_and_hard_denials_skip_review(
    tmp_path: Path,
) -> None:
    arrived = asyncio.Event()
    answer = asyncio.Event()
    reviewed: list[Any] = []

    async def review(_context: Any, _arguments: Any, **prepared: Any) -> bool:
        reviewed.append(prepared)
        arrived.set()
        await answer.wait()
        return False

    (tmp_path / "sub").mkdir()
    async with started_shell(tmp_path, review_shell=review) as shell:
        call = shell.call({"command": "echo safe", "env": {"PUBLIC": "value"}, "workdir": "sub/.."})
        await asyncio.wait_for(arrived.wait(), timeout=2)
        assert shell.launcher.processes == []
        assert reviewed[0]["command"] == "echo safe"
        assert reviewed[0]["cwd"] == tmp_path.resolve()
        assert reviewed[0]["environment"] == {"PUBLIC": "value"}
        answer.set()
        result = await call
        assert result["error"]["code"] == "command_not_approved"
        assert shell.launcher.processes == []

    reviewed.clear()
    async with started_shell(
        tmp_path,
        review_shell=review,
        analyzer=FakeAnalyzer(plan("git push origin")),
        permissions=restricted(tmp_path, deny=["Shell(git push *)"]),
    ) as shell:
        result = await shell.call({"command": "git push origin"})
        assert result["error"]["code"] == "permission_denied"
        assert reviewed == [] and shell.launcher.processes == []


@pytest.mark.asyncio
async def test_full_access_review_cannot_launch_in_a_retargeted_workdir(tmp_path: Path) -> None:
    original, other, link = tmp_path / "original", tmp_path / "other", tmp_path / "link"
    original.mkdir()
    other.mkdir()
    link_directory(link, original)

    async def review(_context: Any, _arguments: Any, **prepared: Any) -> bool:
        assert prepared["cwd"] == original.resolve()
        if os.name == "nt":
            link.rmdir()
        else:
            link.unlink()
        link_directory(link, other)
        return True

    async with started_shell(tmp_path, review_shell=review) as shell:
        result = await shell.call({"command": "echo safe", "workdir": str(link)})
        assert result["error"]["code"] == "invalid_arguments"
        assert shell.launcher.processes == []


@pytest.mark.parametrize(
    ("rules", "analysis", "fragment"),
    [
        pytest.param(
            {"deny": ["Shell(git push *)"]},
            plan("git push origin main"),
            "the rule Shell(git push *) denies it",
            id="denied-command",
        ),
        pytest.param(
            {"commands": "listed", "allow": ["Shell(git status)"]},
            plan("git status", "rm notes.txt"),
            'running "rm notes.txt", because only commands that match an allow rule can run',
            id="unlisted-command",
        ),
        pytest.param(
            {},
            plan("cp a b", writes=[Path("/elsewhere/b")]),
            "outside the folders you can change",
            id="write-outside",
        ),
        pytest.param(
            {"deny": ["Read({workdir}/secrets/**)"]},
            plan("cat secrets/key", reads=[Path("secrets/key")]),
            "denies it",
            id="denied-read",
        ),
        pytest.param(
            {"deny": ["Read({workdir}/secrets/**)"]},
            plan("rm -r .", subtree_writes=[Path(".")]),
            "/secrets, which the rule Read(",
            id="subtree-write-over-denied-folder",
        ),
        pytest.param(
            {"deny": ["Read({workdir}/secrets/**)"]},
            plan("rg x", subtree_reads=[Path(".")]),
            "/secrets/**) denies. Use search_files, "
            "which leaves denied folders out, or name only the folders the command needs.",
            id="recursive-read-over-denied-folder",
        ),
        pytest.param(
            {"web": "listed", "allow": ["Web(example.com)"]},
            plan("ssh git.example.org", hosts=["git.example.org"]),
            "the permission rules refuse connecting to git.example.org",
            id="unlisted-host",
        ),
        pytest.param(
            {},
            plan(
                "cd",
                unresolved=[UnresolvedElement("cwd", "$d", "the folder is computed when it runs")],
            ),
            "Change into folders by their literal path, or pass the folder as workdir.",
            id="unresolved-folder",
        ),
        pytest.param(
            {},
            plan(
                "iwr",
                unresolved=[UnresolvedElement("url", "$u", "the address is computed when it runs")],
            ),
            "so the check cannot tell which address it reaches. "
            "Write each address literally in the command.",
            id="unresolved-address",
        ),
        pytest.param({}, plan("vbot agent list"), "vBot's own command line", id="vbot-cli"),
        pytest.param(
            {},
            plan("curl", urls=[f"http://127.0.0.1:{PORT}/api/agents"]),
            "it is the vBot server itself",
            id="loopback-url",
        ),
        pytest.param(
            {},
            plan(f"nc localhost {PORT}"),
            "it is the vBot server itself",
            id="loopback-host-and-port",
        ),
        pytest.param(
            {},
            plan(
                "cat",
                unresolved=[
                    UnresolvedElement("path_read", "$f", "the path is computed when it runs")
                ],
            ),
            "the path is computed when it runs ($f), so the check cannot tell what it reads. "
            "Write each path literally in the command.",
            id="unresolved",
        ),
        pytest.param(
            {}, UNAVAILABLE, "vBot could not analyze it to check it", id="analysis-unavailable"
        ),
    ],
)
@pytest.mark.asyncio
async def test_restricted_calls_the_rules_refuse_launch_nothing(
    tmp_path: Path, rules: dict[str, object], analysis: object, fragment: str
) -> None:
    analyzer = FakeAnalyzer()
    analyzer.result = analysis  # type: ignore[assignment]
    async with started_shell(
        tmp_path, analyzer=analyzer, permissions=restricted(tmp_path, **rules)
    ) as shell:
        result = await shell.call({"command": "the command", "run_in_background": True})

    assert result["error"]["code"] == "permission_denied", result
    # Only a failed analysis can pass when the same call is sent again.
    assert result["error"]["retryable"] is (analysis is UNAVAILABLE)
    assert fragment in result["error"]["message"]
    assert result["error"]["message"].startswith(f"{SHELL_MODEL_NAME} was not run: ")
    assert shell.launcher.argv == []
    # The analysis saw the call's command in its working directory.
    assert [(line, cwd) for line, _shell, cwd, _env in analyzer.lines] == [
        ("the command", tmp_path)
    ]


@pytest.mark.asyncio
async def test_restricted_shell_keeps_cli_grant_through_review_and_releases_it_after_exit(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    analyzer = FakeAnalyzer(plan("vbot server status"))
    assert not isinstance(analyzer.result, Exception)
    analyzer.result = replace(
        analyzer.result,
        commands=(replace(analyzer.result.commands[0], instance_cli=True),),
    )
    cli = Mock(allows=AsyncMock(return_value=True))
    grant = cli.issue.return_value
    grant.environment_value = "grant-for-this-call"
    grant.reviewing = True
    release_review = asyncio.Event()
    grant.wait_for_reviews = AsyncMock(side_effect=release_review.wait)
    monkeypatch.setattr(shell_environment, "_reviewed_cli_directory", tmp_path / "reviewed")
    async with started_shell(
        tmp_path, shell_cli=cli, analyzer=analyzer, permissions=restricted(tmp_path)
    ) as shell:
        call = shell.call({"command": "vbot server status", "timeout": 1})
        process = await shell.started()
        command, env = launched(shell.launcher)
        assert command == "vbot server status"
        assert env["VBOT_SHELL_CLI"] == grant.environment_value
        assert env["PATH"].split(os.pathsep)[0] == str(tmp_path / "reviewed")
        assert not {"VBOT_RUN_AGENT_ID", "VBOT_SERVER_PORT", "VBOT_DATA_DIR"} & env.keys()
        await shell.commands.advance(2)
        await shell.commands.advance(1)
        assert not call.done()
        grant.release.assert_not_called()
        grant.reviewing = False
        release_review.set()
        process.exit(0)
        assert data(await shell.returned(call))["status"] == "exited"
        await shell.commands.advance(1)
        grant.release.assert_called_once()
        grant.release.reset_mock()
        cli.allows.return_value = False
        refused = await shell.call({"command": "vbot server status"})
        assert refused["error"]["code"] == "permission_denied"
        assert len(shell.launcher.processes) == 1
        cli.issue.assert_called_once()


@pytest.mark.asyncio
async def test_a_restricted_shell_starts_only_in_its_area_without_vbot_control_or_credentials(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("VBOT_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("VBOT_SERVER_PORT", str(PORT))
    # The server's environment carries credentials vBot knows and a variable of the user's.
    login = shell_environment._login_environment
    server = {"OPENAI_API_KEY": "sk-server", "API_TOKEN": "server-token", "FLAVOR": "release"}
    monkeypatch.setattr(shell_environment, "_login_environment", lambda: {**login(), **server})
    outside = tmp_path.parent / f"{tmp_path.name}-outside"
    outside.mkdir()
    handoffs = UpdateHandoffs(tmp_path / "data")
    analyzer = FakeAnalyzer(plan("build"))
    async with started_shell(
        tmp_path,
        analyzer=analyzer,
        permissions=restricted(tmp_path),
        update_handoffs=handoffs,
        credential_names=frozenset({"OPENAI_API_KEY", "API_TOKEN"}),
    ) as shell:
        refused = await shell.call({"command": "build", "workdir": str(outside)})
        # Not granted, so not inherited either: the call says so instead of running without it.
        ungranted = await shell.returned(
            shell.call({"command": "build", "env_keys": ["OPENAI_API_KEY"]})
        )
        call = shell.call({"command": "build", "env": {"MODE": "ci"}, "env_keys": ["API_TOKEN"]})
        (await shell.started()).exit(0)
        assert data(await shell.returned(call))["status"] == "exited"

    assert refused["error"]["code"] == "permission_denied"
    assert "working in" in refused["error"]["message"]
    assert ungranted["error"]["code"] == "invalid_arguments"
    assert len(shell.launcher.processes) == 1
    command, env = launched(shell.launcher)
    assert (command, env["MODE"], env["FLAVOR"]) == ("build", "ci", "release")
    # A granted credential arrives as resolved for the call; the other one not at all.
    assert env["API_TOKEN"] == "value-of-API_TOKEN"
    assert not {
        "OPENAI_API_KEY",
        "VBOT_DATA_DIR",
        "VBOT_SERVER_PORT",
        "VBOT_RUN_AGENT_ID",
        "VBOT_RUN_SESSION_ID",
        "VBOT_RUN_PROJECT_ID",
        "VBOT_UPDATE_HANDOFF",
    } & set(env)
    # The analysis expanded the call's own variables, in the same confined environment.
    assert analyzer.lines[-1][3]["MODE"] == "ci"
    assert not {"VBOT_DATA_DIR", "OPENAI_API_KEY"} & set(analyzer.lines[-1][3])


@pytest.mark.asyncio
async def test_full_access_runs_commands_without_analyzing_them(
    shell: Shell, monkeypatch: pytest.MonkeyPatch
) -> None:
    loop_thread = threading.get_ident()
    confined_environments: list[bool] = []
    environment = shell_module.command_environment
    directory = _shell_arguments.is_dir_strict

    def build_environment(*args: Any, **kwargs: Any) -> Any:
        assert threading.get_ident() != loop_thread
        confined_environments.append(kwargs.get("confined", False))
        return environment(*args, **kwargs)

    def check_directory(path: Path) -> bool:
        assert threading.get_ident() != loop_thread
        return directory(path)

    def inherited(name: str) -> str:
        assert threading.get_ident() != loop_thread
        return "public-value"

    monkeypatch.setattr(shell_module, "command_environment", build_environment)
    monkeypatch.setattr(_shell_arguments, "is_dir_strict", check_directory)
    monkeypatch.setattr(_shell_arguments, "inherited_value", inherited)
    call = shell.call({"command": "vbot agent list", "env_keys": ["PUBLIC"]})
    (await shell.started()).exit(0)
    assert data(await shell.returned(call))["status"] == "exited"

    assert shell.checker.analyzer_started is False
    assert confined_environments == [False]
