"""The read Tool: definition, paths, directories, text windows, media, and documents."""

from __future__ import annotations

import base64
import os
import re
from dataclasses import replace
from pathlib import Path
from typing import Any

import pytest

import core.tools._command_decoding as command_decoding_module
import core.tools._read_text as read_text_module
import core.tools.read as read_module
import core.tools.read_extract as read_extract_module
from core.model_tasks import SpeechError
from core.permissions import (
    BoundaryContext,
    PermissionBoundary,
    PermissionDenied,
    normalize_permission_rules,
)
from core.sessions import SessionAddress
from core.tools import (
    READ_TOOL_NAME,
    READ_TOOL_PARAMETERS,
    ChangeTracker,
    FileReadState,
    ToolContractError,
    ToolRegistry,
    tool_failure_for_exception,
)
from core.tools.file_state import StaleReason
from core.tools.search_files import register_search_files_tool
from tests.core.tools.file_state_test_support import held_by_another_program
from tests.core.tools.read_test_support import (
    FakeAttachmentStore,
    FakeSpeech,
    binary_notice,
    content,
    docx_bytes,
    failure,
    ipynb_bytes,
    make_context,
    pdf_bytes,
    read,
    read_registry,
    xlsx_bytes,
)

_WINDOWS_ONLY = pytest.mark.skipif(os.name != "nt", reason="Windows sharing and lock violations")


def test_register_read_tool_exposes_provider_schema_without_description_property() -> None:
    registry = read_registry()

    tool = registry.get("read")
    assert tool.name == READ_TOOL_NAME == "read"
    assert tool.parameters == READ_TOOL_PARAMETERS

    definitions = registry.provider_definitions(["read"])
    assert len(definitions) == 1
    definition = definitions[0]
    assert set(definition) == {"name", "description", "parameters"}
    assert definition["name"] == "read"

    parameters = definition["parameters"]
    assert parameters["type"] == "object"
    assert parameters["required"] == ["path"]
    assert "additionalProperties" not in parameters
    assert set(parameters["properties"]) == {"path", "offset", "limit", "encoding"}
    assert parameters["properties"]["offset"]["type"] == "integer"
    assert "description" not in parameters["properties"]

    ranged_display = registry.display_for_call(
        "read", {"path": "notes.txt", "offset": 170, "limit": 111}
    )
    default_display = registry.display_for_call("read", {"path": "notes.txt"})
    continued_display = registry.display_for_call(
        "read", {"path": "notes.txt", "offset": "170:42", "limit": 10}
    )
    dialect_display = registry.display_for_call(
        "read", {"file_path": "notes.txt", "start_line": 5, "end_line": 9}
    )
    # A digit int() cannot read is no line number, not a crash.
    unclear_display = registry.display_for_call("read", {"path": "notes.txt", "offset": "\u00b2"})
    assert ranged_display["facts"] == [{"kind": "line_range", "start": 170, "end": 280}]
    assert default_display["facts"] == []
    assert continued_display["facts"] == [{"kind": "line_range", "start": 170, "end": 179}]
    assert dialect_display["facts"] == [{"kind": "line_range", "start": 5, "end": 9}]
    assert unclear_display["facts"] == []
    assert dialect_display["primary"][0]["value"] == "notes.txt"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("in_repo", "path", "expected"),
    [
        (False, "notes.txt", "1| workspace copy\n"),
        # With a working directory set, a relative path reads its copy, not the workspace's.
        (True, "notes.txt", "1| repo copy\n"),
        (False, "outside.txt", "1| absolute\n2| path\n"),
    ],
)
async def test_paths_resolve_from_the_working_directory_or_are_absolute(
    tmp_path: Path, in_repo: bool, path: str, expected: str
) -> None:
    workspace = tmp_path / "workspace"
    repo = tmp_path / "repo"
    workspace.mkdir()
    repo.mkdir()
    workspace.joinpath("notes.txt").write_bytes(b"workspace copy\n")
    repo.joinpath("notes.txt").write_bytes(b"repo copy\n")
    tmp_path.joinpath("outside.txt").write_bytes(b"absolute\npath\n")
    if path == "outside.txt":
        path = str(tmp_path / path)
    store = FakeAttachmentStore()
    context = make_context(workspace, cwd=repo if in_repo else None)

    result = await read(workspace, {"path": path}, context=context, store=store)

    assert content(result) == expected
    assert store.stored == []


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("arguments", "refusal"),
    [
        pytest.param({"path": ""}, "path", id="empty-path"),
        pytest.param({"path": "   "}, "path", id="blank-path"),
        pytest.param({"file_path": " \t "}, "path", id="blank-path-alias"),
        pytest.param(
            {"path": "notes.txt", "mode": "bytes"},
            '"mode" is not a parameter',
            id="unknown-mode",
        ),
        # A NUL makes no path on any platform; the refusal must not depend on
        # whether this host's filesystem layer raises for it or ignores it.
        pytest.param(
            {"path": "notes.txt\x00"},
            re.escape(
                'read was not run: the path "notes.txt\\u0000" contains a NUL character '
                "(U+0000), which no file path can contain. Remove it and call read again."
            ),
            id="nul-in-path",
        ),
    ],
)
async def test_read_refuses_invalid_arguments_before_reading(
    tmp_path: Path, arguments: dict[str, Any], refusal: str
) -> None:
    target = tmp_path / "notes.txt"
    target.write_bytes(b"hello\n")
    file_state = FileReadState()

    with pytest.raises(ToolContractError, match=refusal):
        await read(tmp_path, arguments, file_state=file_state)

    assert file_state.check_stale("session-1", target.resolve()) is StaleReason.NEVER_READ


@pytest.mark.asyncio
async def test_a_missing_file_suggests_ranked_similar_paths(tmp_path: Path) -> None:
    ranked = tmp_path / "ranked"
    ranked.mkdir()
    for name in ["settings.yaml", "settngs.txt", "release-notes.md"]:
        ranked.joinpath(name).write_text(name, encoding="utf-8")
    ranked.joinpath("settings.txt.backup").mkdir()
    many = tmp_path / "many"
    many.mkdir()
    for index in range(8):
        many.joinpath(f"settings-{index}.txt").write_text("candidate", encoding="utf-8")

    for folder in ("tests", "tests/deep", ".hidden", "node_modules"):
        tmp_path.joinpath(folder).mkdir()
        tmp_path.joinpath(folder, "corpus.py").write_text("x", encoding="utf-8")
    modules = tmp_path / "modules"
    modules.mkdir()
    for name in ["ast.py", "lexer.py", "shell.py", "analyzer.py", "parsers.py", "parser.md"]:
        modules.joinpath(name).write_text(name, encoding="utf-8")
    checks = tmp_path / "checks"
    checks.mkdir()
    for name in ["test_index.py", "test_api.py", "test_errors.py", "test_shell.py", "test_exrp.py"]:
        checks.joinpath(name).write_text(name, encoding="utf-8")

    message = failure(await read(tmp_path, {"path": "ranked/settings.txt"}), "file_not_found")
    bounded = failure(await read(tmp_path, {"path": "many/settings.txt"}), "file_not_found")
    elsewhere = failure(await read(tmp_path, {"path": "corpus.py"}), "file_not_found")
    module = failure(await read(tmp_path, {"path": "modules/parser.py"}), "file_not_found")
    prefixed = failure(await read(tmp_path, {"path": "checks/test_expr.py"}), "file_not_found")

    # Same stem first, then files or directories beside it; never unrelated names
    # or the absolute path.
    assert message == (
        "File not found: ranked/settings.txt (similar: ranked/settings.yaml, "
        "ranked/settings.txt.backup, ranked/settngs.txt)."
    )
    assert bounded.count("settings-") == 5
    # The same name in other folders, shallow ones first; hidden and dependency
    # folders are not searched.
    assert (
        elsewhere == "File not found: corpus.py (similar: tests/corpus.py, tests/deep/corpus.py)."
    )
    # A shared extension makes no name similar; the stem or the whole name has to be.
    suggested = module.partition("(similar: ")[2].rstrip(").").split(", ")
    assert suggested == ["modules/parser.md", "modules/parsers.py"]
    # Nor does a shared beginning: only a name a few typos away is similar.
    assert prefixed == "File not found: checks/test_expr.py (similar: checks/test_exrp.py)."


@pytest.mark.asyncio
async def test_a_missing_file_without_similar_names_names_the_listing_call(tmp_path: Path) -> None:
    (tmp_path / "docs").mkdir()
    tmp_path.joinpath("docs/zeta.md").write_text("z", encoding="utf-8")

    in_existing = await read(tmp_path, {"path": "docs/alpha.txt"})
    in_missing = await read(tmp_path, {"path": "gone/alpha.txt"})

    assert failure(in_existing, "file_not_found") == (
        'File not found: docs/alpha.txt. read(path="docs") lists its directory.'
    )
    assert failure(in_missing, "file_not_found") == (
        "File not found: gone/alpha.txt. Its directory gone does not exist."
    )


@pytest.mark.asyncio
async def test_a_directory_is_listed_and_paged_without_being_stamped(tmp_path: Path) -> None:
    folder = tmp_path / "folder"
    (folder / "Sub").mkdir(parents=True)
    # Sizes: bytes below 1 KB, one decimal below 10 units, whole units from 10 up.
    sizes = {"b.txt": 12 * 1024 + 300, "a.py": 1536, ".hidden": 7, "c.bin": 1024 * 1024 - 1}
    for name, size in sizes.items():
        folder.joinpath(name).write_bytes(b"x" * size)
    many = tmp_path / "many"
    many.mkdir()
    for index in range(1, 8):
        many.joinpath(f"f{index}.txt").write_text("x", encoding="utf-8")
    (tmp_path / "empty").mkdir()
    file_state = FileReadState()

    listing = await read(tmp_path, {"path": "folder"}, file_state=file_state)
    first = await read(tmp_path, {"path": "many", "limit": 3})
    last = await read(tmp_path, {"path": "many", "offset": -2})
    nothing = await read(tmp_path, {"path": "empty"})

    assert content(listing) == (
        "Directory folder/ (5 entries):\n.hidden  7 B\na.py  1.5 KB\nb.txt  12 KB\n"
        "c.bin  1.0 MB\nSub/"
    )
    assert file_state.check_stale("session-1", folder.resolve()) is StaleReason.NEVER_READ
    assert content(first) == (
        "Directory many/ (7 entries):\nf1.txt  1 B\nf2.txt  1 B\nf3.txt  1 B\n"
        "[Showing entries 1-3 of 7. Use offset=4 to continue.]"
    )
    assert content(last) == "Directory many/ (7 entries):\nf6.txt  1 B\nf7.txt  1 B"
    assert content(nothing) == "empty/ is an empty directory."
    assert first["data"]["next_offset"] == 4
    for complete in (listing, last, nothing):
        assert "next_offset" not in complete["data"]


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "cause",
    [
        "open-fails",
        "denied",
        # Windows reports a file another program holds or locks as "permission denied".
        pytest.param("open", marks=_WINDOWS_ONLY),
        pytest.param("lock", marks=_WINDOWS_ONLY),
    ],
)
async def test_a_read_time_filesystem_error_names_the_reason(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    deny_access,
    cause: str,
) -> None:
    notes = tmp_path.joinpath("notes.txt")
    notes.write_bytes(b"hello\n")

    def raise_permission_error(self: Path, *args: object, **kwargs: object) -> Any:
        raise PermissionError("access denied while reading")

    if cause in {"open", "lock"}:
        with held_by_another_program(notes, "lock" if cause == "lock" else "open"):
            result = await read(tmp_path, {"path": "notes.txt"})
        assert failure(result, "file_read_error") == (
            "Could not read notes.txt: another program is using it."
        )
        return
    if cause == "denied":
        deny_access(notes)
    else:
        monkeypatch.setattr(Path, "open", raise_permission_error)

    result = await read(tmp_path, {"path": "notes.txt"})

    assert "notes.txt" in failure(result, "file_read_error")


@pytest.mark.asyncio
async def test_permission_rules_refuse_a_read_before_the_file_is_touched(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    work = tmp_path / "work"
    work.mkdir()
    secret = tmp_path / "outside" / "secret.txt"
    secret.parent.mkdir()
    secret.write_bytes(b"secret")
    boundary = PermissionBoundary.build(
        normalize_permission_rules({"read": "work_area"}),
        BoundaryContext(workdir=work, home=tmp_path / "home", data_dir=tmp_path / "data"),
    )
    context = replace(make_context(work, cwd=work), permissions=boundary)
    file_state = FileReadState()

    def untouched(*_args: object, **_kwargs: object) -> Any:
        raise AssertionError("the refused file was accessed")

    registry = read_registry(file_state=file_state)
    for name in ("open", "stat", "resolve", "read_bytes"):
        monkeypatch.setattr(Path, name, untouched)
    with pytest.raises(PermissionDenied) as refused:
        await registry.dispatch(context, {"path": str(secret)})
    monkeypatch.undo()
    # Tool execution turns the refusal into the envelope the Model reads.
    result = tool_failure_for_exception(READ_TOOL_NAME, refused.value)

    message = failure(result, "permission_denied")
    assert result["error"]["retryable"] is False
    assert secret.as_posix() in message and "permission rules" in message
    assert file_state.check_stale("session-1", secret.resolve()) is StaleReason.NEVER_READ


@pytest.mark.asyncio
async def test_approval_is_limited_to_the_prepared_read(tmp_path: Path) -> None:
    work = tmp_path / "work"
    work.mkdir()
    outside = tmp_path / "outside"
    outside.mkdir()
    target = outside / "notes.txt"
    target.write_text("approved content", encoding="utf-8")
    boundary = PermissionBoundary.build(
        normalize_permission_rules({"read": "work_area"}),
        BoundaryContext(workdir=work, home=tmp_path / "home", data_dir=tmp_path / "data"),
    )
    calls: list[Any] = []

    async def approve(
        _context: Any, _reason: str, requirements: Any, _arguments: Any, _cwd: Any
    ) -> bool:
        calls.append(requirements)
        return True

    async def refresh(_force: bool) -> tuple[PermissionBoundary, dict[str, Any]]:
        return boundary, {"computer_id": "server", "allowed_computer_ids": ["server"]}

    ctx = replace(
        make_context(work, cwd=work),
        permissions=boundary,
        approval_hook=approve,
        approval_refresh_hook=refresh,
    )
    result = await read_registry().dispatch(ctx, {"path": str(target)})
    assert "approved content" in content(result)
    assert len(calls) == 1 and len(calls[0]) == 1
    sibling = replace(make_context(work, cwd=work), permissions=boundary)
    with pytest.raises(PermissionDenied):
        await read_registry().dispatch(sibling, {"path": str(target)})


@pytest.mark.asyncio
@pytest.mark.parametrize("missing", ["plan.md", "secret"])
async def test_permission_rules_name_refused_entries_in_listings_and_suggestions(
    tmp_path: Path, missing: str
) -> None:
    work = tmp_path / "work"
    (work / "secrets").mkdir(parents=True)
    (work / "secrets" / "plan.md").write_text("x", encoding="utf-8")
    (work / "notes.txt").write_text("x", encoding="utf-8")
    for index in range(6):
        (work / f"{index}.key").write_text("x", encoding="utf-8")
    rules = {"read": "work_area", "deny": ["Read({workdir}/secrets/**)", "Read({workdir}/*.key)"]}
    boundary = PermissionBoundary.build(
        normalize_permission_rules(rules),
        BoundaryContext(workdir=work, home=tmp_path / "home", data_dir=tmp_path / "data"),
    )
    restricted = replace(make_context(work, cwd=work), permissions=boundary)
    full = make_context(work, cwd=work)

    listing = content(await read(work, {"path": "."}, context=restricted))
    hidden = failure(await read(work, {"path": missing}, context=restricted), "file_not_found")
    shown = failure(await read(work, {"path": missing}, context=full), "file_not_found")

    entries, note = listing.rsplit("\n", 1)
    assert "notes.txt" in entries and "secrets" not in entries
    # The note names the refused entries, so the Agent knows they exist but are refused;
    # past its bound it counts the rest and still names the folder.
    assert "secrets/" in note and "0.key" in note and "5.key" not in note
    assert "more" in note and "permission rules" in note
    assert "secrets" in content(await read(work, {"path": "."}, context=full))
    assert "secrets" in shown
    if missing == "secret":
        # A similar entry beside the missing path is named as refused, as the listing names it.
        assert "secrets" in hidden and "permission rules" in hidden
    else:
        # What lies inside the refused folder stays unknown to the restricted Session.
        assert "secrets" not in hidden


_ELEVEN = "".join(f"line{i}\n" for i in range(1, 12))


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("name", "raw", "expected"),
    [
        # The unpadded gutter numbers every line, blanks included, and rolls from
        # single to multiple digits.
        (
            "code.txt",
            f"start\n\n{_ELEVEN}".encode(),
            "1| start\n2| \n" + "".join(f"{i + 2}| line{i}\n" for i in range(1, 12)),
        ),
        # The separator space tells the gutter from source text starting with a pipe.
        (
            "table.md",
            b"| Variant | Focus |\n|---|---|\n",
            "1| | Variant | Focus |\n2| |---|---|\n",
        ),
        ("bom.txt", b"\xef\xbb\xbfhello\nworld\n", "1| hello\n2| world\n"),
        ("empty.txt", b"", "[empty.txt is empty.]"),
        ("data.bin", b"\x7fELF\x00\x00\x01payload", binary_notice("data.bin")),
        # Text that starts like a media file is still text.
        *[
            ("notes.md", f"{first}\nsecond\n".encode(), f"1| {first}\n2| second\n")
            for first in ["ID3 tags", "OggS notes", "fLaC header", "GIF8 frames", "GIF89a version"]
        ],
    ],
    ids=[
        "numbering",
        "leading_pipe",
        "bom",
        "empty",
        "nul_byte",
        *["id3", "ogg", "flac", "gif8", "gif89a"],
    ],
)
async def test_text_files_are_shown_with_a_line_number_gutter(
    tmp_path: Path, name: str, raw: bytes, expected: str
) -> None:
    tmp_path.joinpath(name).write_bytes(raw)
    speech = FakeSpeech()
    context = make_context(tmp_path)

    result = await read(tmp_path, {"path": name}, context=context, speech=speech)

    assert content(result) == expected
    assert speech.calls == []
    assert context.result_media == []


@pytest.mark.asyncio
@pytest.mark.parametrize("separator", ["\f", "\v", "\x1c", "\x85", " ", " "])
async def test_line_numbers_break_only_at_lf_crlf_and_cr_like_search_files(
    tmp_path: Path, separator: str
) -> None:
    raw = f"import os\n{separator}\ndef foo():\r\n    pass\nx = 1\n".encode()
    tmp_path.joinpath("ff.py").write_bytes(raw)
    search = ToolRegistry()
    register_search_files_tool(search)

    whole = content(await read(tmp_path, {"path": "ff.py"}))
    line = content(await read(tmp_path, {"path": "ff.py", "offset": 4, "limit": 1}))
    found = await search.dispatch(make_context(tmp_path, "search_files"), {"args": ["pass"]})

    assert whole == f"1| import os\n2| {separator}\n3| def foo():\n4|     pass\n5| x = 1\n"
    assert line.startswith("4|     pass\n")
    assert found["data"]["content"] == "ff.py\n4:    pass"
    assert read_module.render_text_file(raw) == whole


@pytest.mark.asyncio
async def test_streaming_text_matches_byte_renderer_across_chunked_line_endings(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    raw = b"\xef\xbb\xbf" + "alpha\r\nbeta\rgamma delta".encode()
    tmp_path.joinpath("line-endings.txt").write_bytes(raw)
    monkeypatch.setattr(read_text_module, "_TEXT_STREAM_CHUNK_CHARACTERS", 2)

    result = await read(tmp_path, {"path": "line-endings.txt"})

    assert content(result) == read_module.render_text_file(raw)


# wsl.exe -l on a German Windows, as it writes it to a pipe: UTF-16LE, no byte order mark.
_WSL_LIST = "Windows Subsystem für Linux-Distributionen:\r\nUbuntu (Standard)\r\ndocker-desktop\r\n"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("raw", "text", "utf16_lines", "nul"),
    [
        (_WSL_LIST.encode("utf-16-le"), _WSL_LIST, "1-3", False),
        # Between the command's own UTF-8 output, at an odd byte offset.
        (
            "start ä\r\n".encode() + _WSL_LIST.encode("utf-16-le") + b"end\r\n",
            f"start ä\r\n{_WSL_LIST}end\r\n",
            "2-4",
            False,
        ),
        # Text beyond U+00FF decodes after a byte order mark, which applies to its
        # own text only: the UTF-8 after it stays UTF-8, also mid-file.
        (
            "\ufeffДистрибутивы:\r\nUbuntu\r\n".encode("utf-16-le") + "готово ä\r\n".encode(),
            "Дистрибутивы:\r\nUbuntu\r\nготово ä\r\n",
            "1-2",
            False,
        ),
        (
            b"start\r\n" + "\ufeff中文 text\r\nUbuntu\r\n".encode("utf-16-le") + b"end\r\n",
            "start\r\n中文 text\r\nUbuntu\r\nend\r\n",
            "2-3",
            False,
        ),
        # Valid UTF-8 before a NUL stays as written; the stray NUL is left out.
        ("Größe: ä\x00\r\nUbuntu\r\n".encode(), "Größe: ä\r\nUbuntu\r\n", None, True),
        (b"ok\nUbuntu\n", "ok\nUbuntu\n", None, False),
        # Output that starts like an image still reads as the text it is.
        (b"\x89PNG\r\nUbuntu\r\n", "\ufffdPNG\r\nUbuntu\r\n", None, False),
        *[
            pytest.param(
                ("\ufeff" + source).encode(encoding),
                source,
                "1" if "\n" not in source.rstrip("\n") else "1-2",
                False,
                id=f"{encoding}-{kind}",
            )
            for encoding in ("utf-16-le", "utf-16-be")
            for kind, source in (
                ("cjk", "你好\n"),
                ("no-final-lf", "你好"),
                ("later-cjk", "Ubuntu\n你好\n"),
                ("lf-cr-bytes", "Ubuntu\n上不\u0a4e\u0d4e\n"),
                ("surrogate", "Ubuntu\n😀\n"),
                ("long-cjk", "Ubuntu\n" + "你好" * 300 + "\n"),
            )
        ],
        # Real Linux child-process bytes: both byte orders between UTF-8 runs.
        pytest.param(
            bytes.fromhex(
                "6865616420ceb10afffe2d4e87650a00666f6f7465720afeff03a94e2d000ac3a4e282acf09f98800a"
            ),
            "head α\n中文\nfooter\nΩ中\nä€😀\n",
            "2 and 4",
            False,
            id="mixed-byte-orders",
        ),
    ],
    ids=[
        "utf16le",
        "between_utf8",
        "bom_then_utf8",
        "bom_mid_file",
        "utf8_before_nul",
        "utf8",
        "starts_like_png",
        *[None] * 13,
    ],
)
async def test_a_command_log_reads_as_the_text_its_programs_wrote(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    raw: bytes,
    text: str,
    utf16_lines: str | None,
    nul: bool,
) -> None:
    monkeypatch.setattr(command_decoding_module, "windows_ansi_encoding", lambda: None)
    # The data directory is beside the workspace.
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    logs = make_context(workspace).data_root / "artifacts" / "temp" / "commands"
    logs.mkdir(parents=True)
    log = logs / "tmp_0123456789ab.log"
    log.write_bytes(raw)
    # Small odd chunks split characters and line ends between reads.
    monkeypatch.setattr(read_text_module, "_DECODING_CHUNK_BYTES", 3)
    lines = text.splitlines()
    selected = next(
        (number for number, line in enumerate(lines, 1) if line.startswith("Ubuntu")), 1
    )
    utf16_numbers: set[int] = set()
    for match in re.finditer(r"(\d+)(?:-(\d+))?", utf16_lines or ""):
        utf16_numbers.update(range(int(match[1]), int(match[2] or match[1]) + 1))

    whole = content(await read(workspace, {"path": str(log)}))
    last = content(await read(workspace, {"path": str(log), "offset": -1}))
    found = content(
        await read(workspace, {"path": str(log), "pattern": re.escape(lines[selected - 1])})
    )

    # A NUL byte makes no command log binary; the result names the lines decoded
    # as UTF-16 and those whose NUL bytes are left out, among the lines it shows.
    numbered = "".join(f"{number}| {line}\n" for number, line in enumerate(lines, 1))
    if not text.endswith(("\n", "\r")):
        numbered = numbered.removesuffix("\n")
    if utf16_lines or nul:
        note, rest = whole.split("\n", 1)
        assert (f" {utf16_lines} " in note and "UTF-16" in note) == bool(utf16_lines)
        assert ("NUL" in note) == nul
        assert rest == numbered
    else:
        assert whole == numbered
    assert last.splitlines()[-1] == f"{len(lines)}| {lines[-1]}"
    assert ("decoded as UTF-16" in last) == (len(lines) in utf16_numbers)
    # A search sees the text a read shows.
    assert f"\n{selected}| {lines[selected - 1]}" in found
    assert ("decoded as UTF-16" in found) == (selected in utf16_numbers)
    assert log.read_bytes() == raw


@pytest.mark.asyncio
async def test_command_log_ansi_inference_is_scoped_to_shown_lines_and_command_logs(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setattr(command_decoding_module, "windows_ansi_encoding", lambda: "cp1252")
    monkeypatch.setattr(read_text_module, "_DECODING_CHUNK_BYTES", 1)
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    logs = make_context(workspace).data_root / "artifacts" / "temp" / "commands"
    logs.mkdir(parents=True)
    path = logs / "output.log"
    raw = "utf8 ä\n".encode() + b"pg_ctl: kein Server l\xe4uft\n" + b"last\n"
    path.write_bytes(raw)
    for window in ({}, {"offset": 2, "limit": 1}, {"pattern": "läuft"}):
        shown = content(await read(workspace, {"path": str(path), **window}))
        assert "cp1252" in shown.splitlines()[0]
        assert "2| pg_ctl: kein Server läuft" in shown
    for window in ({"offset": -1}, {"limit": 1}):
        assert "cp1252" not in content(await read(workspace, {"path": str(path), **window}))
    explicit = content(await read(workspace, {"path": str(path), "encoding": "utf-8"}))
    assert "cp1252" not in explicit and "2| pg_ctl: kein Server l\ufffduft" in explicit
    ordinary = workspace / "ordinary.txt"
    ordinary.write_bytes(raw)
    ordinary_shown = content(await read(workspace, {"path": str(ordinary)}))
    assert ordinary_shown.split("\n", 1)[1] == explicit
    assert "encoding" in ordinary_shown.splitlines()[0]
    assert path.read_bytes() == raw


@pytest.mark.asyncio
@pytest.mark.parametrize("chunk_bytes", [1, 65536])
@pytest.mark.parametrize("newline", [b"\n", b"\r\n", b"\r"])
async def test_invalid_utf8_is_named_only_for_shown_lines(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, chunk_bytes: int, newline: bytes
) -> None:
    monkeypatch.setattr(read_text_module, "_DECODING_CHUNK_BYTES", chunk_bytes)
    monkeypatch.setattr(read_text_module, "_TEXT_STREAM_CHUNK_CHARACTERS", chunk_bytes)
    path = tmp_path / "ordinary.txt"
    # A literal replacement character is valid text; a truncated multibyte
    # sequence is one replacement, even across raw decoder chunk boundaries.
    raw = newline.join(["literal �".encode(), b"bad \xe2\x82", b"clean", b"bad \xff", b"end"])
    path.write_bytes(raw)
    for window, affected in (
        ({}, [2, 4]),
        ({"offset": 2, "limit": 1}, [2]),
        ({"pattern": "bad"}, [2, 4]),
        ({"pattern": "�"}, [2, 4]),
    ):
        shown = content(await read(tmp_path, {"path": path.name, **window}))
        note = shown.splitlines()[0]
        assert [int(n) for n in re.findall(r"\b[24]\b", note)] == affected
        assert "encoding" in note and '"cp1252"' in note
        assert "2| bad �" in shown and "bad ��" not in shown
    for window in ({"limit": 1}, {"offset": -1}, {"offset": 3, "limit": 1}, {"pattern": "clean"}):
        shown = content(await read(tmp_path, {"path": path.name, **window}))
        assert "encoding" not in shown
    assert path.read_bytes() == raw


@pytest.mark.asyncio
async def test_utf8_notes_fit_the_page_and_describe_only_displayed_characters(
    tmp_path: Path,
) -> None:
    path = tmp_path / "damaged.txt"
    path.write_bytes((b"x" * 50 + b"\xff\n") * 20_000)
    for window in ({}, {"pattern": "�"}):
        result = await read(tmp_path, {"path": path.name, **window})
        assert len(content(result).encode("utf-8")) <= 50 * 1024
        assert result["data"]["next_offset"] > 1
        assert "encoding" in content(result)

    # Neither an omitted prefix nor read-ahead beyond the byte cut is shown.
    path.write_bytes(b"\xff" + b"x" * 60_000 + b"\xe2\x82\n")
    first = await read(tmp_path, {"path": path.name, "offset": "1:500"})
    assert "encoding" not in content(first) and "�" not in content(first)
    continued = await read(tmp_path, {"path": path.name, "offset": first["data"]["next_offset"]})
    assert "encoding" in content(continued)
    assert content(continued).endswith("x�\n")


@pytest.mark.asyncio
async def test_utf8_diagnostics_do_not_keep_skipped_lines(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    path = tmp_path / "damaged.txt"
    path.write_bytes(b"\xff\nclean\n" * 10_000)
    recorded: list[int] = []
    record = read_text_module._Utf8Notes.record

    def record_line(notes: read_text_module._Utf8Notes, line: int, character: int) -> None:
        recorded.append(line)
        record(notes, line, character)

    monkeypatch.setattr(read_text_module._Utf8Notes, "record", record_line)
    for window in ({"offset": 20_000}, {"pattern": "clean", "limit": 1}):
        content(await read(tmp_path, {"path": path.name, **window}))
        assert recorded == []


@pytest.mark.asyncio
@pytest.mark.parametrize("encoding", ["utf-16-le", "utf-16-be", "utf-32-le", "utf-32-be"])
async def test_bom_text_names_the_explicit_encoding_that_reads_it(
    tmp_path: Path, encoding: str
) -> None:
    path = tmp_path / "unicode.txt"
    raw = ("\ufeffGrüße aus Köln\n上😀\n").encode(encoding)
    path.write_bytes(raw)
    shown = content(await read(tmp_path, {"path": path.name}))
    chosen = encoding.rsplit("-", 1)[0]
    assert path.name in shown and f'encoding="{chosen}"' in shown
    failure(await read(tmp_path, {"path": path.name, "pattern": "Grüße"}), "invalid_arguments")
    decoded = content(await read(tmp_path, {"path": path.name, "encoding": chosen}))
    assert decoded == "1| Grüße aus Köln\n2| 上😀\n"
    assert path.read_bytes() == raw


@pytest.mark.asyncio
@pytest.mark.parametrize("encoding", ["utf-16", "utf-16-le", "utf-16-be", "utf-8", "cp1252"])
async def test_an_explicit_encoding_applies_to_the_whole_file(
    tmp_path: Path, encoding: str
) -> None:
    # A LF/CR byte in a UTF-16 code unit is not a line break. These long rows
    # intentionally pass the automatic decoder's bounded inference window.
    source = (
        "first\r\n你好上不\u0a4e\u0d4e" + "你好" * 180 + "😀\nlast\x00line"
        if encoding != "cp1252"
        else "first\r\nGröße €\nlast\x00line"
    )
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    logs = make_context(workspace).data_root / "artifacts" / "temp" / "commands"
    logs.mkdir(parents=True)
    raw = source.encode(encoding)
    expected = read_module.render_text_file(source.encode())
    # The same explicit choice works for command logs and ordinary binary-looking files.
    for path in (logs / "output.log", tmp_path / "output.bin"):
        path.write_bytes(raw)
        arguments = {"path": str(path), "encoding": encoding}
        assert content(await read(workspace, arguments)) == expected
        assert content(await read(workspace, {**arguments, "offset": -1})) == "3| last\x00line"
        found = content(await read(workspace, {**arguments, "pattern": "last"}))
        assert "\n3| last\x00line" in found
        # The line:character range fallback must keep the chosen decoder too.
        fallback = content(await read(workspace, {**arguments, "offset": "1:20"}))
        assert fallback.endswith(expected)
        assert path.read_bytes() == raw


@pytest.mark.asyncio
@pytest.mark.parametrize("encoding", ["not-an-encoding", "base64", "rot13", "utf-8\x00"])
async def test_an_invalid_text_encoding_is_rejected_before_opening(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, encoding: str
) -> None:
    tmp_path.joinpath("notes.txt").write_bytes(b"hello\n")

    def unexpected_open(*args: Any, **kwargs: Any) -> Any:
        pytest.fail("invalid encoding opened the file")

    monkeypatch.setattr(Path, "open", unexpected_open)
    result = await read(tmp_path, {"path": "notes.txt", "encoding": encoding})
    assert result["ok"] is False
    message = failure(result, "invalid_arguments")
    assert "encoding" in message and "utf-8" in message


@pytest.mark.asyncio
async def test_an_inferred_encoding_change_is_named_only_for_the_lines_shown(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    logs = make_context(workspace).data_root / "artifacts" / "temp" / "commands"
    logs.mkdir(parents=True)
    path = logs / "output.log"
    # The same bytes can be pure UTF-16 with a CJK suffix, or mixed program output.
    prefix = "Ubuntu\n"
    raw = ("\ufeff" + prefix).encode("utf-16-le") + b"done\nmore\n"
    path.write_bytes(raw)
    monkeypatch.setattr(read_text_module, "_DECODING_CHUNK_BYTES", 1)
    for window in ({}, {"offset": -1}, {"pattern": "more"}):
        shown = content(await read(workspace, {"path": str(path), **window}))
        assert "inferred" in shown and 'encoding="utf-16"' in shown
        assert "3| more" in shown
    first = content(await read(workspace, {"path": str(path), "limit": 1}))
    assert "inferred" not in first
    explicit = content(await read(workspace, {"path": str(path), "encoding": "utf-16"}))
    assert explicit == read_module.render_text_file(raw.decode("utf-16").encode())

    # An unterminated UTF-8 suffix is ambiguous: without a complete line, the
    # automatic decoder keeps the BOM. An explicit choice still exposes either reading.
    path.write_bytes(("\ufeff" + prefix).encode("utf-16-le") + b"done")
    automatic = content(await read(workspace, {"path": str(path)}))
    assert automatic.endswith("2| " + b"done".decode("utf-16-le")) and "inferred" not in automatic
    assert content(await read(workspace, {"path": str(path), "encoding": "utf-8"})).endswith(
        "\x00done"
    )


_LONG = "".join(f"line{i}\n" for i in range(1, 2002))


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("raw", "window", "expected", "next_offset"),
    [
        # Numbers are the file's own, and the hint names the next call.
        (
            "one\ntwo\nthree\nfour\n",
            {"offset": 2, "limit": 2},
            "2| two\n3| three\n[Showing lines 2-3 of 4. Use offset=4 to continue.]",
            4,
        ),
        (
            "one\ntwo\n",
            {"offset": 5},
            "[Offset 5 is beyond end of file (2 lines). Nothing to show.]",
            None,
        ),
        ("one\n", {"offset": 2}, None, None),
        # Without a limit, a read stops after 2000 lines.
        (
            _LONG,
            {},
            "".join(f"{i}| line{i}\n" for i in range(1, 2001))
            + "[Showing lines 1-2000 of 2001. Use offset=2001 to continue.]",
            2001,
        ),
    ],
    ids=["offset_and_limit", "past_the_end", "one_line_past_the_end", "default_limit"],
)
async def test_line_windows_name_the_call_that_continues_them(
    tmp_path: Path, raw: str, window: dict[str, int], expected: str | None, next_offset: int | None
) -> None:
    tmp_path.joinpath("notes.txt").write_bytes(raw.encode())
    file_state = FileReadState()

    result = await read(tmp_path, {"path": "notes.txt", **window}, file_state=file_state)
    assert file_state.check_stale("session-1", (tmp_path / "notes.txt").resolve()) is None
    assert result["data"].get("next_offset") == next_offset
    if next_offset is None:
        assert "next_offset" not in result["data"]

    if expected is None:
        # Both the file path and attachment renderer name a single line correctly.
        for shown in (content(result), read_module.render_text_file(raw.encode(), offset=2)):
            assert "1 line)" in shown and "1 lines" not in shown
    else:
        assert content(result) == expected


@pytest.mark.asyncio
@pytest.mark.parametrize("decimal_boundary", [False, True])
async def test_short_lines_count_their_gutters_against_the_page_budget(
    tmp_path: Path, decimal_boundary: bool
) -> None:
    # At this exact alignment, shrinking the hint from line 1000 to 999 used
    # to re-admit line 1000, whose larger hint then removed it forever.
    source = (
        ("x" * 46 + "\n") * 219 + ("x" * 45 + "\n") * 1781 if decimal_boundary else "\n" * 50_000
    )
    total = 2000 if decimal_boundary else 50_000
    tmp_path.joinpath("short.txt").write_bytes(source.encode())
    offset = 1
    shown: list[int] = []

    while True:
        result = await read(tmp_path, {"path": "short.txt", "offset": offset, "limit": 50_000})
        page = content(result)
        assert len(page.encode("utf-8")) <= 50 * 1024
        shown.extend(int(match[1]) for match in re.finditer(r"(?m)^(\d+)\| [x]*\n", page))
        next_offset = result["data"].get("next_offset")
        if next_offset is None:
            break
        assert next_offset == shown[-1] + 1
        offset = next_offset

    assert shown == list(range(1, total + 1))
    if decimal_boundary:
        # Attachments, Skills and extracted documents share the in-memory renderer.
        for number in (True, False):
            rendered = read_text_module.render_text_page(source, 1, None, number=number)
            assert len(rendered.content.encode("utf-8")) <= 50 * 1024
            assert rendered.next_offset is not None


@pytest.mark.asyncio
@pytest.mark.parametrize("encoding", [None, "utf-16", "utf-16-be"])
async def test_a_line_cut_at_the_byte_limit_continues_at_its_character(
    tmp_path: Path, encoding: str | None
) -> None:
    source = ("x" if encoding is None else "上😀") * 60_000 + "\nsecond\n"
    tmp_path.joinpath("minified.txt").write_bytes(source.encode(encoding or "utf-8"))
    arguments = {"path": "minified.txt", **({"encoding": encoding} if encoding else {})}

    result = await read(tmp_path, arguments)
    first = content(result)
    match = re.search(r'Use offset="(1:\d+)" to continue', first)
    assert match is not None
    offset = result["data"]["next_offset"]
    assert offset == match.group(1)
    character = int(offset.split(":", maxsplit=1)[1])
    assert len(first.encode("utf-8")) <= 50 * 1024 + 500
    assert "Output truncated at 50 KB" in first
    assert first.split("\n\n[", maxsplit=1)[0] == f"1| {source[: character - 1]}"

    # Follow every character continuation, including several pages of non-ASCII text.
    pieces = [source[: character - 1]]
    while True:
        result = await read(tmp_path, {**arguments, "offset": offset})
        continued = content(result)
        next_match = re.search(r'Use offset="(1:\d+)" to continue', continued)
        if next_match is None:
            assert "next_offset" not in result["data"]
            rest = source[character - 1 : source.index(chr(10))]
            assert continued == f"{offset}| {rest}\n2| second\n"
            pieces.append(rest)
            break
        next_character = int(next_match[1].split(":")[1])
        part = continued.split("\n\n[", maxsplit=1)[0].removeprefix(f"{offset}| ")
        assert part == source[character - 1 : next_character - 1]
        pieces.append(part)
        offset, character = result["data"]["next_offset"], next_character
        assert offset == next_match[1]
    assert "".join(pieces) == source[: source.index(chr(10))]


@pytest.mark.asyncio
async def test_read_never_records_change_tracker_stats(tmp_path: Path) -> None:
    tmp_path.joinpath("notes.txt").write_bytes(b"alpha\nbeta\ngamma\n")
    tracker = ChangeTracker()
    context = make_context(tmp_path, change_tracker=tracker)

    content(await read(tmp_path, {"path": "notes.txt"}, context=context))

    run = (SessionAddress(context.project_id, context.agent_id, context.session_id), "run-1")
    assert tracker.peek_run_stats(run) is None


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("name", "raw"),
    [
        ("notes.txt", b"content\n"),
        ("voice.mp3", b"ID3\x04\x00\x00\x00\x00\x00\x0a" + b"x" * 20),
        ("diagram.png", b"\x89PNG\r\n\x1a\n\x00\x00\x00"),
        ("report.docx", docx_bytes("<w:p><w:r><w:t>Report</w:t></w:r></w:p>")),
        ("data.bin", b"\x7fELF\x00payload"),
    ],
    ids=["text", "audio", "image", "document", "binary"],
)
async def test_a_successful_read_stamps_the_file_for_the_write_guard(
    tmp_path: Path, name: str, raw: bytes
) -> None:
    target = tmp_path / name
    target.write_bytes(raw)
    file_state = FileReadState()

    assert (await read(tmp_path, {"path": name}, file_state=file_state))["ok"] is True

    assert file_state.check_stale("session-1", target.resolve()) is None
    assert file_state.check_stale("session-2", target.resolve()) is StaleReason.NEVER_READ


@pytest.mark.asyncio
async def test_read_stamp_predates_bytes_so_a_concurrent_write_forces_reread(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    target = tmp_path / "notes.txt"
    target.write_bytes(b"before\n")
    file_state = FileReadState()
    render = read_module.render_text_path

    def render_after_external_write(
        resolved: Path, arguments: dict[str, Any], **options: Any
    ) -> read_text_module.ReadPage:
        target.write_bytes(b"written during the read\n")
        return render(resolved, arguments, **options)

    monkeypatch.setattr(read_module, "render_text_path", render_after_external_write)

    result = await read(tmp_path, {"path": "notes.txt"}, file_state=file_state)

    assert result["ok"] is True
    assert file_state.check_stale("session-1", target.resolve()) is StaleReason.MODIFIED


_AUDIO = b"ID3\x04\x00\x00\x00\x00\x00\x0a" + b"x" * 20
_PNG = b"\x89PNG\r\n\x1a\n\x00\x00\x00"
_MP4 = b"\x00\x00\x00\x18ftypisommp4-data"


@pytest.mark.asyncio
async def test_an_image_passes_its_pixels_in_memory_without_creating_files(tmp_path: Path) -> None:
    tmp_path.joinpath("diagram.png").write_bytes(_PNG)
    store = FakeAttachmentStore()
    context = make_context(tmp_path)
    before = set(tmp_path.rglob("*"))

    result = await read(tmp_path, {"path": "diagram.png"}, context=context, store=store)

    assert "diagram.png" in content(result)
    assert store.stored == []
    assert set(tmp_path.rglob("*")) == before
    assert base64.b64decode(context.result_media[0]["base64"]) == _PNG
    assert context.presentation_media == [
        {"path": str(tmp_path / "diagram.png"), "kind": "image", "filename": "diagram.png"}
    ]
    # An explicit encoding requests the bytes as text instead of image routing.
    text_context = make_context(tmp_path)
    shown = content(
        await read(
            tmp_path,
            {"path": "diagram.png", "encoding": "utf-8"},
            context=text_context,
            store=store,
        )
    )
    assert shown == read_module.render_text_file(_PNG)
    assert not text_context.result_media and not text_context.presentation_media


@pytest.mark.asyncio
@pytest.mark.parametrize("transcript", ["hello from the recording", "   "])
async def test_audio_is_transcribed(tmp_path: Path, transcript: str) -> None:
    tmp_path.joinpath("voice.mp3").write_bytes(_AUDIO)
    speech = FakeSpeech(text=transcript)
    file_state = FileReadState()

    result = await read(tmp_path, {"path": "voice.mp3"}, speech=speech, file_state=file_state)

    if transcript.strip():
        assert content(result) == f"[Transcription of voice.mp3 (audio/mpeg)]:\n{transcript}"
    else:
        assert "voice.mp3" in content(result) and "30 B" in content(result)
    assert speech.calls == [(_AUDIO, "voice.mp3", "audio/mpeg")]
    assert file_state.check_stale("session-1", (tmp_path / "voice.mp3").resolve()) is None


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("name", "raw", "services", "code", "message"),
    [
        ("voice.mp3", _AUDIO, {"speech_max_size_bytes": 8}, "audio_too_large", "8 B"),
        (
            "voice.mp3",
            _AUDIO,
            {"speech": FakeSpeech(error=SpeechError("speech-to-text is not configured"))},
            "transcription_failed",
            "speech-to-text is not configured",
        ),
        (
            "pic.png",
            _PNG,
            {"store": FakeAttachmentStore(max_size_bytes=4)},
            "attachment_error",
            "4 B",
        ),
        (
            "notes.txt",
            b"hello\n",
            {"arguments": {"encoding": "utf-16"}},
            "invalid_arguments",
            "byte order",
        ),
    ],
    ids=[
        "audio_too_large",
        "speech_error",
        "image_too_large",
        "missing_bom",
    ],
)
async def test_failed_read_does_not_stamp_the_file(
    tmp_path: Path, name: str, raw: bytes, services: dict[str, Any], code: str, message: str
) -> None:
    target = tmp_path / name
    target.write_bytes(raw)
    file_state = FileReadState()
    services = {"speech": FakeSpeech(), **services}
    arguments = {"path": name, **services.pop("arguments", {})}

    result = await read(tmp_path, arguments, file_state=file_state, **services)

    assert name in failure(result, code) and message in failure(result, code)
    assert file_state.check_stale("session-1", target.resolve()) is StaleReason.NEVER_READ
    if code == "audio_too_large":
        assert services["speech"].calls == []


_DOCX_BODY = (
    "<w:p><w:r><w:t>Hello</w:t></w:r><w:r><w:t> World</w:t></w:r></w:p>"
    "<w:p><w:r><w:t>Line</w:t><w:tab/><w:t>Two</w:t></w:r></w:p>"
)
_SHEET = "Name\tAge\nBob\t42"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("name", "raw", "expected"),
    [
        # A rendering, not editable source: no line number gutter. Extensions match
        # in any case.
        ("report.DOCX", docx_bytes(_DOCX_BODY), "(Word document)]:\nHello World\nLine\tTwo"),
        (
            "strict.docx",
            docx_bytes(_DOCX_BODY, strict=True),
            "(Word document)]:\nHello World\nLine\tTwo",
        ),
        (
            "nb.ipynb",
            ipynb_bytes(),
            "(Jupyter notebook)]:\n# Cell 1 [markdown]\n# Title\nintro\n\n# Cell 2 [code]\n"
            "print('hi')",
        ),
        (
            "paper.pdf",
            pdf_bytes(["Hello PDF", "Second line"]),
            "(PDF document)]:\n# Page 1\nHello PDF\nSecond line",
        ),
        # A file without an extension is recognized by its content.
        ("download", pdf_bytes(["Hello PDF"]), "(PDF document)]:\n# Page 1\nHello PDF"),
        # A scanned PDF has no text layer.
        ("scan.pdf", pdf_bytes([]), "(PDF document)]:\n(no extractable text)"),
        # Worksheet relationship targets resolve relative to the workbook part or the root.
        *[
            (
                "people.xlsx",
                xlsx_bytes(worksheet_target=target),
                f"(Excel spreadsheet)]:\n# Sheet: People\n{_SHEET}",
            )
            for target in [
                "worksheets/sheet1.xml",
                "/xl/worksheets/sheet1.xml",
                "./worksheets/sheet1.xml",
                "worksheets/../worksheets/sheet1.xml",
                "../xl/worksheets/sheet1.xml",
            ]
        ],
        # Without a workbook part, sheets are named after their files.
        (
            "people.xlsx",
            xlsx_bytes(worksheet_target=None),
            f"(Excel spreadsheet)]:\n# Sheet: sheet1\n{_SHEET}",
        ),
    ],
    ids=[
        "docx",
        "strict_docx",
        "ipynb",
        "pdf",
        "pdf_without_extension",
        "scanned_pdf",
        *[f"xlsx_target_{index}" for index in range(5)],
        "xlsx_without_workbook",
    ],
)
async def test_documents_are_read_as_their_extracted_text(
    tmp_path: Path, name: str, raw: bytes, expected: str
) -> None:
    tmp_path.joinpath(name).write_bytes(raw)

    result = await read(tmp_path, {"path": name})

    assert content(result) == f"[Extracted text from {name} {expected}"


def _locked_pdf() -> bytes:
    from io import BytesIO

    from pypdf import PdfWriter

    writer = PdfWriter()
    writer.add_blank_page(width=72, height=72)
    writer.encrypt("secret")
    buffer = BytesIO()
    writer.write(buffer)
    return buffer.getvalue()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("name", "raw", "expected"),
    [
        ("clip.mp4", _MP4, "[clip.mp4 is a video (video/mp4); this model cannot view video.]"),
        # Text that only carries a document's extension reads as text.
        ("broken.ipynb", b"{not valid json", "1| {not valid json"),
        ("notes.pdf", b"plain notes", "1| plain notes"),
    ],
    ids=["video", "broken_ipynb", "text_named_pdf"],
)
async def test_files_without_a_readable_form_get_a_note(
    tmp_path: Path, name: str, raw: bytes, expected: str
) -> None:
    tmp_path.joinpath(name).write_bytes(raw)
    store = FakeAttachmentStore()

    result = await read(tmp_path, {"path": name}, store=store)

    assert content(result) == expected
    assert store.stored == []


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("name", "raw", "problem"),
    [
        # Without a NUL byte in its probe, a damaged PDF once streamed as text.
        ("broken.pdf", b"%PDF-1.4 not really a pdf body", "end-of-file marker"),
        ("broken.docx", b"PK\x03\x04 not really a zip \x00 body", "ZIP package"),
        ("locked.pdf", _locked_pdf(), "protected by a password"),
    ],
    ids=["pdf", "docx", "password_pdf"],
)
async def test_documents_whose_text_cannot_be_extracted_fail(
    tmp_path: Path, name: str, raw: bytes, problem: str
) -> None:
    tmp_path.joinpath(name).write_bytes(raw)

    message = failure(await read(tmp_path, {"path": name}), "document_unreadable")

    # The cause and size spare the Agent inspecting the bytes itself.
    assert name in message and problem in message and f"{len(raw)} bytes" in message


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("name", "raw", "headroom"),
    [
        # The file itself exceeds the budget: rejected before it is read in full.
        ("large.docx", docx_bytes("<w:p><w:r><w:t>" + "x" * 512 + "</w:t></w:r></w:p>"), None),
        # Small files whose content expands beyond the budget during extraction.
        ("packed.docx", docx_bytes("<w:p><w:r><w:t>" + "x" * 8192 + "</w:t></w:r></w:p>"), 64),
        ("packed.pdf", pdf_bytes(["x" * 4096], compressed=True), 64),
    ],
    ids=["docx_file", "docx_content", "pdf_stream"],
)
async def test_documents_beyond_the_extraction_budget_fail(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, name: str, raw: bytes, headroom: int | None
) -> None:
    tmp_path.joinpath(name).write_bytes(raw)
    budget = 128 if headroom is None else len(raw) + headroom
    monkeypatch.setattr(read_extract_module, "_MAX_DOCUMENT_EXTRACTED_BYTES", budget)
    if headroom is None:

        def unexpected_extract(_data: bytes, _kind: str) -> str:
            raise AssertionError("oversized document was materialized before preflight")

        monkeypatch.setattr(read_module, "extract_document_text", unexpected_extract)

    result = await read(tmp_path, {"path": name})

    assert "128 MB extraction limit" in failure(result, "document_too_large")


@pytest.mark.asyncio
async def test_text_binary_and_video_reads_never_load_the_whole_file(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    tmp_path.joinpath("large.txt").write_text("first\n" + "x" * 200_000, encoding="utf-8")
    tmp_path.joinpath("data.bin").write_bytes(b"\x7fELF\x00payload")
    tmp_path.joinpath("clip.mp4").write_bytes(_MP4)

    def unexpected_full_read(_resolved: Path, _max_bytes: int) -> bytes:
        raise AssertionError("notice/text branch attempted a full-file read")

    monkeypatch.setattr(read_module, "_read_file_bytes_with_limit", unexpected_full_read)

    text = content(await read(tmp_path, {"path": "large.txt", "limit": 1}))
    binary = content(await read(tmp_path, {"path": "data.bin"}))
    without_shell = replace(make_context(tmp_path), offered_tools={"read"})
    binary_without_shell = content(
        await read(tmp_path, {"path": "data.bin"}, context=without_shell)
    )
    video = content(await read(tmp_path, {"path": "clip.mp4"}))

    assert text.startswith("1| first")
    assert text.endswith("[Showing lines 1-1 of 2. Use offset=2 to continue.]")
    assert binary == binary_notice("data.bin")
    assert binary_without_shell == binary_notice("data.bin", shell=False)
    assert video.startswith("[clip.mp4 is a video")
