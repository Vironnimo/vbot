"""The Permission Boundary of a Run: built from its Agent, carried to every Tool Call."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass, replace
from pathlib import Path
from types import SimpleNamespace
from typing import Any, cast

import pytest

import core.chat._run_permissions as run_permissions
from core.chat import session_permissions
from core.json_documents import document_change
from core.permissions import (
    BoundaryContext,
    PermissionBoundary,
    PermissionRules,
    normalize_permission_rules,
)
from core.projects import AgentOverrides
from core.sessions import SUBAGENT_PARENT_META_KEY, SessionAddress, is_prompt_block_change_note
from core.skills.policy import SkillPackageRef
from core.skills.skills import SkillMetadata, SkillRegistry
from core.storage.layout import DataDirectoryLayout
from core.tools import ToolContext, ToolRegistry, tool_success
from tests.core.chat.chat_loop_support import (
    StubAdapter,
    StubAgent,
    StubProject,
    StubProjects,
    StubRuntime,
    build_chat_loop,
    history,
)
from tests.core.chat.chat_loop_tools_test_support import final, tool_turn
from tests.core.prompts.prompts_test_support import _agent, _manager


@dataclass(frozen=True)
class _RuleAgent(StubAgent):
    permission_rules: PermissionRules | None = None


class _ScratchFolders:
    def __init__(self, root: Path) -> None:
        self.root = root

    async def folder_for(self, address: SessionAddress) -> Any:
        area = self.root / address.session_id
        own = area / address.session_id
        return SimpleNamespace(
            own=own, area=area, tmp=own / "tmp", recreated=False, incarnation="1"
        )


def _runtime(
    tmp_path: Path,
    rules: dict[str, Any] | None,
    *,
    turns: list[Any] | None = None,
    on_call: Callable[[], None] | None = None,
) -> tuple[Any, list[ToolContext]]:
    seen: list[ToolContext] = []

    def probe(context: ToolContext, _arguments: Any) -> Any:
        seen.append(context)
        if on_call is not None:
            on_call()
        return tool_success({})

    tools = ToolRegistry()
    tools.register("probe", "Probe.", {"type": "object"}, probe)
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    agent = _RuleAgent(
        id="coder",
        model="openai/gpt-5.2",
        allowed_tools=["*"],
        workspace=workspace,
        permission_rules=normalize_permission_rules(rules) if rules is not None else None,
    )
    runtime: Any = StubRuntime(
        data_dir=tmp_path / "data",
        agent=agent,
        adapter=StubAdapter(turns or [tool_turn(("call_1", "probe")), final("Done")]),
        tools=tools,
    )
    runtime.scratch_areas = _ScratchFolders(tmp_path / "scratch")
    runtime.chat_sessions.create("coder", session_id="s1")
    return runtime, seen


def _system_prompt(runtime: Any) -> str:
    return str(runtime.adapter.requests[0]["messages"][0]["content"])


@pytest.mark.asyncio
async def test_a_restricted_run_checks_tool_accesses_against_its_expanded_boundary(
    tmp_path: Path,
) -> None:
    runtime, seen = _runtime(
        tmp_path,
        {
            "read": "work_area",
            "write": "scratch",
            "web": "listed",
            "allow": ["Web(docs.example)"],
            "deny": ["Read({workdir}/secrets/**)", "Web(blocked.example)"],
        },
    )

    await build_chat_loop(runtime).send("coder", "Work", session_id="s1")

    [context] = seen
    boundary = context.permissions
    workspace = tmp_path / "workspace"
    scratch = tmp_path / "scratch" / "s1"
    assert boundary.restricted
    # {workdir} is the Session's working directory; the Scratch Area and the
    # Workspace are writable.
    assert boundary.check_path(workspace / "notes.md", "read") is None
    assert boundary.check_path(scratch / "s1" / "draft.md", "write") is None
    assert boundary.check_path(workspace / "notes.md", "write") is None
    refused = boundary.check_path(tmp_path / "elsewhere.md", "write")
    assert refused is not None and refused.reason == "not_permitted"
    denied = boundary.check_path(workspace / "secrets" / "key", "read")
    assert denied is not None and denied.rule == f"Read({workspace.as_posix()}/secrets/**)"
    outside = boundary.check_path(tmp_path / "elsewhere.md", "read")
    assert outside is not None and outside.reason == "not_permitted"
    # The Agent's own configuration is never readable.
    own_config = boundary.check_path(tmp_path / "data" / "agents" / "coder" / "agent.json", "read")
    assert own_config is not None and own_config.reason == "protected_location"

    # The System Prompt names the boundary in the Model's path form.
    prompt = _system_prompt(runtime)
    assert "## Permission rules" in prompt
    assert f"`{workspace.as_posix()}`" in prompt
    assert f"`Read({workspace.as_posix()}/secrets/**)`" in prompt
    assert "`docs.example`" in prompt and "`blocked.example`" in prompt
    assert "Web(" not in prompt


@pytest.mark.asyncio
@pytest.mark.parametrize("source", ["bundled", "home", "withheld"])
async def test_generated_documentation_read_grants_follow_only_an_authorized_bundled_package(
    tmp_path: Path, source: str
) -> None:
    cache = DataDirectoryLayout(tmp_path / "data").skill_documentation
    previous = cache / ("a" * 64) / "vbot-docs"
    current = cache / ("b" * 64) / "vbot-docs"
    denied_file = current / "private.md"

    def registry(package: Path) -> SkillRegistry:
        return SkillRegistry(
            {
                "vbot-docs": SkillMetadata(
                    "vbot-docs",
                    "Documentation fixture.",
                    package / "SKILL.md",
                    package_ref=SkillPackageRef(
                        "home" if source == "home" else "bundled", "vbot-docs"
                    ),
                )
            }
        )

    def reload() -> None:
        if len(seen) == 1:
            # The Skill Tool resolves this new registry, while this active Run
            # retains the Skill-directory grants admitted before its first call.
            runtime.skills = registry(current)

    runtime, seen = _runtime(
        tmp_path,
        {"read": "work_area", "write": "work_area", "deny": [f"Read({denied_file.as_posix()})"]},
        turns=[tool_turn(("call_1", "probe")), tool_turn(("call_2", "probe")), final("Done")],
        on_call=reload,
    )
    runtime.skills = registry(previous)
    runtime.agents._agent = replace(
        runtime.agents._agent, allowed_skills=[] if source == "withheld" else ["vbot-docs"]
    )

    await build_chat_loop(runtime).send("coder", "Read the documentation", session_id="s1")

    first, second = seen
    assert first.permissions is second.permissions
    assert (second.permissions.check_path(current / "usage.md", "read") is None) == (
        source == "bundled"
    )
    # The grant is read-only, deny rules still win, and sibling application data
    # never becomes readable even when a newer documentation generation does.
    assert second.permissions.check_path(current / "usage.md", "write") is not None
    assert second.permissions.check_path(denied_file, "read") is not None
    assert second.permissions.check_path(cache.parent / "private.md", "read") is not None


@pytest.mark.asyncio
async def test_a_restricted_run_gets_only_the_instruction_files_it_may_read(
    tmp_path: Path,
) -> None:
    repo = tmp_path / "repo"
    (repo / "app").mkdir(parents=True)
    (repo / "AGENTS.md").write_text("ROOT_RULES", encoding="utf-8")
    (repo / "private.md").write_text("PRIVATE_RULES", encoding="utf-8")
    (repo / "app" / "AGENTS.md").write_text("APP_RULES", encoding="utf-8")

    def work(context: ToolContext, _arguments: Any) -> Any:
        context.record_worked_paths(repo / "app" / "main.py")
        return tool_success({})

    tools = ToolRegistry()
    tools.register("probe", "Probe.", {"type": "object"}, work)
    deny = [f"Read({(repo / name).as_posix()})" for name in ("private.md", "app/AGENTS.md")]
    agent = _RuleAgent(
        id="coder",
        model="openai/gpt-5.2",
        allowed_tools=["*"],
        permission_rules=normalize_permission_rules({"deny": deny}),
    )
    project = StubProject(
        project_id="vbot",
        cwd=str(repo),
        auto_load=["AGENTS.md", "private.md"],
        display_name="vBot",
        folder_instructions=True,
    )
    runtime: Any = StubRuntime(
        data_dir=tmp_path / "data",
        agent=agent,
        adapter=StubAdapter([tool_turn(("call_1", "probe")), final("Done")]),
        tools=tools,
        projects=StubProjects({"vbot": project}),
    )
    runtime.chat_sessions.create("coder", session_id="s1", working_project_id="vbot")

    await build_chat_loop(runtime).send("coder", "Work", session_id="s1")

    # Neither the Working Project frame nor a folder instruction note carries a
    # file the rules refuse to read.
    prompt = _system_prompt(runtime)
    assert "ROOT_RULES" in prompt and "PRIVATE_RULES" not in prompt
    after_tool = str(runtime.adapter.requests[1]["messages"])
    assert "APP_RULES" not in after_tool


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "rules",
    [
        pytest.param(None, id="no-rules"),
        pytest.param(
            {
                "read": "anywhere",
                "write": "anywhere",
                "commands": "any",
                "web": "any",
                "allow": [],
                "deny": [],
            },
            id="explicit-full-access",
        ),
    ],
)
async def test_a_run_without_rules_gets_full_access_without_building_a_boundary(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, rules: dict[str, object] | None
) -> None:
    runtime, seen = _runtime(tmp_path, rules)

    def unexpected(*_args: object, **_kwargs: object) -> Any:
        raise AssertionError("an unrestricted Run built a boundary")

    monkeypatch.setattr(run_permissions, "installation_dirs", unexpected)
    monkeypatch.setattr(run_permissions, "_skill_dirs", unexpected)

    await build_chat_loop(runtime).send("coder", "Work", session_id="s1")

    [context] = seen
    assert context.permissions is PermissionBoundary.UNRESTRICTED
    # The Agent still learns that nothing limits it.
    assert "## Permission rules" in _system_prompt(runtime)
    assert "full access" in _system_prompt(runtime)


@pytest.mark.asyncio
@pytest.mark.parametrize("inherited_from", ["parent", "cron"])
async def test_an_inherited_ceiling_bounds_an_agent_without_rules(
    tmp_path: Path, inherited_from: str
) -> None:
    runtime, seen = _runtime(
        tmp_path,
        None,
        turns=[
            tool_turn(("call_1", "probe")),
            final("Done"),
            tool_turn(("call_2", "probe")),
            final("Done"),
        ],
    )
    address = SessionAddress(None, "coder", "s1")
    creator = PermissionBoundary.build(
        normalize_permission_rules({"read": "work_area", "write": "scratch"}),
        BoundaryContext(workdir=tmp_path / "creator", home=tmp_path, data_dir=tmp_path / "data"),
    )
    ceiling = creator.ceiling(source=cast(Any, inherited_from))
    assert ceiling is not None
    loop = build_chat_loop(runtime)

    if inherited_from == "parent":

        def link(metadata: dict[str, Any]) -> None:
            metadata[SUBAGENT_PARENT_META_KEY] = {
                "id": "sub_aaaaaaaaaaaa",
                "agent_id": "lead",
                "session_id": "parent",
                "run_id": "parent-run",
                "tool_call_id": None,
                "tool_call_index": None,
                "project_id": None,
            }
            stored = AgentOverrides(
                permission_ceiling=ceiling.to_ceiling_dict(),
                read_folders={"server": ((tmp_path / "library").as_posix(),)},
            )
            metadata.update(stored.session_metadata())

        runtime.chat_sessions.mutate_metadata(address, link)
        await loop.send("coder", "Work", session_id="s1")
    else:
        run = await loop.start_run("coder", "Work", session_id="s1", permission_ceiling=ceiling)
        await run.wait()
    # A follow-up Run of the Session, which nobody passes a ceiling, keeps it.
    await loop.send("coder", "Follow up", session_id="s1")

    for context in seen:
        assert [layer.source for layer in context.permissions.layers] == [inherited_from]
        folder_read = context.permissions.check_path(tmp_path / "library" / "client.py", "read")
        assert (folder_read is None) == (inherited_from == "parent")
        assert context.permissions.ceiling(source="parent") == ceiling
        refused = context.permissions.check_path(tmp_path / "elsewhere.md", "write")
        assert refused is not None and refused.source == inherited_from
        for access in ("read", "write"):
            assert (
                context.permissions.check_path(tmp_path / "scratch" / "s1" / "note.txt", access)
                is None
            )
    assert len(seen) == 2
    # The System Prompt says where the inherited rules come from.
    source = {"parent": "Session that started you", "cron": "Session that scheduled this job"}
    assert source[inherited_from] in _system_prompt(runtime)


@pytest.mark.asyncio
@pytest.mark.parametrize("computer", ["server", "laptop"])
async def test_one_folder_decision_resumes_a_library_search_and_a_parallel_read(
    tmp_path: Path, computer: str
) -> None:
    from core.tools.file_state import FileReadState
    from core.tools.read import register_read_tool
    from core.tools.search_files import register_search_files_tool
    from tests.core.chat.chat_loop_tools_test_support import tool_results

    client = tmp_path / "library" / "client"
    auth = client / "auth" / "oauth2.py"
    stdio = client / "stdio" / "win32.py"
    for file in (auth, stdio):
        file.parent.mkdir(parents=True)
        file.write_text("library_marker", encoding="utf-8")
    runtime, seen = _runtime(
        tmp_path,
        None,
        turns=[
            tool_turn(
                ("search", "search_files", {"pattern": "library_marker", "path": str(auth)}),
                ("read", "read", {"path": str(stdio)}),
            ),
            tool_turn(("list", "read", {"path": str(client)})),
            final("Done"),
            tool_turn(("next", "probe")),
            final("Done"),
        ],
    )
    register_read_tool(
        runtime.tools,
        attachment_store=None,
        speech_service=None,
        file_state=FileReadState(),
        speech_max_size_bytes=1024,
    )
    register_search_files_tool(runtime.tools)
    creator = PermissionBoundary.build(
        normalize_permission_rules({"read": "work_area"}),
        BoundaryContext(workdir=tmp_path / "work", home=tmp_path, data_dir=tmp_path / "data"),
    )
    ceiling = creator.to_ceiling_dict(source="parent")
    address = SessionAddress(None, "coder", "s1")
    runtime.chat_sessions.mutate_metadata(
        address,
        lambda meta: meta.update(
            execution={"computer_id": computer},
            **AgentOverrides(permission_ceiling=ceiling).session_metadata(),
        ),
    )
    waiting = asyncio.Event()

    def observe(snapshot):
        if len(snapshot["requests"]) == 2:
            waiting.set()

    runtime.chat_runs.add_approvals_changed_callback(observe)
    loop = build_chat_loop(runtime)
    run = await loop.start_run("coder", "Read the library", session_id="s1")
    async with asyncio.timeout(8):
        await waiting.wait()
        requests = runtime.chat_runs.approvals_snapshot()["requests"]
        search = next(r for r in requests if r["tool_name"] == "search_files")
        assert search["session_grant"]["folders"][:2] == [auth.parent.as_posix(), client.as_posix()]

        async def save(_request):
            resolver = runtime.agent_resolver
            updated = replace(
                resolver.session_overrides(address), read_folders={computer: (client.as_posix(),)}
            )
            resolver._session_overrides[address] = updated.session_metadata()["agent_overrides"]

        assert await runtime.chat_runs.remember_approval(search["id"], save, folder_read=True)
        await run.wait()
    results = tool_results(history(runtime, "s1"))
    assert len(results) == 3
    assert all(result["ok"] for result in results), results
    assert "library_marker" in str(results[0]["data"])
    assert "library_marker" in str(results[1]["data"])
    assert "stdio" in str(results[2]["data"])
    assert runtime.chat_runs.approvals_snapshot()["requests"] == []

    other_computer = "laptop" if computer == "server" else "server"
    runtime.chat_sessions.mutate_metadata(
        address, lambda meta: meta.update(execution={"computer_id": other_computer})
    )
    await loop.send("coder", "Follow up", session_id="s1")
    [follow_up] = seen
    assert follow_up.permissions.check_path(stdio, "read") is not None


def test_a_ceiling_only_session_boundary_keeps_the_agents_workspace_and_config(
    tmp_path: Path,
) -> None:
    # A Cron watch check of an Identity Agent without a Project works in its
    # Workspace inside the data directory, under the job's ceiling alone.
    data = tmp_path / "data"
    workspace = data / "agents" / "coder" / "workspace"
    agent = replace(
        _agent(workspace), permission_rules=normalize_permission_rules({"web": "listed"})
    )
    creator = PermissionBoundary.build(
        normalize_permission_rules({"read": "work_area", "write": "work_area"}),
        BoundaryContext(workdir=workspace, home=tmp_path, data_dir=data),
    )
    ceiling = creator.ceiling(source="cron")

    composed = session_permissions(agent, data_dir=data, project_root=None, ceiling=ceiling)
    boundary = composed.without_agent_rules().boundary(data, owner=None)

    assert composed.workdir == workspace
    assert [layer.source for layer in boundary.layers] == ["cron"]
    assert boundary.check_path(workspace / "notes.md", "write") is None
    refused = boundary.check_path(data / "agents" / "coder" / "agent.json", "read")
    assert refused is not None and refused.location == "agent_config"


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "changed", ["agent_rules", "session_ceiling", "agent_file", "settings_file"]
)
@pytest.mark.parametrize("restricted", [False, True])
async def test_a_rule_edit_reaches_the_next_tool_round_of_an_active_run(
    tmp_path: Path, changed: str, restricted: bool
) -> None:
    address = SessionAddress(None, "coder", "s1")

    def tighten() -> None:
        if len(seen) != 1:
            return
        if changed in {"agent_rules", "agent_file", "settings_file"}:
            agent = runtime.agents._agent
            runtime.agents._agent = replace(
                agent, permission_rules=normalize_permission_rules({"write": "scratch"})
            )
            if changed == "agent_rules":
                # The edit as vBot saves it: a configuration document change.
                with document_change(tmp_path / "data" / "agents" / "coder" / "agent.json"):
                    pass
            else:
                # An external edit changes only the file, never vBot's document
                # counter. The stub resolver above supplies the newly read rules.
                path = (
                    tmp_path
                    / "data"
                    / ("settings.json" if changed == "settings_file" else "agents/coder/agent.json")
                )
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text('{"permission_rules": {"write": "scratch"}}', encoding="utf-8")
            return
        # A change to what the Session stores, such as a ceiling a Cron fire joins.
        ceiling = PermissionBoundary.build(
            normalize_permission_rules({"write": "scratch"}),
            BoundaryContext(workdir=tmp_path / "cron", home=tmp_path, data_dir=tmp_path / "data"),
        ).ceiling(source="cron")
        runtime.agent_resolver.join_session_ceiling(address, ceiling)

    runtime, seen = _runtime(
        tmp_path,
        None,
        turns=[tool_turn(("call_1", "probe")), tool_turn(("call_2", "probe")), final("Done")],
        on_call=tighten,
    )
    # Real System Prompt assembly, which pins the prompt epoch's blocks.
    runtime.agents._agent = replace(
        _agent(tmp_path / "workspace", allowed_tools=["*"]),
        permission_rules=normalize_permission_rules({"web": "listed"}) if restricted else None,
    )
    runtime.system_prompts = _manager(tmp_path, tools=runtime.tools)

    await build_chat_loop(runtime).send("coder", "Work", session_id="s1")

    first, second = seen
    assert first.permissions.restricted is restricted
    assert first.permissions.check_path(tmp_path / "elsewhere.md", "write") is None
    refused = second.permissions.check_path(tmp_path / "elsewhere.md", "write")
    assert refused is not None and refused.reason == "not_permitted"
    # The Model learns the new rules once, at the request after the change, and
    # the System Prompt stays byte-identical for the Provider cache.
    systems = {str(request["messages"][0]["content"]) for request in runtime.adapter.requests}
    assert len(runtime.adapter.requests) == 3 and len(systems) == 1
    notes = [message for message in history(runtime, "s1") if is_prompt_block_change_note(message)]
    assert len(notes) == 1
    assert ("full access" in systems.pop()) is not restricted
    assert "full access" not in str(notes[0].content)


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "change", ["settings_write", "external_edit", "session_rules", "transient_grant"]
)
async def test_permission_change_during_resolution_applies_before_the_tool_runs(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, change: str
) -> None:
    settings = tmp_path / "data" / "settings.json"

    def edit() -> None:
        # Force resolution for the next Tool round, while another edit races it.
        with document_change(settings):
            pass

    narrowed = {"write": "scratch"}
    runtime, seen = _runtime(
        tmp_path,
        narrowed if change == "transient_grant" else None,
        turns=[tool_turn(("one", "probe")), tool_turn(("two", "probe")), final("Done")],
        on_call=edit,
    )
    resolver = runtime.agent_resolver
    resolve = resolver.resolve_agent_async
    address = SessionAddress(None, "coder", "s1")
    outside = tmp_path / "outside.md"

    async def edit_after_read(*args: Any, **kwargs: Any) -> Any:
        if change == "transient_grant" and len(seen) == 1:
            # A grant is issued after the boundary's first read, then revoked before
            # its last one. The Agent must use the same snapshot as its boundary.
            old = resolver._session_overrides.get(address, {})
            resolver._session_overrides[address] = {
                **old,
                "permission_grants": [f"Edit({outside.as_posix()})"],
            }
            try:
                return await resolve(*args, **kwargs)
            finally:
                resolver._session_overrides[address] = old
        previous = await resolve(*args, **kwargs)
        if len(seen) == 1 and previous.permission_rules is None:
            if change == "session_rules":
                resolver._session_overrides[address] = {"permission_rules": narrowed}
            else:
                runtime.agents._agent = replace(
                    previous, permission_rules=normalize_permission_rules(narrowed)
                )
                if change == "external_edit":
                    settings.parent.mkdir(parents=True, exist_ok=True)
                    settings.write_text('{"permission_profiles":{}}', encoding="utf-8")
                else:
                    edit()
        return previous

    monkeypatch.setattr(resolver, "resolve_agent_async", edit_after_read)
    await build_chat_loop(runtime).send("coder", "Work", session_id="s1")
    first, second = seen
    assert first.permissions.restricted == (change == "transient_grant")
    assert second.permissions.check_path(outside, "write") is not None


@pytest.mark.asyncio
async def test_computer_authority_is_refreshed_before_each_tool_round(tmp_path: Path) -> None:
    address = SessionAddress(None, "coder", "s1")
    initial = {"computer_id": "laptop", "allowed_computer_ids": ["laptop", "server"]}
    narrowed = {"computer_id": "laptop", "allowed_computer_ids": []}

    def tighten() -> None:
        if len(seen) == 1:
            runtime.chat_sessions.mutate_metadata(
                address, lambda metadata: metadata.update(execution=narrowed)
            )

    runtime, seen = _runtime(
        tmp_path,
        None,
        turns=[tool_turn(("call_1", "probe")), tool_turn(("call_2", "probe")), final("Done")],
        on_call=tighten,
    )
    runtime.chat_sessions.mutate_metadata(
        address, lambda metadata: metadata.update(execution=initial)
    )
    await build_chat_loop(runtime).send("coder", "Work", session_id="s1")
    assert [context.execution for context in seen] == [initial, narrowed]


@pytest.mark.asyncio
async def test_the_permissions_block_is_pinned_and_a_change_is_announced_once(
    tmp_path: Path,
) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    agent = _agent(workspace)
    adapter = StubAdapter([final(str(index)) for index in range(5)])
    runtime: Any = StubRuntime(data_dir=tmp_path / "data", agent=cast(Any, agent), adapter=adapter)
    runtime.system_prompts = _manager(tmp_path, tools=runtime.tools)
    runtime.chat_sessions.create(agent.id, session_id="s1")
    loop = build_chat_loop(runtime)

    await loop.send(agent.id, "First", session_id="s1")
    runtime.agents._agent = replace(
        agent, permission_rules=normalize_permission_rules({"write": "work_area"})
    )
    await loop.send(agent.id, "Second", session_id="s1")
    await loop.send(agent.id, "Third", session_id="s1")
    runtime.agents._agent = agent
    await loop.send(agent.id, "Fourth", session_id="s1")
    runtime.chat_sessions.create(agent.id, session_id="s2")
    await loop.send(agent.id, "Fresh", session_id="s2")

    *systems, fresh = [str(request["messages"][0]["content"]) for request in adapter.requests]
    # A new prompt epoch shows the block in the System Prompt itself.
    assert "## Permission rules" in fresh
    assert "full access" in systems[0]
    # The epoch's System Prompt stays byte-identical across both changes.
    assert systems == [systems[0]] * 4
    narrowed, widened = [
        str(message.content)
        for message in history(runtime, "s1", agent.id)
        if is_prompt_block_change_note(message)
    ]
    assert workspace.as_posix() in narrowed and "refused" not in narrowed
    # Widening tells the Agent that calls the earlier rules refused can run now.
    assert "full access" in widened and "refused" in widened
