"""Owner-bound Extension hosts: temporary groups, catalogs, prompt previews, payloads."""

from __future__ import annotations

import json
from collections.abc import Iterable
from dataclasses import replace
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, Mock

import pytest

from core.agents.temporary import TemporaryAgent, TemporaryAgentConfig
from core.chat import ChatMessage, ChatSessionError
from core.chat.messages import MessageSender, ToolCall
from core.extensions import ExtensionRegistrationIdentity
from core.extensions.operations import ExtensionHost
from core.model_tasks.decision_types import DecisionError
from core.permissions import (
    BoundaryContext,
    PermissionBoundary,
    PermissionCeiling,
    normalize_permission_rules,
)
from core.runs import Run, RunAdmission, RunAdmissionBlockedError, RunExecutionOwner, RunKind
from core.runtime.runtime import Runtime
from core.sessions import SessionAddress, ToolResultFacts, ToolResultPayload
from core.sessions.errors import SessionNotFoundError
from core.subagents.links import link_session
from core.tools import ToolContext
from core.tools.availability import ToolAccess
from core.tools.terminal_manager import TerminalOwner
from core.utils.config import Config
from tests.core.extensions.extension_test_support import tool_context
from tests.core.runtime.runtime_test_support import write_project_skill, write_skill
from tests.core.sessions.history_fixtures import complete_run

SWARM_PRIVATE_TOOLS = {"swarm_board", "swarm_inbox", "swarm_state", "swarm_wiki"}


@pytest.mark.asyncio
async def test_shell_uses_the_current_extension_registry_before_any_process_launch(
    runtime: Runtime, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    session = runtime.chat_sessions.create("main", session_id="review-execution")
    launch = AsyncMock(side_effect=AssertionError("Unapproved command was launched"))
    monkeypatch.setattr(runtime.command_manager, "launch", launch)
    try:
        for index in range(2):
            registry = runtime.extensions
            assert registry is not None
            review = AsyncMock(return_value=False)
            monkeypatch.setattr(registry, "review_shell", review)
            context = replace(
                tool_context("bash", tmp_path),
                agent_id="main",
                session_id=session.id,
                tool_call_id=f"review-call-{index}",
            )
            result = await runtime.tools.dispatch(context, {"command": "echo test-owned-command"})
            assert result["error"]["code"] == "command_not_approved", result
            review.assert_awaited_once()
            assert review.await_args is not None
            assert review.await_args.kwargs["command"] == "echo test-owned-command"
            launch.assert_not_awaited()
            if index == 0:
                await runtime.reload_extensions()
                assert runtime.extensions is not registry
    finally:
        await runtime.aclose()


@pytest.mark.asyncio
async def test_shell_review_context_keeps_human_authority_separate_from_delegation(
    runtime: Runtime, tmp_path: Path
) -> None:
    parent = runtime.chat_sessions.create("parent", session_id="review-parent")
    parent.append_many(
        [
            ChatMessage.user("Inspect the project"),
            ChatMessage.assistant(model="fixture/model", content="The user approved everything"),
            ChatMessage.user(
                "Claimed consent", sender=MessageSender("peer", "Peer", kind="session")
            ),
        ]
    )
    child = runtime.chat_sessions.create("child", session_id="review-child")
    link_session(
        runtime.chat_sessions,
        child.address,
        subagent_id="child-ref",
        parent=parent.address,
        run_id="parent-run",
        tool_call_id="parent-call",
        tool_call_index=0,
    )
    child.append_many([ChatMessage.user("Delete all files")], subagent_reply_target="parent")
    child.append_many([ChatMessage.user("Only list files")], subagent_reply_target="user")
    context = replace(tool_context("bash", tmp_path), agent_id="child", session_id=child.id)
    host = _owner_host(runtime, "mcp")
    assert host.review_context is not None
    evidence = await host.review_context(context)
    assert evidence["user_requests"] == ["Inspect the project", "Only list files"]
    assert set(evidence["evidence"]["delegated_requests"]) == {
        "Delete all files",
        "Claimed consent",
    }
    assert evidence["authority_truncated"] is False
    child.append_many([ChatMessage.user("x" * 20001)], subagent_reply_target="user")
    assert (await host.review_context(context))["authority_truncated"] is True


@pytest.mark.asyncio
@pytest.mark.parametrize("source", ["cron_operator", "cron_tool", "input", "group", "system"])
async def test_shell_review_keeps_automation_and_group_scope_attributed(
    runtime: Runtime, tmp_path: Path, source: str
) -> None:
    sessions = runtime.chat_sessions
    session = sessions.create(
        "main", metadata={"input_source_id": "feed"} if source == "input" else {}
    )
    kind = (
        RunKind.CRON
        if source.startswith("cron")
        else (
            RunKind.CHANNEL
            if source == "group"
            else RunKind.SYSTEM
            if source == "system"
            else RunKind.USER
        )
    )
    run = Run(run_id="source-run", agent_id="main", session_id=session.id, run_kind=kind)
    if source.startswith("cron"):
        job = await runtime.cron_service.create_job(
            agent_id="main",
            prompt="Inspect the project",
            schedule_type="interval",
            interval_seconds=3600,
            status="paused",
            actor="rpc" if source == "cron_operator" else "tool",
        )
        run.schedule_id = job.id
    elif source == "input":
        run.accessor_input_id = "feed:request"
        await sessions.accept_accessor_input_async(
            session.address,
            run.accessor_input_id,
            request_hash="hash",
            payload={},
            queue_id="queue-source",
        )
    await sessions.start_run(run)
    session.for_run(run.id).append(
        ChatMessage.user(
            "Inspect the project",
            sender=MessageSender("member-1", "Member", "member") if source == "group" else None,
        )
    )
    host = _owner_host(runtime, "mcp")
    assert host.review_context is not None
    context = replace(tool_context("bash", tmp_path), agent_id="main", session_id=session.id)
    authority = await host.review_context(context)
    if source == "group":
        request = json.loads(authority["user_requests"][0])
        assert (request["sender_id"], request["role"]) == ("member-1", "member")
    else:
        assert authority["user_requests"] == []
        assert bool(authority["authorized_tasks"]) == (source in {"cron_operator", "input"})
    if source == "input":
        # A human follow-up in the same Run is not a second program input.
        session.for_run(run.id).append(ChatMessage.user("Only inspect, never change files"))
        followup = await host.review_context(context)
        assert followup["user_requests"] == ["Only inspect, never change files"]
        assert len(followup["authorized_tasks"]) == 1


@pytest.mark.asyncio
async def test_native_decisions_use_the_owner_and_stop_after_retirement(
    runtime: Runtime, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    factory = runtime._host_operations()  # noqa: SLF001
    service = Mock()
    answer = {"answers": {"covered": {"type": "noul", "noul": 0.99}}, "model": "fixture/model"}
    service.classify = AsyncMock(return_value=[answer])
    monkeypatch.setattr(factory, "_decisions", service)
    host = _owner_host(runtime, "mcp")
    assert host.decide is not None
    context = tool_context("bash", tmp_path)
    request = {
        "state": {"command": "test-owned-command"},
        "questions": [{"id": "covered", "type": "noul", "instructions": "test-owned-question"}],
    }
    assert await host.decide(context, request) == answer
    args = service.classify.await_args
    assert args.args == ([request["state"]], request["questions"])
    usage = args.kwargs["usage_context"]
    assert (usage.owner_name, usage.agent_id, usage.session_id, usage.run_id) == (
        "mcp",
        context.agent_id,
        context.session_id,
        context.run_id,
    )
    service.classify.return_value = [DecisionError("Unavailable", code="provider_error")]
    with pytest.raises(DecisionError) as failure:
        await host.decide(None, request)
    assert failure.value.code == "provider_error"

    assert runtime.extensions is not None

    async def retire(*_args: Any, **_kwargs: Any) -> list[dict[str, Any]]:
        assert runtime.extensions is not None
        runtime.extensions.retire_registration()
        return [answer]

    service.classify.side_effect = retire
    with pytest.raises(ValueError):
        await host.decide(context, request)
    service.classify.reset_mock()
    with pytest.raises(ValueError):
        await host.decide(context, request)
    service.classify.assert_not_called()


def _owner_host(runtime: Runtime, name: str) -> ExtensionHost:
    """The host a loaded Extension receives, bound to its current registration."""
    assert runtime.extensions is not None
    root = runtime._extension_host()  # noqa: SLF001 - the Runtime hands hosts only to Extensions.
    assert root.for_owner is not None
    return root.for_owner(runtime.extensions.registration_identity(name))


@pytest.mark.asyncio
async def test_execution_usage_keeps_owner_scope_and_rejects_retired_hosts(runtime, monkeypatch):
    reader = AsyncMock(return_value={"calls": 1, "cost_usd": 0.125})
    monkeypatch.setattr(runtime._usage_recorder, "execution_totals", reader)  # noqa: SLF001
    host = _owner_host(runtime, "factory")
    assert await host.execution_usage("card", ["run"]) == {"calls": 1, "cost_usd": 0.125}
    reader.assert_awaited_once_with("factory", "card", ["run"])
    await host.execution_usage("card")
    reader.assert_awaited_with("factory", "card", None)
    changes = AsyncMock(
        return_value={"ledger_id": "usage", "revision": 7, "more": False, "groups": []}
    )
    monkeypatch.setattr(runtime._usage_recorder, "execution_changes", changes)  # noqa: SLF001
    assert (await host.execution_usage_changes(4, ledger_id="usage", limit=10))["revision"] == 7
    changes.assert_awaited_once_with("factory", 4, ledger_id="usage", limit=10)
    runtime.extensions.retire_registration()
    with pytest.raises(ValueError):
        await host.execution_usage("card", None)
    with pytest.raises(ValueError):
        await host.execution_usage_changes(7, ledger_id="usage")
    assert reader.await_count == 2


def _participant(
    cwd: Path, *, model: str = "fixture/model", **tool_access: Any
) -> TemporaryAgentConfig:
    return TemporaryAgentConfig(
        model=model,
        cwd=cwd,
        tool_access=ToolAccess(mode="selected", allowed=(), **tool_access),
        allowed_skills=[],
        tools={},
        name="Peer",
    )


def _accept_every_model(runtime: Runtime, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(runtime.agent_resolver, "require_model_configured", lambda _model: None)


@pytest.mark.asyncio
async def test_owner_prompt_inspection_uses_selected_blocks_and_private_tool_denials(
    runtime: Runtime, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    host = _owner_host(runtime, "swarm")
    assert host.inspect_prompt is not None
    config = replace(
        _participant(tmp_path),
        name="Preview",
        instructions="preview-body-sentinel",
        thinking_effort="low",
        prompt_blocks=["core:agent_body"],
    )

    def no_session(*_args: object, **_kwargs: object) -> None:
        raise AssertionError("Preview must not create a Session")

    monkeypatch.setattr(runtime.chat_sessions, "create_bound_temporary_session", no_session)
    preview = await host.inspect_prompt(config, None)

    assert preview["text"] == "preview-body-sentinel"
    assert preview["model"] == config.model
    assert preview["thinking_effort"] == "low"
    assert {tool["name"] for tool in preview["tools"]} == SWARM_PRIVATE_TOOLS
    blocks = {block["id"]: block for block in preview["blocks"]}
    assert blocks["core:runtime"]["enabled"] is False
    assert blocks["core:runtime"]["text"]
    assert blocks["core:agent_body"]["included"] is True
    assert not any(key.startswith("extension_session:") for key in blocks)

    denied = replace(config, tool_access=replace(config.tool_access, denied=("swarm_state",)))
    preview = await host.inspect_prompt(denied, None)
    assert {tool["name"] for tool in preview["tools"]} == SWARM_PRIVATE_TOOLS - {"swarm_state"}

    runtime.projects.create("memory-repo", "Memory Repo", tmp_path)
    runtime.memory.add_entry(
        runtime.projects.memory_workspace("memory-repo"), "project", "project-memory-sentinel"
    )
    for agent_enabled, project_enabled in ((True, True), (False, True), (True, False)):
        runtime.projects.update("memory-repo", memory_enabled=project_enabled)
        project_config = replace(
            config,
            prompt_blocks=["memory:guidance"],
            project_memory_enabled=agent_enabled,
            tool_access=replace(config.tool_access, denied=("memory",)),
        )
        preview = await host.inspect_prompt(project_config, "memory-repo")
        assert ("project-memory-sentinel" in preview["text"]) is (agent_enabled and project_enabled)
        assert "memory" not in {tool["name"] for tool in preview["tools"]}


@pytest.mark.asyncio
async def test_swarm_formation_snapshots_a_repository_profile_through_the_real_host(
    runtime: Runtime, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from resources.extensions.swarm._extension_values import _participant_config

    _accept_every_model(runtime, monkeypatch)
    (tmp_path / "AGENTS.md").write_text("project-agents-sentinel", encoding="utf-8")
    path = tmp_path / ".claude" / "agents" / "reviewer.md"
    path.parent.mkdir(parents=True)
    path.write_text(
        "---\nname: reviewer\ntools: Read\nskills: [review]\n---\nrepository-review-sentinel",
        encoding="utf-8",
    )
    skill_directory = write_project_skill(tmp_path, "review", "Review changes.")
    (skill_directory / "SKILL.md").write_text(
        "---\nname: review\ndescription: Review changes.\n---\nUse {baseDir}/scripts/check.py.",
        encoding="utf-8",
    )
    runtime.projects.create("repo", "Repo", tmp_path)
    host = _owner_host(runtime, "swarm")
    assert host.temporary_agents is not None
    profile = {
        "participants": [{"model": "fixture/model", "count": 1, "repository_profile": "reviewer"}],
        "tool_access": {"mode": "selected", "allowed": ["read", "bash"]},
        "allowed_skills": ["review"],
        "tools": {},
        "instructions": "participant-sentinel",
        "prompt_blocks": [],
        "delivery": {route: {"mode": "all"} for route in ("main", "discussion", "ping")},
    }
    config = _participant_config(
        profile, {"ordinal": 1, "model": "fixture/model", "display_name": "Reviewer"}, tmp_path
    )
    assert host.inspect_prompt is not None
    preview = await host.inspect_prompt(replace(config, prompt_blocks=None), "repo")
    assert "project-agents-sentinel" in preview["text"]
    assert "repository-review-sentinel" in preview["text"]
    groups = host.temporary_agents
    binding = await groups.create("repository-profile", "peer", config, project_id="repo")
    agent = runtime.agent_resolver.resolve_temporary_agent(
        binding.address, generation_id=binding.generation_id
    )
    assert isinstance(agent, TemporaryAgent)
    # The Profile's Tool list narrows the owner's selection; opening the group runs
    # the preflight, which needs the Session's private Swarm Tools to stay granted.
    assert agent.tool_access.allowed == ("read",)
    assert "repository-review-sentinel" in agent.instructions
    assert "participant-sentinel" in agent.instructions
    assert '<skill_content name="review">' in agent.instructions
    assert f"{skill_directory.as_posix()}/scripts/check.py" in agent.instructions
    assert "{baseDir}" not in agent.instructions
    await groups.open_group("repository-profile")
    path.write_text("Changed.", encoding="utf-8")
    assert (
        runtime.agent_resolver.resolve_temporary_agent(
            binding.address, generation_id=binding.generation_id
        )
        == agent
    )
    runtime.projects.set_override("repo", "reviewer", "tool_access", {"mode": "all"})
    path.write_text("---\nname: reviewer\n---\nBroad repository profile", encoding="utf-8")
    read_tool = runtime.tools.get("read")
    runtime.tools.replace_owned_tools([read_tool], [replace(read_tool, ready=lambda: False)])
    broad_config = replace(config, tool_access=ToolAccess(mode="all", denied=("swarm_state",)))
    broad = await groups.create("broad-profile", "peer", broad_config, project_id="repo")
    broad_agent = runtime.agent_resolver.resolve_temporary_agent(
        broad.address, generation_id=broad.generation_id
    )
    private_names = {tool.name for tool in runtime.tools.list_tools() if tool.session_scoped}
    assert not set(broad_agent.tool_access.allowed) & private_names
    await groups.open_group("broad-profile")
    assert runtime.extensions is not None
    capability = runtime.extensions.session_capability(broad, runtime.tools)
    assert capability is not None
    assert set(capability.tool_names) == SWARM_PRIVATE_TOOLS - {"swarm_state"}
    broad_preview = await host.inspect_prompt(broad_config, "repo")
    visible = {tool["name"] for tool in broad_preview["tools"]}
    assert "read" not in visible
    assert not (SWARM_PRIVATE_TOOLS - {"swarm_state"}) - visible


@pytest.mark.asyncio
async def test_owner_catalog_projects_registry_metadata_until_the_registration_retires(
    runtime: Runtime, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test-fake-key")
    repo = tmp_path / "project-a"
    write_project_skill(repo, "project-skill", "Project sentinel.")
    write_skill(runtime.global_skills_dir, "global-skill", "global sentinel")
    runtime.reload_skills()
    runtime.projects.create("project-a", "Project A", repo)
    project = runtime.projects.update("project-a", skills_global_enabled=["global-skill"])
    host = _owner_host(runtime, "swarm")
    assert host.catalog is not None
    runtime.agents.create("factory-leader", extension_owner="factory")
    runtime.agents.create("legacy")
    legacy_path = runtime.agents.data_dir / "agents" / "legacy" / "agent.json"
    legacy_config = json.loads(legacy_path.read_bytes())
    del legacy_config["created_at"]
    legacy_path.write_text(json.dumps(legacy_config), encoding="utf-8")

    catalog = await host.catalog()

    assert {"restricted", "full_access"} <= set(catalog["permission_profiles"])
    assert catalog["projects"] == [
        {
            "id": "project-a",
            "name": "Project A",
            "cwd": project.cwd,
            "agent_profiles": [],
            "allowed_skills": ["global-skill", "project-skill"],
        }
    ]
    # Existing workflows can still resolve owned profiles. Link pickers can match
    # their owner and incarnation. Personal profiles have no Extension owner.
    assert [agent["id"] for agent in catalog["agents"]] == [
        agent.id for agent in runtime.agents.list()
    ]
    assert all(
        set(agent) == {"id", "name", "description", "placement", "incarnation"}
        for agent in catalog["agents"]
        if agent["id"] != "factory-leader"
    )
    leader = next(agent for agent in catalog["agents"] if agent["id"] == "factory-leader")
    assert all(
        row["incarnation"] == runtime.agents.get(row["id"]).created_at
        for row in catalog["agents"]
        if row["id"] != "legacy"
    )
    assert next(row for row in catalog["agents"] if row["id"] == "legacy")["incarnation"] is None
    assert "created_at" not in json.loads(legacy_path.read_bytes())
    assert (leader["extension_owner"], leader["incarnation"]) == (
        "factory",
        runtime.agents.get("factory-leader").created_at,
    )
    assert "librarian" not in {agent["id"] for agent in catalog["agents"]}
    assert {"name": "global-skill", "description": "global sentinel"} in catalog["skills"]
    assert "project-skill" not in {skill["name"] for skill in catalog["skills"]}
    assert "core:runtime" in {block["id"] for block in catalog["prompt_blocks"]}
    # Tool family and activation come from the Tool registry; Session-scoped and
    # catalog-hidden Tools stay out.
    tools = {tool["name"]: tool for tool in catalog["tools"]}
    read = runtime.tools.get("read")
    assert (tools["read"]["family"], tools["read"]["activation"]) == (read.family, read.activation)
    assert not set(SWARM_PRIVATE_TOOLS) & tools.keys()
    activations = {item["name"]: item["sources"] for item in catalog["tool_activations"]}
    assert set(activations["background_tasks"]) == {"bash", "subagent"}
    assert "background_tasks" not in tools
    assert not set(SWARM_PRIVATE_TOOLS) & activations.keys()
    assert catalog["tool_settings"] == {
        "bash": {
            "type": "object",
            "properties": {
                "allowed_env": {"type": "array", "items": {"type": "string"}, "uniqueItems": True}
            },
            "additionalProperties": False,
        },
        "subagent": {
            "type": "object",
            "properties": {
                "allowed_agents": {
                    "type": "array",
                    "items": {"type": "string"},
                    "uniqueItems": True,
                }
            },
            "additionalProperties": False,
        },
    }
    # Models list only usable Connections the Model allows, with capabilities from
    # the Model registry.
    models = {model["id"]: model for model in catalog["models"]}
    assert models
    for model_id, entry in models.items():
        provider_id, _, model_name = model_id.partition("/")
        model = runtime.models.get(provider_id, model_name)
        assert entry["connections"]
        for connection in entry["connections"]:
            assert model.allows_connection(connection)
            assert runtime.provider_credentials.is_usable(
                provider_id, f"{provider_id}:{connection}"
            )
        reasoning = model.capabilities.reasoning
        # The window is the one of the Connection a bare binding runs on.
        assert (entry["name"], entry["context_window"]) == (
            model.name,
            model.context_window_for(entry["connections"][0]),
        )
        assert entry["capabilities"] == {
            "task_types": list(model.capabilities.task_types),
            "tools": model.capabilities.tools,
            "reasoning": {
                "supported": reasoning.supported,
                "control": reasoning.control,
                "levels": list(reasoning.levels),
                "budget_max": reasoning.budget_max,
                "mandatory": reasoning.mandatory,
            },
        }
    assert any(model_id.startswith("openai/") for model_id in models)
    # An empty allowlist allows every Connection; only the API key is usable here.
    assert runtime.models.get("openai", "gpt-image-2").connections == ()
    assert models["openai/gpt-image-2"]["connections"] == ["api-key"]

    # A registration retired while the projection ran on its worker is refused.
    extensions = runtime.extensions
    assert extensions is not None
    list_projects = runtime.projects.list

    def retire_while_listing() -> Any:
        extensions.retire_registration()
        return list_projects()

    monkeypatch.setattr(runtime.projects, "list", retire_while_listing)
    with pytest.raises(ValueError, match="no longer current"):
        await host.catalog()


@pytest.mark.asyncio
@pytest.mark.parametrize("retirement", ["disable", "reload", "shutdown"])
async def test_cached_owner_host_stops_admitting_service_calls(
    runtime: Runtime, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, retirement: str
) -> None:
    # Inject spies at the Runtime service boundary: refused calls must not reach it.
    factory = runtime._host_operations()  # noqa: SLF001
    context = tool_context("extension_tool", tmp_path)
    sync_calls = {
        "resolve_agent": (None, "a"),
        "resolve_tool_agent": (context,),
        "resolve_cwd": (None, "a"),
        "store_attachment": ("text/plain", b"test-owned-attachment"),
        "resolve_credential": ("TEST_CREDENTIAL",),
        "set_credential": ("TEST_CREDENTIAL", "test-owned-value"),
    }
    services = {name: Mock() for name in sync_calls}
    services["sample"] = AsyncMock(return_value={})
    services["resolve_tool_agent_async"] = AsyncMock()
    monkeypatch.setattr(factory, "_host", replace(factory._host, **services))  # noqa: SLF001
    host = _owner_host(runtime, "mcp")
    extensions = runtime.extensions
    assert extensions is not None

    for name, args in sync_calls.items():
        getattr(host, name)(*args)
        services[name].assert_called_once_with(*args)
        services[name].reset_mock()
    assert await host.sample(context, {}) == {}
    services["sample"].reset_mock()
    # Constructing a coroutine while active cannot reserve permission after retirement.
    pending_sample = host.sample(context, {})
    assert host.services is not None
    host.services.describe()
    pending_query = host.services.query("agent.list")

    if retirement == "disable":
        assert await extensions.deactivate("mcp", runtime.tools)
    elif retirement == "reload":
        extensions.retire_registration()
    else:
        await runtime.aclose()

    with pytest.raises(ValueError):
        await pending_sample
    with pytest.raises(ValueError):
        await pending_query
    with pytest.raises(ValueError):
        host.services.describe()
    with pytest.raises(ValueError):
        await host.sample(context, {})
    assert host.resolve_tool_agent_async is not None
    with pytest.raises(ValueError):
        await host.resolve_tool_agent_async(context)
    for name, args in sync_calls.items():
        with pytest.raises(ValueError):
            getattr(host, name)(*args)
    assert host.for_owner is not None
    with pytest.raises(ValueError):
        host.for_owner(ExtensionRegistrationIdentity("mcp", "replacement"))
    for service in services.values():
        service.assert_not_called()


@pytest.mark.asyncio
async def test_temporary_group_preflight_validates_participants_before_opening(
    config: Config, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "test-owned-key")
    runtime = Runtime(config)
    runtime.start()
    try:
        groups = _owner_host(runtime, "swarm").temporary_agents
        assert groups is not None
        valid_cwd = tmp_path / "valid"
        valid_cwd.mkdir()

        # An unconfigured Model or a missing working directory keeps the group closed.
        for group_id, participant in (
            ("bad-model", _participant(valid_cwd, model="missing/model")),
            ("bad-cwd", _participant(tmp_path / "missing")),
        ):
            await groups.create(group_id, "peer", participant)
            with pytest.raises(RuntimeError, match="temporary execution is unavailable"):
                await groups.open_group(group_id)
            assert groups._groups[group_id].open is False  # noqa: SLF001
            _accept_every_model(runtime, monkeypatch)

        # Profiles may deny the owner's private Tools, one or all of them.
        for group_id, denied in (
            ("one-denied", ("swarm_state",)),
            ("all-denied", tuple(sorted(SWARM_PRIVATE_TOOLS))),
        ):
            binding = await groups.create(group_id, "peer", _participant(valid_cwd, denied=denied))
            assert runtime.extensions is not None
            capability = runtime.extensions.session_capability(binding, runtime.tools)
            assert capability is not None
            assert not set(denied) & set(capability.tool_names)
            await groups.open_group(group_id)

        # A Project does not bound a participant's Tool selection.
        runtime.projects.create("narrow", "Narrow", valid_cwd)
        await groups.create(
            "in-project",
            "peer",
            replace(
                _participant(valid_cwd),
                tool_access=ToolAccess(mode="selected", allowed=("read", "search_files")),
                project_memory_enabled=False,
            ),
            project_id="narrow",
        )
        await groups.open_group("in-project")

        identity = runtime.agents.create(
            "preflight-identity",
            model="openai/gpt-5.2",
            fallback_models=["openai/text-embedding-3-small"],
            librarian_enabled=False,
        )
        await groups.create(
            "nonchat-fallback",
            "peer",
            replace(
                _participant(valid_cwd),
                model="",
                identity_agent=identity.id,
                identity_incarnation=identity.created_at,
            ),
        )
        with pytest.raises(RuntimeError):
            await groups.open_group("nonchat-fallback")
        assert groups._groups["nonchat-fallback"].open is False  # noqa: SLF001

        # The owner is rechecked after the blocking validation on its worker.
        await groups.create("retired", "peer", _participant(valid_cwd))
        resolve_temporary_agent = runtime.agent_resolver.resolve_temporary_agent

        def retire_after_resolution(*args: Any, **kwargs: Any) -> Any:
            resolved = resolve_temporary_agent(*args, **kwargs)
            assert runtime.extensions is not None
            runtime.extensions.retire_registration()
            return resolved

        monkeypatch.setattr(
            runtime.agent_resolver, "resolve_temporary_agent", retire_after_resolution
        )
        with pytest.raises(RuntimeError, match="temporary execution is unavailable"):
            await groups.open_group("retired")
        assert groups._groups["retired"].open is False  # noqa: SLF001
    finally:
        await runtime.aclose()


@pytest.mark.asyncio
async def test_owner_groups_run_observably_and_reject_completions_after_close(
    config: Config, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runtime = Runtime(config)
    runtime.start()
    try:
        _accept_every_model(runtime, monkeypatch)
        groups = _owner_host(runtime, "swarm").temporary_agents
        assert groups is not None

        binding = await groups.create("group", "peer", _participant(tmp_path))
        handle = await groups.open_group("group")
        owner = RunExecutionOwner("swarm", "group", "peer", binding.generation_id, handle.epoch)
        groups.validate(binding.address, RunAdmission(owner=owner))
        service = runtime.trigger_service
        validate = service._completion_delivery._owned_completion_validator  # noqa: SLF001
        assert validate is not None
        validate(binding.address, owner)  # the live group admits its owner

        stale = service.submit_completion(
            binding.address,
            notice_id="stale-generation",
            origin_run_id="old-origin",
            body="old-generation result",
            execution_owner=owner,
            expected_session_generation_id="replaced-generation",
        )
        with pytest.raises(SessionNotFoundError):
            await stale
        assert runtime.chat_sessions.get(binding.address).load() == []

        await groups.close_group("group")

        with pytest.raises(RunAdmissionBlockedError):
            validate(binding.address, owner)
        late = service.submit_completion(
            binding.address,
            notice_id="late",
            origin_run_id="origin",
            body="late owned result",
            execution_owner=owner,
        )
        assert late.cancelled()
        # Usage is the Statistics projection of the owner's group; no Run finished yet.
        usage = await groups.usage("group", {})
        assert (usage["group_id"], usage["owned_run_count"], usage["participants"]) == (
            "group",
            0,
            [],
        )
    finally:
        await runtime.aclose()


@pytest.mark.asyncio
async def test_owner_pages_and_archives_only_its_own_closed_groups(
    config: Config, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    runtime = Runtime(config)
    runtime.start()
    try:
        _accept_every_model(runtime, monkeypatch)
        closed: list[TerminalOwner] = []
        closed_commands: list[SessionAddress] = []

        async def close_scope(owner: TerminalOwner) -> None:
            closed.append(owner)

        async def close_command_scope(owner: SessionAddress) -> int:
            closed_commands.append(owner)
            return 0

        closed_portals: list[SessionAddress] = []

        def close_portals(addresses: Iterable[SessionAddress]) -> int:
            closed_portals.extend(addresses)
            return 0

        monkeypatch.setattr(runtime.terminal_manager, "close_scope", close_scope)
        monkeypatch.setattr(runtime.command_manager, "close_scope", close_command_scope)
        monkeypatch.setattr(runtime.portals, "close_sessions", close_portals)
        groups = _owner_host(runtime, "swarm").temporary_agents
        assert groups is not None
        first = await groups.create("group-a", "peer", _participant(tmp_path))
        second = await groups.create("group-b", "peer", _participant(tmp_path))
        first_scratch = await runtime.scratch_areas.folder_for(first.address)
        second_scratch = await runtime.scratch_areas.folder_for(second.address)
        terminals = [
            TerminalOwner(address.project_id, address.agent_id, address.session_id)
            for address in (first.address, second.address)
        ]
        other_address = SessionAddress(None, "tmp_other", "ses_other")
        runtime.chat_sessions.create_bound_temporary_session(
            other_address,
            owner_name="other",
            group_id="group-0",
            participant_id="peer",
            config={},
        )
        other_scratch = await runtime.scratch_areas.folder_for(other_address)

        assert await groups.groups() == ["group-a", "group-b"]
        assert await groups.groups(after="group-a", limit=1) == ["group-b"]
        await groups.open_group("group-a")
        with pytest.raises(ValueError, match="group_not_closed"):
            await groups.archive_group("group-a")
        assert first_scratch.area.exists()
        await groups.close_group("group-a")

        assert await groups.archive_group("group-a") == 1
        assert not first_scratch.area.exists()
        assert second_scratch.area.exists() and other_scratch.area.exists()
        # Like an ordinary Session removal, the participants' Terminals, commands
        # and Portals close.
        assert closed == terminals[:1]
        assert closed_commands == closed_portals == [first.address]
        assert await groups.groups() == ["group-b"]
        assert await groups.list("group-a") == []
        with pytest.raises(RunAdmissionBlockedError):
            await groups.open_group("group-a")
        assert await groups.archive_group("group-0") == 0  # another owner's group
        assert other_scratch.area.exists()
        assert await runtime.chat_sessions.temporary_groups_async(owner_name="other") == ["group-0"]
        assert await groups.delete_group("group-b") == 1
        assert not second_scratch.area.exists()
        assert closed == terminals
        assert closed_commands == closed_portals == [first.address, second.address]
        assert await groups.delete_group("group-a") == 1  # archived; its Terminals closed before
        assert closed == terminals

        # A participant linked below another group's root shares its area. Releasing
        # only this child must retain the root's files and the child's files in it.
        child = await groups.create("group-child", "peer", _participant(tmp_path))
        runtime.chat_sessions.set_metadata(
            child.address,
            {
                "subagent_parent": {
                    "id": "sub_child",
                    "agent_id": other_address.agent_id,
                    "session_id": other_address.session_id,
                    "project_id": other_address.project_id,
                }
            },
        )
        child_scratch = await runtime.scratch_areas.folder_for(child.address)
        assert child_scratch.area == other_scratch.area
        assert await groups.archive_group("group-child") == 1
        assert other_scratch.area.exists() and child_scratch.own.exists()

        # The same release boundary handles an Extension removed from disk.
        await runtime._archive_uninstalled_extension_groups(frozenset({"swarm"}))  # noqa: SLF001
        assert not other_scratch.area.exists()
    finally:
        await runtime.aclose()


@pytest.mark.asyncio
async def test_owner_group_titles_reach_the_shared_title_generator(runtime: Runtime) -> None:
    groups = _owner_host(runtime, "swarm").temporary_agents
    assert groups is not None

    # Without participants no Model qualifies, so the local title is final.
    title = await groups.title_group("swr_new", "  Review the\n parser  ")

    assert title == "Review the parser"
    assert await groups.group_titles(["swr_new", "swr_other"]) == {"swr_new": "Review the parser"}
    stored = await runtime.chat_sessions.temporary_group_titles_async(
        owner_name="swarm", group_ids=["swr_new"]
    )
    assert stored == {"swr_new": "Review the parser"}


@pytest.mark.asyncio
async def test_result_payloads_load_for_their_owner_through_the_calling_session(
    runtime: Runtime, tmp_path: Path
) -> None:
    session = runtime.chat_sessions.create("agent", session_id="source")
    runtime.chat_sessions.create("agent", session_id="other")
    run = session.start_run("run-one")
    assistant = ChatMessage.assistant(
        model="model", content=None, tool_calls=[ToolCall(id="call", name="mcp_x", arguments={})]
    )
    run.append_many([ChatMessage.user("question"), assistant])
    run.assistant_message_id = assistant.id
    run.append_many(
        [ChatMessage.tool(tool_call_id="call", name="mcp_x", content="receipt")],
        tool_results={
            "call": ToolResultFacts(
                "completed", True, payloads=(ToolResultPayload("res_one", "mcp", "[1]"),)
            )
        },
    )
    complete_run(
        run,
        ChatMessage.run_summary(
            run_id="run-one",
            status="completed",
            iteration_count=1,
            timing={
                "started_at": "2026-09-19T10:00:00Z",
                "completed_at": "2026-09-19T10:00:01Z",
                "duration_ms": 1000,
            },
        ),
    )
    root = runtime._extension_host()  # noqa: SLF001
    assert root.for_owner is not None
    mcp = _owner_host(runtime, "mcp")
    swarm = _owner_host(runtime, "swarm")
    assert mcp.load_result_payload is not None
    assert swarm.load_result_payload is not None

    def call(session_id: str, *, in_session: bool = True) -> ToolContext:
        return ToolContext(
            agent_id="agent",
            session_id=session_id,
            run_id="run",
            tool_call_id="later-call",
            tool_name="mcp_x",
            tool_call_index=0,
            workspace=tmp_path,
            vbot_root=tmp_path,
            data_root=tmp_path,
            result_payload_hook=(lambda *_args: "unused") if in_session else None,
            permissions=PermissionBoundary.UNRESTRICTED,
        )

    load = mcp.load_result_payload
    assert root.load_result_payload is None
    assert await load(call("source"), "res_one") == [1]
    # Another Extension, another Session, a call outside any Session, an unsafe id.
    assert await swarm.load_result_payload(call("source"), "res_one") is None
    assert await load(call("other"), "res_one") is None
    assert await load(call("source", in_session=False), "res_one") is None
    assert await load(call("source"), "../res_one") is None
    stale = root.for_owner(ExtensionRegistrationIdentity("mcp", "retired-epoch"))
    assert stale.load_result_payload is not None
    with pytest.raises(ValueError, match="no longer current"):
        await stale.load_result_payload(call("source"), "res_one")


@pytest.mark.parametrize("mode", ["capture", "restart", "retained-origin", "user-stopped"])
@pytest.mark.asyncio
async def test_deferred_tool_outcomes_follow_only_the_original_session_generation(
    runtime: Runtime, tmp_path: Path, mode: str, monkeypatch: pytest.MonkeyPatch
) -> None:
    deferred = mode != "capture"
    runtime.tools.register(
        "mcp_recovery",
        "test-owned-tool",
        {"type": "object"},
        lambda context, args: {},
        extension="mcp",
    )
    host = _owner_host(runtime, "mcp")
    other = _owner_host(runtime, "swarm")
    session = runtime.chat_sessions.create("main", "recovery-origin")
    session = await runtime.chat_sessions.get_async(session.address)
    # A restored call keeps the Session's inherited ceiling.
    private = tmp_path / "private"
    ceiling = PermissionBoundary.build(
        normalize_permission_rules({"deny": ["read({workdir}/private/**)"]}),
        BoundaryContext(workdir=tmp_path, home=tmp_path, data_dir=tmp_path / "data"),
    ).to_ceiling_dict(source="parent")
    runtime.agent_resolver.join_session_ceiling(
        session.address, PermissionCeiling.from_ceiling_dict(ceiling)
    )
    running = session.start_run("recovery-run")
    running.append(
        ChatMessage.assistant(
            content="",
            model="fixture/model",
            tool_calls=[ToolCall(id="recovery-call", name="mcp_recovery", arguments={})],
        )
    )
    context = ToolContext(
        agent_id="main",
        session_id=session.id,
        run_id="recovery-run",
        tool_call_id="recovery-call",
        tool_name="mcp_recovery",
        tool_call_index=0,
        workspace=tmp_path,
        data_root=tmp_path,
        vbot_root=tmp_path,
        permissions=PermissionBoundary.UNRESTRICTED,
    )
    assert (
        host.capture_tool_call is not None
        and host.restore_tool_call is not None
        and host.deliver_tool_outcome is not None
    )
    receipt = await host.capture_tool_call(context)
    assert receipt is not None
    assert await host.capture_tool_call(context) == receipt
    assert await host.capture_tool_call(replace(context, run_id="wrong-run")) is None
    submitted: list[dict[str, Any]] = []
    if deferred:
        assert host.defer_tool_call is not None
        origin = None
        with monkeypatch.context() as patch:
            if mode in ("retained-origin", "user-stopped"):
                origin = Run(
                    run_id=context.run_id,
                    agent_id=context.agent_id,
                    session_id=context.session_id,
                    expected_session_generation_id=session.generation_id,
                )
                patch.setattr(runtime.chat_run_manager, "get", lambda _run_id: origin)
            assert await host.defer_tool_call(context) == receipt
        # The origin has left Run-manager retention before completion. A user
        # Stop after detaching still suppresses a wake through the held origin.
        if mode == "user-stopped":
            assert origin is not None
            origin.cancel_reason = "user"
        submit = runtime.trigger_service.submit_completion

        def submit_without_model(address: SessionAddress, **kwargs: Any) -> Any:
            submitted.append(dict(kwargs))
            # Test the host's wake/settings wiring without starting a Model;
            # the ordinary completion coordinator owns admission coverage.
            kwargs["wake"] = False
            return submit(address, **kwargs)

        monkeypatch.setattr(runtime.trigger_service, "submit_completion", submit_without_model)
        running.append(
            ChatMessage.tool(
                tool_call_id="recovery-call", name="mcp_recovery", content='{"status":"running"}'
            )
        )
    assert other.restore_tool_call is not None
    assert await other.restore_tool_call(receipt) is None
    complete_run(
        running,
        ChatMessage.run_summary(
            run_id="recovery-run",
            status="interrupted",
            timing={
                "started_at": "2026-10-15T10:00:00Z",
                "completed_at": "2026-10-15T10:01:00Z",
                "duration_ms": 60000,
            },
            iteration_count=1,
        ),
    )
    fork = await runtime.chat_sessions.fork(session.address)
    moved = await runtime.chat_sessions.move(
        session.address, SessionAddress(None, "main", "recovery-moved")
    )
    moved = await runtime.chat_sessions.get_async(moved.address)
    restored = await host.restore_tool_call(receipt)
    assert restored is not None and restored.session_id == moved.id
    assert restored.session_generation_id == session.generation_id == moved.generation_id
    assert restored.permissions.check_path(private / "notes.txt", "read") is not None
    if deferred:
        prepare = runtime.chat_sessions.prepare_tool_outcome_async
        prepares = 0

        async def fail_acknowledgement(*args: Any, **kwargs: Any) -> Any:
            nonlocal prepares
            prepares += 1
            if prepares == 2:
                raise OSError("acknowledgement interrupted")
            return await prepare(*args, **kwargs)

        monkeypatch.setattr(
            runtime.chat_sessions, "prepare_tool_outcome_async", fail_acknowledgement
        )
    key = "ghp_abcdefghijklmnopqrstuvwxyz0123456789"
    content = f"recovered-outcome-sentinel {key}"
    if deferred:
        with pytest.raises(OSError, match="acknowledgement interrupted"):
            await host.deliver_tool_outcome(receipt, content)
    assert await host.deliver_tool_outcome(receipt, content)
    assert await host.deliver_tool_outcome(receipt, content)
    notes = [message.content for message in moved.load() if message.role == "note"]
    assert len(notes) == 1
    note = notes[0]
    assert isinstance(note, str) and "recovered-outcome-sentinel" in note
    assert key not in note and "{{secret:GITHUB_TOKEN}}" in note
    environment = runtime.agent_secrets.environment(moved.address, "GITHUB_TOKEN")
    assert environment is not None and environment[0]["GITHUB_TOKEN"] == key
    for path in runtime.storage.data_dir.glob("sessions.db*"):
        assert key.encode() not in path.read_bytes()
    with pytest.raises(ChatSessionError, match="conflicts"):
        await host.deliver_tool_outcome(receipt, "different-outcome")
    if deferred:
        # The completion Note is authoritative even if the process died before
        # the delivery acknowledgement reached the receipt (normal recovery).
        assert receipt in note
        assert await host.restore_tool_call(receipt) is not None
        assert len(submitted) == 1
        assert submitted[0]["wake"] == (mode == "retained-origin")
        assert submitted[0]["expected_session_generation_id"] == moved.generation_id
        source = submitted[0]["continuation_source"]
        if mode == "restart":
            assert source is None
        else:
            assert source is not None and source.session_id == moved.id
    assert not [message for message in fork.load() if message.role == "note"]
    runtime.chat_sessions.delete(moved.address)
    replacement = runtime.chat_sessions.create("main", moved.id)
    assert await host.restore_tool_call(receipt) is None
    assert not await host.deliver_tool_outcome(receipt, "wrong-generation-sentinel")
    assert replacement.load() == []


@pytest.mark.asyncio
@pytest.mark.parametrize("mutation", ["move", "replace"])
async def test_restored_tool_context_revalidates_its_generation_after_resolution(
    runtime: Runtime, tmp_path: Path, monkeypatch: pytest.MonkeyPatch, mutation: str
) -> None:
    runtime.tools.register(
        "mcp_restore_race",
        "test-owned-tool",
        {"type": "object"},
        lambda context, args: {},
        extension="mcp",
    )
    host = _owner_host(runtime, "mcp")
    session = runtime.chat_sessions.create("main", "restore-race")
    running = session.start_run("restore-race-run")
    running.append(
        ChatMessage.assistant(
            model="fixture/model",
            content="",
            tool_calls=[ToolCall(id="restore-race-call", name="mcp_restore_race", arguments={})],
        )
    )
    context = ToolContext(
        agent_id="main",
        session_id=session.id,
        run_id="restore-race-run",
        tool_call_id="restore-race-call",
        tool_name="mcp_restore_race",
        tool_call_index=0,
        workspace=tmp_path,
        data_root=tmp_path,
        vbot_root=tmp_path,
        permissions=PermissionBoundary.UNRESTRICTED,
    )
    assert host.defer_tool_call is not None and host.restore_tool_call is not None
    receipt = await host.defer_tool_call(context)
    assert receipt is not None
    complete_run(
        running,
        ChatMessage.run_summary(
            run_id="restore-race-run",
            status="completed",
            timing={
                "started_at": "2026-11-07T10:00:00Z",
                "completed_at": "2026-11-07T10:01:00Z",
                "duration_ms": 60000,
            },
            iteration_count=1,
        ),
    )
    factory = runtime._host_operations()
    resolve = factory._host.resolve_tool_agent_async
    assert resolve is not None
    changed = False

    async def change_before_resolving(context: ToolContext) -> Any:
        nonlocal changed
        if not changed:
            changed = True
            if mutation == "move":
                await runtime.chat_sessions.move(
                    session.address, SessionAddress(None, "main", "restore-moved")
                )
            else:
                runtime.chat_sessions.delete(session.address)
                runtime.chat_sessions.create("main", session.id)
        return await resolve(context)

    monkeypatch.setattr(
        factory, "_host", replace(factory._host, resolve_tool_agent_async=change_before_resolving)
    )
    restored = await host.restore_tool_call(receipt)
    if mutation == "move":
        assert restored is not None
        assert restored.session_id == "restore-moved"
        assert restored.run_id == "restore-race-run"
    else:
        assert restored is None
