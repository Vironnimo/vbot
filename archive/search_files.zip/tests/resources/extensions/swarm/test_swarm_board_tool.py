"""Swarm Board Tool: posts, discussions, addressing, repaired calls and readable results."""

import json
from dataclasses import replace

import pytest

from core.chat import ChatMessage
from resources.extensions.swarm.agent_text import (
    BEFORE_OTHER_DISCUSSION,
    BOARD_ADDRESSED_STOPPED,
    BOARD_NEW,
    BOARD_NOTHING_NEW,
    BOARD_OLDER_CUT,
    BOARD_OTHER_TOOL,
    BOARD_OUTSIDE,
    BOARD_PAGE_NEWEST,
    BOARD_PENDING_AUTOMATIC,
    BOARD_WAIT,
    CURSOR_AS_BEFORE,
    MENTION_CORRECTED,
    MENTION_HOW,
    MENTION_NO_ONE,
    MENTION_USER,
    POST_DUPLICATE,
    POST_SEEN,
    POST_SEEN_OPENING,
    REFERENCE_MARKUP,
)
from tests.resources.extensions.swarm.swarm_test_support import (
    _name,
    board_posts,
    call,
    continuation,
    dispatch,
    persist_carriers,
    visible,
)


@pytest.mark.asyncio
async def test_registered_board_public_posts_pages_and_durable_read_receipt(board):
    result, _ = await call(board, {"action": "list"})
    # Participants see discussions and posts by their numbers; the request is post #0.
    assert '- d1 "Main": main discussion, joined' in result["data"]["content"]
    assert continuation(result["data"]["user_request"]) == {"action": "read", "message_id": "#0"}
    peer = board.bindings[1].participant_id
    posted, posted_context = await call(
        board,
        {"action": "post", "text": "full text", "recipients": [peer, peer]},
    )
    assert posted["ok"]
    assert posted["data"]["delivery"] == (
        f"Queued for 2 participants. It reaches {_name(board, 1)} in full because it addresses "
        "or answers them."
    )
    replay, _ = await call(
        board,
        {"action": "post", "text": "full text", "recipients": [peer, peer]},
        tool_call_id=posted_context.tool_call_id,
    )
    assert replay["data"]["post_id"] == posted["data"]["post_id"]
    assert "nothing was duplicated" in replay["data"]["replayed"]
    # A pending count beside automatic delivery says the posts need no read.
    assert "pending" not in result["data"]
    listed, _ = await call(board, {"action": "list"}, peer=1)
    assert "pending for you: 1" in listed["data"]["content"]
    assert listed["data"]["pending"] == BOARD_PENDING_AUTOMATIC
    read, context = await call(board, {"action": "read"}, peer=1)
    author = board.swarm["participants"][0]["display_name"]
    assert read["data"]["content"] == (
        f"[{posted['data']['post_id']}] {author} (to you):\nfull text"
    )
    assert "(1 shown)" in read["data"]["page"]
    assert read["data"]["new"] == BOARD_NEW["one"].format(posts=posted["data"]["post_id"])
    assert len(context._delivery_receipts) == 1
    receipt_id, content_hash, effect = context._delivery_receipts[0]
    assert not await board.store.reconcile_delivery(receipt_id)
    binding = board.bindings[1]
    await persist_carriers(
        board.sessions,
        binding.address,
        generation_id=binding.generation_id,
        owner_name="swarm",
        messages=[
            ChatMessage.tool(
                tool_call_id=context.tool_call_id, name="swarm_board", content=json.dumps(read)
            )
        ],
        receipts=[(0, receipt_id, content_hash, effect, "tool")],
    )
    assert await board.store.reconcile_delivery(receipt_id)
    assert (await board.store.prepare_inbox_delivery(board.swarm["id"], peer))["entries"] == []
    # Reading the newest posts again finds nothing new: ending the reply is how to wait.
    again, _ = await call(board, {"action": "read"}, peer=1)
    assert again["data"]["new"] == f"{BOARD_NOTHING_NEW} {BOARD_WAIT['addressed']}"
    own, _ = await call(board, {"action": "read"})
    assert own["data"]["new"] == again["data"]["new"]
    # A post outside the reader's audience may be unknown to it, so no such claim is made.
    created, _ = await call(board, {"action": "create", "title": "Side", "text": "aside"})
    side, _ = await call(
        board, {"action": "read", "discussion_id": created["data"]["discussion_id"]}, peer=1
    )
    assert side["data"]["content"].endswith(":\naside") and "new" not in side["data"]
    assert board.tools.get("swarm_board").catalog_visible is False
    assert board.tools.get("swarm_board").session_scoped
    # Where a route waits for a request, a read can be the way to receive its posts.
    await board.store.apply_delivery_settings(
        board.swarm["id"],
        {**board.swarm["delivery"], "main": {"mode": "pull", "wake_idle": False}},
        expected_revision=1,
        request_id="pull-main",
        actor="test",
    )
    pulled, _ = await call(board, {"action": "list"}, peer=1)
    assert "pending for you: 1" in pulled["data"]["content"] and "pending" not in pulled["data"]


@pytest.mark.asyncio
async def test_board_discussion_join_leave_reply_and_exact_pagination(board):
    changes = []
    board.service.host = replace(
        board.service.host,
        publish_change=lambda resource, ids, _revision: changes.append((resource, *ids)),
    )
    created, _ = await call(board, {"action": "create", "title": "Topic", "text": "opening"})
    # The open page shows the new discussion, its opening and the announcement post.
    sid = board.swarm["id"]
    discussions = await board.store.list_discussions(sid, board.bindings[0].participant_id)
    topic = next(row["id"] for row in discussions.entries if row["sequence"] == 2)
    assert changes == [
        ("discussions", sid),
        ("discussion_posts", f"{sid}/{topic}"),
        ("discussion_posts", f"{sid}/{board.swarm['main_discussion_id']}"),
    ]
    changes.clear()
    discussion = created["data"]["discussion_id"]
    opening = created["data"]["opening_post_id"]
    assert (discussion, opening) == ("d2", "#1")
    first, _ = await call(board, {"action": "list", "limit": 1})
    # A value that continues no list, such as a discussion ID, lists from the start.
    restarted, _ = await call(board, {"action": "list", "cursor": "d1", "limit": 1})
    assert restarted["data"]["content"] == first["data"]["content"]
    assert "note" in restarted["data"] and "note" not in first["data"]
    next_page, _ = await call(board, continuation(first["data"]["more"]))
    assert f'- {discussion} "Topic": joined, members: 1' in next_page["data"]["content"]
    joined, _ = await call(board, {"action": "join", "discussion_id": discussion}, peer=1)
    assert joined["data"]["status"] == "Joined. New posts in this discussion now reach you."
    assert f"[{opening}]" in joined["data"]["content"]
    again, _ = await call(board, {"action": "join", "discussion_id": discussion}, peer=1)
    assert again["data"]["status"] == "You had already joined; nothing changed."
    response, _ = await call(
        board,
        {
            "action": "post",
            "discussion_id": discussion,
            "text": "answer",
            "reply_to": opening,
        },
        peer=1,
    )
    assert response["ok"]
    newest, _ = await call(board, {"action": "read", "discussion_id": discussion, "limit": 1})
    # A reply addresses the author of the post it answers.
    assert newest["data"]["content"].endswith(f"(reply to {opening}; to you):\nanswer")
    older_call = continuation(newest["data"]["older"])
    assert older_call == {
        "action": "read",
        "discussion_id": discussion,
        "before": response["data"]["post_id"],
        "limit": 1,
    }
    older, _ = await call(board, older_call)
    assert older["data"]["content"].startswith(f"[{opening}] {_name(board, 0)}:\n")
    assert "older" not in older["data"]
    one, _ = await call(board, {"action": "read", "message_id": opening})
    assert one["data"]["content"] == (
        f'[{opening}] {_name(board, 0)} (in "Topic" {discussion}):\nopening'
    )
    left, _ = await call(board, {"action": "leave", "discussion_id": discussion}, peer=1)
    assert left["data"]["status"].startswith("Left.")
    assert not next(
        row
        for row in (
            await board.store.list_discussions(board.swarm["id"], board.bindings[1].participant_id)
        ).entries
        if row["sequence"] == 2
    )["joined"]
    again, _ = await call(board, {"action": "leave", "discussion_id": discussion}, peer=1)
    assert again["data"]["status"] == "You were not a member; nothing changed."
    # Joining and leaving change the members; reads change nothing the page shows.
    assert changes == [
        ("discussions", sid),
        ("discussion_posts", f"{sid}/{topic}"),
        ("discussions", sid),
    ]


@pytest.mark.asyncio
async def test_post_stored_while_the_registration_retires_is_reported_as_posted(board):
    # A reload or disable retires the registration and refreshes every open page
    # itself; the post is stored, so the call must not read as failed.
    def retired(*_change):
        raise ValueError("extension change is unavailable")

    board.service.host = replace(board.service.host, publish_change=retired)

    posted, _ = await dispatch(board, {"action": "post", "text": "stored anyway"})

    assert posted["ok"]
    read, _ = await call(board, {"action": "read", "message_id": posted["data"]["post_id"]})
    assert read["data"]["content"].endswith(":\nstored anyway")


@pytest.mark.asyncio
async def test_invalid_board_calls_have_no_effect(board):
    for arguments in [
        {},
        {"action": "do it"},
        {"action": "list", "limit": True},
        {"action": "list", "limit": 0},
        {"action": "list", "swarm_id": "foreign"},
        {"action": "read", "message_id": "foreign", "limit": 20},
        {"action": "read", "text": "wrong"},
        {"action": "post"},
        {"action": "post", "text": ""},
        {"action": "post", "text": "x" * 16001},
        {"action": "create", "text": "x"},
        {"action": "join"},
        {"action": "leave"},
    ]:
        result, context = await call(board, arguments)
        assert not result["ok"], arguments
        assert context._delivery_receipts == [], arguments
    page = await board.store.read_posts(board.swarm["id"], board.bindings[0].participant_id)
    assert page.entries == ()


@pytest.mark.asyncio
async def test_board_rejects_forged_context_and_saves_identical_sibling_posts_once(board):
    foreign = replace(board.contexts[0], session_id=board.contexts[1].session_id)
    result = await board.service.board(foreign, {"action": "list"})
    assert not result["ok"]
    first, _ = await call(board, {"action": "post", "text": "first"})
    # Another Tool Call of the same Model response repeats the post: it saves nothing.
    sibling, sibling_context = await call(board, {"action": "post", "text": "first"})
    assert sibling["data"]["post_id"] == first["data"]["post_id"]
    assert sibling["data"]["note"] == POST_DUPLICATE.format(post_id=first["data"]["post_id"])
    replay, _ = await call(
        board, {"action": "post", "text": "first"}, tool_call_id=sibling_context.tool_call_id
    )
    assert replay["data"]["post_id"] == first["data"]["post_id"]
    # A sibling that differs in anything, or the same post in a later response, posts anew.
    other, _ = await call(board, {"action": "post", "text": "first", "recipients": ["all"]})
    board.contexts[0] = replace(board.contexts[0], iteration_number=1)
    later, _ = await call(board, {"action": "post", "text": "first"})
    assert len({first["data"]["post_id"], other["data"]["post_id"], later["data"]["post_id"]}) == 3
    page = await board.store.read_posts(board.swarm["id"], board.bindings[0].participant_id)
    assert [entry["text"] for entry in page.entries] == ["first"] * 3


@pytest.mark.asyncio
async def test_create_pings_opening_atomically_without_joining_recipients(board):
    peer = board.bindings[1].participant_id
    arguments = {
        "action": "create",
        "title": "Review",
        "text": "Please review this draft",
        "recipients": [peer, peer],
    }
    created, created_context = await call(board, arguments)
    assert created["ok"]
    data = created["data"]
    inbox = await board.store.prepare_inbox_delivery(board.swarm["id"], peer)
    assert [f"#{entry['sequence']}" for entry in inbox["entries"]][:1] == [data["opening_post_id"]]
    announcement = inbox["entries"][1]
    assert announcement["discussion_id"] == board.swarm["main_discussion_id"]
    assert announcement["text"] == (
        f'{_name(board, 0)} opened the discussion "Review" ({data["discussion_id"]}) with post '
        f"{data['opening_post_id']}. Read or join it with swarm_board and this discussion_id."
    )
    discussions = await board.store.list_discussions(board.swarm["id"], peer)
    assert not next(
        row for row in discussions.entries if f"d{row['sequence']}" == data["discussion_id"]
    )["joined"]
    replay, _ = await call(board, arguments, tool_call_id=created_context.tool_call_id)
    assert replay["data"]["discussion_id"] == data["discussion_id"]
    assert replay["data"]["replayed"]
    conflict, _ = await call(
        board, {**arguments, "recipients": []}, tool_call_id=created_context.tool_call_id
    )
    assert conflict["error"]["code"] == "request_conflict"
    invalid, _ = await call(board, {**arguments, "recipients": [peer, "foreign"]})
    assert invalid["error"]["code"] == "invalid_recipient"
    assert (
        await board.store.list_discussions(board.swarm["id"], peer)
    ).entries == discussions.entries
    assert (await board.store.prepare_inbox_delivery(board.swarm["id"], peer))["entries"] == inbox[
        "entries"
    ]


@pytest.mark.asyncio
async def test_reply_uses_owned_message_discussion_and_rejects_contradiction(board):
    created, _ = await call(board, {"action": "create", "title": "Topic", "text": "Opening"})
    topic = created["data"]
    arguments = {
        "action": "post",
        "text": "Answer",
        "reply_to": topic["opening_post_id"],
    }
    reply, reply_context = await call(board, arguments, peer=1)
    assert reply["data"]["discussion"] == f'discussion "Topic" ({topic["discussion_id"]})'
    replay, _ = await call(
        board,
        {**arguments, "discussion_id": topic["discussion_id"]},
        peer=1,
        tool_call_id=reply_context.tool_call_id,
    )
    assert replay["data"]["replayed"]
    mismatch, _ = await call(
        board,
        {**arguments, "discussion_id": board.swarm["main_discussion_id"]},
        peer=1,
    )
    assert mismatch["error"]["code"] == "reply_discussion_mismatch"
    assert mismatch["error"]["message"] == (
        f'reply_to {topic["opening_post_id"]} belongs to discussion "Topic" '
        f"({topic['discussion_id']}), but discussion_id names the main discussion "
        f'(d1). Omit discussion_id to reply in discussion "Topic" ({topic["discussion_id"]}), '
        "or omit reply_to to post a new message in the main discussion (d1). Nothing was saved."
    )
    missing, _ = await call(board, {**arguments, "reply_to": "foreign"}, peer=1)
    assert missing["error"]["code"] == "message_not_found"
    assert missing["error"]["message"] == (
        'reply_to "foreign" is not a post ID in your group. Find the post ID with '
        '{"action": "read"}, or omit reply_to for a new message. Nothing was saved.'
    )
    assert (
        len(
            (
                await board.store.read_posts(
                    board.swarm["id"],
                    board.bindings[0].participant_id,
                    discussion_id=topic["discussion_id"],
                )
            ).entries
        )
        == 2
    )


@pytest.mark.asyncio
async def test_board_validation_names_the_missing_or_misplaced_field_before_any_effect(board):
    for arguments, message in [
        ({"action": "post"}, "post needs text, the message body."),
        (
            {"action": "post", "message_id": "#1"},
            'post needs text, the message body. To read #1, use {"action": "read", '
            '"message_id": "#1"}; to answer it, repeat the call with text.',
        ),
        (
            {"action": "list", "text": "inapplicable"},
            "list does not use text, so the call may mean another action. Repeat it without "
            "text, or use an action that takes text: post or create.",
        ),
        ({"action": "join"}, 'join needs discussion_id. Use {"action": "list"}'),
        ({"action": "create", "text": "opening"}, "create needs title"),
    ]:
        result, context = await dispatch(board, arguments)
        assert result["error"]["code"] == "invalid_arguments"
        assert message in result["error"]["message"]
        assert context._delivery_receipts == []
    # Dispatch rejects an unknown switch before the handler.
    rejected, _ = await dispatch(board, {"action": "post", "text": "Done.", "silent": True})
    assert '"silent" is not a parameter' in rejected["error"]["message"]
    assert not await board_posts(board)


@pytest.mark.asyncio
async def test_create_retains_opening_and_announcement_for_inactive_peers(board):
    peer = board.bindings[1].participant_id
    await board.store.set_participant_state(board.swarm["id"], peer, "cancelled")
    created, _ = await call(
        board,
        {
            "action": "create",
            "title": "Review",
            "text": "Opening",
            "recipients": [peer],
        },
    )
    assert created["ok"]
    assert len((await board.store.prepare_inbox_delivery(board.swarm["id"], peer))["entries"]) == 2
    # The author learns that a stopped participant it addresses cannot answer for now.
    one, two = _name(board, 1), _name(board, 2)
    posted, _ = await dispatch(board, {"text": f"@{one} and @{two}, any news?"})
    assert posted["data"]["delivery"] == " ".join(
        (
            "Queued for 2 participants.",
            _reaches(one, two),
            BOARD_ADDRESSED_STOPPED["one"].format(names=one),
        )
    )


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "name,arguments",
    [
        ("swarm_board", {"request": {"operation": "LIST", "limti": "1"}}),
        ("swarm_inbox", {"receive": {"limit": "1"}}),
        ("swarm_state", {"operation": "STATUS", "limit": "1.0"}),
    ],
)
async def test_scoped_tools_repair_arguments_and_accept_matching_identity(board, name, arguments):
    context = replace(board.contexts[0], tool_name=name, session_tool_grants=(name,))
    result = await board.tools.dispatch(
        context,
        {
            **arguments,
            "swarm_id": board.swarm["id"],
            "participant_id": board.bindings[0].participant_id,
        },
        allowed_tools=[name],
    )
    assert result["ok"], result
    rejected = await board.tools.dispatch(
        context, {**arguments, "swarm_id": "foreign"}, allowed_tools=[name]
    )
    assert not rejected["ok"]


def _ids(board):
    return [participant["id"] for participant in board.swarm["participants"]]


@pytest.mark.asyncio
async def test_board_runs_clear_intent_after_repairing_the_call_shape(board):
    posted, _ = await dispatch(board, {"text": "inferred post", "request_id": "agent-chosen"})
    assert posted["ok"], posted
    first = posted["data"]["post_id"]
    reply, _ = await dispatch(
        board,
        {"arguments": {"action": "respond", "body": "answer", "in_reply_to": first}},
        peer=1,
    )
    assert reply["ok"], reply
    created, _ = await dispatch(board, {"subject": "Plan", "message": "opening"})
    assert created["data"]["status"] == "You joined it, and the main discussion announces it."
    read, _ = await dispatch(board, {"action": "history", "post_id": first}, peer=2)
    assert read["data"]["content"] == (
        f"[{first}] {_name(board, 0)} (in the main discussion d1):\ninferred post"
    )
    # The Tool's own name as recipient or outer action only labels the wrapped call.
    for labelled in (
        {
            "parameters": {"action": "read", "message_id": first},
            "recipient_name": "functions.swarm_board",
        },
        {"action": "swarm_board", "parameters": {"action": "read", "message_id": first}},
        {"action": "swarm_board", "message_id": first},
    ):
        result, _ = await dispatch(board, labelled, peer=2)
        assert result["data"]["content"] == read["data"]["content"], result
    # One closing quote after a complete action changes no intent or payload.
    quoted, _ = await dispatch(board, {"action": 'post"', "text": 'keep "quotes" literally'})
    assert quoted["ok"], quoted
    quoted_read, _ = await dispatch(
        board, {"action": 'read"', "message_id": quoted["data"]["post_id"]}
    )
    assert quoted_read["data"]["content"].endswith('keep "quotes" literally')
    # A placeholder or a repeat beside the real text asks for nothing more.
    for message, text in [("placeholder", "kept"), ("same", "same")]:
        result, _ = await dispatch(board, {"action": "post", "message": message, "text": text})
        assert result["ok"], result
    posts = await board_posts(board)
    assert [(post["text"], post["reply_to"]) for post in posts[:2]] == [
        ("inferred post", None),
        ("answer", posts[0]["id"]),
    ]
    assert [post["text"] for post in posts[-2:]] == ["kept", "same"]
    topic = await board_posts(board, discussion_id=created["data"]["discussion_id"])
    assert [post["text"] for post in topic] == ["opening"]
    # The same repairs never pick one of two differing instructions.
    for arguments, message in [
        ({"text": "one", "body": "two"}, "text"),
        ({"action": "post", "message": "ddl", "text": "real"}, "text"),
        ({"action": "read", "message": first, "post_id": "#9"}, "message_id"),
        ({"action": "post", "arguments": {"action": "read"}}, "action"),
        ({"action": "status"}, "Use swarm_state to see participants"),
        ({"action": "swarm_state"}, "Use swarm_state to see participants"),
        ({"action": "check_inbox"}, 'Use {"action": "read"} to read the newest posts'),
        # A file path names the file the call meant for another Tool.
        ({"action": "read", "parameters": {"limit": 200, "path": "verify.py"}}, '"verify.py"'),
        ({"recipient_name": "swarm_wiki", "text": "x"}, "recipient_name"),
        # An action that names another Tool points to calling that Tool directly.
        ({"action": "search_files"}, BOARD_OTHER_TOOL.format(action="search_files")),
        # Collapsed parameter markup is diagnosed, never executed as an action.
        ({"action": 'read" \nmessage_id">\n#1'}, "message_id as a separate parameter"),
        (
            {"action": 'post" \ndiscussion_id">\nd1', "text": "not posted"},
            "discussion_id as a separate parameter",
        ),
        ({"action": 'post" \ntext">\nnot posted'}, "text as a separate parameter"),
        ({"action": 'join" \ndiscussion_id">\nd2'}, "discussion_id as a separate parameter"),
        ({"action": 'post""', "text": "not posted"}, "action"),
        ({"action": 'posted"', "text": "not posted"}, "action"),
    ]:
        result, _ = await dispatch(board, arguments)
        assert result["error"]["code"] == "invalid_arguments", result
        assert message in result["error"]["message"]
    # A conflict names both values, so the caller can tell which one it meant.
    conflict, _ = await dispatch(board, {"action": "post", "arguments": {"action": "read"}})
    assert '"post"' in conflict["error"]["message"] and '"read"' in conflict["error"]["message"]
    assert len(await board_posts(board)) == len(posts)


def _reaches(*names):
    listed = " and ".join(names)
    return f"It reaches {listed} in full because it addresses or answers them."


@pytest.mark.asyncio
async def test_board_addresses_participants_its_text_names_after_at_or_answers(board):
    ids = _ids(board)
    one, two = _name(board, 1), _name(board, 2)
    named, _ = await dispatch(board, {"text": f"@{one}, can you check the parser?"})
    assert named["data"]["delivery"] == f"Queued for 2 participants. {_reaches(one)}"
    handle, _ = await dispatch(board, {"text": f"thanks @{two.lower()} and @{ids[1]}"})
    assert handle["data"]["delivery"] == f"Queued for 2 participants. {_reaches(one, two)}"
    # A name or ID without "@" credits or mentions a participant; it addresses no one.
    mentioned, _ = await dispatch(
        board, {"text": f"{one} fixed it, {two} and {ids[1]} confirmed; see x@{one} or @ {two}"}
    )
    assert mentioned["data"]["delivery"] == "Queued for 2 participants."
    # "@all", "@User" and "@" before a word that names no participant address no one, and
    # the author learns what readers receive instead; "x@all" and code are no mention at all.
    everyone, _ = await dispatch(
        board, {"text": f"@all, @Everyone and @ALL: status? cc @User @{one}s, see `@Override`"}
    )
    assert everyone["data"]["delivery"] == "Queued for 2 participants."
    assert everyone["data"]["note"] == " ".join(
        (
            MENTION_NO_ONE["main"].format(mentions=f"@all, @Everyone and @{one}s"),
            MENTION_CORRECTED["possessive"].format(name=one),
            MENTION_HOW["address"],
            MENTION_USER.format(mentions="@User"),
        )
    )
    long, _ = await dispatch(board, {"text": "@team " + "word " * 300})
    assert long["data"]["note"] == " ".join(
        (MENTION_NO_ONE["opening_many"].format(mentions="@team", count=2), MENTION_HOW["opening"])
    )
    # A possessive or a one-letter slip of a name gets the precise fix instead of the
    # general rule; addressing itself stays exact.
    possessive, _ = await dispatch(board, {"text": f"@{one}s draft is ready"})
    assert possessive["data"]["delivery"] == "Queued for 2 participants."
    assert possessive["data"]["note"] == " ".join(
        (
            MENTION_NO_ONE["main"].format(mentions=f"@{one}s"),
            MENTION_CORRECTED["possessive"].format(name=one),
        )
    )
    slip = f"{one[:2]}q{one[2:]}"
    close, _ = await dispatch(board, {"text": f"@{slip} and @Stylesheet, please review"})
    assert close["data"]["delivery"] == "Queued for 2 participants."
    assert close["data"]["note"] == " ".join(
        (
            MENTION_NO_ONE["main"].format(mentions=f"@{slip} and @Stylesheet"),
            MENTION_CORRECTED["close"].format(written=f"@{slip}", name=one),
            MENTION_HOW["address"],
        )
    )
    # A possessive with an apostrophe addresses already; so does a post that also writes
    # the plain name. Quoted formats and the example @Name address no one and get no note.
    for addressed in (f"@{one}'s plan", f"@{one}’s plan", f"@{one}: see @{one}s plan"):
        reached, _ = await dispatch(board, {"text": addressed})
        assert reached["data"]["delivery"] == f"Queued for 2 participants. {_reaches(one)}"
        assert "note" not in reached["data"]
    for unaddressed in (
        "mail ops x@all.example",
        "see @override and `@All`",
        'Format: „@X“ or "@Y", as in @Name',
    ):
        address, _ = await dispatch(board, {"text": unaddressed})
        assert "note" not in address["data"]
    # Outside the main discussion, the result says who does not receive a post and names
    # the non-members its text names without "@".
    created, _ = await dispatch(board, {"title": "Schema", "text": f"{two} owns this, @{one}?"})
    assert created["data"]["delivery"] == BOARD_OUTSIDE["one_named"].format(names=two)
    side, _ = await dispatch(
        board, {"text": f"decided with {one} and {two}", "discussion_id": "d2"}
    )
    assert side["data"]["delivery"] == BOARD_OUTSIDE["many_named"].format(
        count=2, names=f"{one} and {two}"
    )
    await dispatch(board, {"action": "join", "discussion_id": "d2"}, peer=1)
    joined, _ = await dispatch(board, {"text": "plain", "discussion_id": "d2"})
    assert joined["data"]["delivery"] == " ".join(
        ("Queued for 1 participant.", BOARD_OUTSIDE["one"])
    )
    answer, _ = await dispatch(
        board, {"text": "done", "reply_to": named["data"]["post_id"]}, peer=2
    )
    assert answer["data"]["delivery"] == (f"Queued for 2 participants. {_reaches(_name(board, 0))}")
    saved = {post["text"]: post["recipients"] for post in await board_posts(board)}
    assert saved[f"@{one}, can you check the parser?"] == [ids[1]]
    assert saved["done"] == [ids[0]]
    routes = {post["text"]: post.get("route_class") for post in await board_posts(board, peer=1)}
    assert routes[f"@{one}, can you check the parser?"] == "ping"
    assert routes["done"] == "main"
    read, _ = await dispatch(board, {"action": "read"}, peer=1)
    assert f"{_name(board, 0)} (to you and {two}):\nthanks" in read["data"]["content"]


@pytest.mark.asyncio
async def test_board_accepts_explicit_recipients_and_never_guesses_one(board):
    # Agents address with @Name; explicit recipients and reply_to stay accepted unadvertised.
    names = ["swarm_board"]
    definition = board.tools.provider_definitions(names, session_grants=names)[0]
    assert not {"recipients", "reply_to"} & set(definition["parameters"]["properties"])
    ids = _ids(board)
    named, _ = await dispatch(board, {"text": "to one", "recipients": [f"@{_name(board, 1)}"]})
    assert named["data"]["delivery"] == f"Queued for 2 participants. {_reaches(_name(board, 1))}"
    everyone, _ = await dispatch(board, {"text": "to all", "to": "all"})
    assert everyone["data"]["delivery"] == (
        f"Queued for 2 participants. {_reaches(_name(board, 1), _name(board, 2))}"
    )
    user, _ = await dispatch(board, {"text": "to user", "recipients": ["the user"]})
    assert user["data"]["note"] == (
        "The user is not a participant and sees every Board post, so the user needs no "
        "recipient entry."
    )
    assert user["data"]["delivery"] == "Queued for 2 participants."
    listed, _ = await dispatch(
        board,
        {"text": "listed", "recipients": [f"{_name(board, 1)}; prt_{_name(board, 2).lower()}"]},
    )
    assert listed["data"]["delivery"] == everyone["data"]["delivery"]
    saved = {post["text"]: sorted(post["recipients"]) for post in await board_posts(board)}
    assert saved == {
        "to one": [ids[1]],
        "to all": sorted(ids[1:]),
        "to user": [],
        "listed": sorted(ids[1:]),
    }
    read, _ = await dispatch(board, {"action": "read"}, peer=1)
    assert f"{_name(board, 0)} (to you and {_name(board, 2)}):\nto all" in read["data"]["content"]

    near = ids[1][:-1] + ("x" if ids[1][-1] != "x" else "y")
    corrected, _ = await dispatch(board, {"text": "typo", "recipients": [near, _name(board, 2)]})
    assert corrected["error"]["code"] == "invalid_recipient"
    assert f'Did you mean {_name(board, 1)} for "{near}"?' in (corrected["error"]["message"])
    assert corrected["error"]["message"].endswith(
        f'Repeat the call with recipients ["{_name(board, 1)}", "{_name(board, 2)}"]; "all" '
        "addresses every other participant. Nothing was saved."
    )
    unknown, _ = await dispatch(board, {"text": "typo", "recipients": ["Nobody"]})
    assert unknown["error"]["code"] == "invalid_recipient"
    assert (
        f"Participants: {_name(board, 0)} (you), {_name(board, 1)}" in (unknown["error"]["message"])
    )
    assert (
        "Repeat the call with recipients chosen from these participants"
        in (unknown["error"]["message"])
    )
    assert "typo" not in {post["text"] for post in await board_posts(board)}


@pytest.mark.asyncio
async def test_board_corrects_read_references_but_never_write_targets(board):
    created, _ = await dispatch(board, {"title": "Topic", "text": "opening"})
    topic = created["data"]["discussion_id"]
    posted, _ = await dispatch(board, {"text": "first main post"})
    first = posted["data"]["post_id"]
    assert (topic, first) == ("d2", "#3")
    stored = next(post for post in await board_posts(board) if post["sequence"] == 3)["id"]

    # A number is an exact reference, with or without "#", for reads and writes alike.
    by_number, _ = await dispatch(board, {"action": "read", "message_id": "3"})
    assert by_number["data"]["content"].endswith(":\nfirst main post")
    assert "note" not in by_number["data"]
    answer, _ = await dispatch(board, {"text": "answer", "reply_to": first}, peer=1)
    assert answer["ok"] and _reaches(_name(board, 0)) in answer["data"]["delivery"]
    # Every post is older than a number past the newest post.
    ahead, _ = await dispatch(board, {"action": "read", "before": "#9"})
    assert ahead["data"]["note"] == (
        'before "#9" names no post yet; the newest post is #4, so this shows the newest posts.'
    )
    assert ahead["data"]["page"].startswith("Newest posts of the main discussion (d1)")
    assert ahead["data"]["content"].endswith(":\nanswer")
    unposted, _ = await dispatch(board, {"action": "read", "message_id": "#9"})
    assert unposted["error"]["message"] == (
        'message_id "#9" names no post yet; the newest post is #4.'
    )
    # Tool-call markup sent as a reference is named as such, never resolved or guessed.
    for arguments, field, shown in (
        (
            {"action": "read", "message_id": "\n</atem:invoke>\n</atem:function_calls>"},
            "message_id",
            "</atem:invoke> </atem:function_calls>",
        ),
        ({"text": "leaked", "reply_to": "#3</invoke>"}, "reply_to", "#3</invoke>"),
    ):
        leaked, _ = await dispatch(board, arguments)
        assert leaked["error"] == {
            "code": "invalid_arguments",
            "message": REFERENCE_MARKUP.format(
                field=field, value=json.dumps(shown), kind="post", example="#42"
            ),
        }, leaked

    near_post = stored[:-1] + ("x" if stored[-1] != "x" else "y")
    close_message, _ = await dispatch(board, {"action": "read", "message_id": near_post})
    assert close_message["data"]["note"] == (
        f'message_id "{near_post}" does not exist; this uses post {first}, its only close match.'
    )
    reply, _ = await dispatch(board, {"text": "misreplied", "reply_to": near_post})
    assert reply["error"]["code"] == "message_not_found"
    assert reply["error"]["message"].startswith(f'reply_to "{near_post}" is not a post ID')
    assert reply["error"]["message"].endswith(
        f'Repeat the call with reply_to "{first}". Nothing was saved.'
    )

    topic_id = next(
        row["id"]
        for row in (
            await board.store.list_discussions(board.swarm["id"], board.bindings[0].participant_id)
        ).entries
        if row["sequence"] == 2
    )
    near = topic_id[:-1] + ("x" if topic_id[-1] != "x" else "y")
    close_read, _ = await dispatch(board, {"action": "read", "discussion_id": near}, peer=1)
    assert close_read["data"]["content"].endswith(":\nopening")
    assert close_read["data"]["note"] == (
        f'discussion_id "{near}" does not exist; this shows discussion "Topic" (d2), its only '
        "close match."
    )
    close_post, _ = await dispatch(board, {"text": "misaddressed", "discussion_id": near})
    assert close_post["error"]["code"] == "discussion_not_found"
    assert 'Repeat the call with discussion_id "d2".' in close_post["error"]["message"]

    older, _ = await dispatch(board, {"action": "read", "cursor": first})
    assert older["data"]["note"] == CURSOR_AS_BEFORE.format(value=first)
    assert older["data"]["page"].startswith("Posts before #3 in the main discussion (d1)")
    # Post numbers count across the Board, so a post of another discussion ends the page too.
    crossed, _ = await dispatch(
        board, {"action": "read", "discussion_id": topic, "before": first}, peer=1
    )
    assert crossed["data"]["page"].startswith('Posts before #3 in discussion "Topic" (d2)')
    assert crossed["data"]["content"].endswith(":\nopening")
    assert crossed["data"]["note"] == BEFORE_OTHER_DISCUSSION.format(
        post_id=first,
        before_discussion="the main discussion (d1)",
        discussion='discussion "Topic" (d2)',
    )
    texts = [post["text"] for post in await board_posts(board)]
    assert "misreplied" not in texts
    assert "misaddressed" not in texts
    assert "leaked" not in texts


@pytest.mark.asyncio
async def test_board_extra_targets_run_only_when_they_change_nothing(board):
    main = board.swarm["main_discussion_id"]
    first, _ = await dispatch(board, {"title": "First", "text": "opening"})
    existing = first["data"]["discussion_id"]
    inside, _ = await dispatch(
        board, {"action": "create", "discussion_id": existing, "title": "Second", "text": "x"}
    )
    assert inside["error"]["message"].startswith(
        "create opens a new discussion, but discussion_id names the existing discussion "
        f"{existing}."
    )
    in_main, _ = await dispatch(
        board, {"action": "create", "discussion_id": main, "title": "Second", "text": "x"}
    )
    assert in_main["ok"] and "note" not in in_main["data"]
    unknown, _ = await dispatch(
        board, {"action": "create", "discussion_id": "new-topic", "title": "Third", "text": "x"}
    )
    assert unknown["data"]["note"] == (
        'discussion_id "new-topic" names no discussion and was ignored; the new discussion has '
        "its own ID."
    )
    listed = await board.store.list_discussions(board.swarm["id"], board.bindings[0].participant_id)
    assert sorted(row["title"] for row in listed.entries) == ["First", "Main", "Second", "Third"]
    # A title beside an existing discussion names nothing new: the post is saved without it.
    titled, _ = await dispatch(
        board, {"action": "post", "discussion_id": existing, "title": "Heading", "text": "titled"}
    )
    assert titled["ok"] and "note" in titled["data"], titled
    for arguments in [
        {"action": "post", "title": "Heading", "text": "untargeted"},
        {"action": "post", "discussion_id": "d9", "title": "Heading", "text": "untargeted"},
    ]:
        refused, _ = await dispatch(board, arguments)
        assert refused["error"]["code"] == "invalid_arguments", refused
    texts = [post["text"] for post in await board_posts(board, discussion_id=existing)]
    assert "titled" in texts
    assert "untargeted" not in {post["text"] for post in await board_posts(board)}

    target = first["data"]["opening_post_id"]
    # A post that names a post with message_id answers it, as with reply_to.
    only_message, _ = await dispatch(
        board, {"action": "post", "message_id": target, "text": "answer"}
    )
    assert only_message["ok"], only_message
    before_mistake = await board_posts(board)
    for wrong_kind in ("d1", main):
        mistaken, context = await dispatch(
            board, {"action": "post", "message_id": wrong_kind, "text": "not redirected"}
        )
        assert not mistaken["ok"]
        assert "discussion_id" in mistaken["error"]["message"]
        assert '"d1"' in mistaken["error"]["message"]
        assert context._delivery_receipts == []
    assert await board_posts(board) == before_mistake
    differing, _ = await dispatch(
        board, {"action": "post", "message_id": main, "reply_to": target, "text": "other"}
    )
    assert differing["error"]["message"] == (
        "message_id and reply_to name different posts. Repeat the call with only reply_to, set "
        "to the post you answer. Nothing was saved."
    )
    same, _ = await dispatch(
        board, {"action": "post", "message_id": target, "reply_to": target, "text": "again"}
    )
    assert same["ok"], same
    replies = [
        post for post in await board_posts(board, discussion_id=existing) if post["reply_to"]
    ]
    assert sorted((post["text"], f"#{post['reply_sequence']}") for post in replies) == [
        ("again", target),
        ("answer", target),
    ]


@pytest.mark.asyncio
async def test_board_clamps_page_size_and_drops_paging_fields_it_cannot_use(board):
    for index in range(3):
        await dispatch(board, {"text": f"post {index}"})
    clamped, _ = await dispatch(board, {"action": "read", "limit": 500})
    assert clamped["data"]["note"] == "limit 500 is above the maximum of 100; used 100."
    assert "(3 shown)" in clamped["data"]["page"]
    # offset, as other harnesses page, skips that many of the newest posts.
    skipped, _ = await dispatch(board, {"action": "read", "limit": 1, "offset": "1"}, peer=1)
    assert skipped["data"]["content"].endswith(":\npost 1")
    assert continuation(skipped["data"]["older"])["before"] == "#2"
    # The page names what offset skipped and the call for the newest posts it left out.
    assert "#2" in skipped["data"]["page"]
    newest, _ = await dispatch(board, continuation(skipped["data"]["page"]), peer=1)
    assert newest["data"]["content"].endswith(":\npost 2")
    beyond, _ = await dispatch(board, {"action": "read", "offset": 3})
    assert beyond["ok"] and "content" not in beyond["data"]
    assert continuation(beyond["data"]["page"]) == {"action": "read"}
    # Beside a post or a page start, offset positions nothing.
    one, _ = await dispatch(board, {"action": "read", "message_id": "#1", "offset": 2})
    assert one["data"]["content"].endswith(":\npost 0") and "note" not in one["data"]
    before, _ = await dispatch(board, {"action": "read", "before": "#3", "offset": 1}, peer=1)
    assert before["data"]["content"].endswith(":\npost 1") and "note" in before["data"]
    negative, _ = await dispatch(board, {"action": "read", "offset": -1})
    assert negative["error"]["code"] == "invalid_arguments"
    ignored, _ = await dispatch(board, {"action": "post", "text": "paged", "limit": 5})
    assert ignored["data"]["note"] == "limit is not used by post and was ignored."
    assert "paged" in {post["text"] for post in await board_posts(board)}
    rejected, _ = await dispatch(board, {"action": "list", "limit": 0})
    assert rejected["error"]["code"] == "invalid_arguments"
    # The page's character bound can end a page before limit; the result says so.
    for index in range(3):
        await dispatch(board, {"text": str(index) * 10_000})
    cut, _ = await dispatch(board, {"action": "read"}, peer=2)
    assert "(2 shown)" in cut["data"]["page"]
    rest = continuation(cut["data"]["older"])
    assert cut["data"]["older"] == BOARD_OLDER_CUT.format(count=2, limit=20, call=json.dumps(rest))
    assert (await dispatch(board, rest, peer=2))[0]["data"]["content"].count("\n\n[#") == 4


@pytest.mark.asyncio
async def test_board_results_read_as_plain_text(board):
    posted, _ = await dispatch(board, {"text": "line one\nline two", "recipients": ["all"]})
    assert visible(posted) == (
        "post_id: #1\ndiscussion: the main discussion (d1)\n"
        f"delivery: Queued for 2 participants. {_reaches(_name(board, 1), _name(board, 2))}"
    )
    await dispatch(board, {"text": "second"}, peer=1)
    read, _ = await dispatch(board, {"action": "read", "limit": 1}, peer=2)
    page = BOARD_PAGE_NEWEST.format(discussion="the main discussion (d1)", count=1)
    assert visible(read) == (
        f"page: {page}\nnew: {BOARD_NEW['one'].format(posts='#2')}\n"
        "older: Older posts exist. Continue with "
        '{"action": "read", "discussion_id": "d1", "before": "#2", "limit": 1}\n\n'
        f"[#2] {_name(board, 1)}:\nsecond"
    )
    # A page shows a post the reader has seen, also a long one, as the call that reads it;
    # a post new to the reader shows whole.
    long = " ".join(["word"] * 300)
    await dispatch(board, {"text": long}, peer=1)
    page, _ = await dispatch(board, {"action": "read"}, peer=1)
    first, second, third = page["data"]["content"].split("\n\n")
    assert first.endswith(":\nline one\nline two")
    assert second == f"[#2] {_name(board, 1)}:\n" + POST_SEEN.format(
        count=len("second"), call='{"action": "read", "message_id": "#2"}'
    )
    assert third == f"[#3] {_name(board, 1)}:\n" + POST_SEEN.format(
        count=len(long), call='{"action": "read", "message_id": "#3"}'
    )
    # A long main-discussion post delivered to the reader may have shown only its opening.
    unread, context = await dispatch(board, {"action": "read", "limit": 1}, peer=2)
    assert unread["data"]["content"].endswith(long)
    receipt_id, content_hash, effect = context._delivery_receipts[0]
    await persist_carriers(
        board.sessions,
        board.bindings[2].address,
        generation_id=board.bindings[2].generation_id,
        owner_name="swarm",
        messages=[
            ChatMessage.tool(
                tool_call_id=context.tool_call_id, name="swarm_board", content=json.dumps(unread)
            )
        ],
        receipts=[(0, receipt_id, content_hash, effect, "tool")],
    )
    assert await board.store.reconcile_delivery(receipt_id)
    again, _ = await dispatch(board, {"action": "read", "limit": 1}, peer=2)
    assert again["data"]["content"] == f"[#3] {_name(board, 1)}:\n" + POST_SEEN_OPENING.format(
        count=len(long), call='{"action": "read", "message_id": "#3"}'
    )


@pytest.mark.asyncio
async def test_goal_is_pinned_user_post_without_automatic_delivery(board):
    goal = await board.service.board(board.contexts[0], {"action": "read", "message_id": "#0"})
    assert goal["data"]["content"] == "[#0] User (in the main discussion d1):\nfixture-goal"
    assert all(item["pending_count"] == 0 for item in board.swarm["participants"])
    board_read = await board.service.board(board.contexts[0], {"action": "read"})
    assert board_read["data"]["page"] == "No posts in the main discussion (d1) yet."
    assert board_read["data"]["user_request"] == (
        'Post #0 holds the user\'s request. Read it with {"action": "read", "message_id": "#0"}'
    )
    listed = await board.service.board(board.contexts[0], {"action": "list"})
    assert listed["data"]["user_request"].startswith("Post #0 holds the user's request.")
