---
name: vbot-docs
description: "Configure and inspect vBot, the app you run in: Agents including yourself, settings, and what it records, such as Sessions, usage and logs. Use when a task reads or changes anything vBot holds, also when your Tools show too little or you would open its data files. Not for editing vBot's own source code."
---

# vBot

With a shell Tool, run the documented `vbot` commands as written, including in a restricted Session. Without target options the CLI reaches the server that runs you, so a saved change applies there at once, also to yourself.

Commands read `vbot <area> <action> [target] [options]`: ids are positional, everything else is a flag. `vbot help` lists the areas, `vbot <area>` its actions, `vbot <area> <action> --help` the exact arguments. Use only commands and flags that help shows.

## Do the task

1. Use the Session recipes below, or read the reference for the task from the table. Done when you know its commands and which flags replace a whole value.
2. When you need a target's id or current values, inspect it with its `list` or `show` command and reuse the exact ids it prints. Before you replace a Skill, a prompt block or an automation prompt, read its complete content; list output shortens it.
3. Change only what the request names. Omitted update flags leave a field unchanged; list and policy flags, such as `--allow`, `--tool-allow` or `--sources`, replace the whole value, so repeat every entry to keep. The references name the commands that clear omitted options.
4. Read the result before you report. `[OK]` means the command finished, `[WARN]` names pending work or a limit, `[ERROR]` a failure. A saved setting is not yet working behavior: an Agent without an effective Model cannot run, an enabled Channel can fail to connect, an accepted update or restart has not finished. Report what the output shows.

Find recent Sessions with `vbot session list --limit 5`. Pass the returned ids to `vbot session usage <session-id>...` for tokens and costs, or to `vbot session show <session-id> --summary` for compact activity. Summaries name their Sub-Agent Sessions; read those by id when the task needs them.

For finding past conversations by content, use `session_search` first. Read `references/session-search.md` for Session filters, transcripts, exact Tool Results, or when search excerpts lack the evidence.

| Task | Read |
|---|---|
| Create an Agent for a purpose, rename an Agent, Agent settings, permission profiles, Tool and Skill permissions, delegation | `references/agents.md` |
| Write or revise an Agent's SOUL.md: its role, how it works, its voice, its boundaries | `references/soul.md` |
| Projects and their Agents, Sessions (create, fork, rename, delete), archived Agents, Projects and Sessions | `references/projects-sessions.md` |
| Send a message to an Agent and read its answer, with files or in a throwaway Session, continue one of its Sessions, set a Session's Model, thinking effort or temperature, or help the user open the terminal TUI | `references/chat.md` |
| Session lists, consumption, compact activity, transcripts, exact Tool Results and extended conversation search | `references/session-search.md` |
| Import Sessions or Memory from another coding agent into vBot | `references/external-import.md` |
| Provider keys, logins and limits, Models, voices, specialized Task Models, and image, video or music generation settings such as quality, image count or video length | `references/providers.md` |
| Settings, System Prompt blocks, Extension settings and enabling or disabling an Extension | `references/configuration.md` |
| Write or change an Extension's Tools, hooks, Commands or settings | `references/extensions.md`; for its own Sessions, then `references/extension-pages.md` |
| Add or replace UI controls, build an Extension page, use product services, add a Provider or Channel platform, or add a local Desktop capability | `references/extension-platform.md`; for page lifecycle or owned Sessions, then `references/extension-pages.md` |
| Use or configure an installed Extension, its CLI operations and setup | `references/extension-index.md`, then the guide for the requested task |
| Channels, including Extension platforms: first setup, platform settings, tokens, allowed chats, group access | `references/channels.md` |
| Automations: scheduled Runs, change checks and Webhooks | `references/cron.md` |
| Runs after startup, including restart continuation | `references/bootstrap.md` |
| Install a Skill from a link, archive or folder; inspect, author, share, disable or pin Skills; review their history; restore deleted Skills; Librarian passes over an Agent's own Skills | `references/skills.md` |
| Pinned Memory for an Identity Agent, its change history, restoring earlier entries | `references/memory.md` |
| Logs, Provider traces, instance-wide usage statistics and server performance | `references/diagnostics.md` |
| Inspect or finish shared first-run setup, help the user reopen the guide, or install and manage SearXNG | `references/server.md` |
| Server start/stop/restart, update, version selection, rollback, uninstall, Autostart, Desktop, Doctor, access mode, paired devices and user permission approvals, reaching another vBot server and signing in to it | `references/server.md` |
| Named credentials and the Secret Store, database health, data snapshots, configuration backups and recovery | `references/data-store.md` |
| Agent Secrets that Agents use as `{{secret:NAME}}`: which Agents may use them and where, waiting Secret requests, Secret Sources such as password managers | `references/agent-secrets.md` |
| Filesystem investigation, data location, backups or manual repair | `references/system-layout.md` |

Read a reference with the `skill` Tool using `name: "vbot-docs"` and its relative `file_path`. When no row fits and `search_files` is available, search the `references` folder inside the loaded Skill directory for the command, flag or term.

## Inputs, credentials and failures

- Pass multiline text with `--file` from a file on the CLI's computer, encoded as UTF-8 (with or without a BOM) or UTF-16 with a BOM. Pass JSON arrays or objects as one argument; when the shell breaks the quoting, pipe the value to the command's stdin option. Edit vBot's files by hand only when no command can make the change, then run `vbot doctor config`.
- Pass a credential only on the stdin of the command made for it; vBot keeps it in its encrypted Secret Store and ignores `.env` files. Never put a credential in an argument, a file or a reply. When the user has not given you the value, give them `vbot data-store secrets set <NAME>` or the area's stdin command to run in their terminal; never ask for the value or offer to take it in the chat, because the chat history keeps it. A value you use yourself in a task, such as a password or an API key for a script, is an Agent Secret instead (`references/agent-secrets.md`).
- On `[ERROR]`, the output explains the failure and prints `Next:` commands to inspect or recover; vBot never runs them itself. Inspect the target before you repeat a change, because earlier steps of a failed command can already be saved.
