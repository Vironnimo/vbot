"""Owner-selected call repairs for the Swarm Session Tools.

Each normalizer runs before central argument validation. It reads call syntax
only: wrappers, other harnesses' field and action names, an action implied by
the supplied fields, placeholders in optional fields, and fields the Tool derives
itself. Values that name Board or Wiki objects are left for the handlers, which
resolve them against the group and explain any correction.
"""

from __future__ import annotations

import json
import re
from collections.abc import Callable, Iterator, Mapping
from typing import Any

from core.tools import ToolContractError
from core.tools.call_syntax import (
    SpellingAliases,
    is_placeholder,
    normalize_call_arguments,
    spelling,
)
from core.tools.contracts import ToolContract

from ._store_values import post_number
from .agent_text import (
    BOARD_ACTION_FIELDS_MERGED,
    BOARD_FILE_PATH,
    BOARD_FOREIGN_ACTIONS,
    BOARD_OTHER_TOOL,
    BOARD_PARAMETERS,
    INBOX_ONLY_RECEIVE,
    STATE_ONLY_STATUS,
)
from .wiki_text import WIKI_ACTION_IS_FIELD, WIKI_ACTIONS, WIKI_PARAMETERS

Json = dict[str, Any]

# Wrapper objects some harnesses put around the argument object.
_WRAPPERS = frozenset({"request", "arguments", "parameters", "params", "input", "args", "payload"})
# Idempotency keys are derived from the Tool Call; an echoed key requests nothing.
_DERIVED = frozenset({"requestid", "idempotencykey"})
# Fields some harnesses fill with the called Tool's own name; that value requests nothing.
_TOOL_LABELS = frozenset({"recipientname", "action", "operation"})

_BOARD_ALIASES: dict[str, tuple[str, ...]] = {
    "text": ("body", "content", "message_text", "msg"),
    "title": ("subject", "discussion_title", "thread_title"),
    "message_id": ("post_id", "message_ids", "post_ids"),
    "reply_to": (
        "reply_to_id",
        "reply_to_post",
        "reply_to_post_id",
        "reply_to_message",
        "reply_to_message_id",
        "in_reply_to",
        "parent_id",
        "parent_post_id",
    ),
    "discussion_id": ("discussion", "thread_id", "channel_id", "topic_id"),
    "recipients": (
        "recipient",
        "to",
        "ping",
        "pings",
        "mention",
        "mentions",
        "notify",
        "participant_ids",
        "recipient_ids",
    ),
    "before": ("before_id", "before_post", "before_post_id", "before_message_id", "older_than"),
    "limit": ("count", "max", "max_results", "page_size", "limti"),
}
# "message" names a post to read when it holds a post ID, and a post's text otherwise.
_BOARD_FIELDS = {
    field: SpellingAliases({**_BOARD_ALIASES, field: (*_BOARD_ALIASES[field], "message")})
    for field in ("text", "message_id")
}
_BOARD_ACTIONS = SpellingAliases(
    {
        "post": (
            "send",
            "send_message",
            "reply",
            "respond",
            "message",
            "write",
            "comment",
            "say",
            "publish",
            "post_message",
            "create_post",
            "add_post",
        ),
        "read": (
            "get",
            "view",
            "fetch",
            "show",
            "history",
            "messages",
            "posts",
            "read_posts",
            "read_messages",
            "read_discussion",
            "get_posts",
            "get_messages",
        ),
        "list": ("discussions", "list_discussions", "channels", "threads", "list_threads"),
        "create": (
            "create_discussion",
            "new_discussion",
            "start_discussion",
            "open_discussion",
            "create_thread",
            "new_thread",
        ),
        "join": ("subscribe", "follow", "join_discussion"),
        "leave": ("unsubscribe", "unfollow", "leave_discussion"),
    }
)
_BOARD_ELSEWHERE = {
    "status": "swarm_state",
    "state": "swarm_state",
    "roster": "swarm_state",
    "participants": "swarm_state",
    "members": "swarm_state",
    "inbox": "swarm_inbox",
    "receive": "swarm_inbox",
    "checkinbox": "swarm_inbox",
    "wiki": "swarm_wiki",
    # The Tool's own name sent as the action.
    "swarmstate": "swarm_state",
    "swarminbox": "swarm_inbox",
    "swarmwiki": "swarm_wiki",
}
# An unknown action spelled like a Tool name, such as "search_files", may be a call meant for
# another of the Agent's Tools; the normalizer cannot see which Tools the Agent has.
_TOOL_NAME = re.compile(r"[A-Za-z][A-Za-z0-9_]*")
# A file path means the call was meant for a Tool that works with files.
_BOARD_FILE_FIELDS = frozenset({"path", "filepath"})
_BOARD_ACTION_VALUES = frozenset(BOARD_PARAMETERS["properties"]["action"]["enum"])
_MERGED_ACTION = re.compile(r'^(\w+)"\s+([a-z_]+)">\s*')

_WIKI_FIELDS = SpellingAliases(
    {
        "page_id": ("id", "page", "path", "wiki_id", "wiki_page_id"),
        "content": ("body", "text", "markdown", "page_content"),
        "old_text": ("old", "old_string", "old_str", "find_text", "search_text"),
        "new_text": ("new", "new_string", "new_str", "replace_text", "replacement", "replace_with"),
        "query": ("q", "search", "search_query", "find", "keyword", "keywords", "term"),
        "expected_revision": ("base_revision", "expected_rev", "if_revision", "current_revision"),
        "revision": ("version", "rev", "revision_number"),
        "since_revision": ("since", "since_rev", "since_version", "changes_since", "diff_since"),
        "offset": ("start", "char_offset", "from"),
        "limit": ("count", "max", "max_chars", "max_results", "length", "page_size", "limti"),
        "include_deleted": ("show_deleted", "with_deleted", "deleted"),
    }
)
# The fields of one item of a swarm_wiki update's edits, by spelling.
_WIKI_EDIT_FIELDS = {"oldtext": "old_text", "newtext": "new_text"}
_WIKI_ACTIONS = SpellingAliases(
    {
        "list": (
            "search",
            "find",
            "grep",
            "lookup",
            "query",
            "pages",
            "list_pages",
            "search_pages",
            "search_wiki",
            "search_files",
            "find_pages",
            "browse",
            "index",
        ),
        "read": ("get", "view", "open", "fetch", "show", "read_page", "get_page", "cat"),
        "create": ("new", "add", "create_page", "new_page"),
        "update": (
            "edit",
            "modify",
            "change",
            "patch",
            "replace",
            "str_replace",
            "update_page",
            "edit_page",
        ),
        "delete": ("remove", "rm", "delete_page", "trash"),
        "history": ("revisions", "versions", "log", "list_revisions", "changes"),
        "restore": ("revert", "rollback", "undelete", "restore_revision"),
    }
)
# The fields an action can name by mistake, by spelling: "action": "content".
_WIKI_FIELD_NAMES = {
    spelling(field): field
    for field in (*WIKI_PARAMETERS["properties"], "edits")
    if field != "action" and spelling(field) not in _WIKI_ACTIONS
}
# "latest" and "current" ask for whatever revision is current, which omission means.
_REVISION_PLACEHOLDERS = frozenset({"latest", "current", "head"})

_INBOX_FIELDS = SpellingAliases({"limit": ("count", "max", "max_results", "page_size", "limti")})
_INBOX_ACTIONS = frozenset(
    spelling(word)
    for word in (
        "receive",
        "get",
        "read",
        "check",
        "fetch",
        "poll",
        "pull",
        "list",
        "next",
        "messages",
        "inbox",
        "check_inbox",
        "read_inbox",
        "get_messages",
        "receive_messages",
    )
)
_STATE_FIELDS = SpellingAliases(
    {
        "limit": ("count", "max", "max_results", "page_size", "limti"),
        "cursor": ("next", "next_cursor", "page_token"),
    }
)
_STATE_ACTIONS = frozenset(
    spelling(word)
    for word in (
        "status",
        "state",
        "get",
        "show",
        "view",
        "list",
        "roster",
        "participants",
        "members",
        "who",
        "check",
        "info",
    )
)


def normalize_board(contract: ToolContract, arguments: Any) -> Any:
    """Repair a swarm_board call and infer an action that its fields imply."""

    value = _prepare(arguments, contract.name)
    if not isinstance(value, dict):
        return value
    path = next(
        (item for key, item in value.items() if spelling(str(key)) in _BOARD_FILE_FIELDS), None
    )
    if isinstance(path, str) and not is_placeholder(path):
        raise ToolContractError(BOARD_FILE_PATH.format(path=json.dumps(path, ensure_ascii=False)))
    message = next(
        (
            item
            for key, item in value.items()
            if isinstance(key, str) and spelling(key) == "message"
        ),
        None,
    )
    reference = message.strip() if isinstance(message, str) else ""
    is_post = reference.startswith("pst_") or (
        reference.startswith("#") and post_number(reference) is not None
    )
    normalized = _normalize(
        contract,
        value,
        fields=_BOARD_FIELDS["message_id" if is_post else "text"],
        actions=_board_action,
        optional=("discussion_id", "message_id", "reply_to", "before", "cursor", "limit"),
        # A placeholder beside the real text, such as "message": "placeholder", asks for
        # nothing; two different texts are refused as conflicting values.
        placeholder_as_omitted=("text",),
    )
    if not isinstance(normalized, dict):
        return normalized
    if "recipients" in normalized:
        recipients = _recipient_list(normalized["recipients"])
        if recipients:
            normalized["recipients"] = recipients
        else:
            del normalized["recipients"]
    if "action" not in normalized:
        implied = _implied_board_action(normalized)
        if implied is not None:
            normalized["action"] = implied
    return normalized


def _board_action(action: Any) -> Any:
    if isinstance(action, str):
        # One extra closing quote cannot change a complete canonical action. Do not
        # strip punctuation generally: a suffix can contain other requested fields.
        if action.endswith('"') and action[:-1] in _BOARD_ACTION_VALUES:
            return action[:-1]
        merged = _MERGED_ACTION.match(action)
        if (
            merged
            and merged[1] in _BOARD_ACTION_VALUES
            and merged[2] in BOARD_PARAMETERS["properties"]
        ):
            # Diagnose the Provider's collapsed parameter markup without reconstructing
            # or executing the embedded target or message.
            raise ToolContractError(
                BOARD_ACTION_FIELDS_MERGED.format(action=json.dumps(merged[1]), field=merged[2])
            )
    return _action_normalizer(_BOARD_ACTIONS, _BOARD_ELSEWHERE, other_tool=BOARD_OTHER_TOOL)(action)


def normalize_wiki(contract: ToolContract, arguments: Any) -> Any:
    """Repair a swarm_wiki call and infer an action that its fields imply."""

    value = _prepare(arguments, contract.name)
    if not isinstance(value, dict):
        return value
    normalized = _normalize(
        contract,
        value,
        fields=_WIKI_FIELDS,
        actions=_action_normalizer(_WIKI_ACTIONS, {}),
        optional=(
            "page_id",
            "revision",
            "since_revision",
            "offset",
            "limit",
            "cursor",
            "include_deleted",
        ),
    )
    if not isinstance(normalized, dict):
        return normalized
    _refuse_field_as_action(normalized)
    expected = normalized.get("expected_revision")
    if is_placeholder(expected) or (
        isinstance(expected, str) and spelling(expected) in _REVISION_PLACEHOLDERS
    ):
        normalized.pop("expected_revision", None)
    if normalized.get("query") in (None, ""):
        normalized.pop("query", None)
    edits = normalized.get("edits")
    if isinstance(edits, list):
        normalized["edits"] = edits = [_wiki_edit(item) for item in edits]
        # A list of one edit is the call's own old_text and new_text.
        if (
            len(edits) == 1
            and isinstance(edits[0], dict)
            and edits[0].keys() == {"old_text", "new_text"}
            and not {"old_text", "new_text"} & normalized.keys()
        ):
            normalized.update(normalized.pop("edits")[0])
    if "action" not in normalized:
        implied = _implied_wiki_action(normalized)
        if implied is not None:
            normalized["action"] = implied
    return normalized


def normalize_inbox(contract: ToolContract, arguments: Any) -> Any:
    """Repair a swarm_inbox call; its only action is receive."""

    value = _prepare(arguments, contract.name)
    if not isinstance(value, dict):
        return value

    def action(item: Any) -> Any:
        if not isinstance(item, str) or is_placeholder(item):
            return item
        if spelling(item) in _INBOX_ACTIONS:
            return "receive"
        raise ToolContractError(INBOX_ONLY_RECEIVE.format(action=item))

    return _normalize(
        contract,
        value,
        fields=_INBOX_FIELDS,
        actions=action,
        optional=("limit",),
    )


def normalize_state(contract: ToolContract, arguments: Any) -> Any:
    """Repair a swarm_state call; every reading of its action is status."""

    value = _prepare(arguments, contract.name)
    if not isinstance(value, dict):
        return value

    def action(item: Any) -> Any:
        if not isinstance(item, str) or is_placeholder(item):
            return item
        if spelling(item) in _STATE_ACTIONS:
            return "status"
        raise ToolContractError(STATE_ONLY_STATUS.format(action=item))

    return _normalize(
        contract,
        value,
        fields=_STATE_FIELDS,
        actions=action,
        optional=("cursor", "limit"),
    )


def _prepare(arguments: Any, tool: str) -> Any:
    """Unwrap wrapper objects and drop derived keys and labels naming ``tool``.

    Some harnesses address the call with ``recipient_name`` or put the Tool's
    own name in ``action`` beside the wrapped arguments; both only repeat which
    Tool is called. Two different values for one field are refused, naming both.
    """

    if not isinstance(arguments, dict):
        return arguments
    value: Json = {}
    sent: dict[Any, str] = {}
    for key, path, item in _entries(arguments, spelling(tool)):
        if key in value and value[key] != item:
            raise ToolContractError(
                f"Conflicting values for {key}: {sent[key]} is {_shown(value[key])} and "
                f"{path} is {_shown(item)}. Send only the intended one."
            )
        value[key] = item
        sent.setdefault(key, path)
    return value


def _entries(arguments: Json, tool: str, prefix: str = "") -> Iterator[tuple[Any, str, Any]]:
    """Yield (key, key path as sent, value) for each argument inside wrapper objects."""

    for key, item in arguments.items():
        name = spelling(key) if isinstance(key, str) else key
        if name in _DERIVED:
            continue
        if name in _TOOL_LABELS and isinstance(item, str) and _names_tool(item, tool):
            continue
        path = f"{prefix}{key}"
        if name in _WRAPPERS and isinstance(item, dict):
            yield from _entries(item, tool, f"{path}.")
            continue
        yield key, path, item


def _names_tool(value: str, tool: str) -> bool:
    return spelling(value) in {tool, f"functions{tool}"}


def _shown(value: Any) -> str:
    text = json.dumps(value, ensure_ascii=False, default=str)
    return text if len(text) <= 40 else text[:37] + "..."


def _normalize(
    contract: ToolContract,
    value: Json,
    *,
    fields: Mapping[str, str],
    actions: Callable[[Any], Any],
    optional: tuple[str, ...],
    placeholder_as_omitted: tuple[str, ...] = (),
) -> Any:
    normalized = normalize_call_arguments(
        contract,
        value,
        enum_fields=("action",) if "action" in contract.input_schema["properties"] else (),
        field_aliases=fields,
        field_normalizers={"action": actions},
        placeholder_as_omitted=placeholder_as_omitted,
    )
    if not isinstance(normalized, dict):
        return normalized
    for field in optional:
        if field in normalized and is_placeholder(normalized[field]):
            del normalized[field]
    if "action" in normalized and is_placeholder(normalized["action"]):
        del normalized["action"]
    return normalized


def _action_normalizer(
    synonyms: Mapping[str, str], elsewhere: Mapping[str, str], *, other_tool: str | None = None
) -> Callable[[Any], Any]:
    def normalize(action: Any) -> Any:
        if not isinstance(action, str):
            return action
        if action in synonyms.values():
            return action
        if action in synonyms:
            return synonyms[action]
        target = elsewhere.get(spelling(action))
        if target is not None:
            raise ToolContractError(BOARD_FOREIGN_ACTIONS[target].format(action=action))
        if (
            other_tool is not None
            and _TOOL_NAME.fullmatch(action)
            and not is_placeholder(action)
            # Enum formatting accepts another spelling of an action, such as "LIST".
            and spelling(action) not in {spelling(value) for value in synonyms.values()}
        ):
            raise ToolContractError(other_tool.format(action=action))
        return action

    return normalize


def _wiki_edit(item: Any) -> Any:
    """Name the fields of one of an update's edits as swarm_wiki does."""

    if not isinstance(item, dict):
        return item
    named: Json = {}
    for key, value in item.items():
        canonical = _WIKI_FIELDS.get(key) or _WIKI_EDIT_FIELDS.get(spelling(key), "")
        field = canonical if canonical in _WIKI_EDIT_FIELDS.values() else str(key)
        if field in named:
            return item  # Two spellings of one field; the handler names both.
        named[field] = value
    return named


def _recipient_list(value: Any) -> Any:
    """Return recipients as a list of meaningful strings, splitting listed strings.

    Participant IDs and names contain no commas or semicolons, so either one
    separates recipients, also inside a list item such as ``["Ada, Bob"]``.
    """

    if is_placeholder(value):
        return []
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list):
        return value
    items: list[Any] = []
    for item in value:
        parts = item.replace(";", ",").split(",") if isinstance(item, str) else [item]
        items.extend(part.strip() if isinstance(part, str) else part for part in parts)
    return [item for item in items if not is_placeholder(item)]


def _implied_board_action(arguments: Json) -> str | None:
    if "title" in arguments:
        return "create"
    if {"text", "reply_to", "recipients"} & arguments.keys():
        return "post"
    if {"message_id", "before"} & arguments.keys():
        return "read"
    return None


def _refuse_field_as_action(arguments: Json) -> None:
    """Refuse a swarm_wiki call whose action names one of its fields, as "content" does.

    The call is not run: the fields may fit another action than the one meant.
    The error names the action the other fields imply, or the valid actions.
    """

    action = arguments.get("action")
    if not isinstance(action, str) or action in WIKI_ACTIONS:
        return
    field = _WIKI_FIELD_NAMES.get(spelling(action))
    if field is None:
        return
    implied = _implied_wiki_action({key: arguments[key] for key in arguments if key != "action"})
    if implied is not None:
        raise ToolContractError(WIKI_ACTION_IS_FIELD["implied"].format(field=field, action=implied))
    raise ToolContractError(
        WIKI_ACTION_IS_FIELD["unknown"].format(field=field, actions=", ".join(WIKI_ACTIONS))
    )


def _implied_wiki_action(arguments: Json) -> str | None:
    if {"old_text", "new_text", "edits"} & arguments.keys():
        return "update"
    if "page_id" in arguments and ("content" in arguments or "title" in arguments):
        return "update"
    if "content" in arguments and "title" in arguments:
        return "create"
    if "page_id" in arguments and not {"expected_revision"} & arguments.keys():
        return "read"
    if "query" in arguments:
        return "list"
    return None


__all__ = ["normalize_board", "normalize_inbox", "normalize_state", "normalize_wiki"]
